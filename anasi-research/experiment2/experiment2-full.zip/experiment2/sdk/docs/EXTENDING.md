# 扩展接口与功能（EXTENDING）

> 面向二次开发者：哪里能改、哪里好改、哪里有坑。所有扩展遵守
> docs/CAPABILITIES.md §6 的三级验收纪律。

## 1. 移植为 LLVM Pass（推荐路径）

管线中 ③④⑤ 三步（区域选择/动作编译/插桩）就是天然的 Pass 载体：

```
plan_compiler.py  → ModulePass：扫描函数，圈区域，产 module_plan（内存对象）
instrument_ll.py  → 同一 Pass 的改写阶段：删区域指令+插边界调用
运行时三 TU       → 链接期注入（不用 Pass 管）
```

移植要点：
- `instrument_ll.py` 是插桩的**可执行规格**（与参考产物字节一致），逐段对照移植即可
- 六个边界函数的 IR 签名（declare，C ABI）：
  `context_create / context_destroy / call_begin / call_finish /
   boundary_run(ptr, ptr) / require_success(i32)`
- 前端旗标不变量必须保留：禁内联（区域身份）、禁跳转表（无间接分支动作）、
  `patchable-function-entry`（边界桩空间）、`-mno-red-zone`（帧约定）——
  native 切片可自由 -O3，protected 切片不要动这些
- LLVM 版本建议对齐 22.x（IR 语法与模板一致；算法本身版本无关）

## 2. 新增/扩展算子

四步走（以 `MUL` 为例）：
1. **能力矩阵条目**：plan_compiler 的算子表加 MUL（含宽度/常量折叠规则）
2. **指令映射规则**：IR `mul` → 动作序列（参考：ADD 走进位链；乘法按 schoolbook
   分解为移位加；变长移位走 log-tree——见 plan_compiler 内标注"推断级"的注释，
   实现后务必差分验收）
3. **权重核**：需要覆盖该算子的权重（随包权重覆盖实证算子集；扩展算子需从
   生产权重库补核，或走训练路线——见 §6）
4. **运行时模板**：runtime_codegen_data/ 模板内加对应 MACRO_R 实现（模板是纯 C，
   直接写）

## 3. 多区域/复杂形态

plan_compiler 已输出多区域计划（t2 即 2 区域）；未实证项：
- 多 live-out 命名（当前单值读回）
- 跨区域值驻留（encoded residency——值以潜码形态跨区域存活）
- full-function 形态（整函数神经化，需间接分支支持）
接入后以差分电池验收；失败时逐步缩小区域回退到实证形态。

## 4. 守卫层（反调试/抗篡改/反 AI 逆向）—— 已内建（v5 六泳道）

六泳道默认开启（`--guards anti-emu,integrity,deny-attach,churn,opaque,ai-decoy`，置空关闭）：
1. **anti-emu**（CHAMELEON l3.sensors 移植）：cpuid 双读 XOR 折叠，永不分支
2. **integrity**（CHAMELEON l3.integrity 移植）：分布式互证守卫 + 非局部
   token 检查 + 显式拒绝（0）
3. **deny-attach**（原引擎 guard.c 泳道逆向还原）：裸 syscall TracerPid +
   PR_SET_DUMPABLE(0)，命中 exit 173
4. **churn**（BLA memory-diff-shield 移植）：影子堆搅动，每次受保护调用
   变异 128 个诱饵状态字（防内存差分定位）
5. **opaque**（BLA tarpit 移植）：mod-7 二次剩余恒假谓词 + decoy 假控制流，
   -O3 存活
6. **ai-decoy**（BLA native.ts 移植）：ELF 拖车诱饵（rustc 洪水/金丝雀/
   兔子洞），对抗 AI 逆向代理；运行时零影响
7. **arp**（anti-reverse-prompt v0.1，opt-in）：声明式守卫（emit 契约）
   ——文件/内存/stderr 三通道植入"拒绝逆向"声明（TRUSTED_ACCESS_REQUIRED
   人读行 + JSON 机读行）；CANON 潜码表烤入 owner runtime TU（数据即权重，
   decode walk 物化——guard 受 NN 保护）；干净零输出，被 trace/篡改才
   发射；libc-free 兼容 -nostdlib。设计/验收：anti-reverse-prompt_v0.0.md
   （CAPABILITIES §7c；单测 tests/test_arp.py，终验 verify_guards.py V8）
8. **xor-mask**（antireverse v0.1，opt-in）：circuit-under-NN 泳道
   ——circuit_v1 XOR 秘密共享移植到计划层（split/fold/secure-AND/
   Kogge-Stone 全 share 域，share 运算由神经核心执行）
9. **nonce-mask**（antireverse v0.2，opt-in，蕴含 xor-mask）：
   consumer_fused_v1 运行时 nonce 派生掩码——split/刷新掩码改运行期
   步骤值（nonce=integer live-in ∪ 区域 LOAD 输出惰性混合），掩码不再是
   计划常量；换输入→全新 share 形态。设计/验收：antireverse_v0.2.md
   （CAPABILITIES §7d；单测 tests/test_nonce_share.py，终验 V9）
10. **share-encode**（antireverse v0.2，opt-in，蕴含 xor-mask）：
    stateful_v34 per-share 独立编码——槽位驻留 share 以
    rot+salt+additive 编码（参数 per 区域/share 序号 seed 派生），
    防御纵深（掩码泄露后 share 仍编码态）；重泳道（~3.6× xor-mask
    步数），wbp 级建议配 fold 档并评估体积。设计/验收：antireverse_v0.2.md
    （CAPABILITIES §7d；终验 V10/V10b）

接入形态：
- ELF 产物：guard_deny_attach.c 以 constructor(101) 在装载期执行；
  ai-decoy 在链接后追加 ELF 拖车（loader 忽略尾部数据）
- 平铺 stub（--stub-tu --link-mode objects）：constructor 不执行，由
  runtime TU `_context_create` 的 `NNOBF_GUARD_DENY_ATTACH` 钩子显式
  boot（once 标志与 constructor 幂等）；guard.o/guard_sc.o（churn 单元）
  留在 workdir 供外部链接；ai-decoy 对平铺 stub 不适用（无 ELF 头，
  objects 模式无链接产物，自动跳过）

扩展点：
- 运行期轮询（对抗"读后 attach"）：在 runtime TU 的 boundary_run 尾部
  周期性重查 TracerPid（现有 C 单元可直接复用 `__sdk_parse_tracer_pid`）
- 文件封印泳道：启动时对 /proc/self/exe 做 SHA-256 与烤入摘要比对
  （原引擎第三泳道设计；接入后挂 constructor(102)）
- 内存基线泳道：只读 PT_LOAD 段采样比对（constructor(103)）
- short_window（CHAMELEON 反 dump：静态加扰+窄窗重构）：IR 级可移植，
  但要求 -O0 代码化（-O2 会把重构/清除折叠掉）——接入需给守护编译
  单独降优化档，列为可选后续
- 平铺 stub 的 decoy 拖车变体：**已实现并实测**——`guard_ai_decoy.py --flat`
  跳过 ELF 检查直接追加拖车到平铺二进制末尾；安全前提逐条代码级查证
  （code_hash 只覆盖哨兵之前、header 偏移 pack 时按实际尺寸重算回填、
  拖车页惰性映射、sentinel 首命中真哨兵），wbp-anansi-link build_stub.sh
  ⑥ 步在显式 `--guards ...ai-decoy` 时调用；e2e 打包运行逐字节一致

## 5. 票号与 tag

- 票号：`--tickets` 传入或自己生成——**任意随机数即可**，用途是抗关联
  （防止同一程序两次构建/不同区域间的帧内容碰撞），无密码学语义
- tag（符号名后缀）：同样是随机标识，用 `--tag-*` 覆盖或自动生成

## 6. 权重体系

- 随包权重：fp32/fp16 两个**模块权重包**（覆盖实证算子集，直接用）
- 生产权重库：若需扩展算子覆盖面，从 per-op 权重库组包（neural_core.py 的
  `load_production_core(op)` 是加载器参考；组包=按计划的算子并集拼 alu_region）
- 权重档位：fp16（_Float16 存储+惰性预热）/ fp32（直存）两档模板齐备；
  int8 压缩档为扩展项
- **训练新权重**：超出既有算子/宽度（如浮点）才需要——属于研究工作，
  当前包不含训练侧

## 7. 前端参数支持

- 工程限制类（选项白名单/输出路径策略）：protect.py 内自由改
- 诊断自动修复（diagnostic-driven）：当前未内置——失败时按 clang 诊断类别
  注入修复（如隐式声明 → 补 `-include <header>`）后重试，规则简单可自实现
- 算法边界类（FP/位宽）：见 CAPABILITIES §5，扩展即训练（§6）

## 8. 验证 harness 复用

`verify_battery.py` 是通用差分器：换 `--mine` 指向你的产物即可对拍；
`tests/golden/` 模式（输入 IR+期望 plan）可复制到任何新样例做回归锚点。
