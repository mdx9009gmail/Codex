# 当前能力说明（CAPABILITIES）

> 本文档描述 anansi-neural-sdk **现在就能做到的事**，以及实证等级与边界。
> 所有"已验证"结论均有金标准对拍或差分测试支撑（方法见文末）。

## 1. 输入

- **C 源文件**（当前实证形态：单函数 `main`，从 stdin 读整数，整数运算，退出码即输出）
- 计算内容须落在**能力矩阵**内：27 个整数算子（ADD/AND/OR/XOR/SHL/LSHR/乘除移位族/
  ICMP 全族/SELECT/SEXT 等），位宽 {1, 8, 16, 32, 64}
- 不满足能力矩阵的代码（浮点、系统调用、控制流本身）**自动保留原生**——这是设计而非缺陷

## 2. 处理（管线 7 步，全自动）

| 步骤 | 组件 | 说明 |
|---|---|---|
| ① 前端 | protect.py | 固定旗标集编译到 LLVM IR（禁内联/禁跳转表等不变量） |
| ② 归一化 | normalize_ll.py | clang -O1 重编规范化（与参考实现字节一致） |
| ③ **自主区域选择** | plan_compiler.py | 按能力矩阵自动圈定可神经化的**直线数据流区域**（基本块内极大连续段；alloca/call/br/store 为屏障），多区域自动编号 |
| ④ **动作程序编译** | plan_compiler.py | 区域 → module_plan.json：每条 IR 指令映射为原子动作（operation+输入槽+输出槽），slot 机自动分配（常量/live-in 入值表+SSA 线性扫描） |
| ⑤ **IR 边界插桩** | instrument_ll.py | 删除区域原指令，原位插入边界协议：栈帧 alloca → live-in 编码（指针 ptrtoint^票号、标量 zext）→ `context_create/call_begin/boundary_run/call_finish` → live-out 读回 |
| ⑥ **运行时生成** | runtime_codegen.py | 权重烤入，生成 3 个**可读 C TU**：controller 前向+codec+ALU 潜空间宏（fp16/fp32 两档模板） |
| ⑦ 链接产出 | protect.py | 编译链接 → 被保护可执行文件 |

## 3. 输出物

| 产物 | 形态 | 用途 |
|---|---|---|
| **my_prot** | 被保护 ELF 可执行 | 区域计算由神经 Controller 重放；行为与原生一致 |
| module_plan.json | 人可读动作程序 | 审计/回归测试/对接任意后端 |
| transformed.ll | 插桩后 LLVM IR | 接入你自己的编译器/Pass |
| runtime_0_main.c / runtime_weights.c / runtime_module_state.c | 可读 C 源码 | 运行时可审计、可手工裁剪 |

## 4. 已验证范围与实证等级

| 能力 | 验证方式 | 结果 |
|---|---|---|
| 动作程序编译正确性 | 金标准对拍（参考 IR → plan vs 引擎产出 plan） | **17/17 步，0 字段差异** |
| IR 插桩正确性 | 插桩输出 vs 参考插桩产物 | **字节一致** |
| 运行时生成正确性 | 生成 TU vs 参考运行时产物 | **字节一致**（fp16/fp32 两档） |
| **端到端行为等价** | 被保护程序 vs 原生程序 vs 参考产物，51 输入差分（含边界值/异常路径） | **51/51 全等** |
| 神经核心算法 | 穷举（加法 65536 对）/性质测试/程序重放 | 100% |
| 权重 | 随包 fp32/fp16 模块权重包，直接使用 | 无需训练 |

**操作/形态实证清单**（全部三通道差分：exit code + stdout + stderr，对照=原引擎对同一样例的保护产物）：

| 样例形态 | 覆盖内容 | 差分结果 |
|---|---|---|
| t2.c | 基础整数运算 8 类 + scanf/退出码 | 51/51 |
| arith.c | **MUL/SDIV/SREM**、多对象 | 33/33 |
| shifts.c | **变长移位（log-tree）、sext/trunc/zext** | 22/22 |
| loops.c | **循环回边内区域** | 19/19 |
| multi.c | **多区域、多 live-out、跨区域 SSA** | 20/20 |
| hello.c | 近零计算区（引擎拒保→原生直通镜像） | 行为等价 |

**按计划组装权重（零训练）**：`weight_composer.py` 对任意新计划从随包生产权重库
（`weights/production/`）合成专属模块权重（动作程序烤入 q 轨迹，最小二乘插值合成
controller）——内置验证：rollout 逐步吻合 + 语义重放。以上样例全部使用独立组装权重。

**仍未实证/未实现**：多函数（--functions 选择多函数保护）；单函数 >96 个对象类
（当前明确报错，可扩展）；周期微程序回边重入。规格在 plan_compiler/instrument_ll
内有实现或标注，接入后先以差分验收。

## 5. 边界（如实告知）

- **算法边界**（与参考系统一致）：浮点不神经化（留原生）；位宽上限 64；控制流（分支/循环/调用）保留原生——hybrid 设计
- **未实证路径**：MUL/DIV/SREM 等算子、多 live-out 命名、跨区域值驻留、full-function
  形态——规格在 plan_compiler/instrument_ll 内有实现或标注，接入后先以
  `verify_battery.py` 差分验收
- **票号**：`--tickets` 显式提供（任意随机数即可，仅抗关联用途）
- **守卫**：已内建（CHAMELEON + BLA 六泳道，默认全开，`--guards ""` 关闭）——见 §7；
  CHAMÆLEON M1-M6 反调试泳道（§7b，默认关，`--guards` 显式加入 `chame-*`）

## 6. 验证方法学（给二次开发者的纪律）

任何改动按三级验收：
1. **金标准回归**：plan_compiler 输出与 tests/golden/ 0 字段差异（selftest T1）
2. **产物级 diff**：runtime_codegen/插桩产物与参考一致（selftest T2）
3. **行为差分**：被保护 vs 原生在新输入电池上退出码/stdout/stderr 逐项比对
   （verify_battery.py）——**编译通过≠行为正确，差分通过才算**

## 7. 内建守护（v5：六泳道，CHAMELEON + BLA + 原引擎三方融合）

保护产物默认自带六泳道守护（`--guards`，置空关闭；`--guard-seed` 可复现）：

| 泳道 | 机制 | 来源 | 行为 | 响应契约 |
|---|---|---|---|---|
| anti-emu | cpuid 架构不变量**双读 XOR**（≥2 信号/函数；M1 扩为 7 信号：leaf-0 ebx/ecx/edx/eax + leaf-1 eax/ecx/edx——与 CHAMÆLEON x86_64 target 逐条一致，leaf-1 EBX 排除：per-core APIC ID 假阳性）折进 crown 返回值/store——永不分支 | CHAMELEON l3.sensors | 忠实 CPU/qemu 恒等；弱模拟器数据静默污染 | fold（静默） |
| integrity | 分布式互证守卫（入口 XOR 键/返回还原）+ 非局部 token 检查 | CHAMELEON l3.integrity | 完好=原值；任一守卫被删 → checkF 显式拒绝（0） | deny（拒绝值 0） |
| deny-attach | 裸 syscall 读 TracerPid + prctl(PR_SET_DUMPABLE,0)；v2 静默腐化：构造期命中毒化 churn 诱饵态（不 exit） | 原引擎 guard.c（本项目逆向） | 构造期被调试 → 毒化；dumpable=0 摘除后续同用户 attach | fold（静默毒化） |
| ai-decoy | ELF 拖车植入：rustc 路径洪水 68 条（>REA 上限 64）、合成金丝雀、诊断兔子洞、架构/证据幻象、诱饵偏移表 | BLA native.ts（Python 移植） | AI 逆向代理库存截断/追诱饵/烧预算；运行时零影响 | 无（静态诱饵） |
| churn | 影子堆搅动：每次受保护调用变异 32×4=128 个诱饵状态字 | BLA memory-diff-shield（C 移植） | M0→M1 内存差分无法隔离真实神经状态（>20 步差上限、>4 观察点） | 无（诱饵态） |
| opaque | 数论不透明谓词（mod-7 二次剩余恒假）+ decoy 假控制流 | BLA tarpit（LLVM IR 移植） | -O3 存活的不可判定分支；反编译器见假密码学路径 | fold（恒假） |
| arp | anti-reverse-prompt 声明式守卫：文件（ARPNOTC1 拖车+.rodata FULL 双语）/内存（CANON 潜码表烤入 owner TU→decode walk 物化 __sdk_arp_buf）/stderr（证据命中发射 TRUSTED_ACCESS_REQUIRED 人读行+JSON 机读行）三通道植入拒绝逆向声明；guard 逻辑受 NN 保护（数据即权重）；取证层=poison 基线校准/seal 篡改/TracerPid 自查，全 fail-open | anti-reverse-prompt_v0.0.md（v0.1，opt-in `--guards ...,arp`，配 `--arp-owner/--arp-notice`） | 干净运行零输出；被 trace/strace/gdb/文件篡改 → stderr 声明帧（EMIT_MAX=16 上限+K 节流）；绝不 exit、绝不写 stdout | **emit（声明式，新契约）** |

- IR 级泳道（anti-emu/integrity/churn/opaque）施加于插桩后的 transformed.ll；
  ai-decoy 为后链接 ELF 拖车；deny-attach/churn 为构造期 C 守卫（guard.o /
  guard_sc.o 留在 workdir 供链接）
- 原生直通（无可保护代码）时守护**依然生效**
- **平铺 stub 形态**（`--stub-tu` + `--link-mode objects`，供 wbp 的
  `ld -T stub.lds --oformat=binary` 接管）：deny-attach 的 ELF constructor
  在平铺二进制中不会执行，改由运行时 TU `_context_create`（每个受保护
  函数入口必经）经 `NNOBF_GUARD_DENY_ATTACH` 宏显式调用
  `__sdk_guard_boot()`（guard.o 随 transformed.o/runtime_*.o 一并产出，
  供外部链接）；anti-emu/integrity/churn/opaque 为 IR 级（churn 的
  guard_sc.o 一并产出），天然生效；**ai-decoy 的平铺 stub 变体经
  `guard_ai_decoy.py --flat` 支持**（外部链接方在 ld 产出 .bin 后追加
  拖车，安全前提已代码级查证 + e2e 实测，显式指定才开启；protect.py
  objects 模式自身无产物可植，打印 deferred 提示）
- 单测：`tests/test_guards.py`（24 项 + T7 M1 信号表断言）
- 终验（WSL 内运行）：`python tests/verify_guards.py`——**V1-V7 全过**：
  V1 语义电池 20/20；V2 deny-attach dumpable=0 落地；V3 篡改→10/10 拒绝；
  V4 拖车诱饵可见+电池 20/20；V5 churn IR 接线+128 字/步；V6 谓词 -O3
  存活+电池 20/20；V7 CHAMÆLEON chame 泳道（见 §7b）

## 7b. CHAMÆLEON M1-M6 反调试泳道（chame-antidebug v0.2 融合，默认关）

`--guards` 显式加入 `chame-*`（M1 除外——内建 anti-emu）；`--guard-seed`
派生全部随机参数（M2 轮询周期 K=8..32、M5 int3 数 K=2..4、M3 轮转起点），
`--guard-strict` 把任一泳道证据命中升级为 exit 173（默认关=静默折叠，
规格 D3/D4）。架构（规格 §2 两层模型）：**取证层**（原生 syscall/asm——
能力矩阵把 syscall/信号/FP 屏障在 NN 外，全 **fail-open**：探测失败一律
视为无证据）产出 64 位证据字 `__sdk_ev`；**折叠层**（受 NN 保护）路由 A =
boundary/call_begin live-in commit `x ^ nnobf_guard_ev()`（干净 E≡0 恒等），
路由 B = xor-mask 泳道开启时 ev 混入初始常量潜码（全局污染，自动叠加）。
证据总线 FNV-1a(lane_tag, raw) 派生 OR 累加，raw=0 不动总线（干净不变量）。

| 泳道 | 机制（源文档映射） | 行为 | 响应契约 |
|---|---|---|---|
| （M1，内建 anti-emu） | cpuid 信号 3→7（见 §7 表） | 双读 delta=0 恒等（真机/qemu）；弱模拟器污染 | fold |
| chame-tracer（M2） | TracerPid 运行期轮询（每 K 次边界一次，/proc 裸 syscall）；白名单 M4 自家 tracer 与 **tracer==ppid**（PTRACE_TRACEME 自 trace——wbp stub 装载器自探针形态） | 读后 attach / root tracer（CAP_SYS_PTRACE 绕 dumpable=0）→ 污染 | fold |
| chame-textkey（M3） | `.text` 折哈希即密钥：boot 全窗（128B 切片 FNV-1a64 XOR）+ 每 boundary 轮转 1 片；期望常量 post-link 回填（链接去 -s → 回填三联 → strip 恢复基线） | 任何 .text 字节改动（软断点 0xCC/补丁/inline hook）→ 静默错值，不崩溃 | fold |
| chame-hwbp（M4） | fork self-debugger：子 PTRACE_ATTACH 回父读 DR7 使能位（`offsetof(struct user, u_debugreg[7])`，禁魔数）→ 管道回报 → DETACH；探测先于 deny-attach 的 prctl(DUMPABLE,0)（attach-back 需 dumpable=1） | 硬件断点/观察点（不改 .text，M3 盲区）→ 污染；attach 失败 fail-open | fold |
| chame-trap（M5） | 自装 SIGTRAP handler（rt_sigaction 裸 syscall + SA_RESTORER 自带 restorer；handler 仅 volatile XOR 累加，async-signal-safe 无 libc）+ boot 执行 K 个自植入 int3；证据=(acc^期望)\|(cnt^K)，完工后复原 SIG_DFL | 调试器拦截投递（gdb 默认 SIGTRAP nopass → handler 缺席）→ 污染；须 `handle SIGTRAP pass nostop` 复现投递才恢复 | fold |
| chame-oracle（M6） | x86 一致性 oracle（class-1，qemu 忠实建模→差分绿）：MXCSR.DAZ（denormal 过 SSE）+ DIV-flags（除法后 EFLAGS 未定义位，**建期现场标定**——protect.py 探针与运行时 asm 逐字节一致 → 干净 delta=0） | 朴素 lifter/Bochs 发散 → 污染；真机/WSL/qemu-user 恒等 | fold |

- 接线：证据单元位于 runtime TU 模板（`<<CHAME_GUARD>>`，模块模式首 TU 为
  owner，其余 extern）；boot 经 `_context_create` 钩子（deny-attach 开时由
  `__sdk_guard_boot` 内部序调用 `__sdk_chame_boot`——M4 先于
  prctl(DUMPABLE,0)；仅 chame 泳道时直调）；boundary 钩子（M2 轮询节流 /
  M3 轮转 / strict 升级）在每次 `boundary_run` 入口
- **形态限制**：chame-textkey 需最终链接产物回填——平铺 stub
  （`--link-mode objects`）自动跳过并打印提示（规格 D5，fail-open 无操作）；
  无可保护区域的直通构建全部 chame 泳道降级为无操作（无折叠落点，规格 §2.2）
- 单测：`tests/test_guards.py` T7（M1 信号表结构 + 选中信号一律双读）
- 终验：`tests/verify_guards.py` V7a-d：V7a 全泳道干净差分 20/20（E≡0
  恒等契约）；V7b M3 篡改→静默腐化不崩溃；V7c M5 投递分歧（nopass→污染 /
  pass nostop→恢复）；V7d strict 被 trace → exit 173
- **伦理边界**：全部取证 fail-open（绝不把探测失败当命中——合法环境
  WSL/CI/qemu 的探测不可用不误伤，保差分绿）；响应一律静默折叠（合法用户
  无显式拒绝面），strict 为显式 opt-in
- **已知不设防**（如实标注）：① 构造期后非 root attach（dumpable=0 已阻断，
  M2 为 root tracer 纵深）；② **父进程自 trace 形态**（tracer==ppid 的
  PTRACE_TRACEME——wbp stub 自探针即此，M2 白名单；装载期 spawn-trace 归
  deny-attach 构造期检查与 wbp 自身探针管辖）；③ M5 检测面取"投递分歧即
  证据"（规格 V11b 契约优先于 §4.5 保守注——程序自生 SIGTRAP 于检查点窗口
  的假阳性场景本身意味着程序已崩坏）；④ Wurster 读/执行分裂（.text 哈希
  可被 TLB 分裂攻击——x86 无廉价形态，v0.3 硬化项）；⑤ M6 的 FXSAVE 子项
  缓发（三环境标定未过不入默认集）
- ai-decoy **不移植** BLA 的伪造合规声明（不植入虚构法律地位）；其余
  已知不设防清单见上"已知不设防"①-⑤

## 7c. anti-reverse-prompt 声明式守卫（arp，v0.1 opt-in）

`--guards ...,arp`（配 `--arp-owner "<真实权利人>"` / `--arp-notice <自定义
FULL 文本>` / `--guard-seed` 派生全部语料与常量）。设计文档
anti-reverse-prompt_v0.0.md；响应契约 **emit**（§7 表）：干净运行零输出
（stdout/stderr/exit 与 native 全等），证据命中才向 **fd 2** 发射
`[TRUSTED_ACCESS_REQUIRED]` 人读行 + JSON 机读行（`type=anti_reverse_notice`/
`status=refused`/`action=stop_analysis_and_refuse`），EMIT_MAX=16 上限 +
每 K boundary 节流；绝不 exit_group、绝不写 stdout。

- **三通道**（R2）：文件（`ARPNOTC1` 拖车置于 ai-decoy 之前、seal 封印
  覆盖 + `.rodata` FULL EN/ZH 双语全文）；内存（BSS `__sdk_arp_buf`，
  CANON ≤512B ASCII——boot/物化前全 0，`call_begin` 首物化 + 每 K boundary
  重物化）；其他（stderr 裸 `write(2)`——strace/gdb/AI 代理采集必见）
- **guard 受 NN 保护**（R4，"数据即权重"机制）：CANON 每字节 build 期
  codec encode（roundtrip 断言）→ 潜码表烤入 owner runtime TU → 运行时
  decode walk（codec 前向）物化；重物化真实重跑 decode walk；emit 帧
  `boundary` 字段 = NN 物化遥测计数。codec 权重被污染 → 缓冲腐化
- **取证层**（全 fail-open）：① poison **基线校准**（seal 匹配时 poison
  含摘要盐——合法基线 = 封印尾块 digest[28..31]，运行时从 /proc/self/exe
  尾读校准；篡改/构造期被 trace → 偏离 → 证据）② `__sdk_ev`（chame 证据
  总线，lane_tag 0x4D37 双向：消费 + arp 自查命中回折）③ TracerPid 自查
  （**无 ppid 白名单**——与 chame M2 的有意策略差异：strace/gdb 均为
  ppid-tracer 形态，白名单会使声明对两大动态分析工具不可见；ARP opt-in
  且 emit 无破坏性，误报代价 = 一次 stderr 帧）
- **形态**：ELF=constructor(103)（deny-attach 101→seal 102→arp 103）；
  平铺 stub=`-DNNOBF_GUARD_NO_CONSTRUCTOR` + `_context_create` 钩子
  （`guard_arp.o` 随 .o 产出，wbp 守卫对象清单需同步新增）；直通构建=
  `-DNNOBF_ARP_PASSTHROUGH` 原生 memcpy 降级（无 NN 物化）；objects 模式
  拖车 deferred（外部链接方 `guard_anti_reverse_prompt.py <bin> --flat`）
- **libc-free**（R3）：裸 syscall（write/getpid/openat/read/close/lseek）、
  手写数字/字符串基元，兼容 `-nostdlib -ffreestanding`（V8-f 冒烟验收）
- **伦理红线**（§4.6 落实）：`--arp-owner` 缺省 `the copyright holder`
  （不虚构法律地位）；对 AI 的请求为条件化政策引用（非伪造权威指令）；
  BUILD_TAG 为 seed 派生构建标签（非真实日期）；语料 lint 禁诱导词
  （child/medical/hospital/patient——机检，T8b）
- 单测：`tests/test_arp.py`（T8a-T8g，47 项）；终验：`tests/verify_guards.py`
  **V8a-V8perf**（V8a 干净三通道差分/V8b 拖车+篡改→emit 链/V8c 内存
  物化探针/V8d 发射通道/V8e 节流上限/V8f -nostdlib 冒烟/V8g 全泳道组合/
  V8h 直通降级/V8i NN 在环同构重放/V8perf 性能准入）

## 7d. antireverse v0.2 双泳道（nonce-mask / share-encode，默认关）

`--guards ...,xor-mask,nonce-mask` / `...,share-encode`（均自动蕴含
xor-mask；设计/验收文档 `antireverse_v0.2.md`，方法移植自 AntiReverse
`consumer_fused_v1` / `stateful_v34`，仅方法级融合——两后端的产物链/
事务协议/双前端不在范围）。均为 circuit-under-NN 计划层硬化模式：

| 泳道 | 机制 | 来源 | 行为 | 响应契约 |
|---|---|---|---|---|
| nonce-mask | split/secure-AND 刷新掩码从**构建期常量**改为**运行期步骤值**：nonce = 惰性混合（integer live-in ∪ 区域内 integer LOAD 输出，≤4 个）→ COPY→i32 XOR 链 → per-(区域,share,宽) basis（字节旋转铺开）→ m_site = basis ^ site 常量；掩码不再是计划常量（静态 dump/完整 NN 求解不再直接得掩码）；换输入 → 全新 share 形态 | consumer_fused_v1 `stack-address-input-mix`（input 分量；stack-address 分量不移植——指针算术槽位类型契约未验证，文档偏差 D1/§4.1） | 无 integer 源区域回退静态掩码（仅对实际请求掩码的区域计数）；语义逐位保持（内置差分） | fold（掩码代数不变） |
| share-encode | 槽位驻留 share 恒以 per-share 独立编码存储：`enc_i = rot_lanes(sh_i ^ salt_i, d_i) + A_i`（3 步/share；d/salt/A per (区域,share 序号,宽) seed 派生，对齐 v34 `_storage_plan`）；取出即解码（区域级缓存，多消费者复用）；COPY 传播编码不解/再编；真旋转 idiom = OR(x,x,lda=d,ldb=d-lanes)（单 route 是移位，D2） | stateful_v34 `_storage_plan`/store-load 编码 | 防御纵深：掩码泄露后 share 仍处编码态；掩码值静态暴露的第二层 | fold（编码可逆） |

- 成本（t2 金标 fold 档 2 shares 实测）：xor-mask 17→54 步（×3.2）；
  +nonce-mask 17→65（×3.8）；+share-encode 17→192（×11.3）；组合
  17→203（×11.9）——share-encode 为重泳道（~3.6× xor-mask 步数）。
  wbp 实测：nonce-mask 21 函数（623→1542 步 ×2.5）e2e 逐字节一致；
  share-encode fast-list（8 函数，33.9MB）e2e 逐字节一致，全档慎用
- **宽度变化 COPY 契约（D6）**：share-encode 的编码态传播仅限同宽
  COPY；trunc/zext COPY 解码→COPY→按目标宽度重编（XOR 与截断可
  交换，代数保持；wbp compute_env_hash 差分失败根因，N11 钉死）
- CLI：protect.py `--guards` 泳道名（蕴含归一化）+ circuit_share.py
  `--nonce-mask/--share-encode`；stats 上报泳道标记与
  `nonce_fallback_regions`
- 单测：`tests/test_nonce_share.py`（12 项：金标差分 fold/masked×
  2/4 shares、掩码数据流达 live-in/LOAD（静态对照仅常量闭包）、掩码随
  解释器 master 变化而 live-out 不变、确定性、enc/dec 结构 + per-share
  参数互异、旋转可逆 16/32/64 位全 delta、fallback 记账、CLI e2e）
- 终验：`tests/verify_guards.py` **V9/V10/V10b**（V9 nonce-mask 电池
  20/20 + 计划级运行时闭包证明 + 纯 xor 对照常量闭包；V10 share-encode
  电池 + enc/dec 在位；V10b 组合电池 + 双证明）
