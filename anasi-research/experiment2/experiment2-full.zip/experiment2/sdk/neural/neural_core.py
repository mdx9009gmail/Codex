#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ANANSI 保护引擎神经核心 —— 可读 / 可运行 / 可验证 Python 参考实现。

================================================================================
算法全景（一段话）
================================================================================
ANANSI 把被保护函数的 LLVM 整数指令降级为一条「Controller 动作流」。数值本身
不再以原生整数存在，而是每个字节经神经 codec 编码成 32 维 float 潜码
（word_t = 4 lane × 32 维）。三层结构：

  ① codec（边界编解码器）
     encode: byte --8bit LSB 展开--> dense(8→128,relu) → dense(128→128,relu)
             → dense(128→32)  得 32 维潜码 E(byte)；
     decode: dense(32→128,relu) → dense(128→128,relu) → dense(128→8 logits)，
             逐位 logits[i] >= 0 置位（符号阈值，非 argmax）。
     内部另有 3 个「内部格式」E_1..E_3 = E_x·P_i（正交符号置换），ALU 把 P_i
     折叠进有效权重，使执行器无需解码（"Fold E_i(v)=E_x(v)P_i into the
     effective ALU weights"）。

  ② Controller（每步产出一个动作）
     input[96] = q[64] ‖ condition[32] → dense(96→64) → tanh（单塔
     single-tower-v1）→ 低秩 selector 头（64→8→61，rank 8）+ 直连头
     （64→128）= 189 维 heads；heads argmax 查离散表解出 read_a/b/c、write、
     宽度/偏移/对象等数据搬运字段；heads[61:125]=option(64) 经 option
     conditioner（64→8→34）解出 route[16](±1)/format/effect；
     heads[125:189]=q_next，符号量化到 ±4 回馈（q[0] 是 token 消费门）。

  ③ ALU（全部整数运算在潜空间完成）
     静态宏路径（StableTool 字节核）：full_byte(96→320→320→64+refiner) 实现
     逐 lane 纹波进位加/减法；binary_byte(64→…) 实现 AND/OR/XOR；
     select_byte(96→…) 实现 SELECT；word 级宏 = 字节核的纹波/循环组合。
     部署路径（本程序实际启用）：option 条件的统一共享 ALU —— route[16] 经
     6×16 选择矩阵 argmax|·| 选中 6 个基底 core 之一（XOR/OR/SUB/SHL/AND/
     SELECT，权重与 production npz 逐位一致，SUB/AND 以取负形式存储），±1
     系数与内部格式置换折叠进有效权重，option 再以 0.5/2 通道缩放调制隐层；
     输出经 256 码字最近邻 snap 吸附回合法码本。

素材锚点（概念→C→权重→二进制地址 四向索引详见 README-neural.md）：
  - 引擎生成 C：full_controller_runtime/runtime_0_main.c（3710 行，第一锚点）
  - 部署权重：同目录 runtime_weights.c（1134063 个 float 字面量）
  - 生产核权重：anansi-linux-…/models/production/stable_*_weights.npz
  - 反编译地址：Ghidra base 0x100000（详见 decomp/notes-neural-core.md）

运行：python3 neural_core.py   （依赖 numpy + 上述权重文件；路径可用环境变量覆盖）
"""

import os
import re

import numpy as np

# --------------------------------------------------------------------------
# 路径（可用环境变量覆盖）
# --------------------------------------------------------------------------
_HERE = os.path.dirname(os.path.abspath(__file__))
RUNTIME_DIR = os.environ.get(
    "ANANSI_RUNTIME_DIR",
    "/Users/system-security/Desktop/re-agent-v2/re-run/anansi-20261027/"
    "artifacts/engine-trace/prot.build/run-6qdudb/work/function_0/work/"
    "program/full_controller_runtime",
)
RUNTIME_WEIGHTS_C = os.path.join(RUNTIME_DIR, "runtime_weights.c")
RUNTIME_MAIN_C = os.path.join(RUNTIME_DIR, "runtime_0_main.c")
PRODUCTION_DIR = os.environ.get(
    "ANANSI_PRODUCTION",
    "/Users/system-security/Downloads/anansi-linux-20261022-x86_64/models/production",
)
CODEC_NPZ = os.environ.get(
    "ANANSI_CODEC_NPZ",
    "/Users/system-security/Downloads/anansi-linux-20261022-x86_64/runtime/codec/"
    "weights/neural_codec_weights.npz",
)
MODULE_CACHE = os.path.join(_HERE, "_anansi_module_weights.npz")

# --------------------------------------------------------------------------
# 架构常量 —— runtime_0_main.c L23-29（#define EMBED 32 / MAX_BYTES 4 / …）
#   对应二进制 .rodata 模板：0x6eb000-0x730000（c_runtime_codegen 模板串）
# --------------------------------------------------------------------------
EMBED = 32          # 潜码维度
MAX_BYTES = 4       # word_t 最多 4 字节 lane（i32）
V_SLOTS = 8         # 临时 V-slot 数（NNOBF_TEMP_SLOTS）
Q_DIM = 64          # Controller 循环潜状态维（NIR_CTRL_q_states）
CONDITION_DIM = 32  # condition 维
CONTROLLER_INPUT_DIM = 96  # = Q_DIM + CONDITION_DIM
CONTROLLER_HEADS = 189     # 61 selector + 64 option + 64 q_next（见验证 6）
CONTROLLER_HIDDEN = 64
SELECTOR_HEADS = 61
SELECTOR_RANK = 8
OPTION_DIM = 64
OPTION_ROUTE_DIM = 16
OPTION_FORMATS = 4
SLOT_CHOICES = 9    # 9-way categorical（8 号 = 无效 → -1）

# 离散选择表 —— runtime_0_main.c L2346-2362
WIDTHS = [1, 32]
LANE_DELTAS = [-1, 0]
BYTE_OFFSETS = [-1, 0]
ACCESS_WIDTHS = [0, 4]
ALIGNMENTS = [0, 4]

# 部署 ragged 统一 ALU 的 6 个基底 term —— runtime_0_main.c L2520-2535
#   shapes[i] = (input, hidden, output, refiner)；权重与 production npz 对应：
#   t0=XOR t1=OR t2=SUB(存储取负) t3=SHIFT_SHL t4=AND(存储取负) t5=SELECT
RAGGED_SHAPES = [(64, 352, 32, 128), (64, 320, 32, 128), (96, 320, 64, 128),
                 (96, 384, 32, 128), (64, 320, 32, 128), (96, 320, 32, 128)]
RAGGED_TERM_NAMES = ["XOR", "OR", "-SUB", "SHIFT_SHL", "-AND", "SELECT"]
# 各 term 14 个张量在 ALU 权重区（基址 43560）内的相对偏移
#   顺序：W1, GW_LEFT, GW_RIGHT, B1, W2, B2, W3, B3, RW1, RB1, RW2, RB2, RW3, RB3
RAGGED_OFFSETS = [
    [0, -1, -1, 22528, 22880, 146784, 147136, 158400, 158432, 162528, 162656, 179040, 179168, 183264],
    [183296, -1, -1, 203776, 204096, 306496, 306816, 317056, 317088, 321184, 321312, 337696, 337824, 341920],
    [341952, -1, -1, 372672, 372992, 475392, 475712, 496192, 496256, 500352, 500480, 516864, 516992, 521088],
    [521120, -1, -1, 557984, 558368, 705824, 706208, 718496, 718528, 722624, 722752, 739136, 739264, 743360],
    [743392, -1, -1, 763872, 764192, 866592, 866912, 877152, 877184, 881280, 881408, 897792, 897920, 902016],
    [902048, -1, -1, 932768, 933088, 1035488, 1035808, 1046048, 1046080, 1050176, 1050304, 1066688, 1066816, 1070912],
]
RAGGED_BASE = 43560  # NNOBF_W_…_0103：ALU 权重区基址（codec 之后）

# Controller/option 权重区布局（float 索引，源自 runtime_0_main.c 头部宏表）
#   模板锚点：.rodata 0x6fb638-0x723232；二进制函数 FUN_00415020（torch 前向）
CTRL_LAYOUT = dict(
    ragged_M=(1114504, 1114600, (6, 16)),      # 6×16 term 选择矩阵（0104）
    ctrl_w1=(1114600, 1120744, (96, 64)),      # 单塔第一层（00fc）
    ctrl_b1=(1120744, 1120808, None),
    sel_w2l=(1120808, 1121320, (64, 8)),       # selector 低秩左（00f8）
    sel_w2r=(1121320, 1121808, (8, 61)),       # selector 低秩右（00f9）
    sel_lat_b=(1121808, 1121816, None),        # 低秩中层偏置（00fa）
    qnext_w2=(1121816, 1130008, (64, 128)),    # option+qnext 直连层（00fb）
    sel_heads_b=(1130008, 1130069, None),      # selector 头偏置（00f1）
    qnext_heads_b=(1130069, 1130197, None),
    cond_w=(1130197, 1132245, (64, 32)),       # condition 投影（00f3）
    cond_b=(1132245, 1132277, None),           # （00f2）
    q_init=(1132277, 1132341, None),           # q 初值（00f6）
    region_q=(1132341, 1132917, (9, 64)),      # 9 个 region 入口 q（00f7）
    oc_w1=(1132917, 1133429, (64, 8)),         # option conditioner 第一层（0101）
    oc_b1=(1133429, 1133437, None),            # （00fd）
    oc_w2=(1133437, 1133709, (8, 34)),         # 第二层（0102）
    oc_b2=(1133709, 1133743, None),            # （00fe）
    fmt_perm=(1133743, 1133871, (4, 32)),      # 格式置换表（00ff，int 索引）
    fmt_sign=(1133871, 1133999, (4, 32)),      # 格式符号表（0100）
    ct_perm=(1133999, 1134031, (1, 32)),       # control_transform 置换（00f4）
    ct_sign=(1134031, 1134063, (1, 32)),       # control_transform 符号（00f5）
)
N_WEIGHTS = 1134063  # nnobf_module_72471b587e2e22bc_weights 总长


# ==========================================================================
# 0. 权重装载
# ==========================================================================
def parse_runtime_weights_c(path=RUNTIME_WEIGHTS_C):
    """解析 runtime_weights.c 中的 float 字面量数组（两轮部署格式通用）。

    第一轮声明为 `_Float16 …_weights_storage[1134063]`（fp16-control-path-v1
    模板痕迹，发射的十进制字面量为完整 f32）；第二轮声明为
    `const float …_weights[1538445]`（fp32-control-path-v1，certification
    deployment_quantization.format）。长度一律取文件头方括号内声明的
    元素数校验，不再绑定单一轮次的 N_WEIGHTS 常量。
    对应二进制：FUN_00346420（运行时 C 发射器，0x346420）。
    """
    text = open(path).read()
    head = text[:text.index("{")]
    m = re.search(r"\[\s*(\d+)\s*\]", head)
    declared = int(m.group(1)) if m else N_WEIGHTS
    i = text.index("{")
    j = text.index("};", i)
    vals = []
    for tok in re.split(r"[,\s]+", text[i + 1:j]):
        if not tok:
            continue
        if tok[-1] in "fF":
            tok = tok[:-1]
        vals.append(float(tok))
    w = np.asarray(vals, dtype=np.float32)
    if w.size != declared:
        raise ValueError(f"weights count {w.size} != declared {declared}")
    return w


def _slice_ragged(alu_region, shapes=None, offsets=None):
    """从 ALU 权重区切出各 term 的 14 张量。

    alu_region: float64 数组，起点=RAGGED_BASE（第一轮）或 T2_RAGGED_BASE
    （第二轮）。shapes/offsets 缺省取第一轮 6-term 表；第二轮 8-term 传
    T2_RAGGED_SHAPES / T2_RAGGED_OFFSETS。GW_LEFT/GW_RIGHT（索引 1/2）
    两轮均缺席（UINT32_MAX/-1，不提取）。
    """
    if shapes is None:
        shapes = RAGGED_SHAPES
    if offsets is None:
        offsets = RAGGED_OFFSETS
    ragged = []
    for t in range(len(shapes)):
        inp, hid, outp, ref = shapes[t]
        o = offsets[t]

        def g(idx, n, shp, _o=o):
            x = alu_region[_o[idx]:_o[idx] + n]
            return x.reshape(shp) if isinstance(shp, tuple) else x

        ragged.append(dict(
            w1=g(0, inp * hid, (inp, hid)), b1=g(3, hid, None),
            w2=g(4, hid * hid, (hid, hid)), b2=g(5, hid, None),
            w3=g(6, hid * outp, (hid, outp)), b3=g(7, outp, None),
            rw1=g(8, EMBED * ref, (EMBED, ref)), rb1=g(9, ref, None),
            rw2=g(10, ref * ref, (ref, ref)), rb2=g(11, ref, None),
            rw3=g(12, ref * EMBED, (ref, EMBED)), rb3=g(13, EMBED, None),
        ))
    return ragged


def load_module_weights():
    """装载本模块部署权重（codec + controller + ragged ALU + 格式表）。"""
    if os.path.exists(MODULE_CACHE):
        z = np.load(MODULE_CACHE)
        if "alu_region" in z.files:
            mw = {k: z[k] for k in z.files if k != "alu_region"}
            mw["ragged"] = _slice_ragged(z["alu_region"])
            return mw
    w = parse_runtime_weights_c()

    def sl(a, b, shape=None):
        x = w[a:b].astype(np.float64)
        return x.reshape(shape) if shape else x

    out = {}
    # codec —— runtime_0_main.c L657-695（encode_byte/decode_byte）
    out["enc_w1"] = sl(0, 1024, (8, 128))
    out["enc_b1"] = sl(1024, 1152)
    out["enc_w2"] = sl(1152, 17536, (128, 128))
    out["enc_b2"] = sl(17536, 17664)
    out["enc_w3"] = sl(17664, 21760, (128, 32))
    out["enc_b3"] = sl(21760, 21792)
    out["dec_w1"] = sl(21792, 25888, (32, 128))
    out["dec_b1"] = sl(25888, 26016)
    out["dec_w2"] = sl(26016, 42400, (128, 128))
    out["dec_b2"] = sl(42400, 42528)
    out["dec_w3"] = sl(42528, 43552, (128, 8))
    out["dec_b3"] = sl(43552, 43560)
    for k, (a, b, sh) in CTRL_LAYOUT.items():
        out[k] = sl(a, b, sh)
    alu_region = w[RAGGED_BASE:N_WEIGHTS].astype(np.float64)
    out["ragged"] = _slice_ragged(alu_region)
    np.savez(MODULE_CACHE, **{k: v for k, v in out.items() if k != "ragged"},
             alu_region=alu_region)
    return out


def load_production_core(op):
    """装载 models/production/stable_{op}_weights.npz 字节核。"""
    return {k: v.astype(np.float64) for k, v in
            np.load(os.path.join(PRODUCTION_DIR, f"stable_{op}_weights.npz")).items()}


# ==========================================================================
# 1. dense / 激活 —— runtime_0_main.c L625-655（FP64 累加行主序 GEMM）
# ==========================================================================
def dense(x, w, b, relu=False):
    """out[j] = b[j] + Σ_i x[i]·w[i,j]（C 版以 double 累加器逐行累加）。

    二进制锚点：FP64 基准核 .rodata 模板 0x6fd51b；C++ numpy 兼容 matmul
    FUN_004cffa0（cblas_sgemm/sgemv/sdot）。
    """
    y = x @ w + b
    return np.maximum(y, 0.0) if relu else y


def argmax_first(x):
    """与 C 版 argmax 相同的 first-index-wins 语义（runtime_0_main.c L1152）。"""
    return int(np.argmax(x))


# ==========================================================================
# 2. 神经 codec（模块部署版）—— runtime_0_main.c L657-695
#    encode_byte: L657-663；decode_byte: L687-695
#    .rodata 模板锚点 0x6fc598；装载器 FUN_00680300（0x680300）
# ==========================================================================
class Codec:
    """8bit ↔ 32 维潜码 边界编解码器（deployed module codec）。

    注：anansi-linux bundle 的 runtime/codec/weights/neural_codec_weights.npz
    与本模块 codec 相差一个 32×32 正交共轭 X（encoder 尾层 @X、decoder 首层
    Xᵀ@），两者 roundtrip 均精确；production ALU 核与本模块码制逐位兼容
    （验证 3），故本类直接使用 runtime_weights.c 区域 [0,43560)。
    """

    def __init__(self, mw):
        self.enc = [mw["enc_w1"], mw["enc_b1"], mw["enc_w2"], mw["enc_b2"],
                    mw["enc_w3"], mw["enc_b3"]]
        self.dec = [mw["dec_w1"], mw["dec_b1"], mw["dec_w2"], mw["dec_b2"],
                    mw["dec_w3"], mw["dec_b3"]]
        self.codebook = self.encode_batch(np.arange(256))

    def encode_byte(self, value):
        """byte → 32 维潜码；bits LSB-first（runtime_0_main.c L657-663）。"""
        bits = np.array([(value >> i) & 1 for i in range(8)], dtype=np.float64)
        h1 = dense(bits, self.enc[0], self.enc[1], relu=True)
        h2 = dense(h1, self.enc[2], self.enc[3], relu=True)
        return dense(h2, self.enc[4], self.enc[5])

    def encode_batch(self, values):
        """批量编码。values: (N,) int → (N,32)。"""
        values = np.asarray(values).astype(np.uint64)
        bits = ((values[:, None] >> np.arange(8, dtype=np.uint64)) & 1).astype(np.float64)
        h1 = dense(bits, self.enc[0], self.enc[1], relu=True)
        h2 = dense(h1, self.enc[2], self.enc[3], relu=True)
        return dense(h2, self.enc[4], self.enc[5])

    def decode_byte(self, code):
        """32 维潜码 → byte；logit>=0 逐位置位（runtime_0_main.c L687-695）。"""
        h1 = dense(code, self.dec[0], self.dec[1], relu=True)
        h2 = dense(h1, self.dec[2], self.dec[3], relu=True)
        logits = dense(h2, self.dec[4], self.dec[5])
        v = 0
        for i in range(8):
            if logits[i] >= 0.0:
                v |= 1 << i
        return v

    def decode_batch(self, codes):
        h1 = dense(codes, self.dec[0], self.dec[1], relu=True)
        h2 = dense(h1, self.dec[2], self.dec[3], relu=True)
        logits = dense(h2, self.dec[4], self.dec[5])
        return ((logits >= 0.0) * (1 << np.arange(8))).sum(1).astype(np.int64)

    def snap(self, codes):
        """最近邻 L2 吸附到 256 码本 —— runtime_0_main.c L811-847
        （nnobf_snap_encoded_state；NEON 4-lane 核 + 1e-4 歧义带回退的
        可移植等价：argmin first-index-wins）。codes: (N,32)。"""
        d = ((codes[:, None, :] - self.codebook[None, :, :]) ** 2).sum(2)
        return self.codebook[np.argmin(d, axis=1)]


# ==========================================================================
# 3. word_t 与内部格式 —— runtime_0_main.c L374-378（typedef word_t）
#    格式变换 L1001-1030（nnobf_apply_encoded_format）
# ==========================================================================
class Word:
    """word_t：MAX_BYTES 个 lane × EMBED 维潜码 + format + domain。

    批量形态 lanes 形状 (N, MAX_BYTES, EMBED)；domain 0=EXTERNAL 1=INTERNAL。
    """

    def __init__(self, lanes, fmt=0, domain=0):
        self.lanes = np.asarray(lanes, dtype=np.float64)
        self.fmt = fmt
        self.domain = domain


def width_bytes(width):
    """runtime_0_main.c L950。"""
    return 1 if width <= 1 else (width + 7) // 8


class FormatBank:
    """4 个内部格式的正交符号置换（E_f(v) = E_x(v)·P_f）。

    表来自权重区 [1133743,1133999)（模板 .rodata 0x7033b0 format_bank 段）。
    格式 0 = 恒等。apply/逆 apply 均支持 (…,32) 批量。
    """

    def __init__(self, mw):
        self.perm = mw["fmt_perm"].astype(int)   # (4,32) int
        self.sign = mw["fmt_sign"]               # (4,32) ±1

    def apply(self, codes, fmt, inverse=False):
        """nnobf_apply_encoded_format —— 正向: out[…,perm[i]] = in[…,i]*sign[i]；
        逆向: out[…,i] = in[…,perm[i]]*sign[i]。codes: (…,32)。"""
        if fmt <= 0 or fmt >= OPTION_FORMATS:
            return codes
        p, s = self.perm[fmt], self.sign[fmt]
        if inverse:
            return codes[..., p] * s
        out = np.empty_like(codes)
        out[..., p] = codes * s
        return out

    def code_component(self, fmt, canonical):
        """nnobf_ragged_code_component —— 折叠用：canonical → (encoded, sign)。"""
        if fmt == 0:
            return canonical, 1.0
        return int(self.perm[fmt][canonical]), float(self.sign[fmt][canonical])


# ==========================================================================
# 4. Controller 栈 —— runtime_0_main.c L2364-2506
#    torch 侧拟合前向：FUN_00415020（0x415020）；布局判定 FUN_00651ed0
# ==========================================================================
class Controller:
    """single-tower-v1 Controller（prot.json controller_layout）。

    forward: input96 = q‖cond → dense(96→64) → tanh
             → selector 低秩头（64→8→61）与 option/qnext 直连头（64→128）。
    """

    def __init__(self, mw):
        self.w1, self.b1 = mw["ctrl_w1"], mw["ctrl_b1"]
        self.sel_w2l, self.sel_lat_b = mw["sel_w2l"], mw["sel_lat_b"]
        self.sel_w2r, self.sel_heads_b = mw["sel_w2r"], mw["sel_heads_b"]
        self.qnext_w2, self.qnext_heads_b = mw["qnext_w2"], mw["qnext_heads_b"]
        self.cond_w, self.cond_b = mw["cond_w"], mw["cond_b"]
        self.q_init = mw["q_init"]
        self.region_q = mw["region_q"]

    def forward(self, q, cond):
        """nnobf_controller_forward（runtime_0_main.c L2364-2388）→ 189 维 heads。"""
        inp = np.concatenate([q, cond])
        h = np.tanh(dense(inp, self.w1, self.b1))
        latent = dense(h, self.sel_w2l, self.sel_lat_b)
        sel = dense(latent, self.sel_w2r, self.sel_heads_b)
        rest = dense(h, self.qnext_w2, self.qnext_heads_b)
        return np.concatenate([sel, rest])

    def refresh_condition(self, q, token):
        """nnobf_controller_refresh_condition（L2390-2404）。

        condition = tanh(dense(q,64→32) + token_gate·token)；
        token_gate = (q[0] >= 0) —— q[0] 是控制消费门（仅 BRANCH 态消费 token）。
        """
        gate = 1.0 if q[0] >= 0 else 0.0
        return np.tanh(dense(q, self.cond_w, self.cond_b) + gate * token)


def decode_action(h):
    """controller_step 的动作解码（runtime_0_main.c L2413-2461）。

    61 个 selector 头 → argmax 查表 → 数据搬运字段；9-way slot 的 8 号=-1
    （nnobf_controller_slot L2406-2409）。头布局：
      [0:36] read_a/b/c/write（各 9-way）
      [36:40] input_layout(4)  [40:42] input_span  [42:48] lane_delta_a/b/c
      [48:50] source_width  [50:52] target_width  [52:54] object_index
      [54:56] byte_offset  [56:58] access_width  [58:60] alignment
      [60:61] control_transform  [61:125] option(64)  [125:189] q_next(64)
    """
    def slot(h9):
        s = argmax_first(h9[:SLOT_CHOICES])
        return -1 if s == 8 else s

    return dict(
        read_a=slot(h[0:9]), read_b=slot(h[9:18]), read_c=slot(h[18:27]),
        write=slot(h[27:36]),
        input_layout=argmax_first(h[36:40]),
        input_span=WIDTHS[argmax_first(h[40:42])],
        lane_delta_a=LANE_DELTAS[argmax_first(h[42:44])],
        lane_delta_b=LANE_DELTAS[argmax_first(h[44:46])],
        lane_delta_c=LANE_DELTAS[argmax_first(h[46:48])],
        source_width=WIDTHS[argmax_first(h[48:50])],
        target_width=WIDTHS[argmax_first(h[50:52])],
        object_index=(-1 if argmax_first(h[52:54]) == 1 else argmax_first(h[52:54])),
        byte_offset=BYTE_OFFSETS[argmax_first(h[54:56])],
        access_width=ACCESS_WIDTHS[argmax_first(h[56:58])],
        alignment=ALIGNMENTS[argmax_first(h[58:60])],
        control_transform=argmax_first(h[60:61]),
    )


def controller_step(ctrl, q, cond):
    """nnobf_controller_step（runtime_0_main.c L2413-2461）。

    返回 (action dict, option[64], q_next[64])；q_next 符号量化到 ±4
    （部署递归直接消费预测潜状态，L2457-2458）。"""
    h = ctrl.forward(q, cond)
    action = decode_action(h)
    option = h[SELECTOR_HEADS:SELECTOR_HEADS + OPTION_DIM]
    q_next = np.where(h[SELECTOR_HEADS + OPTION_DIM:CONTROLLER_HEADS] >= 0.0,
                      4.0, -4.0)
    return action, option, q_next


def option_profile(mw, option):
    """nnobf_option_profile（runtime_0_main.c L2479-2506）。

    option(64) → dense(64→8) → tanh → dense(8→34) 解出：
    enabled / route[16](±1) / format / auxiliary_format / control_transform /
    effect[8]（结构效应头：0=STORE 1=ALU 2=LOAD 3=COPY 4/5=RENAME
    6=token 保持 7=HALT；>=0 判激活，effect[1] 为 ALU 缺省分支）。
    """
    hidden = np.tanh(dense(option, mw["oc_w1"], mw["oc_b1"]))
    heads = dense(hidden, mw["oc_w2"], mw["oc_b2"])
    enabled = bool(heads[0] >= 0.0)
    route = [1 if heads[1 + i] >= 0.0 else -1 for i in range(OPTION_ROUTE_DIM)]
    fmt = argmax_first(heads[17:21])
    aux_fmt = argmax_first(heads[21:25])
    ct = argmax_first(heads[25:26])
    effect = heads[26:34]
    return enabled, route, fmt, aux_fmt, ct, effect


def ragged_choose(mw, route):
    """nnobf_ragged_choose（runtime_0_main.c L2560-2583）。

    6×16 选择矩阵上 key·M 各行点积，winner = argmax|·|，coefficient = ±1。
    本程序 6 term = XOR/OR/−SUB/SHL/−AND/SELECT（route→term 映射固定）。
    """
    key = np.asarray(route, dtype=np.float64)
    vals = mw["ragged_M"] @ key
    term = int(np.argmax(np.abs(vals)))
    coef = 1.0 if vals[term] >= 0.0 else -1.0
    return term, coef


# ==========================================================================
# 5. 静态 ALU 字节核（StableTool 生产核，production npz）
#    结构对应 runtime_0_main.c：full_byte L703-737 / binary_byte L739-767 /
#    select_byte L853-870 / unary_byte L872-894
#    装载器 FUN_00681df0（0x681df0，StableFusedFullByteTool 等）
# ==========================================================================
def _refine(x, core):
    """refiner 残差头：dense(32→128,relu)→(128→128,relu)→(128→32)，
    out += residual（与 full_byte/binary_byte/select_byte 内嵌块一致）。"""
    h1 = dense(x, core["rw1"], core["rb1"], relu=True)
    h2 = dense(h1, core["rw2"], core["rb2"], relu=True)
    return x + dense(h2, core["rw3"], core["rb3"])


def full_byte(core, a, b, carry):
    """full_byte —— ADD/SUB 全加器字节核（3×32 输入 → 2×32 输出）。

    input = [a‖b‖carry] → dense(96→H,relu) → dense(H→H,relu) → dense(H→64)
    输出前 32 维 = 本字节值，后 32 维 = next carry；两者各过 refiner。
    production: stable_add_byte / stable_sub_byte（H=320）。
    a/b/carry: (N,32)。返回 (value (N,32), next_carry (N,32))。
    """
    inp = np.concatenate([a, b, carry], axis=1)
    h1 = dense(inp, core["w1"], core["b1"], relu=True)
    h2 = dense(h1, core["w2"], core["b2"], relu=True)
    out = dense(h2, core["w3"], core["b3"])
    return _refine(out[:, :EMBED], core), _refine(out[:, EMBED:], core)


def binary_byte(core, a, b):
    """binary_byte —— AND/OR/XOR 字节核（2×32 输入 → 32 输出 + refiner）。

    production: stable_and/or/xor_byte（AND/OR H=320，XOR H=352）。"""
    inp = np.concatenate([a, b], axis=1)
    h1 = dense(inp, core["w1"], core["b1"], relu=True)
    h2 = dense(h1, core["w2"], core["b2"], relu=True)
    return _refine(dense(h2, core["w3"], core["b3"]), core)


def select_byte(core, cond, when_true, when_false):
    """select_byte —— SELECT 字节核（3×32 → 32，production stable_select_byte）。

    输入布局 [condition‖when_true‖when_false]。"""
    inp = np.concatenate([cond, when_true, when_false], axis=1)
    h1 = dense(inp, core["w1"], core["b1"], relu=True)
    h2 = dense(h1, core["w2"], core["b2"], relu=True)
    return _refine(dense(h2, core["w3"], core["b3"]), core)


def bit_index_byte(core, value, position):
    """stable_bit_index —— 变量位提取宏 MACRO_R_BIT_INDEX 的字节核。

    输入约定（实测 2048/2048 穷举验证）：[E(value) ‖ E(position)]，
    position 为 0..7 的字节码；输出 = E((value>>position)&1)。"""
    inp = np.concatenate([value, position], axis=1)
    h1 = dense(inp, core["w1"], core["b1"], relu=True)
    h2 = dense(h1, core["w2"], core["b2"], relu=True)
    return _refine(dense(h2, core["w3"], core["b3"]), core)


# ==========================================================================
# 6. word 级静态宏 —— runtime_0_main.c L1106-1148
#    word_full L1106-1121 / word_binary L1123-1138 / word_select L1140-1148
#    （宏族其余成员 nnobf_k_* L1989-2328 为完整程序模板的静态路径库）
# ==========================================================================
def word_full(codec, core, a_bytes, b_bytes, width):
    """word_full —— 潜空间纹波进位加/减宏（stable_add_byte 端到端重放）。

    carry 初值 = E(0)；逐 lane full_byte(a,b,carry) → value/next；
    尾 lane word_normalize（width 非 8 倍数时 AND 掩码；width=32 为 no-op）；
    final_carry 为副产品（借位用于 ICMP_ULT）。
    a_bytes/b_bytes: (N, lanes) uint8。返回 (sum_bytes (N,lanes), carry (N,32))。
    """
    lanes = width_bytes(width)
    carry = np.tile(codec.encode_byte(0), (a_bytes.shape[0], 1))
    out = np.zeros((a_bytes.shape[0], lanes), dtype=np.uint8)
    for lane in range(lanes):
        a = codec.encode_batch(a_bytes[:, lane])
        b = codec.encode_batch(b_bytes[:, lane])
        value, carry = full_byte(core, a, b, carry)
        out[:, lane] = codec.decode_batch(value)
    return out, carry


def word_ult(codec, sub_core, a_bytes, b_bytes, width):
    """ICMP_ULT 宏 —— word_full(SUB) 的最终借位（runtime_0_main.c L1966-1973
    nnobf_word_ult：'ICMP_ULT is lowered as the final borrow produced by the
    exact shared SUB recurrence'；finalize_predicate_byte 本 build = 恒等）。

    返回 (N,) bool。"""
    _, borrow = word_full(codec, sub_core, a_bytes, b_bytes, width)
    return codec.decode_batch(borrow) == 1


# ==========================================================================
# 7. 部署 ragged 统一 ALU（option 条件共享执行器）
#    runtime_0_main.c：rebuild L2747-2861 / ragged_byte L2953-3031 /
#    option_shared_alu L3033-3110 —— 模板锚点 .rodata 0x713878/0x70c5a0
# ==========================================================================
def ragged_rebuild(tensors, fmt_bank, in_fmts, out_fmt, aux_fmt, coef):
    """nnobf_ragged_rebuild_fused —— 把 ±1 系数与内部格式置换折叠进有效权重。

    本部署 6 term 的 GW_LEFT/GW_RIGHT 均缺席（低秩中层未启用，
    hidden_scale≡1），故等价于：全部张量 × coef，再把输入格式的置换折进 w1
    行、输出/aux 格式折进 w3 列、b3、refiner 的 rw1 行/rw3 列/rb3。
    in_fmts = (a_fmt, b_fmt, c_fmt)。返回折叠后的参数字典。
    """
    inp, hid = tensors["w1"].shape
    outp = tensors["w3"].shape[1]
    ref = tensors["rw2"].shape[0]
    iblocks = inp // EMBED
    oblocks = outp // EMBED
    fmts = [in_fmts[0], in_fmts[1], in_fmts[2], out_fmt, aux_fmt]

    def comp(f, c):
        return fmt_bank.code_component(f, c)

    p = {k: coef * v for k, v in tensors.items()}
    # w1 输入块行折叠
    for blk in range(iblocks):
        for c in range(EMBED):
            enc_c, s = comp(fmts[blk], c)
            p["w1"][blk * EMBED + enc_c, :] = coef * s * tensors["w1"][blk * EMBED + c, :]
    # w3/b3 输出块列折叠
    for blk in range(oblocks):
        for c in range(EMBED):
            enc_c, s = comp(fmts[3 + blk], c)
            p["b3"][blk * EMBED + enc_c] = coef * s * tensors["b3"][blk * EMBED + c]
            p["w3"][:, blk * EMBED + enc_c] = coef * s * tensors["w3"][:, blk * EMBED + c]
    # refiner 折叠：C 中 RW1..RB3 与 AUX_RW1..AUX_RB3 两个参数槽从同一组源
    # 张量恢复，分别以 value 输出格式 / aux 格式折叠（rebuild_fused L2832-2859）
    for path, f, pfx in ((0, out_fmt, ""), (1, aux_fmt, "aux_")):
        for key in ("rw1", "rb1", "rw2", "rb2", "rw3", "rb3"):
            p[pfx + key] = coef * tensors[key]
        rw1, rw3, rb3 = p[pfx + "rw1"], p[pfx + "rw3"], p[pfx + "rb3"]
        for c in range(EMBED):
            enc_c, s = comp(f, c)
            rw1[enc_c, :] = coef * s * tensors["rw1"][c, :]
            rb3[enc_c] = coef * s * tensors["rb3"][c]
            rw3[:, enc_c] = coef * s * tensors["rw3"][:, c]
    p["shape"] = (inp, hid, outp, ref)
    return p


def ragged_byte(params, option, a, b, c):
    """nnobf_ragged_byte —— 折叠后字节核的单次前向（批量 N）。

    option 通道缩放：channel_scale[j] = option[j%64]<0 ? 0.5 : 2.0
    （nnobf_option_channel_scale L925-927：'The full 64-D option changes the
    concrete hidden-channel path of the one unified ALU'）；
    w2 行 i 以 1/cs[i] 反缩放。a/b/c: (N,32)。返回 (value, aux)。
    """
    inp, hid, outp, ref = params["shape"]
    reps = (hid + 63) // 64
    cs = np.where(np.tile(option, reps)[:hid] < 0, 0.5, 2.0)  # (hid,)
    parts = [a, b] + ([c] if inp > 2 * EMBED else [])
    inp_v = np.concatenate(parts, axis=1)
    total1 = params["b1"][None, :] * cs + (inp_v @ params["w1"]) * cs
    h1 = np.maximum(total1, 0.0)
    total2 = params["b2"][None, :] + (h1 * (1.0 / cs)[None, :]) @ params["w2"]
    h2 = np.maximum(total2, 0.0)
    total3 = params["b3"][None, :] + h2 @ params["w3"]
    value = total3[:, :EMBED]
    aux = total3[:, EMBED:] if outp > EMBED else np.zeros_like(value)

    def refine(x, base):
        r1 = dense(x, params[base + "rw1"], params[base + "rb1"], relu=True)
        r2 = dense(r1, params[base + "rw2"], params[base + "rb2"], relu=True)
        return x + dense(r2, params[base + "rw3"], params[base + "rb3"])

    value = refine(value, "")
    if outp > EMBED:
        aux = refine(aux, "aux_")
    return value, aux


def option_shared_alu(mw, fmt_bank, codec, route, option, ternary,
                      a_word, b_word, c_word, width, out_fmt, aux_fmt,
                      need_aux):
    """nnobf_option_shared_alu（runtime_0_main.c L3033-3110）—— 部署执行路径。

    route(16) → 选 term + coef → rebuild（格式折叠）→ 逐 lane ragged_byte
    （ternary: 0=binary 1=SELECT 广播 2=full/shift 3=c 广播）→ 每 lane snap。
    a_word/b_word/c_word: Word，lanes 形状 (N, MAX_BYTES, EMBED)。
    返回 (out_word, final_aux (N,32))。
    """
    term, coef = ragged_choose(mw, route)
    tensors = mw["ragged"][term]
    in_fmts = (a_word.fmt, b_word.fmt, c_word.fmt if ternary else aux_fmt)
    params = ragged_rebuild(tensors, fmt_bank, in_fmts, out_fmt, aux_fmt, coef)
    outp = params["shape"][2]
    need_aux = need_aux and outp > EMBED
    lanes = width_bytes(width)
    A, B, C = a_word.lanes, b_word.lanes, c_word.lanes
    N = A.shape[0]

    state = np.tile(fmt_bank.apply(codec.encode_byte(0), aux_fmt), (N, 1))
    if ternary == 3:
        state = C[:, 0, :]
    out_lanes = np.tile(codec.encode_byte(0), (N, MAX_BYTES, 1))
    for lane in range(lanes):
        first, second, third = A[:, lane, :], B[:, lane, :], state
        if ternary == 1:
            first, second, third = A[:, 0, :], B[:, lane, :], C[:, lane, :]
        elif ternary == 2:
            third = C[:, lane, :]
        value, aux = ragged_byte(params, option, first, second, third)
        # snap：canonical 域最近邻吸附（option_shared_alu L3083-3091）
        value = fmt_bank.apply(codec.snap(fmt_bank.apply(value, out_fmt, True)),
                              out_fmt, False)
        if need_aux:
            aux = fmt_bank.apply(codec.snap(fmt_bank.apply(aux, aux_fmt, True)),
                                 aux_fmt, False)
        out_lanes[:, lane, :] = value
        state = aux
    out = Word(out_lanes, out_fmt, domain=1)
    if width != 1:
        word_normalize(codec, out, width)  # width=32 → 仅清 format 字段
    out.fmt = out_fmt
    return out, state


def word_normalize(codec, word, width):
    """word_normalize（runtime_0_main.c L1091-1104）—— 尾 lane AND 掩码归一化。

    width 为 8 的倍数时仅重置 format 字段（本实现覆盖的主路径；宽度非整字节
    时用 binary_byte(AND) 学习掩码 (1<<r)-1 —— 部署程序宽度均为 1/32，
    不触发该分支）。"""
    word.fmt = 0
    return word


# ==========================================================================
# 8. 部署程序全量重放 —— runtime_0_main.c L3249-3469（nnobf_execute_range）
#    boundary_run L3535-3560 / initial_constants L3491-3502
# ==========================================================================
class ProgramReplay:
    """重放 full_controller_runtime 的 8 动作计划（批量 N 个样本）。

    部署计划（Controller rollout 确定，与 prot.json
    operations=[ICMP_ULT×2,OR,XOR,LOAD,SHIFT_SHL,AND,SELECT] 逐位吻合）：
      step0 ICMP_ULT(slot5=arg, slot1=1) → slot6   (i1)
      step1 ICMP_ULT(slot1=1, slot5=arg) → slot7   (i1)
      step2 OR(slot6, slot7) → slot6                (i1)
      step3 XOR(slot6, slot0=1) → slot6             (i1, == (arg==1))
      step4 LOAD obj0[0:4] → slot7                  (i32, 同步内存)
      step5 SHL(slot7, slot7 ldb=-1, slot2={1,1,1,1}) → slot7  (i32, <<1)
      step6 AND(slot7, slot4={255×4}) → slot7       (i32, 归一化掩码)
      step7 SELECT(slot6, slot7, slot3=42) → slot6  (i32, 三目)
    call_end 导出 slot6 解码 i32 —— 语义等价
      main(arg, mem) = (arg == 1) ? (mem << 1) & 0xffffffff : 42
    """

    def __init__(self, mw, codec, fmt_bank, ctrl):
        self.mw, self.codec, self.fmt, self.ctrl = mw, codec, fmt_bank, ctrl

    def run(self, args, mems, verbose=False):
        """args/mems: (N,) uint32。返回 (N,) uint32 解码输出。"""
        N = len(args)
        codec, fmtb, ctrl, mw = self.codec, self.fmt, self.ctrl, self.mw
        zero_token = codec.encode_byte(0)

        # ---- call_begin：初始常量（runtime_0_main.c L3494-3518）----
        def word_const(bytes_, fmt=0):
            lanes = np.zeros((N, MAX_BYTES, EMBED))
            for i, b in enumerate(bytes_):
                lanes[:, i, :] = codec.encode_batch(np.full(N, b))
            return Word(lanes, fmt, domain=0)

        slots = [
            word_const([1]),                      # slot0 = i1 1
            word_const([1, 0, 0, 0]),             # slot1 = i32 1
            word_const([1, 1, 1, 1]),             # slot2 = i32 移位量码（1bit/lane）
            word_const([42, 0, 0, 0]),            # slot3 = i32 42
            word_const([255, 255, 255, 255]),     # slot4 = i32 0xffffffff
            None, None, None,
        ]
        # slot5 = word_encode(arg, 32)（boundary_run L3546-3548）
        lanes5 = np.zeros((N, MAX_BYTES, EMBED))
        for i in range(4):
            lanes5[:, i, :] = codec.encode_batch((args >> (8 * i)) & 0xff)
        slots[5] = Word(lanes5, 0, domain=0)
        # sync_in：obj0 = 4 字节镜像内存（L3544-3545）
        mem = np.zeros((N, 4, EMBED))
        for i in range(4):
            mem[:, i, :] = codec.encode_batch((mems >> (8 * i)) & 0xff)

        # ---- Controller rollout（q 递归 + condition 刷新）----
        q = ctrl.q_init.copy()
        cond = ctrl.refresh_condition(q, zero_token)

        def refresh_all():
            return ctrl.refresh_condition(q, zero_token)

        for step in range(8):
            h = ctrl.forward(q, cond)
            action = decode_action(h)
            option = h[SELECTOR_HEADS:SELECTOR_HEADS + OPTION_DIM]
            q = np.where(h[SELECTOR_HEADS + OPTION_DIM:CONTROLLER_HEADS] >= 0,
                         4.0, -4.0)
            en, route, fmt, aux_fmt, ct, eff = option_profile(mw, option)
            if verbose:
                term, coef = ragged_choose(mw, route)
                print(f"  step{step}: {action} fmt={fmt} aux={aux_fmt} "
                      f"term={RAGGED_TERM_NAMES[term]} coef={coef:+.0f}")
            # ---- 效应分支（execute_range L3298-3466）----
            if eff[6] >= 0:      # token 保持（本程序未触发）
                cond = refresh_all()
                continue
            if eff[5] >= 0 or eff[4] >= 0:   # RENAME（本程序未触发）
                cond = refresh_all()
                continue
            if eff[7] >= 0:      # HALT
                break
            if eff[0] >= 0:      # STORE（本程序未触发）
                raise NotImplementedError("STORE not exercised by this plan")
            if eff[2] >= 0:      # LOAD（L3352-3372）
                loaded = Word(mem.copy(), 0, domain=0)
                # word_from_canonical(result, option_format)（L3361）
                if fmt:
                    loaded.lanes = fmtb.apply(loaded.lanes, fmt, False)
                    loaded.fmt = fmt
                slots[action["write"]] = loaded
                cond = refresh_all()
                continue
            if eff[3] >= 0:      # COPY/TRUNC/ZEXT（本程序未触发）
                raise NotImplementedError("COPY not exercised by this plan")

            # ---- ALU 动作（L3416-3465）----
            A = slots[action["read_a"]]
            B = slots[action["read_b"]]
            ic = action["read_c"]

            def route_lanes(W_, delta):
                """nnobf_route_word_lanes（L1619-1635）—— 仿射 byte-lane 路由。"""
                if delta == 0 and action["input_span"] == action["source_width"]:
                    return W_
                lanes = width_bytes(action["source_width"])
                out = np.zeros((N, lanes, EMBED))
                fz = fmtb.apply(codec.encode_byte(0), W_.fmt, False)
                for d in range(lanes):
                    s = d + delta
                    if 0 <= s < width_bytes(action["input_span"]):
                        out[:, d, :] = W_.lanes[:, s, :]
                    else:
                        out[:, d, :] = fz
                return Word(out, W_.fmt, W_.domain)

            Ar = route_lanes(A, action["lane_delta_a"])
            Br = route_lanes(B, action["lane_delta_b"])
            Cw = Word(np.zeros((N, MAX_BYTES, EMBED)), 0, 1)
            if ic is not None and ic >= 0:
                Cw = route_lanes(slots[ic], action["lane_delta_c"])
            width = action["source_width"]
            need_aux = width > 1 or action["target_width"] == 1
            out, aux = option_shared_alu(
                mw, fmtb, codec, route, option, action["input_layout"],
                Ar, Br, Cw, width, fmt, aux_fmt, need_aux)
            # ICMP 降级：target i1 且源宽 >1 → 取辅助通道（execute_typed_alu
            # L3155-3164：'ICMP_ULT is lowered as the final borrow'）
            if action["target_width"] == 1 and width > 1:
                out = Word(np.tile(codec.encode_byte(0), (N, MAX_BYTES, 1)),
                           0, domain=1)
                out.lanes[:, 0, :] = aux
                out.fmt = aux_fmt
            slots[action["write"]] = out
            cond = refresh_all()

        # ---- call_end：导出 slot6 解码 i32（L3658-3668）----
        w6 = slots[6]
        canon = fmtb.apply(w6.lanes, w6.fmt, True) if w6.fmt else w6.lanes
        out = np.zeros(N, dtype=np.uint64)
        for i in range(4):
            out |= codec.decode_batch(canon[:, i, :]).astype(np.uint64) << (8 * i)
        return out.astype(np.uint32)


# ==========================================================================
# 9. 验证电池（python3 neural_core.py 的主输出）
# ==========================================================================
def verify():
    lines = []

    def P(s=""):
        print(s)
        lines.append(s)

    P("=" * 74)
    P("ANANSI 神经核心参考实现 —— 验证报告（权重均为真实部署/生产权重）")
    P("=" * 74)

    mw = load_module_weights()
    codec = Codec(mw)
    fmt_bank = FormatBank(mw)
    ctrl = Controller(mw)
    P(f"[0] 权重源: runtime_weights.c({N_WEIGHTS} floats) + models/production npz"
      f" + runtime/codec npz(对照)")

    # ---- 验证 1：codec roundtrip（穷举 256 字节）----
    codes = codec.encode_batch(np.arange(256))
    back = codec.decode_batch(codes)
    ok1 = int((back == np.arange(256)).sum())
    P(f"[1] codec roundtrip (encode→decode, 真实权重): {ok1}/256 "
      f"({100.0 * ok1 / 256:.1f}%)")

    # ---- 验证 2：stable_add_byte 宏重放 ----
    add_core = load_production_core("add_byte")
    a = np.arange(256).repeat(256)
    b = np.tile(np.arange(256), 256)
    ac = codec.encode_batch(a)
    bc = codec.encode_batch(b)
    zero = np.tile(codec.encode_byte(0), (len(a), 1))
    correct_sum = ((a + b) & 0xff).astype(np.int64)
    correct_carry = ((a + b) >= 256).astype(np.int64)
    okv = okc = 0
    CH = 16384
    for s in range(0, len(a), CH):
        v, nx = full_byte(add_core, ac[s:s + CH], bc[s:s + CH], zero[s:s + CH])
        okv += int((codec.decode_batch(v) == correct_sum[s:s + CH]).sum())
        okc += int((codec.decode_batch(nx) == correct_carry[s:s + CH]).sum())
    P(f"[2a] stable_add_byte 字节重放 (穷举 65536 对): "
      f"sum {okv}/65536 ({100.0 * okv / 65536:.2f}%), "
      f"carry {okc}/65536 ({100.0 * okc / 65536:.2f}%)")

    rng = np.random.default_rng(20261027)
    NW = 2000
    wa = rng.integers(0, 2 ** 32, NW).astype(np.uint64)
    wb = rng.integers(0, 2 ** 32, NW).astype(np.uint64)
    ab = np.stack([(wa >> (8 * i)) & 0xff for i in range(4)], 1).astype(np.uint8)
    bb = np.stack([(wb >> (8 * i)) & 0xff for i in range(4)], 1).astype(np.uint8)
    sb, _ = word_full(codec, add_core, ab, bb, 32)
    got = sum((sb[:, i].astype(np.uint64) << (8 * i)) for i in range(4))
    exp = (wa + wb) & 0xffffffff
    okw = int((got == exp).sum())
    P(f"[2b] word_full 纹波进位 32 位加法 (随机 {NW} 对): "
      f"{okw}/{NW} ({100.0 * okw / NW:.2f}%)")

    # ---- 验证 3：production 核与部署码制兼容性（对照实验）----
    z = np.load(CODEC_NPZ)

    def enc_npz(v):
        bits = np.array([(v >> i) & 1 for i in range(8)], dtype=np.float64)
        return dense(dense(dense(bits, z["encoder_w1"], z["encoder_b1"], True),
                           z["encoder_w2"], z["encoder_b2"], True),
                     z["encoder_w3"], z["encoder_b3"])

    def dec_npz(c):
        lg = dense(dense(dense(c[None, :], z["decoder_w1"], z["decoder_b1"], True),
                         z["decoder_w2"], z["decoder_b2"], True),
                   z["decoder_w3"], z["decoder_b3"])[0]
        return sum(1 << i for i in range(8) if lg[i] >= 0)

    X, *_ = np.linalg.lstsq(z["encoder_w3"].astype(np.float64),
                            mw["enc_w3"], rcond=None)
    rt_npz = sum(1 for v in range(256) if dec_npz(enc_npz(v)) == v)
    demo = [(13, 244), (255, 255), (128, 128), (0, 0), (200, 100)]
    ok_npz = sum(1 for x, y in demo
                 if dec_npz(full_byte(add_core, enc_npz(x)[None, :],
                                      enc_npz(y)[None, :],
                                      enc_npz(0)[None, :])[0][0]) == (x + y) & 0xff)
    ok_mod = sum(1 for x, y in demo
                 if codec.decode_byte(full_byte(add_core,
                                                codec.encode_byte(x)[None, :],
                                                codec.encode_byte(y)[None, :],
                                                codec.encode_byte(0)[None, :])[0][0])
                 == (x + y) & 0xff)
    P(f"[3] 码制对照: bundle npz codec roundtrip {rt_npz}/256；"
      f"ADD 核×npz 码 {ok_npz}/5 vs ×部署模块码 {ok_mod}/5 "
      f"(X 正交共轭 ‖XᵀX−I‖={np.abs(X.T @ X - np.eye(32)).max():.1e}) → "
      f"production 核锚定部署码制")

    # ---- 验证 4：bit_index 宏重放（穷举 256×8）----
    bi_core = load_production_core("bit_index")
    vs = np.repeat(np.arange(256), 8)
    ps = np.tile(np.arange(8), 256)
    outbi = bit_index_byte(bi_core, codec.encode_batch(vs), codec.encode_batch(ps))
    okbi = int((codec.decode_batch(outbi) == ((vs >> ps) & 1)).sum())
    P(f"[4] stable_bit_index 宏重放 (穷举 256×8): {okbi}/2048 "
      f"({100.0 * okbi / 2048:.2f}%)")

    # ---- 验证 5：ICMP_ULT 静态宏（SUB 借位）----
    sub_core = load_production_core("sub_byte")
    ua = rng.integers(0, 2 ** 32, 3000).astype(np.uint64)
    ub = rng.integers(0, 2 ** 32, 3000).astype(np.uint64)
    uab = np.stack([(ua >> (8 * i)) & 0xff for i in range(4)], 1).astype(np.uint8)
    ubb = np.stack([(ub >> (8 * i)) & 0xff for i in range(4)], 1).astype(np.uint8)
    pred = word_ult(codec, sub_core, uab, ubb, 32)
    oku = int((pred == (ua < ub)).sum())
    P(f"[5] ICMP_ULT 宏 (SUB 最终借位, 随机 3000 对 32 位): "
      f"{oku}/3000 ({100.0 * oku / 3000:.2f}%)")

    # ---- 验证 6：controller_step 冒烟 ----
    ok_smoke = 0
    NS = 200
    for _ in range(NS):
        q = rng.choice([-4.0, 4.0], Q_DIM)
        cond = np.tanh(rng.uniform(-2, 2, CONDITION_DIM))
        action, option, q_next = controller_step(ctrl, q, cond)
        valid = (action["read_a"] in range(-1, 8)
                 and action["read_b"] in range(-1, 8)
                 and action["write"] in range(-1, 8)
                 and action["input_layout"] in range(4)
                 and action["input_span"] in WIDTHS
                 and action["source_width"] in WIDTHS
                 and action["target_width"] in WIDTHS
                 and action["object_index"] in (-1, 0)
                 and np.all(np.isfinite(option))
                 and np.all(np.isin(q_next, (-4.0, 4.0))))
        ok_smoke += int(valid)
    P(f"[6] controller_step 冒烟 (随机 {NS} 个合法 q/condition): "
      f"字段/输出合法 {ok_smoke}/{NS}；q_next 全部 ∈ {{-4,+4}}；"
      f"heads 总数 = {CONTROLLER_HEADS} (61 selector + 64 option + 64 q_next；"
      f"模板旧常量 HEADS=116 为废弃 schema)")

    # ---- 验证 7：部署 8 动作程序全量重放 ----
    replay = ProgramReplay(mw, codec, fmt_bank, ctrl)
    NA = 1000
    args = rng.integers(0, 2 ** 32, NA).astype(np.uint64)
    mems = rng.integers(0, 2 ** 32, NA).astype(np.uint64)
    args[:50] = 1  # 覆盖 arg==1 分支
    got = replay.run(args, mems)
    exp = np.where(args == 1, (mems * 2) & 0xffffffff, 42).astype(np.uint32)
    okp = int((got == exp).sum())
    P(f"[7] 部署 8 动作程序全量重放 (Controller+option+ragged ALU+codec+snap；")
    P(f"    随机 {NA} 个 (arg,mem)，含 50 个 arg==1): {okp}/{NA} "
      f"({100.0 * okp / NA:.2f}%)")
    P(f"    还原语义: main(arg, mem) = (arg == 1) ? ((mem << 1) & 0xffffffff) : 42")
    P(f"    （动作序列 ICMP_ULT×2→OR→XOR→LOAD→SHL→AND→SELECT，与 prot.json")
    P(f"     operations 列表逐位吻合；重放经完整格式折叠+码本 snap 管线）")
    P("=" * 74)
    with open(os.path.join(_HERE, "_verify_output.txt"), "w") as f:
        f.write("\n".join(lines) + "\n")
    return dict(codec=ok1, add_byte=okv, add_word=okw, bit_index=okbi,
                icmp_ult=oku, controller=ok_smoke, program=okp)


# ==========================================================================
# 10. t2/fp32 新轮部署（nnobf-controller-action-v7, fp32-control-path-v1）
#     素材：engine-verify2/prot2.build/run-fL5D2U/work/attempt_01/program/
#     与第一轮的差异（全部源自新轮 runtime_0_main.c 用点比对）：
#       - 权重 1538445 float（const float，非 _Float16 模板）
#       - CONTROLLER_HEADS=204（76 selector + 64 option + 64 q_next），
#         selector rank 16；slot 解码改为 12 维线性码匹配（15×12 矩阵，
#         14 号=无效）；lane_delta 3 值 [-1,0,1]
#       - option conditioner 隐层 17（64→17→34）
#       - ragged 统一 ALU 扩为 8 term（XOR/OR/SUB/ADD/SHL-funnel/LSHR-funnel/
#         AND/SELECT，term 身份由 probe_ragged_terms 实测）
#       - hybrid-regions：region0(step0-3)=scanf==1 分支条件，region1
#         (step4-13)=y 计算；两段共享同一连续 Controller rollout
#     执行派发顺序（execute_range L3329-3436）：eff[3]token→eff[1]/[5]rename→
#     eff[6]halt→eff[4]store→eff[2]load→eff[7]copy→其余 ALU。
# ==========================================================================
T2_RUNTIME_DIR = os.environ.get(
    "ANANSI_T2_RUNTIME_DIR",
    "/Users/system-security/Desktop/re-agent-v2/re-run/anansi-20261027/"
    "artifacts/engine-verify2/prot2.build/run-fL5D2U/work/attempt_01/program/"
    "full_controller_runtime",
)
T2_WEIGHTS_C = os.path.join(T2_RUNTIME_DIR, "runtime_weights.c")
T2_MODULE_CACHE = os.path.join(_HERE, "_anansi_t2_module_weights.npz")
T2_N_WEIGHTS = 1538445        # nnobf_module_6475a8d2e2ab049e_weights 总长
T2_RAGGED_BASE = 43560        # NNOBF_W_…_0104：ALU 权重区基址
T2_RAGGED_SHAPES = [(64, 352, 32, 128), (96, 384, 32, 128), (96, 320, 64, 128),
                    (96, 384, 32, 128), (96, 320, 32, 128), (96, 320, 64, 128),
                    (64, 320, 32, 128), (64, 320, 32, 128)]
T2_RAGGED_OFFSETS = [
    [0, -1, -1, 22528, 22880, 146784, 147136, 158400, 158432, 162528, 162656, 179040, 179168, 183264],
    [183296, -1, -1, 220160, 220544, 368000, 368384, 380672, 380704, 384800, 384928, 401312, 401440, 405536],
    [405568, -1, -1, 436288, 436608, 539008, 539328, 559808, 559872, 563968, 564096, 580480, 580608, 584704],
    [584736, -1, -1, 621600, 621984, 769440, 769824, 782112, 782144, 786240, 786368, 802752, 802880, 806976],
    [807008, -1, -1, 837728, 838048, 940448, 940768, 951008, 951040, 955136, 955264, 971648, 971776, 975872],
    [975904, -1, -1, 1006624, 1006944, 1109344, 1109664, 1130144, 1130208, 1134304, 1134432, 1150816, 1150944, 1155040],
    [1155072, -1, -1, 1175552, 1175872, 1278272, 1278592, 1288832, 1288864, 1292960, 1293088, 1309472, 1309600, 1313696],
    [1313728, -1, -1, 1334208, 1334528, 1436928, 1437248, 1447488, 1447520, 1451616, 1451744, 1468128, 1468256, 1472352],
]
T2_LAYOUT = dict(
    ragged_M=(1515944, 1516072, (8, 16)),      # 0105：8×16 term 选择矩阵
    ctrl_w1=(1516072, 1522216, (96, 64)),      # 00fd：单塔第一层
    ctrl_b1=(1522216, 1522280, None),          # 00f0
    slot_codes=(1522280, 1522460, (15, 12)),   # 00fb：15×12 slot 线性码
    sel_w2l=(1522460, 1523484, (64, 16)),      # 00f8：selector 低秩左
    sel_w2r=(1523484, 1524700, (16, 76)),      # 00f9：selector 低秩右
    sel_lat_b=(1524700, 1524716, None),        # 00fa
    qnext_w2=(1524716, 1532908, (64, 128)),    # 00fc：option+qnext 直连层
    sel_heads_b=(1532908, 1532984, None),      # 00f1：selector 头偏置（76）
    qnext_heads_b=(1532984, 1533112, None),    # 00f1+76（128）
    cond_w=(1533112, 1535160, (64, 32)),       # 00f3
    cond_b=(1535160, 1535192, None),           # 00f2
    q_init=(1535192, 1535256, None),           # 00f6
    region_q=(1535256, 1536408, (18, 64)),     # 00f7：18 region 入口 q
    oc_w1=(1536408, 1537496, (64, 17)),        # 0102：option conditioner L1
    oc_b1=(1537496, 1537513, None),            # 00fe
    oc_w2=(1537513, 1538091, (17, 34)),        # 0103：option conditioner L2
    oc_b2=(1538091, 1538125, None),            # 00ff
    fmt_perm=(1538125, 1538253, (4, 32)),      # 0100：格式置换表
    fmt_sign=(1538253, 1538381, (4, 32)),      # 0101：格式符号表
    ct_perm=(1538381, 1538413, (1, 32)),       # 00f4
    ct_sign=(1538413, 1538445, (1, 32)),       # 00f5
)

LANE_DELTAS_V7 = [-1, 0, 1]     # 3 值（第一轮是 2 值）
CONTROLLER_HEADS_V7 = 204       # 76 selector + 64 option + 64 q_next
SELECTOR_HEADS_V7 = 76
SLOT_CODE_DIM = 12
SLOT_CHOICES_V7 = 15            # 0..13 有效，14 号=无效→-1
OPTION_HIDDEN_V7 = 17


def load_t2_module_weights(weights_c=T2_WEIGHTS_C):
    """装载 t2/fp32 新轮部署权重（codec + v7 controller + 8-term ragged ALU）。"""
    if os.path.exists(T2_MODULE_CACHE):
        z = np.load(T2_MODULE_CACHE)
        if "alu_region" in z.files:
            mw = {k: z[k] for k in z.files if k != "alu_region"}
            mw["ragged"] = _slice_ragged(z["alu_region"], T2_RAGGED_SHAPES,
                                         T2_RAGGED_OFFSETS)
            return mw
    w = parse_runtime_weights_c(weights_c)

    def sl(a, b, shape=None):
        x = w[a:b].astype(np.float64)
        return x.reshape(shape) if shape else x

    out = {}
    # codec 区域 [0,43560) 与第一轮逐偏移一致（新轮 008x 宏表同值）
    out["enc_w1"] = sl(0, 1024, (8, 128))
    out["enc_b1"] = sl(1024, 1152)
    out["enc_w2"] = sl(1152, 17536, (128, 128))
    out["enc_b2"] = sl(17536, 17664)
    out["enc_w3"] = sl(17664, 21760, (128, 32))
    out["enc_b3"] = sl(21760, 21792)
    out["dec_w1"] = sl(21792, 25888, (32, 128))
    out["dec_b1"] = sl(25888, 26016)
    out["dec_w2"] = sl(26016, 42400, (128, 128))
    out["dec_b2"] = sl(42400, 42528)
    out["dec_w3"] = sl(42528, 43552, (128, 8))
    out["dec_b3"] = sl(43552, 43560)
    for k, (a, b, sh) in T2_LAYOUT.items():
        out[k] = sl(a, b, sh)
    alu_region = w[T2_RAGGED_BASE:T2_N_WEIGHTS].astype(np.float64)
    out["ragged"] = _slice_ragged(alu_region, T2_RAGGED_SHAPES, T2_RAGGED_OFFSETS)
    np.savez(T2_MODULE_CACHE, **{k: v for k, v in out.items() if k != "ragged"},
             alu_region=alu_region)
    return out


class ControllerV7:
    """single-tower v7 Controller（204 heads，selector rank 16）。

    forward: input96 = q‖cond → dense(96→64) → tanh
             → selector 低秩头（64→16→76）与 option/qnext 直连头（64→128）。
    refresh_condition 与第一轮同式（q[0] 门控 token）。
    """

    def __init__(self, mw):
        self.w1, self.b1 = mw["ctrl_w1"], mw["ctrl_b1"]
        self.sel_w2l, self.sel_lat_b = mw["sel_w2l"], mw["sel_lat_b"]
        self.sel_w2r, self.sel_heads_b = mw["sel_w2r"], mw["sel_heads_b"]
        self.qnext_w2, self.qnext_heads_b = mw["qnext_w2"], mw["qnext_heads_b"]
        self.cond_w, self.cond_b = mw["cond_w"], mw["cond_b"]
        self.q_init = mw["q_init"]
        self.region_q = mw["region_q"]

    def forward(self, q, cond):
        inp = np.concatenate([q, cond])
        h = np.tanh(dense(inp, self.w1, self.b1))
        latent = dense(h, self.sel_w2l, self.sel_lat_b)
        sel = dense(latent, self.sel_w2r, self.sel_heads_b)
        rest = dense(h, self.qnext_w2, self.qnext_heads_b)
        return np.concatenate([sel, rest])

    def refresh_condition(self, q, token):
        gate = 1.0 if q[0] >= 0 else 0.0
        return np.tanh(dense(q, self.cond_w, self.cond_b) + gate * token)


def decode_action_v7(h, slot_codes):
    """nnobf_controller_step 的 v7 动作解码（runtime_0_main.c L2408-2467）。

    76 个 selector 头：4 个 slot 头各占 12 维线性码（15×12 矩阵点积取
    argmax，14 号=无效→-1，first-index-wins）；其余字段布局见
    L2439-2466（input_layout/span/delta×3/宽度×2/object/offset/access/
    alignment/ct）。slot_codes: (15,12)。
    """
    def slot(off):
        scores = slot_codes @ h[off:off + SLOT_CODE_DIM]
        s = int(np.argmax(scores))
        return -1 if s == SLOT_CHOICES_V7 - 1 else s

    oi = argmax_first(h[67:69])
    return dict(
        read_a=slot(0), read_b=slot(12), read_c=slot(24), write=slot(36),
        input_layout=argmax_first(h[48:52]),
        input_span=WIDTHS[argmax_first(h[52:54])],
        lane_delta_a=LANE_DELTAS_V7[argmax_first(h[54:57])],
        lane_delta_b=LANE_DELTAS_V7[argmax_first(h[57:60])],
        lane_delta_c=LANE_DELTAS_V7[argmax_first(h[60:63])],
        source_width=WIDTHS[argmax_first(h[63:65])],
        target_width=WIDTHS[argmax_first(h[65:67])],
        object_index=(-1 if oi == 1 else oi),
        byte_offset=BYTE_OFFSETS[argmax_first(h[69:71])],
        access_width=ACCESS_WIDTHS[argmax_first(h[71:73])],
        alignment=ALIGNMENTS[argmax_first(h[73:75])],
        control_transform=argmax_first(h[75:76]),
    )


def option_profile_v2(mw, option):
    """nnobf_option_profile（v2，隐层 17）—— runtime_0_main.c L2496-2523。

    option(64) → dense(64→17) → tanh → dense(17→34)：enabled / route[16](±1) /
    format / auxiliary_format / control_transform / effect[8]。
    """
    hidden = np.tanh(dense(option, mw["oc_w1"], mw["oc_b1"]))
    heads = dense(hidden, mw["oc_w2"], mw["oc_b2"])
    enabled = bool(heads[0] >= 0.0)
    route = [1 if heads[1 + i] >= 0.0 else -1 for i in range(OPTION_ROUTE_DIM)]
    fmt = argmax_first(heads[17:21])
    aux_fmt = argmax_first(heads[21:25])
    ct = argmax_first(heads[25:26])
    effect = heads[26:34]
    return enabled, route, fmt, aux_fmt, ct, effect


def probe_ragged_terms(mw, fmt_bank, codec, n=2048, seed=20261027):
    """对 ragged term 做字节函数探针，返回 {term: dict}。

    要点（实测教训）：
      - 多数 term 以取负形式存储（同第一轮 -SUB/-AND），必须同时试 ±1 系数，
        部署系数 = 唯一命中的那个；
      - SELECT 的条件输入是 i1（0/1 字节码），任意字节条件超出发行分布；
      - 移位 funnel 为 fixed-funnel 蒸馏（plan 用量 s∈{1,2}），仅对部分 s
        精确，记录 exact_s 集合；
      - ADD/SUB 的第三输入为进位/借位 ∈{0,1}，aux=出向进位/借位。
    返回 {t: dict(name=…, coef=±1, value_ok, aux_ok, n, exact_s=None)}。
    """
    rng = np.random.default_rng(seed)
    option_pos = np.ones(OPTION_DIM)          # 通道缩放恒 2.0
    zero_codes = np.tile(codec.encode_byte(0), (n, 1))
    report = {}
    for t in range(len(mw["ragged"])):
        tensors = mw["ragged"][t]
        inp = tensors["w1"].shape[0]
        outp = tensors["w3"].shape[1]
        found = None
        for coef in (1.0, -1.0):
            params = ragged_rebuild(tensors, fmt_bank, (0, 0, 0), 0, 0, coef)
            a = rng.integers(0, 256, n).astype(np.int64)
            b = rng.integers(0, 256, n).astype(np.int64)
            A, B = codec.encode_batch(a), codec.encode_batch(b)
            if inp <= 2 * EMBED:
                v, _ = ragged_byte(params, option_pos, A, B, zero_codes)
                vd = codec.decode_batch(v)
                for name, exp in (("XOR", a ^ b), ("OR", a | b), ("AND", a & b)):
                    ok = int((vd == exp).sum())
                    if ok == n:
                        found = dict(name=name, coef=coef, value_ok=ok,
                                     aux_ok=n, n=n, exact_s=None)
                        break
            elif outp > EMBED:
                c = rng.integers(0, 2, n).astype(np.int64)
                v, aux = ragged_byte(params, option_pos, A, B,
                                     codec.encode_batch(c))
                vd, ad = codec.decode_batch(v), codec.decode_batch(aux)
                for name, ev, ea in (
                    ("ADD", (a + b + c) & 0xff,
                     ((a + b + c) >= 256).astype(np.int64)),
                    ("SUB", (a - b - c) & 0xff,
                     (a < (b + c)).astype(np.int64)),
                ):
                    ok, ax = int((vd == ev).sum()), int((ad == ea).sum())
                    if ok == n and ax == n:
                        found = dict(name=name, coef=coef, value_ok=ok,
                                     aux_ok=ax, n=n, exact_s=None)
                        break
            else:
                # SELECT（i1 条件）与两个方向的 fixed 移位 funnel
                cond = rng.integers(0, 2, n).astype(np.int64)
                c_sel = rng.integers(0, 256, n).astype(np.int64)
                v, _ = ragged_byte(params, option_pos,
                                   codec.encode_batch(cond), B,
                                   codec.encode_batch(c_sel))
                ok = int((codec.decode_batch(v)
                          == np.where(cond == 1, b, c_sel)).sum())
                if ok == n:
                    found = dict(name="SELECT", coef=coef, value_ok=ok,
                                 aux_ok=n, n=n, exact_s=None)
                    break
                s = rng.integers(0, 8, n).astype(np.int64)
                v, _ = ragged_byte(params, option_pos, A, B,
                                   codec.encode_batch(s))
                vd = codec.decode_batch(v)
                for name, exp in (
                    ("SHIFT_SHL", ((a << s) | (b >> np.maximum(8 - s, 0))) & 0xff),
                    ("SHIFT_LSHR", (a >> s) | ((b << np.maximum(8 - s, 0)) & 0xff)),
                ):
                    hits = vd == exp
                    exact = [int(k) for k in range(8)
                             if (s == k).any() and hits[s == k].all()]
                    if exact:
                        found = dict(name=name, coef=coef,
                                     value_ok=int(hits[np.isin(s, exact)].sum()),
                                     aux_ok=n, n=int(np.isin(s, exact).sum()),
                                     exact_s=exact)
                        break
            if found:
                break
        if not found:
            found = dict(name="?", coef=0, value_ok=0, aux_ok=0, n=n, exact_s=None)
        report[t] = found
    return report


class ProgramReplayT2:
    """重放 t2/fp32 新轮 hybrid-regions 部署程序（批量 N 个样本）。

    与第一轮 ProgramReplay 的差别：
      - 动作程序不再硬编码，而是跑 v7 Controller rollout（17 步连续 q 链，
        region0[step0-3] 与 region1[step4-16] 共享同一 rollout——对应 C 的
        execute_range(0,4)+execute_range(4,13) 顺序拼接）；
      - 初始常量/live-in 槽位从 module_plan.json initial_values 读取；
      - LOAD 从镜像内存（sync_in 导入的 x 四字节）取 canonical 码再按
        option format 折叠；
      - 效果派发按 v7 顺序（eff[3]/[1]/[5]/[6]/[4]/[2]/[7]/ALU）；
      - 边界导出：region0 导 slot10(i1)=分支条件，region1 导 slot11(i32)
        =返回值；scanf 失败（r≠1）时按 t2.c 语义返回 99。
    """

    def __init__(self, mw, codec, fmt_bank, ctrl, plan):
        self.mw, self.codec, self.fmt, self.ctrl = mw, codec, fmt_bank, ctrl
        self.plan = plan
        p = plan["plans"][0]
        self.steps = p["steps"]
        self.initial_values = p["initial_values"]
        self.boundary = {v["logical_width"]: v["slot"] for v in p["boundary_values"]}
        self.n_steps = len(self.steps)

    def run(self, scanf_results, xs, verbose=False):
        """scanf_results/xs: (N,) uint。返回 (exit_codes (N,) uint32, trace)。"""
        N = len(xs)
        codec, fmtb, ctrl, mw = self.codec, self.fmt, self.ctrl, self.mw
        E0 = codec.encode_byte(0)

        def word_bytes(byte_lanes, fmt=0):
            lanes = np.zeros((N, MAX_BYTES, EMBED))
            for i in range(MAX_BYTES):
                lanes[:, i, :] = codec.encode_batch(byte_lanes[i])
            return Word(lanes, fmt, domain=0)

        def word_u64(values):
            v = np.asarray(values, dtype=np.uint64)
            return word_bytes([(v >> (8 * i)) & 0xff for i in range(MAX_BYTES)])

        # ---- call_begin：初始常量（runtime_0_main.c L3515-3551，取自 plan）----
        slots = [None] * 16
        for iv in self.initial_values:
            if iv["kind"] != "constant":
                continue
            cv = np.full(N, int(iv["constant_value"]), dtype=np.uint64)
            slots[iv["slot"]] = word_u64(cv)
        live_in = next(iv for iv in self.initial_values if iv["kind"] == "live-in")
        # 边界 case1：word_encode(frame[2]=scanf 返回值, 32) → live-in 槽
        slots[live_in["slot"]] = word_u64(np.asarray(scanf_results, dtype=np.uint64))
        # 边界 case2：sync_in_range(obj0, x 的 4 字节) → 镜像内存（canonical）
        mem = np.zeros((N, MAX_BYTES, EMBED))
        xv = np.asarray(xs, dtype=np.uint64)
        for i in range(MAX_BYTES):
            mem[:, i, :] = codec.encode_batch((xv >> (8 * i)) & 0xff)

        # ---- Controller rollout（17 步连续；q 链与数据无关，动作固定）----
        q = ctrl.q_init.copy()
        cond = ctrl.refresh_condition(q, E0)
        trace = []
        for step in range(self.n_steps):
            h = ctrl.forward(q, cond)
            action = decode_action_v7(h, mw["slot_codes"])
            option = h[SELECTOR_HEADS_V7:SELECTOR_HEADS_V7 + OPTION_DIM]
            q = np.where(h[SELECTOR_HEADS_V7 + OPTION_DIM:CONTROLLER_HEADS_V7] >= 0,
                         4.0, -4.0)
            en, route, fmt, aux_fmt, ct, eff = option_profile_v2(mw, option)
            term, coef = ragged_choose(mw, route)
            rec = dict(step=step, action=action, fmt=fmt, aux_fmt=aux_fmt,
                       term=term, coef=coef, effect=float(eff.max()), branch=None)
            trace.append(rec)
            if verbose:
                print(f"  step{step:2d}: r{action['read_a']},{action['read_b']},"
                      f"{action['read_c']}→w{action['write']} "
                      f"lay={action['input_layout']} span={action['input_span']} "
                      f"lda/b/c={action['lane_delta_a']},{action['lane_delta_b']},"
                      f"{action['lane_delta_c']} sw={action['source_width']} "
                      f"tw={action['target_width']} fmt={fmt}/{aux_fmt} "
                      f"term={term} coef={coef:+.0f} effmax={eff.max():+.2f}")

            def route_lanes(W_, delta):
                """nnobf_route_word_lanes（L1621-1637）—— 仿射 byte-lane 路由。"""
                if delta == 0 and action["input_span"] == action["source_width"]:
                    return W_
                lanes = width_bytes(action["source_width"])
                out = np.zeros((N, MAX_BYTES, EMBED))
                fz = fmtb.apply(codec.encode_byte(0), W_.fmt, False)
                for d in range(lanes):
                    s = d + delta
                    if 0 <= s < width_bytes(action["input_span"]):
                        out[:, d, :] = W_.lanes[:, s, :]
                    else:
                        out[:, d, :] = fz
                return Word(out, W_.fmt, W_.domain)

            # ---- 效果派发（execute_range L3329-3436 的 v7 顺序）----
            if eff[3] >= 0:      # token 保持（本程序未触发）
                raise NotImplementedError("token-keep not exercised by this plan")
            if eff[1] >= 0 or eff[5] >= 0:   # RENAME（本程序未触发）
                raise NotImplementedError("RENAME not exercised by this plan")
            if eff[6] >= 0:      # HALT
                rec["branch"] = "HALT"
                break
            if eff[4] >= 0:      # STORE（本程序未触发）
                raise NotImplementedError("STORE not exercised by this plan")
            if eff[2] >= 0:      # LOAD（L3373-3393）：镜像内存 → option format
                rec["branch"] = "LOAD"
                loaded = Word(mem.copy(), 0, domain=0)
                if fmt:
                    loaded.lanes = fmtb.apply(loaded.lanes, fmt, False)
                    loaded.fmt = fmt
                slots[action["write"]] = loaded
                cond = ctrl.refresh_condition(q, E0)
                continue
            if eff[7] >= 0:      # COPY/TRUNC/ZEXT（本程序未触发）
                raise NotImplementedError("COPY not exercised by this plan")

            # ---- ALU 动作（L3437-3484）----
            rec["branch"] = "ALU"
            A = slots[action["read_a"]]
            B = slots[action["read_b"]]
            ic = action["read_c"]
            Ar = route_lanes(A, action["lane_delta_a"])
            Br = route_lanes(B, action["lane_delta_b"])
            # read_c<0 → canonical 零词（C word_zero，L3456）
            Cw = Word(np.tile(E0, (N, MAX_BYTES, 1)), 0, 1)
            if ic is not None and ic >= 0:
                Cw = route_lanes(slots[ic], action["lane_delta_c"])
            width = action["source_width"]
            need_aux = width > 1 or action["target_width"] == 1
            out, aux = option_shared_alu(
                mw, fmtb, codec, route, option, action["input_layout"],
                Ar, Br, Cw, width, fmt, aux_fmt, need_aux)
            # ICMP 降级：target i1 且源宽 >1 → 取辅助通道（最终借位）
            if action["target_width"] == 1 and width > 1:
                out = Word(np.tile(codec.encode_byte(0), (N, MAX_BYTES, 1)),
                           0, domain=1)
                out.lanes[:, 0, :] = aux
                out.fmt = aux_fmt
            slots[action["write"]] = out
            # control = E(0)（ct 恒 0 → L3221 else 分支）
            cond = ctrl.refresh_condition(q, E0)

        # ---- 边界导出：region0 slot(i1)=分支条件；region1 slot(i32)=返回值 ----
        def decode_slot(slot, width):
            w = slots[slot]
            canon = fmtb.apply(w.lanes, w.fmt, True) if w.fmt else w.lanes
            v = codec.decode_batch(canon[:, 0, :])
            if width > 8:
                for i in range(1, width_bytes(width)):
                    v = v | (codec.decode_batch(canon[:, i, :]) << (8 * i))
            return v

        branch = decode_slot(self.boundary[1], 1)       # (r == 1) ?
        retval = decode_slot(self.boundary[32], 32)     # y & 0xff
        exit_code = np.where(branch == 1, retval & 0xffffffff, 99)
        return exit_code.astype(np.uint32), trace


if __name__ == "__main__":
    verify()
