#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ANANSI t2/fp32 新轮 —— 三方一致性对拍驱动。

三方 = ① native C 真值（t2.c 编译运行） ② 被保护二进制实测退出码
（exit_codes.tsv prot 列） ③ 本仓 Python 神经重放（neural_core.py
ControllerV7 + 8-term ragged ALU 全管线）。

素材（engine-verify2）：
  - prot2.build/run-fL5D2U/work/attempt_01/program/module_plan.json
    （17 步动作程序，nnobf-neural-ir-module-v2 / action-v7）
  - 同目录 full_controller_runtime/runtime_weights.c（float[1538445]，
    fp32-control-path-v1 —— 与第一轮 _Float16[1134063] 不同）
  - exit_codes.tsv（51 行 input\tnative_exit\tprot_exit）
  - t2.c：y=x+0x1234; y^=x>>2; y=(y<<1)|(y&1); if(y<100) y+=7;
    return y%256

运行：python3 verify_t2.py   （依赖同目录 neural_core.py + numpy）
"""

import json
import os
import sys

import numpy as np

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import neural_core as nc  # noqa: E402

BASE = os.environ.get(
    "ANANSI_VERIFY2_DIR",
    "/Users/system-security/Desktop/re-agent-v2/re-run/anansi-20261027/"
    "artifacts/engine-verify2",
)
PLAN_PATH = os.path.join(
    BASE, "prot2.build/run-fL5D2U/work/attempt_01/program/module_plan.json")
TSV_PATH = os.path.join(BASE, "exit_codes.tsv")
README_PATH = os.path.join(_HERE, "README-neural.md")
SECTION_TITLE = "三方对拍验证（t2/fp32 新轮）"

# plan 操作 → (term 探针名, 期望 ternary/input_layout)
OP_SPEC = {
    "ICMP_ULT": ("SUB", 0),
    "ADD": ("ADD", 0),
    "AND": ("AND", 0),
    "OR": ("OR", 0),
    "XOR": ("XOR", 0),
    "SELECT": ("SELECT", 1),
    "SHIFT_SHL": ("SHIFT_SHL", 2),
    "SHIFT_LSHR": ("SHIFT_LSHR", 2),
    "LOAD": (None, None),
}


def t2_reference(x):
    """t2.c 语义参考（仅用于不一致时的归因诊断，不进对拍表）。"""
    y = (x + 0x1234) & 0xFFFFFFFF
    y ^= (x >> 2) & 0xFFFFFFFF
    y = ((y << 1) | (y & 1)) & 0xFFFFFFFF
    if y < 100:
        y = (y + 7) & 0xFFFFFFFF
    return y & 0xFF


def cross_check_plan(trace, plan_steps, probe):
    """rollout 解码动作 vs module_plan.json 17 步动作程序，逐字段比对。

    比对项：read_a/b/c、write、lane_delta×3、input_span、source_width、
    target_width、ternary(input_layout)、效果分支、（ALU 步）term 身份+
    部署系数、（LOAD 步）object/byte_offset/access_width。
    返回 (mismatch 描述列表, 逐步对照行)。
    """
    mism, lines = [], []
    for rec, ps in zip(trace, plan_steps):
        a, step = rec["action"], rec["step"]
        op = ps["operation"]
        md = ps.get("metadata", {})
        ins = ps["input_slots"]
        tw = 1 if ps["value_type_id"] == "i1" else 32
        want = dict(
            read_a=ins[0] if len(ins) > 0 else -1,
            read_b=ins[1] if len(ins) > 1 else -1,
            read_c=ins[2] if len(ins) > 2 else -1,
            write=ps["output_slot"],
            lane_delta_a=md.get("lane_delta_a", 0),
            lane_delta_b=md.get("lane_delta_b", 0),
            lane_delta_c=md.get("lane_delta_c", 0),
            source_width=ps["source_width"],
            target_width=tw,
        )
        bad = [f"{k}: plan={v} rollout={a[k]}"
               for k, v in want.items() if a[k] != v]
        term_name, want_lay = OP_SPEC[op]
        if op == "LOAD":
            if rec["branch"] != "LOAD":
                bad.append(f"branch: plan=LOAD rollout={rec['branch']}")
            else:
                addr = ps.get("address") or {}
                if a["object_index"] != 0:
                    bad.append(f"object: plan=0 rollout={a['object_index']}")
                if a["byte_offset"] != addr.get("constant_offset", 0):
                    bad.append(f"offset: plan={addr.get('constant_offset')}"
                               f" rollout={a['byte_offset']}")
                if a["access_width"] != 4:
                    bad.append(f"access: plan=4 rollout={a['access_width']}")
        else:
            if rec["branch"] != "ALU":
                bad.append(f"branch: plan=ALU rollout={rec['branch']}")
            else:
                pr = probe[rec["term"]]
                if term_name and pr["name"] != term_name:
                    bad.append(f"term: plan_op={op}→{term_name}"
                               f" rollout=t{rec['term']}={pr['name']}")
                if pr["coef"] and rec["coef"] != pr["coef"]:
                    bad.append(f"coef: probe={pr['coef']:+.0f}"
                               f" rollout={rec['coef']:+.0f}")
                if a["input_layout"] != want_lay:
                    bad.append(f"input_layout: plan={want_lay}"
                               f" rollout={a['input_layout']}")
        if a["input_span"] != ps["source_width"]:
            bad.append(f"input_span: plan={ps['source_width']}"
                       f" rollout={a['input_span']}")
        mism.extend(f"step{step}({op}): {b}" for b in bad)
        lines.append(
            f"    step{step:2d} {op:11s} r[{a['read_a']},{a['read_b']},"
            f"{a['read_c']}]→w{a['write']} d({a['lane_delta_a']},"
            f"{a['lane_delta_b']},{a['lane_delta_c']}) sw={a['source_width']:2d}"
            f" tw={a['target_width']:2d} lay={a['input_layout']}"
            f" fmt={rec['fmt']}/{rec['aux_fmt']} term=t{rec['term']}"
            f"={probe[rec['term']]['name']} coef={rec['coef']:+.0f}"
            f" {rec['branch']}")
    return mism, lines


def main():
    lines = []

    def P(s=""):
        print(s)
        lines.append(s)

    P("=" * 74)
    P("ANANSI t2/fp32 新轮 三方对拍 —— native C vs 被保护二进制实测 vs Python 神经重放")
    P("=" * 74)

    # ---- 素材装载 ----
    plan = json.load(open(PLAN_PATH))
    plan_steps = plan["plans"][0]["steps"]
    rows = [ln.split("\t") for ln in open(TSV_PATH).read().splitlines()
            if ln.strip()]
    inputs = np.array([int(r[0]) for r in rows], dtype=np.uint64)
    native = np.array([int(r[1]) for r in rows], dtype=np.int64)
    prot = np.array([int(r[2]) for r in rows], dtype=np.int64)
    assert len(rows) == 51, f"exit_codes.tsv 行数 {len(rows)} != 51"
    assert len(plan_steps) == 17, f"module_plan 步数 {len(plan_steps)} != 17"

    mw = nc.load_t2_module_weights()
    codec = nc.Codec(mw)
    fmt_bank = nc.FormatBank(mw)
    ctrl = nc.ControllerV7(mw)
    P(f"[0] 权重源: {nc.T2_WEIGHTS_C}")
    P(f"    float[{nc.T2_N_WEIGHTS}]（fp32-control-path-v1，certification"
      f" deployment_quantization.passed）")
    P(f"    plan: {os.path.basename(PLAN_PATH)}（17 steps, schema "
      f"{plan['schema']}, action {plan['plans'][0]['controller_action_schema']}）")
    P(f"    对照真值: exit_codes.tsv（{len(rows)} 行 input/native/prot）")

    # ---- [1] ragged term 身份探针 ----
    probe = nc.probe_ragged_terms(mw, fmt_bank, codec)
    P(f"[1] 8-term ragged ALU 字节函数探针（canonical 码制, ±1 系数扫描, "
      f"每 term 2048 随机样本）:")
    unknown = 0
    for t in sorted(probe):
        r = probe[t]
        inp, hid, outp, ref = nc.T2_RAGGED_SHAPES[t]
        if r["name"] == "?":
            unknown += 1
        note = ""
        if r["exact_s"]:
            note = (f"（fixed-funnel，s∈{r['exact_s']} 内 value "
                    f"{r['value_ok']}/{r['n']} 精确；plan 用量 s=1/2）")
        elif r["name"] != "?":
            note = f"，value {r['value_ok']}/{r['n']} aux {r['aux_ok']}/{r['n']}"
        P(f"    t{t} ({inp},{hid},{outp},{ref}) = {r['name']:11s} "
          f"部署系数 {r['coef']:+.0f}{note}")
    if unknown:
        P(f"    !! {unknown} 个 term 身份未识别，交叉检查将失真")

    # ---- [2] Python 神经重放（51 行批量，含 rollout 交叉检查）----
    replay = nc.ProgramReplayT2(mw, codec, fmt_bank, ctrl, plan)
    scanf_ok = np.ones(len(rows), dtype=np.uint64)  # 51 行 scanf 均成功
    py_exit, trace = replay.run(scanf_ok, inputs, verbose=False)
    P(f"[2] Controller rollout（v7, 204 heads, q_init 连续 17 步）"
      f"vs module_plan 动作程序:")
    mism, plan_lines = cross_check_plan(trace, plan_steps, probe)
    for ln in plan_lines:
        P(ln)
    if mism:
        P(f"    ✗ 不吻合 {len(mism)} 处:")
        for m in mism:
            P(f"      - {m}")
    else:
        P(f"    ✓ 17/17 步逐字段吻合（slots/lane_delta/宽度/ternary/"
          f"LOAD 地址/term 身份+部署系数）—— rollout 与引擎计划程序一致")

    # ---- [3] 三方对拍表 ----
    P(f"[3] 三方对拍（input | native | prot2 实测 | python 重放 | 一致?）:")
    all_ok = 0
    diffs = []
    for i, (x, nv, pv, y) in enumerate(zip(inputs, native, prot, py_exit)):
        ok = (int(nv) == int(pv) == int(y))
        all_ok += int(ok)
        if not ok:
            diffs.append(i)
        P(f"    {int(x):>10d} | {nv:>3d} | {pv:>3d} | {y:>3d} | "
          f"{'一致' if ok else '不一致'}")
    np_ok = int((native == py_exit).sum())
    pr_ok = int((prot == py_exit).sum())
    npr_ok = int((native == prot).sum())

    # ---- [4] 汇总 ----
    P("[4] 汇总:")
    P(f"    三方全一致: {all_ok}/{len(rows)}")
    P(f"    native==prot2 实测: {npr_ok}/{len(rows)}（引擎产物端到端保真）")
    P(f"    python==native:    {np_ok}/{len(rows)}（参考实现 vs C 真值）")
    P(f"    python==prot2:     {pr_ok}/{len(rows)}（参考实现 vs 保护产物）")
    if diffs:
        P(f"    ✗ 不一致行号 {diffs}，逐行归因（t2.c 语义参考 ref(x)）:")
        for i in diffs:
            ref = t2_reference(int(inputs[i]))
            P(f"      input={int(inputs[i])} native={int(native[i])} "
              f"prot={int(prot[i])} python={int(py_exit[i])} ref={ref}"
              f"（python==ref → 引擎侧差异；python!=ref → 重放/权重/精度差异）")
        cause = ("重放与 t2.c 语义一致但与实测不符" if all(
            int(py_exit[i]) == t2_reference(int(inputs[i])) for i in diffs)
            else "Python 重放存在偏差（权重装载/动作解释/码制/浮点精度）")
        P(f"    归因: {cause}")
    else:
        P("    ✓ 51/51 全一致 —— Python 神经重放与 native C、被保护二进制实测")
        P("      在端到端行为上三方等价；参考实现与新轮 fp32 引擎产物互证。")
    P("=" * 74)

    # ---- 写产物 + 追加 README ----
    with open(os.path.join(_HERE, "_verify_t2_output.txt"), "w") as f:
        f.write("\n".join(lines) + "\n")
    section = ("\n\n---\n\n## 8. " + SECTION_TITLE + "\n\n```text\n"
               + "\n".join(lines) + "\n```\n")
    readme = open(README_PATH).read()
    marker = "\n\n---\n\n## 8. " + SECTION_TITLE
    if marker in readme:
        readme = readme[:readme.index(marker)]
    with open(README_PATH, "w") as f:
        f.write(readme + section)
    print(f"[i] 输出已写 _verify_t2_output.txt 并追加 README-neural.md"
          f"（章节「{SECTION_TITLE}」）")
    return 0 if all_ok == len(rows) and not mism else 1


if __name__ == "__main__":
    sys.exit(main())
