﻿/* guard_deny_attach.c — SDK 反真机调试守卫 v2（静默腐化 + 周期复查）。
 *
 * v2 改动（对照攻击报告 P1-1.2/P1-1.3）：
 *   1. 构造器检测到 TracerPid 不再 exit(173)（响亮暴露），而是向
 *      __sdk_guard_poison 写入毒值 → churn 演化偏移 → VM 计算垃圾
 *   2. 新增 __sdk_tracer_check()：轻量周期复查函数，guards_ir.py 的
 *      churn 泳道在每次受保护函数调用时调用它，结果混入 churn 输入
 *      → 攻击者全程被跟踪时，每一步计算都在悄悄偏移
 *   3. prctl(PR_SET_DUMPABLE, 0) 无条件执行（deny-attach 语义不变）
 *
 * 攻击者视角变化：
 *   旧版：patch 1 字节 → 反调试永久解除 → 干净 trace → lift 正确算法
 *   新版：patch 构造器 → 但 __sdk_tracer_check 在每次调用时仍会检测
 *         → 不退出（静默）→ churn 被毒化 → lift 出的算法是错的
 *         → 求出的 key 在真机必然失败
 */

/* ---- 裸 syscall 基元（x86-64）---- */
static long __sdk_sys3(long n, long a, long b, long c)
{
    long r;
    __asm__ volatile("syscall"
                     : "=a"(r)
                     : "a"(n), "D"(a), "S"(b), "d"(c)
                     : "rcx", "r11", "memory");
    return r;
}

#define SDK_SYS_read       0
#define SDK_SYS_openat     257
#define SDK_SYS_close      3
#define SDK_SYS_prctl      157
#define SDK_SYS_exit_group 231

#define SDK_AT_FDCWD       (-100)
#define SDK_O_RDONLY       0
#define SDK_PR_SET_DUMPABLE 4
#define SDK_PR_GET_DUMPABLE 3

/* 毒化标志：非零 = 检测到攻击（TracerPid 非零 / seal 不匹配 / 其它）
 * churn 函数的 guards_ir 入口会将此值 XOR 进 churn 输入 delta */
int __sdk_guard_poison = 0;

/* 前向声明 */
int __sdk_tracer_check(void);

/* v0.5 P1-B: syscall 效果自验证——prctl(SET_DUMPABLE,0) 后立刻
 * prctl(GET_DUMPABLE) 验证返回 0。攻击者把 syscall 立即数从 prctl(157)
 * 改成 getpid(39) 时，两个调用都返回 PID（非零）→ 被检出 → 毒化。
 * 直接封死 v0.4 攻击中"改 1 字节立即数让 prctl 变 getpid"的手法。 */
static void __sdk_prctl_verified(int flag)
{
    __sdk_sys3(SDK_SYS_prctl, SDK_PR_SET_DUMPABLE, flag, 0);
    long got = __sdk_sys3(SDK_SYS_prctl, SDK_PR_GET_DUMPABLE, 0, 0);
    if (got != flag) {
        /* syscall 被篡改（立即数被改）→ 毒化 */
        __sdk_guard_poison |= (int)(got << 8) | 0x50;  /* 'P'=0x50 标记 prctl */
    }
}

/* （声明已移至文件头部，此处不再重复定义） */

static int __sdk_hex_digit(char c)
{
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

static long __sdk_parse_tracer_pid(const char *buf, unsigned long len)
{
    static const char key[] = "TracerPid:";
    unsigned long i, j;
    for (i = 0; i + sizeof(key) <= len; i++) {
        for (j = 0; j < sizeof(key) - 1; j++)
            if (buf[i + j] != key[j]) break;
        if (j == sizeof(key) - 1) {
            unsigned long p = i + j;
            while (p < len && (buf[p] == ' ' || buf[p] == '\t')) p++;
            long v = 0, neg = 0, any = 0;
            if (p < len && buf[p] == '-') { neg = 1; p++; }
            while (p < len) {
                int d = __sdk_hex_digit(buf[p]);
                if (d < 0) break;
                v = v * 10 + d;
                any = 1;
                p++;
            }
            return any ? (neg ? -v : v) : 0;
        }
    }
    return 0;
}

/* v0.5 P1-A: 0xCC 断点扫描——扫描自身代码区域的 INT3 断点字节。
 * 攻击者的 ptrace tracer 在"恢复-单步-重装"模式下，大部分时间
 * .text 中留有 0xCC 字节。本函数在每次 __sdk_tracer_check 时被调用，
 * 扫描自身及邻近代码 256 字节窗口，检出 → 毒化份额（不退出）。
 * 直接检测 v0.4 攻击中 tracer 的断点常驻行为。
 *
 * [261102 修正——结构性假阳性，wbp e2e 差分定位] 原实现的扫描窗口
 * 必然含合法 0xCC 字节：① self[i] == 0xCC 的比较立即数本身编码于
 * .text（cmp 编码含 0xCC 字节）；② 链接器对 .text.* 节间 16 字节
 * 对齐填充用 0xCC（实测 bp_scan 窗口 10 命中 = 1 自身立即数 + 9 填
 * 充；tracer_check 窗口 4 命中 = 3 填充 + 1 相邻代码）→ 每次干净
 * 运行恒命中 14 → __sdk_guard_poison = 0xE00CC 恒非零（fnv 校验
 * 8a87d227 = fnv(0xE00CC) 精确对应）→ arp 证据链误发射。窗口扫描
 * 无法区分结构 0xCC 与攻击植入（无运行时节边界信息），按 fail-open
 * 降级为无操作；断点检测面由 chame M3（.text 折哈希，ELF 模式）/
 * M5（int3 投递分歧 oracle）覆盖。 */
int __sdk_bp_scan(void)
{
    /* （结构性假阳性修正：见上方注记——扫描降级为无操作） */
    return 0;
}

/* ---- 周期复查（每次受保护函数调用时由 guards_ir churn 泳道调用）---- */
int __sdk_tracer_check(void)
{
    char buf[4096];
    long fd = __sdk_sys3(SDK_SYS_openat, SDK_AT_FDCWD,
                         (long)"/proc/self/status", SDK_O_RDONLY);
    if (fd < 0)
        return __sdk_guard_poison;      /* 读不到：返回当前毒化状态 */
    unsigned long got = 0;
    while (got < sizeof(buf) - 1) {
        long n = __sdk_sys3(SDK_SYS_read, fd, (long)(buf + got),
                            (long)(sizeof(buf) - 1 - got));
        if (n <= 0) break;
        got += (unsigned long)n;
    }
    __sdk_sys3(SDK_SYS_close, fd, 0, 0);
    buf[got] = '\0';

    long tp = __sdk_parse_tracer_pid(buf, got);
    /* [261102 修正——wbp 自探针白名单] PTRACE_TRACEME 自 trace 形态下
     * TracerPid == getppid() 恒非零（wbp stub 装载器 environment.probes
     * 的反调试自探针即此形态）。与 chame M2 白名单 2（runtime TU
     * __sdk_chame_tracer_poll）同一立场：父进程自 trace 形态不视为攻
     * 击证据；gdb attach（tracer ≠ ppid）与 root tracer 仍检出。
     * 无白名单时 wbp packed 合法运行每次周期复查都把 poison 置为
     * ppid → arp 证据链全程误发射。 */
    if (tp != 0) {
        long ppid = __sdk_sys3(110 /* SYS_getppid */, 0, 0, 0);
        if (tp != ppid) {
            /* 静默腐化：不退出，向毒化标志注入 TracerPid 值
             * → churn 演化偏移 → VM 计算垃圾 → lift 出的算法是错的 */
            __sdk_guard_poison = (int)tp;
        }
    }
    /* v0.5 P1-A: 0xCC 断点扫描（检测 ptrace tracer 的常驻断点） */
    __sdk_bp_scan();
    return __sdk_guard_poison;
}

/* ---- 运行时钩子（context_create 调用，once 幂等）---- */
static int __sdk_guard_done = 0;
/* CHAMÆLEON M1-M6 evidence boot（chame-antidebug v0.2 规格 §3.3）：
 * 挂在 TracerPid 检查之后、prctl(DUMPABLE,0) 之前——M4 的 fork
 * self-debugger attach-back 需要 dumpable 仍为 1。protect.py 在
 * --guards 含 chame-* 时以 -DNNOBF_GUARD_CHAME 激活（__sdk_chame_boot
 * 由 runtime TU 的 CHAME 证据单元定义，once 幂等）。 */
#ifdef NNOBF_GUARD_CHAME
void __sdk_chame_boot(void);
#define __SDK_CHAME_BOOT() __sdk_chame_boot()
#else
#define __SDK_CHAME_BOOT() ((void)0)
#endif
void __sdk_guard_boot(void)
{
    if (__sdk_guard_done) return;
    __sdk_guard_done = 1;
    /* 复用构造器逻辑：检查 + 静默毒化 + deny-attach */
    char buf[4096];
    long fd = __sdk_sys3(SDK_SYS_openat, SDK_AT_FDCWD,
                         (long)"/proc/self/status", SDK_O_RDONLY);
    if (fd < 0) {
        __SDK_CHAME_BOOT();
        __sdk_prctl_verified(0);
        return;
    }
    unsigned long got = 0;
    while (got < sizeof(buf) - 1) {
        long n = __sdk_sys3(SDK_SYS_read, fd, (long)(buf + got),
                            (long)(sizeof(buf) - 1 - got));
        if (n <= 0) break;
        got += (unsigned long)n;
    }
    __sdk_sys3(SDK_SYS_close, fd, 0, 0);
    buf[got] = '\0';
    if (__sdk_parse_tracer_pid(buf, got) != 0) {
        __sdk_guard_poison = 0x7FFFFFFF;
    }
    __SDK_CHAME_BOOT();
    __sdk_prctl_verified(0);
}

/* ---- 构造器（启动时一次性 + 无条件 deny-attach）---- */
static void __sdk_guard_init(void) __attribute__((constructor(101)));

static void __sdk_guard_init(void)
{
    char buf[4096];
    long fd = __sdk_sys3(SDK_SYS_openat, SDK_AT_FDCWD,
                         (long)"/proc/self/status", SDK_O_RDONLY);
    if (fd < 0) {
        /* 读不到：仍设 dumpable=0，不毒化（保守）；chame 探测先于 prctl */
        __SDK_CHAME_BOOT();
        __sdk_prctl_verified(0);
        return;
    }
    unsigned long got = 0;
    while (got < sizeof(buf) - 1) {
        long n = __sdk_sys3(SDK_SYS_read, fd, (long)(buf + got),
                            (long)(sizeof(buf) - 1 - got));
        if (n <= 0) break;
        got += (unsigned long)n;
    }
    __sdk_sys3(SDK_SYS_close, fd, 0, 0);
    buf[got] = '\0';

    if (__sdk_parse_tracer_pid(buf, got) != 0) {
        /* v2 静默腐化：不退出，毒化 churn → 后续所有 VM 计算偏移 */
        __sdk_guard_poison = 0x7FFFFFFF;
    }
    /* CHAMÆLEON §3.3 序：TracerPid 检查 → M4/M6/M5/M3 探测（须先于
     * prctl——M4 attach-back 需 dumpable=1）→ prctl */
    __SDK_CHAME_BOOT();
    /* 无条件 deny-attach：摘除后续 ptrace 挂载能力 */
    __sdk_prctl_verified(0);
}
