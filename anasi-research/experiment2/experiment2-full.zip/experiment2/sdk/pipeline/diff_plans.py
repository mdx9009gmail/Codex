#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""多函数计划对齐差分器：我方 module_plan vs 引擎真值 module_plan。

逐函数对比 steps/regions/slots（+步骤序列摘要），输出对齐报告。
用法：python3 diff_plans.py MY.json ORIG.json [--verbose N]
"""

import argparse
import json
import sys


def step_sig(s):
    """步骤签名（忽略 slot 编号差异的可选模式由调用方决定）。"""
    md = s.get("metadata") or {}
    parts = [s["operation"]]
    if s.get("address"):
        a = s["address"]
        parts.append("@" + a["object_id"].split(":")[-1])
    if md.get("predicate"):
        parts.append("pred:" + str(md["predicate"]))
    if md.get("stage"):
        parts.append("st:" + str(md["stage"]))
    return " ".join(parts)


def cmp_plan(mine, orig, verbose=0):
    issues = []
    ms, os_ = mine["steps"], orig["steps"]
    mr, orr = mine["regions"], orig["regions"]
    if len(ms) != len(os_):
        issues.append(f"steps {len(ms)} != {len(os_)}")
    if len(mr) != len(orr):
        issues.append(f"regions {len(mr)} != {len(orr)}")
    mvc = mine["context"]["temp_slot_capacity"]
    ovc = orig["context"]["temp_slot_capacity"]
    if mvc != ovc:
        issues.append(f"v_slots {mvc} != {ovc}")
    mo = [o["object_id"] for o in mine["context"]["persistent_objects"]]
    oo = [o["object_id"] for o in orig["context"]["persistent_objects"]]
    if mo != oo:
        only_m = [x for x in mo if x not in oo]
        only_o = [x for x in oo if x not in mo]
        issues.append(f"objects {len(mo)} != {len(oo)}"
                      f" (mine-only {len(only_m)}, orig-only {len(only_o)})")

    # 步骤序列 diff（LCS 摘要：首个分歧点 + 操作计数对比）
    if not issues or verbose:
        n = min(len(ms), len(os_))
        first_div = None
        for i in range(n):
            if step_sig(ms[i]) != step_sig(os_[i]):
                first_div = i
                break
        if first_div is None and len(ms) == len(os_):
            pass                      # 序列一致
        elif first_div is not None and verbose:
            issues.append(f"first step divergence @{first_div}: "
                          f"mine[{step_sig(ms[first_div])}] vs "
                          f"orig[{step_sig(os_[first_div])}]")
        elif first_div is None and len(ms) != len(os_):
            # 前缀一致，长度不同
            longer = "mine" if len(ms) > len(os_) else "orig"
            issues.append(f"common prefix {n}, {longer} has extra steps")
    # 区域序列 diff
    if len(mr) == len(orr) and not issues:
        for a, b in zip(mr, orr):
            if [a["action_start"], a["action_count"]] != \
                    [b["action_start"], b["action_count"]]:
                issues.append(f"region {a['index']} exec "
                              f"[{a['action_start']},{a['action_count']}] != "
                              f"[{b['action_start']},{b['action_count']}]")
                break
    if verbose and (issues or verbose > 1):
        # 步骤级并排（前 verbose*40 步）
        for i in range(min(n if 'n' in dir() else 0, 0)):
            pass
    return issues


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mine")
    ap.add_argument("orig")
    ap.add_argument("--verbose", type=int, default=0)
    ap.add_argument("--function", default=None,
                    help="只看指定函数（默认全部）")
    args = ap.parse_args()

    m = json.load(open(args.mine))
    o = json.load(open(args.orig))
    mo = {p["function"]: p for p in m["plans"]}
    oo = {p["function"]: p for p in o["plans"]}

    n_exact = n_close = n_diff = 0
    for fn, op in oo.items():
        mp = mo.get(fn)
        if mp is None:
            print(f"MISSING  {fn}")
            n_diff += 1
            continue
        if args.function and fn != args.function:
            continue
        issues = cmp_plan(mp, op, verbose=args.verbose)
        ms = len(mp["steps"])
        osl = len(op["steps"])
        mr = len(mp["regions"])
        orr = len(op["regions"])
        if not issues:
            tag = "EXACT"
            n_exact += 1
        elif ms == osl and mr == orr:
            tag = "CLOSE"
            n_close += 1
        else:
            tag = "DIFF "
            n_diff += 1
        print(f"{tag} {fn:32s} steps {ms}/{osl} regions {mr}/{orr} "
              f"slots {mp['context']['temp_slot_capacity']}/"
              f"{op['context']['temp_slot_capacity']}"
              + ("  " + "; ".join(issues[:3]) if issues else ""))
        if args.verbose and issues:
            for x in issues[:args.verbose]:
                print("        ", x)
    print(f"\n== {n_exact} EXACT / {n_close} CLOSE / {n_diff} DIFF "
          f"(of {len(oo)})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
