﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ANANSI 引擎「运行时 C 代码生成器」复现（任务 A2）。

引擎侧（anansi-protect, base 0x100000）的生成链：
    FUN_002dde50 (runtime-generation 编排)
      ├─ FUN_0033a790 (.rodata 0x6eb000-0x730000 模板库 + @NNOBF_n@ 渲染)
      ├─ FUN_00346420 (runtime_0_main.c 主 TU + NNOBF_W_<tag>_<id> 宏块)
      ├─ FUN_002d7d70 → FUN_00335d80 / FUN_0034d2a0 / FUN_00397370
      │     (runtime_weights.c：fp32 直存 / fp16 _Float16+lazy-prepare /
      │      int8 / zlib-stream 变体)
      ├─ FUN_00367030 (module_plan.json → k_ 内核 + boundary_run 票号 case)
      └─ FUN_00301430 (certification.json)

本脚本复现其中 fp32 / fp16 两条路径（两轮真实构建实证）：
    轮1 (fp16): run-6qdudb, _Float16[1134063] + weights_prepare()
    轮2 (fp32): run-fL5D2U, const float[1538445]

权重存储布局（两轮逐位验证，算法可复算）：
    [12 个 codec 张量 (enc/dec, npz 键序)] + [alu_region 大块]
    alu_region = [ragged N 项 × (W1,B1,-,-,W2,B2,W3,B3,RW1,RB1,RW2,RB2,RW3,RB3)]
               + [controller 尾部 21 张量 (ragged_M..ct_sign)]
    数值格式 = '%.9g' + 无小数点补 '.0'（2,672,508 个字面量 0 失配）。

用法：
    python3 runtime_codegen.py --weights <module_weights.npz> \
        --profile runtime_codegen_data/profile_fp32_t2.json \
        --out OUT_DIR [--verify REAL_RUNTIME_DIR] [--tag-w HEX]

输入：权重 npz（codec 12 键 + alu_region，即 src-neural-wip/_anansi_*_module_weights.npz
形态）+ 轮 profile（tags/计划派生量/张量注册表）。tag 可用 --tag-* 覆盖（引擎侧 tag 为
build 会话随机值，见 notes-runtime-codegen.md §4）。
"""

import argparse
import json
import os
import re
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, 'runtime_codegen_data')

CODEC_KEYS = ['enc_w1', 'enc_b1', 'enc_w2', 'enc_b2', 'enc_w3', 'enc_b3',
              'dec_w1', 'dec_b1', 'dec_w2', 'dec_b2', 'dec_w3', 'dec_b3']

# ---------------------------------------------------------------------------
# CHAMÆLEON M1-M6 evidence 泳道（chame-antidebug v0.2）——路由 A 生成门控：
# protect.py --guards 含 chame-* 时传 --guard-evidence，boundary live-in
# commit / call_begin encoded 参数发射 `x ^ nnobf_guard_ev()` 形态（干净
# E≡0 恒等；E≠0 静默污染）。未传时发射基线形态（产物零扰动）。
# ---------------------------------------------------------------------------
_GUARD_EVIDENCE = [False]


def _ev(fmt, *args):
    """commit 行模板：@EV@ 占位 → 证据泳道开时替换为 XOR，关时删除。"""
    repl = ' ^ nnobf_guard_ev()' if _GUARD_EVIDENCE[0] else ''
    return fmt.replace('@EV@', repl, 1) % args


def chame_guard_block(owner):
    """CHAME 证据单元 C 块（<<CHAME_GUARD>> 占位符的替换文本）。

    结构（规格 §2-§4 的 anasi-nn 形态）：
      - 取证层（原生 syscall/asm，全 fail-open）：M2 TracerPid 轮询（K 节流
        + M4 自家 tracer 白名单）/ M3 .text 折哈希（boot 全量 + 每 boundary
        128B 轮转，期望 post-link 回填三联）/ M4 fork self-debugger 读 DR7
        （offsetof(struct user, u_debugreg[7])，attach 失败 fail-open）/
        M5 SIGTRAP handler 即密钥（rt_sigaction 裸 syscall + SA_RESTORER +
        K 个自植入 int3 检查点）/ M6 一致性 oracle（MXCSR.DAZ + DIV-flags
        建期标定）。
      - 折叠层（受 NN 保护）：路由 A = live-in/encoded 参数 commit XOR
        nnobf_guard_ev()（模板 boundary/call_begin 发射点，x^0==x 恒等）；
        路由 B = NNOBF_GUARD_SEED 时 ev 混入本 TU 初始常量潜码（xor-mask
        泳道开启时 protect.py 自动叠加，规格 D2）。
      - 证据总线 __sdk_ev：FNV-1a(lane_tag, raw) 派生 OR 累加，raw=0 →
        不动总线（干净不变量）；--guard-strict 可升级 exit 173（D4）。
      - owner=首个 TU 定义全局与函数；其余 TU extern 视图 + static inline。
        泳道子集/常量经 -DNNOBF_CHAME_* / -DNNOBF_{EV_POLL_K,TRAP_K,TRAP_C,
        TK_ROT0,ORACLE_DIVFLAGS} 编译期烘焙（protect.py 从 --guard-seed
        派生 + M6 现场标定，构建可复现）。
    """
    owner_def = '#define NNOBF_CHAME_OWNER 1' if owner else ''
    return r'''/* ==== CHAM<AE>LON M1-M6 evidence unit（chame-antidebug v0.2 融合）====
 * 两层模型（规格 2.1）：取证层（原生 syscall/asm，本块——能力矩阵把
 * syscall/信号/FP 屏障在 NN 外，别无选择）产出 64 位证据字；折叠层
 * （受 NN 保护）经路由 A/B 进数据流。契约：干净环境 __sdk_ev==0，
 * 输出与原生逐字节一致；被调试/被篡改 ev!=0，输出静默污染（无分支、
 * 无退出码变化——「fold the signal into state, never a branch」）。
 * fail-open：一切探测失败视为无证据（规格 2.4，保差分绿）。
 * 证据总线：raw 经 FNV-1a(lane_tag, raw) 派生后 OR 累加，泳道互不覆写；
 * raw==0 -> 派生 word==0（干净不变量，规格 3.4）。 */
#ifdef NNOBF_GUARD_CHAME
#include <stddef.h>
__OWNER_DEF__
#if defined(NNOBF_CHAME_HWBP) && defined(NNOBF_CHAME_OWNER)
#include <sys/user.h>   /* 仅取 struct user 定义（DR7 偏移，禁魔数） */
#endif
#ifdef NNOBF_CHAME_OWNER
volatile uint64_t __sdk_ev = 0;          /* 证据总线（BSS 零初始化=干净） */
volatile int __sdk_self_tracer = 0;      /* M4 探测子 pid（M2 白名单） */
volatile uint64_t __sdk_trap_acc = 0;    /* M5 handler 累加器 */
volatile uint64_t __sdk_trap_cnt = 0;    /* M5 handler 计数 */
/* M3 textkey 回填三联（非零初值 -> .data 文件背书，可 post-link 回填；
 * len==~0ull -> 未武装（未回填即无操作，fail-open）。ref 为窗口锚符号
 * （PIE 相对偏移）；expect 为期望折哈希（位于 .data，不在 .text 窗口内
 * ——无自引用循环）。 */
volatile int64_t __sdk_textkey_off = 1;
volatile uint64_t __sdk_textkey_len = 0xFFFFFFFFFFFFFFFFull;
volatile uint64_t __sdk_textkey_expect = 0xC0FFEE00C0FFEE01ull;
void __sdk_textkey_ref(void) {}

/* ---- 裸 syscall 基元（x86-64，自持无 libc；guard 单元同款）---- */
static long __sdk_c3(long n, long a, long b, long c)
{
    long r;
    __asm__ volatile("syscall" : "=a"(r) : "a"(n), "D"(a), "S"(b), "d"(c)
                     : "rcx", "r11", "memory");
    return r;
}
static long __sdk_c4(long n, long a, long b, long c, long d)
{
    long r;
    register long __r10 __asm__("r10") = d;
    __asm__ volatile("syscall" : "=a"(r) : "a"(n), "D"(a), "S"(b), "d"(c),
                                 "r"(__r10) : "rcx", "r11", "memory");
    return r;
}
#define __SDK_SYS_read       0
#define __SDK_SYS_write      1
#define __SDK_SYS_close      3
#define __SDK_SYS_rt_sigact  13
#define __SDK_SYS_pipe       22
#define __SDK_SYS_ptrace     101
#define __SDK_SYS_fork       57
#define __SDK_SYS_wait4      61
#define __SDK_SYS_getpid     39
#define __SDK_SYS_getppid    110
#define __SDK_SYS_openat     257
#define __SDK_SYS_exit_group 231
#define __SDK_AT_FDCWD       (-100L)
#define __SDK_O_RDONLY       0L
#define __SDK_PTRACE_ATTACH   16L
#define __SDK_PTRACE_DETACH   17L
#define __SDK_PTRACE_PEEKUSER 3L
#define __SDK_SIGTRAP 5

static void __sdk_ev_fold(uint64_t lane, uint64_t raw)
{
    if (raw == 0) return;                 /* 干净不变量：无证据即不动总线 */
    uint64_t h = 0xCBF29CE484222325ull;
    for (int i = 0; i < 8; ++i) {
        h ^= (lane >> (i * 8)) & 0xFF; h *= 0x100000001B3ull;
        h ^= (raw >> (i * 8)) & 0xFF;  h *= 0x100000001B3ull;
    }
    __sdk_ev |= h;
}

/* ---- M2：TracerPid 运行期轮询（对抗"读后 attach"；root tracer 纵深）---- */
static int __sdk_ch_hex(char c)
{
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}
static long __sdk_ch_tracer_pid(const char *buf, unsigned long len)
{
    static const char key[] = "TracerPid:";
    unsigned long i, j;
    for (i = 0; i + sizeof(key) <= len; i++) {
        for (j = 0; j < sizeof(key) - 1; j++)
            if (buf[i + j] != key[j]) break;
        if (j == sizeof(key) - 1) {
            unsigned long p = i + j;
            while (p < len && (buf[p] == ' ' || buf[p] == '\t')) p++;
            long v = 0, any = 0;
            while (p < len) {
                int d = __sdk_ch_hex(buf[p]);
                if (d < 0) break;
                v = v * 10 + d; any = 1; p++;
            }
            return any ? v : 0;
        }
    }
    return 0;
}
#ifdef NNOBF_CHAME_TRACER
static int __sdk_ev_poll_counter = 0;
static void __sdk_chame_tracer_poll(void)
{
    char buf[4096];
    long fd = __sdk_c3(__SDK_SYS_openat, __SDK_AT_FDCWD,
                       (long)"/proc/self/status", __SDK_O_RDONLY);
    if (fd < 0) return;                   /* fail-open：读不到即无证据 */
    unsigned long got = 0;
    while (got < sizeof(buf) - 1) {
        long n = __sdk_c3(__SDK_SYS_read, fd, (long)(buf + got),
                          (long)(sizeof(buf) - 1 - got));
        if (n <= 0) break;
        got += (unsigned long)n;
    }
    __sdk_c3(__SDK_SYS_close, fd, 0, 0);
    buf[got] = 0;
    long tp = __sdk_ch_tracer_pid(buf, got);
    if (tp == 0) return;
    /* 白名单 1：M4 自家探测 tracer（规格 4.4 交互 2，探测窗口内） */
    if (tp == (long)__sdk_self_tracer) return;
    /* 白名单 2：tracer == 自身父进程 = PTRACE_TRACEME 自 trace 形态
     * （wbp stub 装载器 environment.probes 的反调试自探针即此形态——
     * 实测 TRACEME 后 TracerPid==ppid 恒非零）。装载期 spawn-trace 归
     * deny-attach 构造期检查与 wbp 自身探针管辖；M2 增量价值按规格 4.2
     * 定为"读后 attach"（gdb attach 的 tracer 非本进程父）与 root
     * tracer（CAP_SYS_PTRACE 绕 dumpable=0）——两者均不等于 ppid，
     * 不受白名单影响。已知代价：父进程自 trace 形态对本泳道不可见
     * （CAPABILITIES 已知不设防项）。 */
    if (tp == __sdk_c3(__SDK_SYS_getppid, 0, 0, 0)) return;
    __sdk_ev_fold(0x4D32ull, (uint64_t)tp);
}
#endif

/* ---- M3：.text 哈希即密钥（软断点覆盖；期望 post-link 回填）----
 * 窗口 = __sdk_textkey_ref 相对偏移覆盖（protect.py 回填 .text 全节——
 * 受保护代码的可靠超集）。折定义（与回填侧逐位一致）：128B 切片 FNV-1a64
 * 逐一哈希后 XOR（含尾片）。boot 全量一次；运行期每 boundary 轮转重哈希
 * 1 片，全窗覆盖完成时折叠 delta=acc^expect（干净 0），累加器复位。 */
#define __SDK_TK_SLICE 128
static uint64_t __sdk_fnv1a64(const unsigned char *p, unsigned long n)
{
    uint64_t h = 0xCBF29CE484222325ull;
    for (unsigned long i = 0; i < n; ++i) { h ^= p[i]; h *= 0x100000001B3ull; }
    return h;
}
#ifdef NNOBF_CHAME_TEXTKEY
static uint64_t __sdk_tk_rot_acc = 0;
static uint64_t __sdk_tk_rot_done = 0;
static uint64_t __sdk_tk_rot_next = 0;
static int __sdk_tk_armed(void)
{
    return __sdk_textkey_len != 0 &&
           __sdk_textkey_len != 0xFFFFFFFFFFFFFFFFull;
}
static const unsigned char *__sdk_tk_window(void)
{
    return (const unsigned char *)&__sdk_textkey_ref + __sdk_textkey_off;
}
static uint64_t __sdk_tk_slices(void)
{
    return __sdk_textkey_len / __SDK_TK_SLICE +
           ((__sdk_textkey_len % __SDK_TK_SLICE) ? 1 : 0);
}
static unsigned long __sdk_tk_slice_len(uint64_t i)
{
    unsigned long len = __SDK_TK_SLICE;
    if (i * __SDK_TK_SLICE + len > __sdk_textkey_len)
        len = (unsigned long)(__sdk_textkey_len - i * __SDK_TK_SLICE);
    return len;
}
static void __sdk_chame_textkey_boot(void)
{
    if (!__sdk_tk_armed()) return;       /* stub/未回填 -> 无操作 */
    const unsigned char *win = __sdk_tk_window();
    uint64_t acc = 0;
    uint64_t n = __sdk_tk_slices();
    for (uint64_t i = 0; i < n; ++i)
        acc ^= __sdk_fnv1a64(win + i * __SDK_TK_SLICE, __sdk_tk_slice_len(i));
    __sdk_ev_fold(0x4D33ull, acc ^ __sdk_textkey_expect);
    __sdk_tk_rot_acc = 0;
    __sdk_tk_rot_done = 0;
    __sdk_tk_rot_next = (uint64_t)NNOBF_TK_ROT0;  /* guard-seed 派生 */
}
static void __sdk_chame_textkey_rotate(void)
{
    if (!__sdk_tk_armed()) return;
    const unsigned char *win = __sdk_tk_window();
    uint64_t n = __sdk_tk_slices();
    uint64_t i = __sdk_tk_rot_next % n;
    __sdk_tk_rot_acc ^= __sdk_fnv1a64(win + i * __SDK_TK_SLICE,
                                      __sdk_tk_slice_len(i));
    __sdk_tk_rot_next++;
    if (++__sdk_tk_rot_done >= n) {      /* 全窗覆盖：折叠并复位 */
        __sdk_ev_fold(0x4D33ull, __sdk_tk_rot_acc ^ __sdk_textkey_expect);
        __sdk_tk_rot_acc = 0;
        __sdk_tk_rot_done = 0;
    }
}
#endif

/* ---- M4：硬件断点检测（fork self-debugger 读 DR7，规格 4.4）----
 * 子进程 PTRACE_ATTACH 回父（descendant，Yama scope 1 合法）→ 读 DR7
 * 使能位（DR7 & 0xFF：Lx/Gx 任一置位即 HW 断点/观察点在位）→ DETACH →
 * 管道回报 → 退出。ATTACH/读失败一律 fail-open（绝不把探测失败当命中）。
 * DR7 偏移以 offsetof(struct user, u_debugreg[7]) 表达（禁魔数，
 * sys/user.h 为准）。探测先于 deny-attach 的 prctl(DUMPABLE,0)（模板
 * boot 序保证）——attach-back 期间 dumpable 仍为 1。 */
#ifdef NNOBF_CHAME_HWBP
static void __sdk_chame_hwbp_probe(void)
{
    int pfd[2];                           /* pipe(2) 填 int[2]——禁 long */
    long parent = __sdk_c3(__SDK_SYS_getpid, 0, 0, 0);
    if (__sdk_c3(__SDK_SYS_pipe, (long)pfd, 0, 0) != 0) return;
    long child = __sdk_c3(__SDK_SYS_fork, 0, 0, 0);
    if (child < 0) {
        __sdk_c3(__SDK_SYS_close, pfd[0], 0, 0);
        __sdk_c3(__SDK_SYS_close, pfd[1], 0, 0);
        return;                           /* fork 失败 fail-open */
    }
    if (child == 0) {
        long st;
        uint64_t status = 0;
        __sdk_c3(__SDK_SYS_close, pfd[0], 0, 0);
        if (__sdk_c4(__SDK_SYS_ptrace, __SDK_PTRACE_ATTACH, parent, 0, 0)
            == 0) {
            __sdk_c4(__SDK_SYS_wait4, parent, (long)&st, 0, 0);
            long dr7 = __sdk_c4(
                __SDK_SYS_ptrace, __SDK_PTRACE_PEEKUSER, parent,
                (long)__builtin_offsetof(struct user, u_debugreg[7]), 0);
            if (dr7 != -1 && (dr7 & 0xFFL))
                status |= 0x02ull;
            __sdk_c4(__SDK_SYS_ptrace, __SDK_PTRACE_DETACH, parent, 0, 0);
        }
        __sdk_c3(__SDK_SYS_write, pfd[1], (long)&status, 8);
        __sdk_c3(__SDK_SYS_close, pfd[1], 0, 0);
        __sdk_c3(__SDK_SYS_exit_group, 0, 0, 0);
        __builtin_unreachable();
    }
    /* 父：记录自家 tracer pid（M2 白名单窗口）→ 收子结果 → 收尸 → 复位 */
    long st;
    __sdk_c3(__SDK_SYS_close, pfd[1], 0, 0);
    __sdk_self_tracer = (int)child;
    uint64_t status = 0;
    if (__sdk_c3(__SDK_SYS_read, pfd[0], (long)&status, 8) != 8)
        status = 0;                       /* 短读 fail-open */
    __sdk_c3(__SDK_SYS_close, pfd[0], 0, 0);
    __sdk_c4(__SDK_SYS_wait4, child, (long)&st, 0, 0);
    __sdk_self_tracer = 0;
    __sdk_ev_fold(0x4D34ull, status);
}
#endif

/* ---- M5：SIGTRAP 处理器即密钥（x86 投递分歧 oracle，规格 4.5）----
 * boot 装 handler（rt_sigaction 裸 syscall + SA_RESTORER 自带 restorer；
 * handler 仅 volatile XOR 累加/计数——async-signal-safe 无 libc）→ 执行
 * K 个自植入 int3 检查点 → 证据 = (acc^期望)|(cnt^K)（干净 0）→ 复原
 * SIG_DFL。被 ptrace 时信号先经 tracer（gdb 默认 SIGTRAP nopass）→
 * handler 永不执行 → 证据缺失 → 静默错值；门槛从"翻布尔"抬到"复现投递
 * 计算"。自植入 int3 为构建期静态字节——M3 期望哈希天然含之（无冲突，
 * 规格 4.5 交互）；调试器新植入的 int3 由 M3 抓，两泳道正交叠加。 */
#ifdef NNOBF_CHAME_TRAP
static void __sdk_trap_restorer(void)
{
    __asm__ volatile("mov $15, %%rax\n\tsyscall"
                     : : : "rax", "rcx", "r11", "memory");
    __builtin_unreachable();
}
static void __sdk_trap_handler(int sig)
{
    (void)sig;
    __sdk_trap_acc ^= (uint64_t)NNOBF_TRAP_C;
    __sdk_trap_cnt += 1u;
}
static void __sdk_chame_trap_checkpoint(void)
{
    struct { void (*handler)(int); unsigned long flags;
             void (*restorer)(void); unsigned long mask; } sa, old;
    sa.handler = __sdk_trap_handler;
    sa.flags = 0x04000000ul;              /* SA_RESTORER */
    sa.restorer = __sdk_trap_restorer;
    sa.mask = 0;
    if (__sdk_c4(__SDK_SYS_rt_sigact, __SDK_SIGTRAP, (long)&sa,
                 (long)&old, 8) != 0)
        return;                           /* 装不上 fail-open */
    __sdk_trap_acc = 0;
    __sdk_trap_cnt = 0;
    for (int i = 0; i < NNOBF_TRAP_K; ++i)
        __asm__ volatile("int3" : : : "memory");
    uint64_t exp_acc = (NNOBF_TRAP_K & 1) ? (uint64_t)NNOBF_TRAP_C : 0u;
    /* 证据 = (acc ^ 期望) | (cnt ^ K)：cnt != K（投递被拦截——gdb 默认
     * SIGTRAP nopass 下 handler 缺席）是 V11b 的核心检测面（nopass → 污染、
     * pass nostop 且 handler 正确 → 恢复），按 V11b 契约取"投递分歧即证据"；
     * 规格 §4.5 保守注（count!=K → 0）与之冲突，以 V11b 为准——代价仅
     * "程序自身在 K 检查点窗口内自生 SIGTRAP"的极罕见假阳性，且该场景
     * 本身意味着程序已崩坏。干净环境（真机/qemu-user）投递忠实 →
     * cnt==K、acc==exp → raw==0，差分恒绿。 */
    uint64_t raw = (__sdk_trap_acc ^ exp_acc)
                   | (__sdk_trap_cnt ^ (uint64_t)NNOBF_TRAP_K);
    __sdk_ev_fold(0x4D35ull, raw);
    /* 复原默认处置（后续调试器断点行为不受本泳道影响；软断点归 M3） */
    sa.handler = (void (*)(int))0L;      /* SIG_DFL */
    sa.flags = 0;
    sa.restorer = (void (*)(void))0L;
    sa.mask = 0;
    __sdk_c4(__SDK_SYS_rt_sigact, __SDK_SIGTRAP, (long)&sa, 0, 8);
}
#endif

/* ---- M6：x86 一致性 oracle（规格 4.6，class-1：qemu 忠实建模 → 差分绿）----
 * MXCSR.DAZ：置 denormals-are-zero 送 denormal 过 SSE，忠实实现（真机
 * 与 qemu-user）结果为 0；朴素 lifter 发散。DIV-flags：除法后 EFLAGS
 * 未定义位与建期标定期望求差（protect.py 现场标定探针——asm 形态与
 * 本处逐字节一致，标定=运行时取值 → 干净 delta==0）。FP 探针仅存于
 * 取证层（V12c：IR 零 FP 增加）。FXSAVE 子项按规格缓发（三环境标定
 * 未过不入默认集——已知边界，见 CAPABILITIES）。 */
#ifdef NNOBF_CHAME_ORACLE
static void __sdk_chame_oracle_probe(void)
{
    uint64_t raw = 0;
    unsigned int old_mxcsr, set_mxcsr;
    __asm__ volatile("stmxcsr %0" : "=m"(old_mxcsr));
    set_mxcsr = old_mxcsr | 0x40u;        /* DAZ */
    __asm__ volatile("ldmxcsr %0" : : "m"(set_mxcsr));
    __asm__ volatile("" : : : "memory");
    {
        volatile float one = 1.0f;
        union { float f; unsigned int u; } du;
        du.u = 0x00400000u;               /* denormal（指数域 0） */
        volatile float dv = du.f;
        volatile float z = dv * one;
        __asm__ volatile("" : : : "memory");
        if (z != 0.0f) raw |= 1u;         /* DAZ 未生效 -> 发散 */
    }
    __asm__ volatile("ldmxcsr %0" : : "m"(old_mxcsr));  /* 复原神经 FP 环境 */
    {
        unsigned long f;
        __asm__ volatile("xor %%edx, %%edx\n\t"
                         "mov $1, %%eax\n\t"
                         "mov $3, %%ecx\n\t"
                         "div %%ecx\n\t"
                         "pushfq\n\t"
                         "popq %0"
                         : "=r"(f)
                         :
                         : "rax", "rcx", "rdx", "memory");
        raw |= (uint64_t)((f & 0x8D5ul) ^ (unsigned long)NNOBF_ORACLE_DIVFLAGS)
               << 8;
    }
    __sdk_ev_fold(0x4D36ull, raw);
}
#endif

/* ---- boot 编排（once 幂等；序 M6->M5->M4->M3->strict，规格 3.3）----
 * M4 须先于 deny-attach 的 prctl(DUMPABLE,0)：protect.py 编 guard 单元
 * 时传 -DNNOBF_GUARD_CHAME，guard_deny_attach.c 的构造器/__sdk_guard_boot
 * 在 TracerPid 检查后、prctl 前调用 __sdk_chame_boot()（模板 _context_create
 * 序：deny-attach 开走 guard_boot 内部序；否则本块 boot 直调）。 */
static int __sdk_chame_done = 0;
void __sdk_chame_boot(void)
{
    if (__sdk_chame_done) return;
    __sdk_chame_done = 1;
#ifdef NNOBF_CHAME_ORACLE
    __sdk_chame_oracle_probe();
#endif
#ifdef NNOBF_CHAME_TRAP
    __sdk_chame_trap_checkpoint();
#endif
#ifdef NNOBF_CHAME_HWBP
    __sdk_chame_hwbp_probe();
#endif
#ifdef NNOBF_CHAME_TEXTKEY
    __sdk_chame_textkey_boot();
#endif
#ifdef NNOBF_GUARD_STRICT
    if (__sdk_ev != 0) {
        __asm__ volatile("syscall" : : "a"(231L), "D"(173L)
                         : "rcx", "r11", "memory");
        __builtin_unreachable();
    }
#endif
}
/* ---- boundary 钩子（模板 boundary_run 入口调用）：
 * M2 轮询 K 节流 + M3 轮转 + strict 升级（规格 4.2/4.3）---- */
void __sdk_guard_boundary(void)
{
#ifdef NNOBF_CHAME_TRACER
    if (++__sdk_ev_poll_counter >= NNOBF_EV_POLL_K) {
        __sdk_ev_poll_counter = 0;
        __sdk_chame_tracer_poll();
    }
#endif
#ifdef NNOBF_CHAME_TEXTKEY
    __sdk_chame_textkey_rotate();
#endif
#ifdef NNOBF_GUARD_STRICT
    if (__sdk_ev != 0) {
        __asm__ volatile("syscall" : : "a"(231L), "D"(173L)
                         : "rcx", "r11", "memory");
        __builtin_unreachable();
    }
#endif
}
#else  /* !NNOBF_CHAME_OWNER */
extern volatile uint64_t __sdk_ev;
extern void __sdk_chame_boot(void);
extern void __sdk_guard_boundary(void);
#endif
/* 路由 A 折叠函数（每 TU 可见；生成器发射 `x ^ nnobf_guard_ev()` 消费点；
 * x ^ 0 == x —— 干净恒等，无分支）。 */
static uint64_t nnobf_guard_ev(void) { return (uint64_t)__sdk_ev; }
/* 路由 B（NNOBF_GUARD_SEED，xor-mask 泳道开启时 protect.py 自动叠加，
 * 规格 D2）：boot 单点把 ev 混入本 TU 初始常量潜码——错证据 -> 错常量
 * -> 本 TU 全部消费常量的区域错（全局污染）；ev==0 逐位恒等。
 * 纯数据面折叠（不动控制器 q/动作解码——垃圾动作可能触发防御性
 * break 错误路径，非静默；常量污染保证静默腐化契约）。 */
#ifdef NNOBF_GUARD_SEED
static void nnobf_chame_seed_constants(word_t *w, int n)
{
    uint64_t ev = (uint64_t)__sdk_ev;
    if (ev == 0) return;                  /* 干净恒等（跳过纯优化） */
    for (int i = 0; i < n; ++i)
        for (int l = 0; l < MAX_BYTES; ++l)
            for (int j = 0; j < EMBED; ++j) {
                union { float f; unsigned int u; } v;
                v.f = w[i].lane[l][j];
                v.u ^= (unsigned int)(ev >> ((j & 7) * 8));
                w[i].lane[l][j] = v.f;
            }
}
#endif
#endif /* NNOBF_GUARD_CHAME */
'''.replace('__OWNER_DEF__', owner_def).replace('CHAM<AE>LON', 'CHAM\xc6LON')

# ---------------------------------------------------------------------------
# anti-reverse-prompt (arp) 泳道 NN 物化单元（anti-reverse-prompt_v0.0.md
# §5.2）：protect.py --guards 含 arp 时传 --arp-codes（arp_codes.json，
# guard_anti_reverse_prompt.py 产出——CANON 每字节 codec encode + build 期
# roundtrip 断言）。owner TU 烤入潜码表 + __sdk_arp_materialize 强定义
# （decode walk）；guard_arp.c 经 extern 引用（__sdk_arp_materialize_once /
# __sdk_arp_step 回调）。未传时发射注释（产物零扰动）。
# ---------------------------------------------------------------------------
_ARP_CODES = [None]


def arp_guard_block(owner):
    """arp NN 物化单元 C 块（<<ARP_GUARD>> 占位符的替换文本）。

    owner=首个 TU：潜码表（build 期 Python codec encode 烤入，'%.9g' float
    字面量）+ __sdk_arp_materialize 强定义（逐字节 decode_byte 前向 →
    guard_arp.o 的 __sdk_arp_buf BSS——内存通道物化；decode walk 与模板
    codec 前向同源，codec 权重被污染/篡改 → 缓冲腐化）。非 owner TU：仅
    注释（materialize 引用由 owner 定义满足）。泳道关 → 纯注释。
    """
    data = _ARP_CODES[0]
    if data is None:
        return '/* anti-reverse-prompt (arp) lane off */\n'
    n = len(data['codes'])
    if not owner:
        return ('/* anti-reverse-prompt (arp) NN materialization: '
                'owner-TU only (latent table + decode walk) */\n')
    rows = []
    for code in data['codes']:
        rows.append('    {%s},'
                    % ', '.join(fmt_float(v) + 'f' for v in code))
    table = '\n'.join(rows)
    return '''/* ==== anti-reverse-prompt (arp) NN 物化单元（owner TU）====
 * 声明字节以潜码形态烤入（build 期 codec encode + roundtrip 断言，
 * guard_anti_reverse_prompt.py --emit-text）；运行时 decode walk 逐字节
 * codec 前向物化到 __sdk_arp_buf（guard_arp.o BSS，内存通道——dump/
 * 调试/AI 内存分析必见）。重物化（每 K boundary，__sdk_arp_step 回调）
 * 真实重跑 decode walk——声明内容由神经数据面产出：codec 权重被污染或
 * 路由 B 常量种子错位 → 缓冲内容腐化（guard 与 NN 数据面纠缠）。 */
#ifdef NNOBF_GUARD_ARP
extern unsigned char __sdk_arp_buf[];
extern volatile unsigned long __sdk_arp_buf_len;
extern volatile unsigned long __sdk_arp_materialized;
static const float nnobf_arp_codes[%d][EMBED] = {
%s
};
void __sdk_arp_materialize(void)
{
    unsigned long i;
    for (i = 0; i < %dul; ++i)
        __sdk_arp_buf[i] = decode_byte(&nnobf_arp_codes[i][0]);
    __sdk_arp_buf[%dul] = 0;             /* NUL 终止（调试器打印友好） */
    __sdk_arp_buf_len = %dul;
    __sdk_arp_materialized++;            /* NN 在环遥测（emit 帧 boundary 字段） */
}
#endif
''' % (n, table, n, n, n)





# ---------------------------------------------------------------------------
# 数值格式：'%.9g'，无 '.'/'e' 时补 '.0'（与引擎字面量 0 失配，两轮全量验证）
# ---------------------------------------------------------------------------
def fmt_float(v):
    s = '%.9g' % float(v)
    if '.' not in s and 'e' not in s and 'n' not in s:
        s += '.0'
    return s


# ---------------------------------------------------------------------------
# 布局引擎：npz → 张量表（名称/偏移/尺寸）
# ---------------------------------------------------------------------------
def ragged_term_size(sh):
    """每 ragged 项字节数（float 数）——与生成 C 的 nnobf_ragged_offsets 逐位一致。"""
    i, h, o, r = sh
    E = 32
    return i * h + h + h * h + h + h * o + o + E * r + r + r * r + r + r * E + E


def ragged_offsets_table(shapes):
    """渲染 nnobf_ragged_offsets[N][14]：W1,GWL,GWR,B1,W2,B2,W3,B3,RW1..RB3。"""
    E = 32
    rows = []
    off = 0
    for (i, h, o, r) in shapes:
        sizes = [i * h, None, None, h, h * h, h, h * o, o,
                 E * r, r, r * r, r, r * E, E]
        row = []
        for s in sizes:
            if s is None:
                row.append('UINT32_MAX')
            else:
                row.append('%du' % off)
                off += s
        rows.append(row)
    return rows, off


def controller_entries(npz, profile):
    """controller 尾部张量表（名称,尺寸）——ragged_M..ct_sign，slot_codes 条件出现。"""
    hidden = profile.get('controller_hidden', 64)
    order = ['ragged_M', 'ctrl_w1', 'ctrl_b1']
    if 'slot_codes' in npz.files:
        order.append('slot_codes')
    order += ['sel_w2l', 'sel_w2r', 'sel_lat_b', 'qnext_w2', 'heads_b',
              'cond_w', 'cond_b', 'q_init', 'region_q',
              'oc_w1', 'oc_b1', 'oc_w2', 'oc_b2',
              'fmt_perm', 'fmt_sign', 'ct_perm', 'ct_sign']
    dims = {
        'ragged_M': (profile['ragged_terms'], 16),
        'ctrl_w1': (96, hidden), 'ctrl_b1': (hidden,),
        'slot_codes': (profile['slot_choices'], profile['slot_code_dim']),
        'sel_w2l': (hidden, profile['selector_rank']),
        'sel_w2r': (profile['selector_rank'], profile['selector_heads']),
        'sel_lat_b': (profile['selector_rank'],),
        'qnext_w2': (hidden, 128),
        'heads_b': (profile['controller_heads'],),
        'cond_w': (64, 32), 'cond_b': (32,),
        'q_init': (64,),
        'region_q': (profile['region_entry_rows'], 64),
        'oc_w1': (64, profile['option_hidden']),
        'oc_b1': (profile['option_hidden'],),
        'oc_w2': (profile['option_hidden'], 34),
        'oc_b2': (34,),
        'fmt_perm': (4, 32), 'fmt_sign': (4, 32),
        'ct_perm': (1, 32), 'ct_sign': (1, 32),
    }
    return [(n, int(np.prod(dims[n]))) for n in order]


def compute_layout(npz, profile):
    """总布局：codec(12) + alu_region(ragged+controller)。返回 [(name,off,size)], total。"""
    entries = [(k, int(npz[k].size)) for k in CODEC_KEYS]
    ragged_len = sum(ragged_term_size(sh) for sh in profile['ragged_shapes'])
    alu_size = int(npz['alu_region'].size)
    ctrl = controller_entries(npz, profile)
    # alu_region npz blob = ragged N 项 + controller 尾部（两轮逐位实证）；
    # 宏布局把 blob 拆成 1 个 alu_region 宏（仅 ragged 部分）+ 21 个 controller 宏
    assert alu_size == ragged_len + sum(s for _, s in ctrl), \
        (alu_size, ragged_len, sum(s for _, s in ctrl))
    entries.append(('alu_region', ragged_len))
    entries += ctrl
    off = 0
    out = []
    for n, s in entries:
        out.append((n, off, s))
        off += s
    return out, off


# ---------------------------------------------------------------------------
# 权重数组文本
# ---------------------------------------------------------------------------
def render_weights_array(values, indent='  ', per_line=8):
    lines = []
    n = len(values)
    for i in range(0, n, per_line):
        chunk = values[i:i + per_line]
        tail = ',' if i + per_line < n else ''
        lines.append(indent + ', '.join(fmt_float(v) + 'f' for v in chunk) + tail)
    return '\n'.join(lines)


def emit_weights_c(npz, profile, layout, total):
    tagm = profile['tags']['TAG_MOD']
    values = np.concatenate(
        [npz[k].ravel() for k in CODEC_KEYS] + [npz['alu_region'].ravel()]
    ).astype(np.float32)
    assert len(values) == total, (len(values), total)
    body = render_weights_array(values)
    # M3 修正:定义显式 hidden(与 extern 声明配套,阻断 GOT 路径)。
    if profile['storage'] == 'fp32':
        head = ('#include <stddef.h>\n'
                'const float nnobf_module_%s_weights[%d]'
                ' __attribute__((visibility("hidden"))) = {\n'
                % (tagm, total))
        tail = '\n};\n'
    else:
        head = ('#include <stddef.h>\n'
                '#include <stdint.h>\n\n'
                '/* M1/D2: freestanding 下剥离 stdatomic/string,单线程降级 */\n'
                '#ifndef NNOBF_FREESTANDING\n'
                '#include <stdatomic.h>\n'
                '#include <string.h>\n'
                '#define NNOBF_W_ATOMIC(v) atomic_int v = 0\n'
                '#else\n'
                '#define NNOBF_W_ATOMIC(v) int v = 0\n'
                '/* M5: fp16 档 prepare 的 (float)_Float16 转换由 clang 发为\n'
                ' * compiler-rt __extendhfsf2 调用 —— freestanding 无 libgcc,\n'
                ' * 此处提供软件实现(IEEE 754 半精度→单精度位级展开,\n'
                ' * 含次正规归一化;行为由 fp16 端到端差分验证)。 */\n'
                'float __extendhfsf2(unsigned short h);\n'
                'float __extendhfsf2(unsigned short h) {\n'
                '  uint32_t sign = ((uint32_t)(h & 0x8000u)) << 16;\n'
                '  uint32_t exp = ((uint32_t)h >> 10) & 0x1Fu;\n'
                '  uint32_t mant = (uint32_t)h & 0x3FFu;\n'
                '  uint32_t bits;\n'
                '  if (exp == 0u) {\n'
                '    if (mant == 0u) {\n'
                '      bits = sign;\n'
                '    } else {\n'
                '      uint32_t e = 0u, m = mant;\n'
                '      while (!(m & 0x400u)) { m <<= 1; e++; }\n'
                '      bits = sign | ((113u - e) << 23) | ((m & 0x3FFu) << 13);\n'
                '    }\n'
                '  } else if (exp == 0x1Fu) {\n'
                '    /* NaN: 置 fp32 quiet 位(对齐 glibc/__extendhfsf2 语义) */\n'
                '    bits = sign | ((mant == 0u) ? 0x7F800000u : 0x7FC00000u)\n'
                '           | (mant << 13);\n'
                '  } else {\n'
                '    bits = sign | ((exp + 112u) << 23) | (mant << 13);\n'
                '  }\n'
                '  float out;\n'
                '  __builtin_memcpy(&out, &bits, sizeof(out));\n'
                '  return out;\n'
                '}\n'
                '#endif\n\n'
                'static const _Float16 nnobf_module_%s_weights_storage[%d] = {\n'
                % (tagm, total))
        tail = (
            '\n};\n'
            'float nnobf_module_%s_weights[%d]'
            ' __attribute__((visibility("hidden")));\n'
            'static NNOBF_W_ATOMIC(nnobf_module_%s_weights_state);\n'
            '\n'
            'void nnobf_module_%s_weights_prepare(void)'
            ' __attribute__((visibility("hidden")));\n'
            'void nnobf_module_%s_weights_prepare(void) {\n'
            '#ifdef NNOBF_FREESTANDING\n'
            '  /* M1/D2: 顺序 once-init,无竞争 */\n'
            '  if (nnobf_module_%s_weights_state == 2) return;\n'
            '  nnobf_module_%s_weights_state = 1;\n'
            '#else\n'
            '  if (atomic_load_explicit(\n'
            '          &nnobf_module_%s_weights_state, memory_order_acquire) == 2)\n'
            '    return;\n'
            '  int expected = 0;\n'
            '  if (!atomic_compare_exchange_strong_explicit(\n'
            '          &nnobf_module_%s_weights_state, &expected, 1,\n'
            '          memory_order_acq_rel, memory_order_acquire)) {\n'
            '    while (atomic_load_explicit(\n'
            '               &nnobf_module_%s_weights_state, memory_order_acquire) != 2) {}\n'
            '    return;\n'
            '  }\n'
            '#endif\n'
            '  for (size_t i = 0; i < %du; ++i)\n'
            '    nnobf_module_%s_weights[i] = (float)nnobf_module_%s_weights_storage[i];\n'
            '  \n'
            '#ifdef NNOBF_FREESTANDING\n'
            '  nnobf_module_%s_weights_state = 2;\n'
            '#else\n'
            '  atomic_store_explicit(\n'
            '      &nnobf_module_%s_weights_state, 2, memory_order_release);\n'
            '#endif\n'
            '}\n') % (tagm, total,   # weights[] 定义
                     tagm, tagm,   # _state 声明 / prepare 原型
                     tagm,         # prepare 定义
                     tagm, tagm,   # fs: state==2 / =1
                     tagm, tagm, tagm,   # hosted: load/cas/load
                     total,        # for 循环上界
                     tagm, tagm,   # weights[i] / storage[i]
                     tagm, tagm)   # fs: =2 / hosted store
    return head + body + tail


def emit_module_state_c(profile):
    tagm = profile['tags']['TAG_MOD']
    n = profile['module_persist_bytes']
    # M1/D2: 文本内嵌 #ifdef — freestanding 编译时 atomic_int 降级为
    # 普通 int(单线程),剥离 stdatomic.h;hosted 编译零变化。
    # M3 修正:定义显式 hidden(与 template_main.txt 的 extern 声明配套,
    # 阻断 lld 非 PIE 链接的 GOT→绝对立即数松弛)。
    hid = ' __attribute__((visibility("hidden")))'
    return ('#include <stdint.h>\n'
            '#ifdef NNOBF_FREESTANDING\n'
            'int nnobf_module_%s_state%s = 0;\n'
            '#else\n'
            '#include <stdatomic.h>\n'
            'atomic_int nnobf_module_%s_state%s = 0;\n'
            '#endif\n'
            '#define EMBED 32\n'
            'float nnobf_module_%s_persist[%d * EMBED]%s;\n'
            'float nnobf_module_%s_valid[%d]%s;\n'
            'float nnobf_module_%s_dirty[%d]%s;\n'
            'uint8_t nnobf_module_%s_format[%d]%s;\n'
            % (tagm, hid, tagm, hid, tagm, n, hid, tagm, n, hid,
               tagm, n, hid, tagm, n, hid))


# ---------------------------------------------------------------------------
# 宏块 / extern 块
# ---------------------------------------------------------------------------
def emit_macro_block(profile, layout):
    tagw = profile['tags']['TAG_W']
    reg = profile['registry']
    present = []
    for name, off, size in layout:
        if name in reg:
            present.append((reg[name], off))
    present.sort(key=lambda x: x[1])
    lines = ['#define NNOBF_W_%s_%s %du' % (tagw, tid, off) for tid, off in present]
    lines += ['#define NNOBF_W_%s_%s 0u' % (tagw, tid) for tid in profile['absent_ids']]
    return '\n'.join(lines)


def emit_weights_extern(profile, total):
    tagm = profile['tags']['TAG_MOD']
    # M3 修正:extern 声明显式 hidden —— 裸 extern 走 GOT(REX_GOTPCRELX),
    # lld 非 PIE 链接松弛成绝对立即数 → stub 随机基址 SIGSEGV(dense 崩溃
    # 根因);hidden 使 clang 直发 RIP 相对 lea(R_X86_64_PC32)。
    hid = ' __attribute__((visibility("hidden")))'
    if profile['storage'] == 'fp32':
        return ('extern const float nnobf_module_%s_weights[%d]%s;\n'
                '#define NNOBF_WEIGHTS nnobf_module_%s_weights\n'
                '#define NNOBF_PREPARE_WEIGHTS() ((void)0)\n'
                '#define NNOBF_WEIGHT(index) (NNOBF_WEIGHTS[(index)])\n'
                '#define NNOBF_PREPARE_RANGE(offset) ((void)(offset))\n'
                % (tagm, total, hid, tagm))
    return ('extern float nnobf_module_%s_weights[%d]%s;\n'
            'void nnobf_module_%s_weights_prepare(void)'
            ' __attribute__((visibility("hidden")));\n'
            '#define NNOBF_WEIGHTS nnobf_module_%s_weights\n'
            '#define NNOBF_PREPARE_WEIGHTS() nnobf_module_%s_weights_prepare()\n'
            '#define NNOBF_WEIGHT(index) (NNOBF_WEIGHTS[(index)])\n'
            '#define NNOBF_PREPARE_RANGE(offset) ((void)(offset))\n'
            % (tagm, total, hid, tagm, tagm, tagm))


# ---------------------------------------------------------------------------
# 计划派生代码块
# ---------------------------------------------------------------------------
def emit_init_const_body(profile):
    lines = []
    for i, (consts, width) in enumerate(zip(profile['initial_constants'],
                                            profile['initial_widths'])):
        bytes_txt = ', '.join('%du' % b for b in consts)
        lines.append('  word_encode_bytes((const uint8_t[]){%s}, %d, '
                     '&nnobf_initial_constants[%d]);' % (bytes_txt, width, i))
    return '\n'.join(lines) + '\n'


def emit_call_begin_commits(profile):
    n = len(profile['initial_constants'])
    lines = []
    for i in range(n):
        lines.append('  ctx->temp[%d] = nnobf_initial_constants[%d];' % (i, i))
        lines.append('  ctx->temp_valid[%d] = 1u;' % i)
    return '\n'.join(lines) + '\n'


def emit_boundary_cases(profile):
    """每区域一个 case：ptr 同步 → 标量 commit → exec → 多 live-out 逐槽导出
    （形态对齐引擎 multi/shifts 轮的多 live-out boundary_run C）。"""
    parts = []
    for case in profile['boundary_cases']:
        L = ['    case UINT64_C(%d): {' % case['ticket']]
        for p in case['ptr_in']:
            L.append('      uint8_t *native_%d = (uint8_t *)(uintptr_t)frame[%d];'
                     % (p['frame'], p['frame']))
            L.append('      if (!nnobf_sync_in_range(ctx, %d, native_%d, %du, %du)) return 0;'
                     % (p['object'], p['frame'], p['off'], p['size']))
        for s in case['scalar_in']:
            L.append('      word_t input_%d;' % s['frame'])
            L.append(_ev('      word_encode(frame[%d]@EV@, %d, &input_%d);',
                         s['frame'], s['width'], s['frame']))
            L.append('      if (!nnobf_commit(ctx, %d, &input_%d)) return 0;'
                     % (s['slot'], s['frame']))
        L.append('      if (!nnobf_execute_range(ctx, %du, %du)) return 0;'
                 % tuple(case['exec']))
        outs = case.get('outs') or ([case['out']] if case.get('out') else [])
        for i, o in enumerate(outs):
            L.append('      if (!nnobf_temp_ready(ctx, %d)) return 0;' % o['slot'])
            L.append('      word_t output_%d;' % o['frame'])
            L.append('      nnobf_word_export(nnobf_temp_word(ctx, %d), &output_%d);'
                     % (o['slot'], o['frame']))
            L.append('      frame[%d] = word_decode(&output_%d, %d);'
                     % (o['frame'], o['frame'], o['width']))
        L.append('      return ctx->error == NNOBF_CONTEXT_OK;')
        L.append('    }')
        parts.append('\n'.join(L))
    return '\n'.join(parts)


def emit_self_test(profile):
    if not profile.get('self_test'):
        return '\n\n\n'
    tagi = profile['tags']['TAG_IR']
    ret = profile['call_end_ret']
    return (
        '\n\nNNOBF_EXPORT %s __nnobf_neural_ir_%s(void) {\n'
        '  nnobf_session_t *session =\n'
        '      (nnobf_session_t *)__nnobf_neural_ir_%s_context_create();\n'
        '  if (!session) return (%s)0;\n'
        '  %s decoded =\n'
        '      __nnobf_neural_ir_%s_call_reuse(session);\n'
        '  __nnobf_neural_ir_%s_context_destroy(session);\n'
        '  return decoded;\n'
        '}\n\n\n' % (ret, tagi, tagi, ret, ret, tagi, tagi))


def emit_controller_step(profile):
    offs = profile['head_offsets']
    L = []
    A = L.append
    A('static int nnobf_controller_step(nnobf_context_t *ctx,')
    A('                                 nnobf_controller_action_t *action) {')
    A('  float heads[NNOBF_CONTROLLER_HEADS];')
    A('  nnobf_controller_forward(')
    A('      ctx->controller_q, ctx->controller_condition, heads);')
    A('  action->read_a = nnobf_controller_slot(heads + %d);' % offs['read_a'])
    A('  action->read_b = nnobf_controller_slot(heads + %d);' % offs['read_b'])
    A('  action->read_c = nnobf_controller_slot(heads + %d);' % offs['read_c'])
    A('  action->write = nnobf_controller_slot(heads + %d);' % offs['write'])
    A('  action->input_layout = (uint8_t)argmax(')
    A('      heads + %d, NNOBF_CONTROLLER_INPUT_LAYOUT_CHOICES);' % offs['input_layout'])
    A('  action->input_span = NNOBF_CONTROLLER_WIDTHS[')
    A('      argmax(heads + %d, NNOBF_CONTROLLER_WIDTH_CHOICES)];' % offs['input_span'])
    A('  action->lane_delta_a = NNOBF_CONTROLLER_LANE_DELTAS[argmax(')
    A('      heads + %d, NNOBF_CONTROLLER_LANE_DELTA_CHOICES)];' % offs['lane_delta_a'])
    A('  action->lane_delta_b = NNOBF_CONTROLLER_LANE_DELTAS[argmax(')
    A('      heads + %d, NNOBF_CONTROLLER_LANE_DELTA_CHOICES)];' % offs['lane_delta_b'])
    A('  action->lane_delta_c = NNOBF_CONTROLLER_LANE_DELTAS[argmax(')
    A('      heads + %d, NNOBF_CONTROLLER_LANE_DELTA_CHOICES)];' % offs['lane_delta_c'])
    A('  action->source_width = NNOBF_CONTROLLER_WIDTHS[')
    A('      argmax(heads + %d, NNOBF_CONTROLLER_WIDTH_CHOICES)];' % offs['source_width'])
    A('  action->target_width = NNOBF_CONTROLLER_WIDTHS[')
    A('      argmax(heads + %d, NNOBF_CONTROLLER_WIDTH_CHOICES)];' % offs['target_width'])
    A('  int object_index = argmax(heads + %d,' % offs['object'])
    A('                            NNOBF_CONTROLLER_OBJECT_CHOICES);')
    A('  action->object_index = object_index == <<OBJECT_SENTINEL>>')
    A('      ? -1 : (int16_t)object_index;')
    A('  action->byte_offset = NNOBF_CONTROLLER_BYTE_OFFSETS[')
    A('      argmax(heads + %d, %d)];' % (
        offs['byte_offset'], len(profile.get('byte_offsets', [-1, 0]))))
    A('  action->access_width = NNOBF_CONTROLLER_ACCESS_WIDTHS[')
    A('      argmax(heads + %d,' % offs['access_width'])
    A('             NNOBF_CONTROLLER_ACCESS_WIDTH_CHOICES)];')
    A('  action->alignment = NNOBF_CONTROLLER_ALIGNMENTS[')
    A('      argmax(heads + %d, %d)];' % (
        offs['alignment'], len(profile.get('alignments', [0, 4]))))
    A('  action->control_transform = (uint8_t)argmax(')
    A('      heads + %d,' % offs['control_transform'])
    A('      NNOBF_CONTROL_TRANSFORM_CHOICES);')
    A('  action->rename_count = 0u;')
    A('')
    A('  for (int i = 0; i < NNOBF_CONTROLLER_OPTION_DIM; ++i)')
    A('    ctx->controller_option[i] = heads[%d + i];' % offs['option'])
    A('  /* The deployed recurrence consumes its predicted latent state directly.')
    A('   * Offline rollout verification retains the private prototype codebook for')
    A('   * Eq. (16), but no finite control-state enumeration aid is emitted. */')
    A('  for (int i = 0; i < Q_DIM; ++i)')
    A('    ctx->controller_q[i] = heads[%d + i] >= 0.0f ? 4.0f : -4.0f;' % offs['q_next'])
    A('')
    A('  return 1;')
    A('}')
    return '\n'.join(L) + '\n'


# ---------------------------------------------------------------------------
# 主 TU 渲染
# ---------------------------------------------------------------------------
FP16_TEXT_SUBS = [
    # 统一 ALU ragged 重建路径：fp16 存储配 double 累加恢复精度（0x6fa990 模板族）
    ('  float total', '  double total'),
    ('nnobf_accumulate_row_f32(total', 'nnobf_accumulate_row_f64(total'),
    ('nnobf_accumulate_row_f32(left_gate', 'nnobf_accumulate_row_f64(left_gate'),
    ('nnobf_accumulate_row_f32(right_gate', 'nnobf_accumulate_row_f64(right_gate'),
    ('nnobf_accumulate_scalar_scaled_row_f32(total2',
     'nnobf_accumulate_scalar_scaled_row_f64(total2'),
    ('nnobf_accumulate_scaled_row_f32(total1',
     'nnobf_accumulate_scaled_row_f64(total1'),
    ('float left_gate[h], right_gate[h];', 'double left_gate[h], right_gate[h];'),
    ('total1[j] = (float)(b1[j] * channel_scale[j]);',
     'total1[j] = (double)(b1[j] * channel_scale[j]);'),
    ('total1[j] += left_gate[j] * right_gate[j] * (float)channel_scale[j];',
     'total1[j] += left_gate[j] * right_gate[j] * (double)channel_scale[j];'),
]


def emit_ragged_shapes(shapes):
    rows = ['  {%du,%du,%du,%du}' % tuple(sh) for sh in shapes]
    return ',\n'.join(rows)


def ragged_param_max(shapes):
    """M1/D2: 单 ragged term 的最大 parameter_count(模板
    nnobf_ragged_assign_layout 的 Python 镜像),供 freestanding 静态
    参数池定尺(NNOBF_RAGGED_PARAM_MAX)。shape = (input, hidden,
    output, refiner)。"""
    EMBED_ = 32
    best = 0
    for sh in shapes:
        i, h, o, r = (int(v) for v in sh)
        c = (i * h + 2 * EMBED_ * h + h + h * h + h + h * o + o
             + 2 * (EMBED_ * r + r + r * r + r + EMBED_ * r + EMBED_))
        best = max(best, c)
    return best


def emit_ragged_offsets(rows):
    out = ['  {%s}' % ','.join(r) for r in rows]
    return ',\n'.join(out)


def emit_object_table(profile):
    """NNOBF_OBJECTS 表（t2 缺省 = 单 4 字节栈对象，字节回归）。"""
    objs = profile.get('objects')
    if objs is None:
        objs = [{'storage_offset': 0, 'size_bytes': 4,
                 'object_id_hash': 6982650410390112078}]
    rows = []
    for o in objs:
        size = o['size_bytes']
        rows.append('  {%du, %du, %du, %du, 0u, UINT64_C(%d), 0u, 1u, '
                    '0u, 0u, 0u, 0u, 0u}' % (
                        o['storage_offset'], size, size, size,
                        o['object_id_hash']))
    return ',\n'.join(rows)



def _mem_table_values(profile):
    """BYTE_OFFSETS/ALIGNMENTS/ACCESS_WIDTHS 的 C 表文本（缺省 = t2 R2
    锚点逐字：-1, 0 / 0u, 4u / 0u, 4u）。"""
    bo = profile.get('byte_offsets', [-1, 0])
    al = profile.get('alignments', [0, 4])
    aw = profile.get('access_widths', [0, 4])
    return {
        'BYTE_OFFSET_CHOICES': str(len(bo)),
        'BYTE_OFFSETS': ', '.join(str(int(x)) for x in bo),
        'ALIGNMENT_CHOICES': str(len(al)),
        'ALIGNMENTS': ', '.join('%du' % int(x) for x in al),
        'ACCESS_WIDTH_CHOICES': str(len(aw)),
        'ACCESS_WIDTHS': ', '.join('%du' % int(x) for x in aw),
    }


def render_main_c(npz, profile, layout, total, template, variants):
    tagw = profile['tags']['TAG_W']
    reg = profile['registry']
    storage = profile['storage']

    # 槽位选择变体：V_SLOTS ≤ 8 → argmax；更大 → 学习码本点积（slot_codes 张量）
    slot_fn = (variants['slot_argmax'] if profile['v_slots'] <= 8
               else variants['slot_codebook'])
    dense = variants['dense_fp16'] if storage == 'fp16' else variants['dense_fp32']
    dnb = (variants['dense_no_bias_fp16'] if storage == 'fp16'
           else variants['dense_no_bias_fp32'])

    values = {
        'TAG_W': tagw,
        'TAG_MOD': profile['tags']['TAG_MOD'],
        'TAG_IR': profile['tags']['TAG_IR'],
        'TAG_K': profile['tags']['TAG_K'],
        'V_SLOTS': str(profile['v_slots']),
        'MAX_BYTES': str(profile.get('max_bytes', 4)),
        # 扫描上限 = 本函数槽位数；哨兵码本行 = 模块级 slot_choices-1
        # （单函数两值相等：t2 14/14 → 字节不变）
        'SLOT_NOOP': str(profile['slot_choices'] - 1),
        **_mem_table_values(profile),
        'CONTROLLER_HEADS': str(profile['controller_heads']),
        'CONTROLLER_HIDDEN': str(profile.get('controller_hidden', 64)),
        'SLOT_CHOICES': str(profile['slot_choices']),
        'SLOT_SENTINEL': str(profile['v_slots']),
        'SLOT_CODE_DIM': str(profile['slot_code_dim']),
        'LANE_DELTA_CHOICES': str(profile['lane_delta_choices']),
        'WIDTH_CHOICES': str(len(profile.get('width_values', [1, 32]))),
        'WIDTH_VALUES': ', '.join('%du' % w for w in
                                  profile.get('width_values', [1, 32])),
        'SELECTOR_HEADS': str(profile['selector_heads']),
        'SELECTOR_RANK': str(profile['selector_rank']),
        'OPTION_HIDDEN': str(profile['option_hidden']),
        'RAGGED_TERMS': str(profile['ragged_terms']),
        'RAGGED_SHAPES': emit_ragged_shapes(profile['ragged_shapes']),
        'RAGGED_OFFSETS': emit_ragged_offsets(
            ragged_offsets_table(profile['ragged_shapes'])[0]),
        'RAGGED_PARAM_MAX': str(
            ragged_param_max(profile['ragged_shapes'])),
        # M5: 单函数模式唯一 TU 即共享 ragged 缓存 owner
        'FS_RAGGED_OWNER': '#define NNOBF_FS_RAGGED_OWNER 1',
        # CHAME evidence 单元：单函数唯一 TU 恒为 owner（泳道关时仅注释）
        'CHAME_GUARD': (chame_guard_block(True) if _GUARD_EVIDENCE[0]
                        else '/* chame-antidebug lanes off */\n'),
        # arp NN 物化单元：单函数唯一 TU 恒为 owner（泳道关时仅注释）
        'ARP_GUARD': arp_guard_block(True),
        'REGION_ENTRY_ROWS': str(profile['region_entry_rows']),
        'MAX_ACTIONS': str(profile['max_actions']),
        'LANE_DELTAS': profile['lane_deltas'],
        **{k: str(v) for k, v in profile['eff'].items()},
        'N_INIT_CONST': str(len(profile['initial_constants'])),
        'INIT_CONST_BODY': emit_init_const_body(profile),
        'CALL_BEGIN_COMMITS': emit_call_begin_commits(profile),
        'CALL_BEGIN_ARGS': 'void *opaque',
        'CALL_REUSE_ARGS': 'void *opaque',
        'CALL_BEGIN_FWD_ARGS': 'session',
        'CALL_BEGIN_ENCODE': '',
        'BOUNDARY_CASES': emit_boundary_cases(profile),
        'OBJECT_CHOICES': str(len(profile.get('objects', [1])) + 1),
        'OBJECT_SENTINEL': str(len(profile.get('objects', [1]))),
        'CALL_PERSIST_BYTES': str(sum(
            o['size_bytes'] for o in profile.get('objects', [{'size_bytes': 4}]))),
        'MODULE_PERSIST_BYTES': str(profile['module_persist_bytes']),
        'OBJECT_COUNT': str(len(profile.get('objects', [1]))),
        'OBJECT_TABLE': emit_object_table(profile),
        'CALL_END_RET': profile['call_end_ret'],
        'CALL_END_DECODE': emit_call_end_decode(profile),
        'SELF_TEST': emit_self_test(profile),
        'MACRO_BLOCK': emit_macro_block(profile, layout),
        'WEIGHTS_EXTERN': emit_weights_extern(profile, total).rstrip('\n'),
        'FN_DENSE': dense,
        'FN_DENSE_NO_BIAS': dnb,
        'FN_CONTROLLER_SLOT': slot_fn,
        'FN_CONTROLLER_STEP': emit_controller_step(profile),
    }

    def resolve(m):
        key = m.group(1)
        if key.startswith('W:'):
            name = key[2:]
            return 'NNOBF_W_%s_%s' % (tagw, reg[name])
        if key in values:
            return values[key]
        raise KeyError('unresolved placeholder: %s' % key)

    # 迭代解析：变体文本内可含嵌套占位符（如槽码本变体的 <<W:slot_codes>>）
    out = template
    prev = None
    while prev != out:
        prev = out
        out = re.sub(r'<<([^<>]+)>>', resolve, out)

    # fp16 路径的 ragged 累加精度变体（文本级替换，对应 .rodata 模板对选择）
    if storage == 'fp16':
        for a, b in FP16_TEXT_SUBS:
            out = out.replace(a, b)
    return out


def emit_call_end_decode(profile):
    """R1（有返回值计划）：从 live-out 槽解码；R2（void 计划）：空。"""
    if profile.get('call_end_decode_slot') is None:
        return '\n'
    slot = profile['call_end_decode_slot']
    width = profile.get('call_end_decode_width', 32)
    return (
        '  if (ctx->error == NNOBF_CONTEXT_OK &&\n'
        '      nnobf_temp_ready(ctx, %d)) {\n'
        '    word_t exported_output;\n'
        '    nnobf_word_export(nnobf_temp_word(ctx, %d),\n'
        '                      &exported_output);\n'
        '    decoded = word_decode(&exported_output, %d);\n'
        '  }\n' % (slot, slot, width))


# ---------------------------------------------------------------------------
# 验证
# ---------------------------------------------------------------------------
def structural_diff(gen, real, label):
    """结构级一致度：行集合/函数集/宏集/权重数组长度。"""
    res = {'label': label}
    g_lines, r_lines = gen.split('\n'), real.split('\n')
    res['gen_lines'] = len(g_lines)
    res['real_lines'] = len(r_lines)

    def funcs(lines):
        return set(l.split('(')[0].strip() for l in lines
                   if re.match(r'^(static |NNOBF_EXPORT )?\w[\w \*]*\(', l))
    fg, fr = funcs(g_lines), funcs(r_lines)
    res['gen_funcs'] = len(fg)
    res['real_funcs'] = len(fr)
    res['funcs_only_gen'] = sorted(fg - fr)
    res['funcs_only_real'] = sorted(fr - fg)

    mg = set(re.findall(r'#define NNOBF_W_\w+_\w+', gen))
    mr = set(re.findall(r'#define NNOBF_W_\w+_\w+', real))
    res['macros_gen'] = len(mg)
    res['macros_real'] = len(mr)
    res['macros_diff'] = sorted(mg ^ mr)[:20]

    m = re.search(r'const (\w+) nnobf_module_\w+_weights(?:_storage)?\[(\d+)\]', gen)
    res['gen_weights_ty_len'] = m.groups() if m else None
    m = re.search(r'const (\w+) nnobf_module_\w+_weights(?:_storage)?\[(\d+)\]', real)
    res['real_weights_ty_len'] = m.groups() if m else None
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--weights', required=True, help='module weights npz')
    ap.add_argument('--profile', required=True, help='round profile json')
    ap.add_argument('--out', required=True, help='output dir')
    ap.add_argument('--verify', default=None, help='real full_controller_runtime dir')
    ap.add_argument('--tag-w', default=None, help='override weights tag')
    ap.add_argument('--tag-mod', default=None)
    ap.add_argument('--tag-ir', default=None)
    ap.add_argument('--tag-k', default=None)
    ap.add_argument('--guard-evidence', action='store_true',
                    help='CHAME M1-M6 evidence 泳道开（protect.py --guards '
                         '含 chame-* 时透传）：发射路由 A 的 '
                         '`x ^ nnobf_guard_ev()` commit 形态 + 模板 CHAME '
                         '证据单元（<<CHAME_GUARD>>）；关闭时零扰动')
    ap.add_argument('--arp-codes', default=None,
                    help='arp 泳道潜码 json（protect.py --guards 含 arp 时'
                         '透传，arp_codes.json——guard_anti_reverse_prompt.py'
                         ' 产出）：发射 <<ARP_GUARD>> owner NN 物化单元'
                         '（潜码表 + decode walk）；关闭时零扰动')
    args = ap.parse_args()

    _GUARD_EVIDENCE[0] = bool(args.guard_evidence)
    if args.arp_codes:
        _ARP_CODES[0] = json.load(open(args.arp_codes))
    profile = json.load(open(args.profile))
    if profile.get('mode') == 'module':
        main_module(args)
        return
    for k, v in [('TAG_W', args.tag_w), ('TAG_MOD', args.tag_mod),
                 ('TAG_IR', args.tag_ir), ('TAG_K', args.tag_k)]:
        if v:
            profile['tags'][k] = v

    npz = np.load(args.weights)
    layout, total = compute_layout(npz, profile)
    print('layout: %d tensors, total %d floats' % (len(layout), total))

    template = open(os.path.join(DATA, 'template_main.txt'), encoding='utf-8').read()
    variants = json.load(open(os.path.join(DATA, 'variants.json')))
    # 变体文本提取自真实 R2 产物，其中槽码本变体内嵌 R2 tag/宏名 → 归一化
    # 为占位符；槽哨兵（t2 的 14 / t1 的 8）→ 占位符按 profile 参数化
    variants['slot_codebook'] = variants['slot_codebook'].replace(
        'NNOBF_W_43e7a084facd_00fb', '<<W:slot_codes>>')
    variants['slot_codebook'] = re.sub(
        r'local <= 14', 'local <= <<SLOT_SENTINEL>>',
        variants['slot_codebook'])
    variants['slot_codebook'] = re.sub(
        r'local < 14 \? local : 14', 'local < <<SLOT_SENTINEL>> '
        r'? local : <<SLOT_NOOP>>', variants['slot_codebook'])
    variants['slot_codebook'] = re.sub(
        r'selected == 14', 'selected == <<SLOT_NOOP>>',
        variants['slot_codebook'])
    variants['slot_argmax'] = variants['slot_argmax'].replace(
        'selected == 8', 'selected == <<SLOT_NOOP>>')

    # R1 侧 absent-id 回退（slot_codes 注册位移）：id ≥ threshold 一律 +delta
    remap = profile.get('id_remap')
    if remap and remap.get('threshold') is not None:
        th, delta = int(remap['threshold'], 16), remap['delta']
        def shift(m):
            tid = int(m.group(1), 16)
            if tid >= th:
                return 'NNOBF_W_<<TAG_W>>_%04x' % (tid + delta)
            return m.group(0)
        template = re.sub(r'NNOBF_W_<<TAG_W>>_(\w{4})', shift, template)

    os.makedirs(args.out, exist_ok=True)
    main_c = render_main_c(npz, profile, layout, total, template, variants)
    weights_c = emit_weights_c(npz, profile, layout, total)
    state_c = emit_module_state_c(profile)

    open(os.path.join(args.out, 'runtime_0_main.c'), 'w').write(main_c)
    open(os.path.join(args.out, 'runtime_weights.c'), 'w').write(weights_c)
    open(os.path.join(args.out, 'runtime_module_state.c'), 'w').write(state_c)
    print('written:', os.path.join(args.out))

    if args.verify:
        print('\n===== verify vs %s =====' % args.verify)
        for fn in ('runtime_0_main.c', 'runtime_weights.c', 'runtime_module_state.c'):
            gen = open(os.path.join(args.out, fn)).read()
            real = open(os.path.join(args.verify, fn)).read()
            ident = gen == real
            print('[%s] byte-identical: %s' % (fn, ident))
            if not ident and fn == 'runtime_0_main.c':
                r = structural_diff(gen, real, fn)
                print('  lines %s vs %s; funcs %s vs %s; only-gen %s; only-real %s'
                      % (r['gen_lines'], r['real_lines'], r['gen_funcs'], r['real_funcs'],
                         r['funcs_only_gen'], r['funcs_only_real']))
                # first differing line
                import difflib
                dl = list(difflib.unified_diff(real.split('\n'), gen.split('\n'),
                                               'real', 'gen', n=1))
                print('  diff hunks:', sum(1 for l in dl if l.startswith('@@')))
                for l in dl[:24]:
                    print('   ', l)
            elif not ident and fn == 'runtime_weights.c':
                # compare value streams
                gv = re.findall(r'(-?\d+\.?\d*(?:[eE][+-]?\d+)?)f', gen)
                rv = re.findall(r'(-?\d+\.?\d*(?:[eE][+-]?\d+)?)f', real)
                same = gv == rv
                print('  values: %d vs %d, identical=%s' % (len(gv), len(rv), same))
                if not same:
                    for i, (a, b) in enumerate(zip(gv, rv)):
                        if a != b:
                            print('  first value diff at %d: gen=%s real=%s' % (i, a, b))
                            break


# =========================================================================
# 多函数模式：模块 profile（mode=module）→ 每函数一 TU + 共享权重/状态
# =========================================================================
def controller_entries_module(npz, profile):
    """模块布局：q_init (F,64) + region_q (Σrows,64) 整块。"""
    hidden = profile.get('controller_hidden', 64)
    order = ['ragged_M', 'ctrl_w1', 'ctrl_b1']
    if 'slot_codes' in npz.files:
        order.append('slot_codes')
    order += ['sel_w2l', 'sel_w2r', 'sel_lat_b', 'qnext_w2', 'heads_b',
              'cond_w', 'cond_b', 'q_init', 'region_q',
              'oc_w1', 'oc_b1', 'oc_w2', 'oc_b2',
              'fmt_perm', 'fmt_sign', 'ct_perm', 'ct_sign']
    dims = {
        'ragged_M': (profile['ragged_terms'], 16),
        'ctrl_w1': (96, hidden), 'ctrl_b1': (hidden,),
        'slot_codes': (profile['slot_choices'], profile['slot_code_dim']),
        'sel_w2l': (hidden, profile['selector_rank']),
        'sel_w2r': (profile['selector_rank'], profile['selector_heads']),
        'sel_lat_b': (profile['selector_rank'],),
        'qnext_w2': (hidden, 128),
        'heads_b': (profile['controller_heads'],),
        'cond_w': (64, 32), 'cond_b': (32,),
        'q_init': (int(np.prod(npz['q_init'].shape)),),
        'region_q': (int(np.prod(npz['region_q'].shape)),),
        'oc_w1': (64, profile['option_hidden']),
        'oc_b1': (profile['option_hidden'],),
        'oc_w2': (profile['option_hidden'], 34),
        'oc_b2': (34,),
        'fmt_perm': (4, 32), 'fmt_sign': (4, 32),
        'ct_perm': (1, 32), 'ct_sign': (1, 32),
    }
    return [(n, int(np.prod(dims[n]))) for n in order]


def compute_layout_module(npz, profile):
    entries = [(k, int(npz[k].size)) for k in CODEC_KEYS]
    ragged_len = sum(ragged_term_size(sh) for sh in profile['ragged_shapes'])
    alu_size = int(npz['alu_region'].size)
    ctrl = controller_entries_module(npz, profile)
    assert alu_size == ragged_len + sum(s for _, s in ctrl), \
        (alu_size, ragged_len, sum(s for _, s in ctrl))
    entries.append(('alu_region', ragged_len))
    entries += ctrl
    off = 0
    out = []
    for n, s in entries:
        out.append((n, off, s))
        off += s
    return out, off


def emit_macro_block_module(profile, layout):
    """宏块：共享张量 + 每函数 q_init_fn{i}/region_q_fn{i} 偏移。"""
    tagw = profile['tags']['TAG_W']
    lines = []
    base = {}
    for name, off, size in layout:
        base[name] = (off, size)
    q_off, _q_sz = base['q_init']
    rq_off, _rq_sz = base['region_q']
    reg = profile['registry']
    seen = set()
    for name, off, size in layout:
        if name in reg:
            lines.append('#define NNOBF_W_%s_%s %du'
                         % (tagw, reg[name], off))
            seen.add(reg[name])
    row = 0
    for i, f in enumerate(profile['functions']):
        lines.append('#define NNOBF_W_%s_%s %du'
                     % (tagw, 'qinit%02x' % i, q_off + i * 64))
        lines.append('#define NNOBF_W_%s_%s %du'
                     % (tagw, 'rq%02x' % i, rq_off + row * 64))
        row += f['region_entry_rows']
    lines += ['#define NNOBF_W_%s_%s 0u' % (tagw, tid)
              for tid in profile['absent_ids']]
    return '\n'.join(lines)


def emit_boundary_cases_multi(f):
    """每函数 case：sync_in → commit → exec → outs → sync_out。"""
    parts = []
    for case in f['boundary_cases']:
        L = ['    case UINT64_C(%d): {' % case['ticket']]
        for p in case['ptr_in']:
            L.append('      uint8_t *native_%d = (uint8_t *)(uintptr_t)'
                     'frame[%d];' % (p['frame'], p['frame']))
            L.append('      if (!nnobf_sync_in_range(ctx, %d, native_%d, '
                     '%du, %du)) return 0;'
                     % (p['object'], p['frame'], p['off'], p['size']))
        for s in case['scalar_in']:
            L.append('      word_t input_%d;' % s['frame'])
            L.append(_ev('      word_encode(frame[%d]@EV@, %d, &input_%d);',
                         s['frame'], s['width'], s['frame']))
            L.append('      if (!nnobf_commit(ctx, %d, &input_%d)) '
                     'return 0;' % (s['slot'], s['frame']))
        L.append('      if (!nnobf_execute_range(ctx, %du, %du)) return 0;'
                 % tuple(case['exec']))
        outs = case.get('outs') or ([case['out']] if case.get('out') else [])
        for o in outs:
            L.append('      if (!nnobf_temp_ready(ctx, %d)) return 0;'
                     % o['slot'])
            L.append('      word_t output_%d;' % o['frame'])
            L.append('      nnobf_word_export(nnobf_temp_word(ctx, %d), '
                     '&output_%d);' % (o['slot'], o['frame']))
            L.append('      frame[%d] = word_decode(&output_%d, %d);'
                     % (o['frame'], o['frame'], o['width']))
        for p in case.get('sync_out', []):
            L.append('      if (!nnobf_sync_out(ctx, %d, native_%d, %du)) '
                     'return 0;' % (p['object'], p['frame'], p['size']))
        L.append('      return ctx->error == NNOBF_CONTEXT_OK;')
        L.append('    }')
        parts.append('\n'.join(L))
    return '\n'.join(parts)


LLVM_TO_C = {'ptr': 'void *', 'i8': 'uint8_t', 'i16': 'uint16_t',
             'i32': 'uint32_t', 'i64': 'uint64_t'}


def emit_call_begin_abi(f):
    """(call_begin 签名, call_reuse 签名, 转发实参, encoded 参数块)。"""
    args = ['void *opaque']
    fwd = ['session']
    for a in f['abi_parameters']:
        cty = LLVM_TO_C.get(a['type'], 'void *')
        args.append('%s a%d' % (cty, a['index']))
        fwd.append('a%d' % a['index'])
    enc = []
    for a in f['abi_parameters']:
        if a['encoded']:
            cty = LLVM_TO_C.get(a['type'], 'uint32_t')
            enc.append(
                '  {\n'
                '    word_t arg_word;\n'
                + _ev('    word_encode((uint64_t)a%d@EV@, %d, &arg_word);\n',
                      a['index'], a['encoded']['width']) +
                '    if (!nnobf_commit(ctx, %d, &arg_word)) return 0;\n'
                '    ctx->temp_valid[%d] = 1u;\n'
                '  }\n'
                % (a['encoded']['slot'], a['encoded']['slot']))
    return (', '.join(args), ', '.join(args), ', '.join(fwd), ''.join(enc))


def render_module(npz, profile, layout, total, template, variants):
    """模块渲染：每函数一 TU（per-function 占位符 + 共享宏块）。"""
    tagw = profile['tags']['TAG_W']
    reg = profile['registry']
    storage = profile['storage']
    slot_fn = (variants['slot_argmax'] if profile['v_slots'] <= 8
               else variants['slot_codebook'])
    dense = variants['dense_fp16'] if storage == 'fp16' \
        else variants['dense_fp32']
    dnb = (variants['dense_no_bias_fp16'] if storage == 'fp16'
           else variants['dense_no_bias_fp32'])
    base = {}
    for name, off, size in layout:
        base[name] = off
    macro_block = emit_macro_block_module(profile, layout)
    object_choices_mod = (
        max(f_['object_count'] for f_ in profile['functions']) + 1)

    outs = []
    row = 0
    for i, f in enumerate(profile['functions']):
        args_sig, reuse_sig, fwd_args, enc_block = emit_call_begin_abi(f)
        values = {
            'TAG_W': tagw,
            'TAG_MOD': profile['tags']['TAG_MOD'],
            'TAG_IR': f['tags']['TAG_IR'],
            'TAG_K': f['tags']['TAG_K'],
            'V_SLOTS': str(f['v_slots']),
            'MAX_BYTES': str(f.get('max_bytes', 4)),
            # 扫描上限 = 本函数槽位数；哨兵行 = 模块级 slot_choices-1
            # （引擎实测：local <= V_SLOTS，哨兵候选 = 73 = 74-1）
            'SLOT_NOOP': str(profile['slot_choices'] - 1),
            **_mem_table_values(profile),
            'CONTROLLER_HEADS': str(profile['controller_heads']),
            'CONTROLLER_HIDDEN': str(profile.get('controller_hidden', 64)),
            'SLOT_CHOICES': str(profile['slot_choices']),
            'SLOT_SENTINEL': str(f['v_slots']),
            'SLOT_CODE_DIM': str(profile['slot_code_dim']),
            'LANE_DELTA_CHOICES': str(profile['lane_delta_choices']),
            'WIDTH_CHOICES': str(len(profile.get('width_values', [1, 32]))),
            'WIDTH_VALUES': ', '.join('%du' % w for w in
                                      profile.get('width_values', [1, 32])),
            'SELECTOR_HEADS': str(profile['selector_heads']),
            'SELECTOR_RANK': str(profile['selector_rank']),
            'OPTION_HIDDEN': str(profile['option_hidden']),
            'RAGGED_TERMS': str(profile['ragged_terms']),
            'RAGGED_SHAPES': emit_ragged_shapes(profile['ragged_shapes']),
            'RAGGED_OFFSETS': emit_ragged_offsets(
                ragged_offsets_table(profile['ragged_shapes'])[0]),
            'RAGGED_PARAM_MAX': str(
                ragged_param_max(profile['ragged_shapes'])),
            # M5: 模块模式共享 ragged 缓存(条目+参数存储)——首 TU 为
            # owner(定义),其余 TU 引 hidden extern;各 TU 的
            # RAGGED_PARAM_MAX 同为模块级值,共享存储定尺天然覆盖。
            'FS_RAGGED_OWNER': ('#define NNOBF_FS_RAGGED_OWNER 1'
                                if i == 0 else ''),
            # CHAME evidence 单元：首 TU 为 owner（全局/函数定义），其余
            # TU extern 视图（泳道关时仅注释，零扰动）
            'CHAME_GUARD': (chame_guard_block(i == 0)
                            if _GUARD_EVIDENCE[0]
                            else '/* chame-antidebug lanes off */\n'),
            # arp NN 物化单元：首 TU 为 owner（潜码表 + decode walk），
            # 其余 TU 仅注释（guard_arp.c 的 extern 引用由 owner 满足）
            'ARP_GUARD': arp_guard_block(i == 0),
            'REGION_ENTRY_ROWS': str(f['region_entry_rows']),
            'MAX_ACTIONS': str(f['max_actions']),
            'LANE_DELTAS': profile['lane_deltas'],
            **{k: str(v) for k, v in profile['eff'].items()},
            'N_INIT_CONST': str(len(f['initial_constants'])),
            'INIT_CONST_BODY': emit_init_const_body(f),
            'CALL_BEGIN_COMMITS': emit_call_begin_commits(f),
            'CALL_BEGIN_ARGS': args_sig,
            'CALL_REUSE_ARGS': reuse_sig,
            'CALL_BEGIN_FWD_ARGS': fwd_args,
            'CALL_BEGIN_ENCODE': enc_block,
            'BOUNDARY_CASES': emit_boundary_cases_multi(f),
            # 对象头 = 模块级并集（引擎实测：TU23 OBJECT_CHOICES=20、
            # 哨兵 19 = max(object_count)+1-1；本函数越界由
            # ctx->object_count 校验兜底）
            'OBJECT_CHOICES': str(object_choices_mod),
            'OBJECT_SENTINEL': str(object_choices_mod - 1),
            'CALL_PERSIST_BYTES': str(f['call_persist_bytes']),
            'MODULE_PERSIST_BYTES': str(profile['module_persist_bytes']),
            'OBJECT_COUNT': str(f['object_count']),
            'OBJECT_TABLE': emit_object_table(f),
            'CALL_END_RET': profile['call_end_ret'],
            'CALL_END_DECODE': emit_call_end_decode(profile),
            'SELF_TEST': emit_self_test(profile),
            'MACRO_BLOCK': macro_block,
            'WEIGHTS_EXTERN': emit_weights_extern(profile, total).rstrip('\n'),
            'FN_DENSE': dense,
            'FN_DENSE_NO_BIAS': dnb,
            'FN_CONTROLLER_SLOT': slot_fn,
            'FN_CONTROLLER_STEP': emit_controller_step(profile),
        }
        fn_reg = dict(reg)
        fn_reg['q_init'] = 'qinit%02x' % i
        fn_reg['region_q'] = 'rq%02x' % i

        def resolve(m, _reg=fn_reg, _vals=values):
            key = m.group(1)
            if key.startswith('W:'):
                name = key[2:]
                return 'NNOBF_W_%s_%s' % (tagw, _reg[name])
            if key in _vals:
                return _vals[key]
            raise KeyError('unresolved placeholder: %s' % key)

        out = template
        prev = None
        while prev != out:
            prev = out
            out = re.sub(r'<<([^<>]+)>>', resolve, out)
        outs.append((f['function'], out))
        row += f['region_entry_rows']
    return outs


def emit_init_const_body_f(f):
    return emit_init_const_body(f)


def main_module(args):
    profile = json.load(open(args.profile))
    assert profile.get('mode') == 'module'
    for k, v in [('TAG_W', args.tag_w), ('TAG_MOD', args.tag_mod),
                 ('TAG_K', args.tag_k)]:
        if v:
            profile['tags'][k] = v
    npz = np.load(args.weights)
    layout, total = compute_layout_module(npz, profile)
    print('layout(module): %d tensors, total %d floats'
          % (len(layout), total))
    template = open(os.path.join(DATA, 'template_main.txt'), encoding='utf-8').read()
    variants = json.load(open(os.path.join(DATA, 'variants.json')))
    variants['slot_codebook'] = variants['slot_codebook'].replace(
        'NNOBF_W_43e7a084facd_00fb', '<<W:slot_codes>>')
    variants['slot_codebook'] = re.sub(
        r'local <= 14', 'local <= <<SLOT_SENTINEL>>',
        variants['slot_codebook'])
    variants['slot_codebook'] = re.sub(
        r'local < 14 \? local : 14', 'local < <<SLOT_SENTINEL>> '
        r'? local : <<SLOT_NOOP>>', variants['slot_codebook'])
    variants['slot_codebook'] = re.sub(
        r'selected == 14', 'selected == <<SLOT_NOOP>>',
        variants['slot_codebook'])
    variants['slot_argmax'] = variants['slot_argmax'].replace(
        'selected == 8', 'selected == <<SLOT_NOOP>>')

    os.makedirs(args.out, exist_ok=True)
    tus = render_module(npz, profile, layout, total, template, variants)
    for i, (fn, text) in enumerate(tus):
        path = os.path.join(args.out, 'runtime_%d_%s.c' % (i, fn))
        open(path, 'w', encoding='utf-8').write(text)
    wpath = os.path.join(args.out, 'runtime_weights.c')
    wtext = emit_weights_c(npz, profile, layout, total)
    open(wpath, 'w').write(wtext)
    open(os.path.join(args.out, 'runtime_module_state.c'), 'w').write(
        emit_module_state_c(profile))
    print('wrote %d function TUs + weights + module_state → %s'
          % (len(tus), args.out))
    if args.verify:
        structural_diff_module(args.out, args.verify, profile)


def structural_diff_module(gen_dir, real_dir, profile):
    """多 TU 结构级对比（函数集/宏集/行数）。"""
    import glob
    ok = 0
    for i, f in enumerate(profile['functions']):
        fn = f['function']
        gen = os.path.join(gen_dir, 'runtime_%d_%s.c' % (i, fn))
        reals = glob.glob(os.path.join(real_dir, 'runtime_%d_*.c' % i))
        if not reals or not os.path.exists(gen):
            print('MISSING %s' % fn)
            continue
        real = reals[0]
        g, r = open(gen).read(), open(real).read()
        same_lines = g.count('\n') == r.count('\n')
        gf = set(re.findall(r'static \w+ nnobf_\w+', g))
        rf = set(re.findall(r'static \w+ nnobf_\w+', r))
        ok += int(same_lines and gf == rf)
        if not (same_lines and gf == rf):
            print('DIFF  %s lines %d/%d static-fns %d/%d'
                  % (fn, g.count('\n'), r.count('\n'), len(gf), len(rf)))
    print('structural: %d/%d TUs match' % (ok, len(profile['functions'])))


if __name__ == "__main__":
    main()
