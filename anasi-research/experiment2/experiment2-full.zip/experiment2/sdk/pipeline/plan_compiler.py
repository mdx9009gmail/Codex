#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ANANSI 引擎 IR→动作程序编译器 —— 可运行参考实现（任务 A1 交付物 2）。

把被保护函数的 LLVM IR（文本 .ll）整数计算区域翻译成 module_plan.json 等价的
"神经动作程序"（steps 列表），规则逆向自 ANANSI 引擎（见 decomp/notes-ir2plan-spec.md）。

覆盖范围（与两轮金标准实例对齐的指令子集，超出即报错退出）：
  - 指令：alloca / call / br / ret / phi / store（原生屏障）
    icmp(eq|ne|ult) / load(直接 alloca 指针) / add / and / or / xor /
    shl|lshr(常量移位量 1..7) / select
  - 类型：i1 / i32
  - rewrite_kind：hybrid-regions（控制流主权留原生 LLVM）

用法：
    python3 plan_compiler.py INPUT.ll [-o OUT.json] [--function main]
        [--module-identifier PATH] [--source-name t.c]

验收（对两轮金标准）：
    python3 plan_compiler.py run-6qdudb/input/program/input.ll \
        --module-identifier /tmp/nnobf-ir-compat-2210868245/input.ll

关键算法（全部经两轮实例反推 + 反编译佐证）：
  1. 值键：SSA= function:<fn>:block:unnamed_block_<B>:inst:<I>；
     常量= const:i<宽度>:<小写hex无前导零>。
  2. 槽分配：初始槽 = 常量+live-in 按键字典序（std::map 序）顺序编号；
     工作槽 = 线性扫描最低空闲槽（半开活跃区间，区间边界值延寿至计划尾）。
  3. 指令降级：icmp eq→(ULT,ULT,OR,XOR1) 4 步；icmp ne→(ULT,ULT,OR) 3 步；
     icmp ult→1 步；常量移位→funnel(0xK..K 逐 lane 复制)+AND(2^w-1) 2 步；
     load→memory 步（地址表达式，栈对象镜像）。
"""

import argparse
import hashlib
import json
import re
import sys

# ---------------------------------------------------------------------------
# 0. 常量：能力矩阵（certification.json accepted_operations 的已验证子集）
# ---------------------------------------------------------------------------
VERIFIED_OPS = {  # operation -> (arity, is_memory)
    "ADD": (2, False), "AND": (2, False), "OR": (2, False), "XOR": (2, False),
    "SUB": (2, False), "MUL": (2, False),
    "ICMP_ULT": (2, False), "SELECT": (3, False),
    "SHIFT_SHL": (3, False), "SHIFT_LSHR": (3, False),
    "SDIV": (2, False), "SREM": (2, False),
    "UDIV": (2, False), "UREM": (2, False),
    "TRUNC": (1, False), "ZEXT": (1, False), "SEXT": (1, False),
    "COPY": (1, False),
    "LOAD": (0, True),
}
NATIVE_OPCODES = {"alloca", "call", "br", "ret", "phi", "store",
                  "getelementptr", "inttoptr", "freeze", "extractvalue",
                  "unreachable", "switch"}
NEURAL_OPCODES = {"icmp", "load", "add", "sub", "mul", "and", "or", "xor",
                  "shl", "lshr", "ashr", "select", "sdiv", "srem", "udiv",
                  "urem", "trunc", "zext", "sext", "store", "ptrtoint"}
# 移位 funnel 核的已实证 barrel 档位（neural_core probe：exact_s={1,2,4}）
SHIFT_STAGES = (4, 2, 1)

PTR_TYPE_ID = "ptr:as0:64"

EVENT_KINDS = ["entry", "condition", "loop-backedge", "memory", "call",
               "return", "sync", "exit"]


def type_info(type_id):
    """i1/i8/i16/i32/i64/ptr → (kind, bit_width, storage, align)。"""
    if type_id in ("ptr", PTR_TYPE_ID):
        return "pointer", 64, 8, 8
    m = re.fullmatch(r"i(\d+)", type_id)
    if not m:
        raise NotImplementedError(f"type {type_id} outside verified subset")
    w = int(m.group(1))
    if w not in (1, 8, 16, 32, 64):
        raise NotImplementedError(f"width {w} not in accepted_integer_widths")
    if w == 1:
        return "predicate", 1, 1, 1
    return "integer", w, (w + 7) // 8, (w + 7) // 8


def encoded_bytes(width):
    return 1 if width <= 1 else (width + 7) // 8


# ---------------------------------------------------------------------------
# 0b. 全局类型表（%struct.X = type {...} / 数组嵌套）→ (size, align)
# ---------------------------------------------------------------------------
def _elem_size_align(elem, structs):
    """单个类型元素 → (size, align)。elem 为文本（'i8'/'[16 x i8]'/'%struct.S'/'ptr'）。"""
    elem = elem.strip()
    if elem in ("ptr", "ptr:as0:64"):
        return 8, 8
    m = re.fullmatch(r"i(\d+)", elem)
    if m:
        w = int(m.group(1))
        if w == 1:
            return 1, 1
        return (w + 7) // 8, (w + 7) // 8
    m = re.fullmatch(r"\[\s*(\d+)\s*x\s+(.+)\]", elem)
    if m:
        n = int(m.group(1))
        es, ea = _elem_size_align(m.group(2), structs)
        return n * es, ea
    if elem.startswith("%"):
        if elem in structs:
            return structs[elem]
        # 未知结构体：按引用尺寸兜底（对齐 8——保守）
        return 8, 8
    raise NotImplementedError(f"elem type {elem}")


def layout_struct(body, structs):
    """'{ i16, [64 x i8], i16 }' → (size, align)（LLVM 顺序布局 + 对齐填充）。"""
    fields = [f.strip() for f in re.sub(r"^\{|\}$", "", body).split(",")
              if f.strip()]
    off = 0
    align = 1
    for f in fields:
        fs, fa = _elem_size_align(f, structs)
        align = max(align, fa)
        off = (off + fa - 1) // fa * fa
        off += fs
    return (off + align - 1) // align * align, align


def parse_struct_types(text):
    """扫描 module 级 '%name = type {...}' 定义（两轮遍历解引用嵌套）。"""
    structs = {}
    for _ in range(3):
        changed = False
        for m in re.finditer(r"^(%[\w.$-]+)\s*=\s*type\s*(\{.*\})\s*$",
                             text, re.M):
            name, body = m.group(1), m.group(2)
            sz, al = layout_struct(body, structs)
            if structs.get(name) != (sz, al):
                structs[name] = (sz, al)
                changed = True
        if not changed:
            break
    return structs


def alloca_size_align(type_str, structs):
    """alloca 操作数类型（'i8'/'[16 x i8]'/'%struct.S'/'ptr'）→ (size, align)。"""
    return _elem_size_align(type_str, structs)


# ---------------------------------------------------------------------------
# 1. 轻量 LLVM 文本 IR 解析（只处理两轮涉及的指令子集）
# ---------------------------------------------------------------------------
class Inst:
    __slots__ = ("opcode", "ssa", "type", "pred", "flags", "operands",
                 "callee", "ptr", "align", "block_idx", "inst_idx", "ref",
                 "function", "value_width", "raw")

    def __init__(self, opcode):
        self.opcode = opcode
        self.ssa = None          # 结果 SSA 名（%1 / %.0），无结果则 None
        self.type = None         # 结果类型（i32 / i1 / ptr）
        self.pred = None         # icmp 谓词
        self.flags = []          # nuw/nsw/disjoint...
        self.operands = []       # [(kind, value)] kind∈{ssa,const}
        self.callee = None
        self.ptr = None          # load 的指针 SSA
        self.align = 4
        self.block_idx = self.inst_idx = 0
        self.ref = None


def _strip_line(line):
    """去注释/元数据后缀（; 开头整行注释、!tbaa、#N 属性组）。"""
    line = re.sub(r"\s*;.*$", "", line)
    line = re.sub(r",?\s*![A-Za-z0-9]+\s*$", "", line)
    line = re.sub(r"\s*#\d+\s*$", "", line)
    return line.strip()


def _parse_operands(rest):
    """从 `, a, b, 1, ptr %N, null, true` 形态提取操作数（SSA/常量）。

    带 'ptr %N' 类型前缀的 token 保留 ('ptr-ssa', %N) 形态（指针比较等
    需要）；'null'/'true'/'false' 折叠为常量 0/1/0。
    """
    out = []
    for tok in rest:
        tok = tok.strip()
        if not tok:
            continue
        m = re.fullmatch(r"(ptr|[\w.$-]+)\s+(%[\w.$-]+)", tok)
        if m:
            out.append(("ptr-ssa", m.group(2)))
            continue
        if tok.startswith("%"):
            out.append(("ssa", tok))
            continue
        if tok == "null":
            out.append(("ptr-const", 0))
            continue
        if tok == "true":
            out.append(("const", 1))
            continue
        if tok == "false":
            out.append(("const", 0))
            continue
        try:
            v = int(tok, 0)
        except ValueError:
            continue          # 其余带类型前缀 token：跳过
        out.append(("const", v))
    return out


def parse_llvm_ir(text):
    """解析 module 文本 → {function_name: [block0_insts, block1_insts, ...]}。

    附加产物（模块级属性）：
      STRUCT_TYPES  %struct.X 定义 → {name: (size, align)}
      FUNC_SIGS     函数签名 → {fn: [(type, ssa_name), ...]}
    """
    global STRUCT_TYPES, FUNC_SIGS
    STRUCT_TYPES = parse_struct_types(text)
    FUNC_SIGS = {}

    functions = {}
    cur_fn = None
    cur_blocks = None
    cur_block = None

    for raw in text.splitlines():
        line = _strip_line(raw)
        if not line:
            continue
        m = re.match(r"define\s+.*?@([\w.$-]+)\s*\(", line)
        if m:
            cur_fn = m.group(1)
            cur_blocks = [[]]
            cur_block = cur_blocks[0]
            functions[cur_fn] = cur_blocks
            # 签名：参数列表（单行 define 的参数全在首行）
            # 括号感知切分（initializes((0, 16)) 内含逗号）
            pm = re.search(r"\((.*)\)", line)
            parts, depth, cur = [], 0, ""
            for ch in (pm.group(1) if pm else ""):
                if ch == "(":
                    depth += 1
                elif ch == ")":
                    depth -= 1
                if ch == "," and depth == 0:
                    parts.append(cur)
                    cur = ""
                else:
                    cur += ch
            if cur.strip():
                parts.append(cur)
            params = []
            for tok in parts:
                tok = tok.strip()
                if not tok:
                    continue
                vm = re.search(r"(%[\w.$-]+)$", tok)
                body = tok[:vm.start()] if vm else tok
                # 剥带括号属性（含一层嵌套：initializes((0, 1))）
                body = re.sub(r"\w+\(\s*\w+\s+\d+\s*,\s*-?\d+\s*\)\)?",
                              " ", body)
                body = re.sub(r"\w+\([^()]*\)", " ", body)
                body = re.sub(r"\(\s*\d+\s*,\s*-?\d+\s*\)", " ", body)
                cands = re.findall(
                    r"\[[^\[\]]*\]|%[\w.$-]+|i\d+|ptr|float|double",
                    body)
                ty = cands[-1] if cands else "i32"
                if ty.startswith("%") or ty.startswith("["):
                    ty = "ptr"           # 按值聚合参数 → 指针宽度
                if vm:
                    params.append((ty, vm.group(1)))
            FUNC_SIGS[cur_fn] = params
            continue
        if cur_fn is None:
            continue
        if line.startswith("}"):
            cur_fn = None
            cur_blocks = None
            continue
        m = re.match(r"^([\w.]+):\s*$", line)  # 块标签（含数字标签）
        if m:
            cur_block = []
            cur_blocks.append(cur_block)
            continue

        inst = _parse_inst(line)
        if inst is not None:
            cur_block.append(inst)
    return functions


def _parse_inst(line):
    ssa = None
    m = re.match(r"(%[\w.$-]+)\s*=\s*(.*)$", line)
    rest = line
    if m:
        ssa, rest = m.group(1), m.group(2)

    # tail/musttail call 前缀剥离
    m = re.match(r"(?:must)?tail\s+(call\s.*)$", rest)
    if m:
        rest = m.group(1)

    head = rest.split(None, 1)[0] if rest.split() else ""
    inst = None

    # 记录原文（gep 步长/常量索引推断用）
    raw = rest

    if head == "alloca":
        inst = Inst("alloca")
        inst.ssa = ssa
        m2 = re.match(
            r"alloca\s+(\[[^\]]+\]|%[\w.$-]+|[\w:]+)", rest)
        inst.type = m2.group(1) if m2 else "i8"
    elif head == "call":
        inst = Inst("call")
        inst.ssa = ssa
        m2 = re.match(r"call\s+[^@]*@([\w.$-]+)\(", rest)
        inst.callee = m2.group(1) if m2 else "?"
        # 返回类型：跳过调用约定（fastcc/…/cc N）与结果属性 token
        # （noundef/zeroext/signext/memory(...)/align N 等）后，紧邻
        # callee 的类型 token。修正：C++ 的 unsigned char 返回带
        # `noundef zeroext`——原白名单正则失配即 fallback i32，i8 call
        # 结果被登记为 i32 → instrument 的 scalar live-in 发射
        # `zext i32 %x`（实际 i8）编译错误（首暴露：crackme_case_5 的
        # add8/gf_multiply 调用链）。asm call（类型后非 @/% callee）
        # 不匹配 → 维持 i32 fallback（与原行为一致）。
        m3 = re.match(
            r"call\s+(?:[^\s(@%]+(?:\([^()]*\))?\s+)*?"
            r"(\{[^}]*\}|void|ptr|half|float|double|i\d+)\s+"
            r"[@%][\w.$-]+\(", rest)
        inst.type = m3.group(1) if m3 else "i32"
        if inst.type.startswith("{"):
            inst.type = "ptr"           # asm 多返回值 → 按指针宽
        # 参数 SSA 提取（live-out 检测需要 call 消费的区域产物）。
        # 全量 %token 提取：直接调用（@f）/间接调用（%fp）/ptr 参数
        # （ptr noundef %x）/标量参数（i32 noundef %y）全部覆盖。
        ops_seen = []
        for m in re.findall(r"%[\w.$-]+", rest):
            if m not in ops_seen:
                ops_seen.append(m)
        inst.operands = [("ssa", m) for m in ops_seen]
    elif head == "icmp":
        inst = Inst("icmp")
        inst.ssa = ssa
        m2 = re.match(r"icmp\s+(?:samesign\s+)?(\w+)\s+([\w:]+)\s+(.*)$",
                      rest)
        inst.pred, inst.type = m2.group(1), m2.group(2)
        inst.operands = _parse_operands(m2.group(3).split(","))
    elif head == "load":
        inst = Inst("load")
        inst.ssa = ssa
        m2 = re.match(r"load\s+(?:volatile\s+)?(\w+)\s*,\s*ptr\s+"
                      r"([@%][\w.$-]+)", rest)
        if m2 is None:
            return None
        inst.type, inst.ptr = m2.group(1), m2.group(2)
        am = re.search(r"align\s+(\d+)", rest)
        inst.align = int(am.group(1)) if am else 1
    elif head == "getelementptr":
        inst = Inst("getelementptr")
        inst.ssa = ssa
        m2 = re.match(r"getelementptr\s+(?:inbounds\s+)?(?:nuw\s+|nsw\s+)*"
                      r"(?:\[[^\]]+\]|%?[\w.$-]+)\s*,\s*"
                      r"ptr\s+([@%][\w.$-]+)(.*)$", rest)
        if m2:
            inst.type = "ptr"
            inst.ptr = m2.group(1)
            inst.operands = [("ssa", m2.group(1))] if \
                m2.group(1).startswith("%") else []
            # 索引操作数（i64 %N / i64 常量）：gep 原生消费这些值
            for tok in m2.group(2).split(","):
                tok = tok.strip()
                m3 = re.fullmatch(r"i\d+\s+(%[\w.$-]+)", tok)
                if m3:
                    inst.operands.append(("ssa", m3.group(1)))
    elif head == "switch":
        # 开关终结符（原生屏障；被切换值是原生消费者）
        inst = Inst("switch")
        inst.ssa = ssa
        m2 = re.match(r"switch\s+[\w:]+\s+(%[\w.$-]+)\s*,\s*label", rest)
        if m2:
            inst.operands = [("ssa", m2.group(1))]
    elif head in ("unreachable", "freeze", "extractvalue"):
        inst = Inst(head)
        inst.ssa = ssa
        if head == "freeze":
            m2 = re.match(r"freeze\s+([\w:]+)\s+(%[\w.$-]+)$", rest)
            if m2:
                inst.type = m2.group(1)
                inst.operands = [("ssa", m2.group(2))]
        elif head == "extractvalue":
            inst.operands = [("ssa", m) for m in
                             re.findall(r"%[\w.$-]+", rest.split(",", 1)[0])]
    elif head in ("br", "ret", "phi", "store"):
        inst = Inst(head)
        inst.ssa = ssa
        if head == "br":
            m2 = re.match(r"br\s+i1\s+(%\w+)\s*,", rest)
            if m2:
                inst.operands = [("ssa", m2.group(1))]
        elif head == "ret":
            m2 = re.match(r"ret\s+\w+\s+(.+)$", rest)
            if m2:
                inst.operands = _parse_operands([m2.group(1)])
        elif head == "phi":
            m3 = re.match(r"phi\s+(ptr|i\d+)\s", rest)
            inst.type = m3.group(1) if m3 else None
            inst.operands = [("ssa", v) for v in re.findall(r"\[\s*(%\w+)\s*,", rest)]
        elif head == "store":
            sm = re.match(r"store\s+(?:volatile\s+)?([\w.$-]+)\s+"
                          r"(%[\w.$-]+|@[\w.$-]+|true|false|-?\d+|null)\s*,\s*"
                          r"ptr\s+([@%][\w.$-]+)", rest)
            if sm is None:
                return None
            inst.type = sm.group(1)
            val = sm.group(2)
            if val.startswith("%"):
                inst.operands = [("ssa", val)]
            elif val.startswith("@"):
                inst.operands = [("global", val)]   # 全局常量 → 原生屏障
            elif val == "null":
                inst.operands = [("ptr-const", 0)]
            elif val in ("true", "false"):
                inst.operands = [("const", 1 if val == "true" else 0)]
            else:
                inst.operands = [("const", int(val, 0))]
            inst.ptr = sm.group(3)
            if inst.ptr.startswith("%"):
                inst.operands.append(("ssa", inst.ptr))
            am = re.search(r"align\s+(\d+)", rest)
            inst.align = int(am.group(1)) if am else 1
    elif head in ("add", "sub", "mul", "and", "or", "xor",
                  "shl", "lshr", "ashr", "sdiv", "srem", "udiv", "urem"):
        m2 = re.match(r"(add|sub|mul|and|or|xor|shl|lshr|ashr|sdiv|srem|"
                      r"udiv|urem)((?:\s+\w+)*)\s+"
                      r"(\w+)\s+(.*)$", rest)
        inst = Inst(m2.group(1))
        inst.ssa = ssa
        inst.flags = m2.group(2).split()
        inst.type = m2.group(3)
        inst.operands = _parse_operands(m2.group(4).split(","))
    elif head in ("trunc", "zext", "sext"):
        m2 = re.match(r"(trunc|zext|sext)\s+((?:nuw|nsw|nneg|exact)\s+)*"
                      r"i(\d+)\s+(%\w+)\s+to\s+i(\d+)$", rest)
        if m2 is None:
            return None
        inst = Inst(m2.group(1))
        inst.ssa = ssa
        inst.type = "i" + m2.group(5)
        inst.operands = [("ssa", m2.group(4))]
        inst.value_width = int(m2.group(3))   # 源宽度
    elif head == "ptrtoint":
        inst = Inst("ptrtoint")
        inst.ssa = ssa
        m2 = re.match(r"ptrtoint\s+ptr\s+(%[\w.$-]+)\s+to\s+i(\d+)$", rest)
        inst.type = "i" + m2.group(2)
        inst.value_width = 64
        inst.operands = [("ssa", m2.group(1))]
    elif head == "inttoptr":
        inst = Inst("inttoptr")
        inst.ssa = ssa
        m2 = re.match(r"inttoptr\s+i(\d+)\s+(%[\w.$-]+)\s+to\s+ptr$", rest)
        inst.type = "ptr"
        inst.value_width = int(m2.group(1))
        inst.operands = [("ssa", m2.group(2))]
    elif head == "select":
        inst = Inst("select")
        inst.ssa = ssa
        m2 = re.match(r"select\s+(\w+)\s+(%[\w.$-]+)\s*,\s*(\w+)\s+"
                      r"(%[\w.$-]+|true|false|-?\d+)\s*,\s*"
                      r"(\w+)\s+(%[\w.$-]+|true|false|-?\d+)$", rest)
        if m2 is None:
            return None
        inst.type = m2.group(3)
        # cond
        inst.operands = [("ssa", m2.group(2))]
        # true / false 值
        for part in (m2.group(4), m2.group(6)):
            if part.startswith("%"):
                inst.operands.append(("ssa", part))
            elif part in ("true", "false"):
                inst.operands.append(("const", 1 if part == "true" else 0))
            else:
                inst.operands.append(("const", int(part, 0)))
    else:
        return None
    if inst is not None:
        inst.raw = raw
        if inst.type == "ptr":
            inst.type = PTR_TYPE_ID
    return inst


# ---------------------------------------------------------------------------
# 2. 值表 / 步骤中间表示
# ---------------------------------------------------------------------------
class Value:
    __slots__ = ("key", "kind", "type_id", "constant_value", "source_reference",
                 "slot", "origin_inst")

    def __init__(self, key, kind, type_id, constant_value=None,
                 source_reference=None):
        self.key = key
        self.kind = kind              # constant / live-in / ssa
        self.type_id = type_id
        self.constant_value = constant_value
        self.source_reference = source_reference
        self.slot = None
        self.origin_inst = None       # 产生该值的 Inst（ssa）

    def width(self):
        return type_info(self.type_id)[1]

    def to_json(self):
        _kind, w, _, _ = type_info(self.type_id)
        return {
            "key": self.key, "kind": self.kind,
            "type_kind": "pointer" if _kind == "pointer" else "integer",
            "logical_width": w, "encoded_bytes": encoded_bytes(w),
            "type_id": self.type_id, "slot": self.slot,
            "constant_value": self.constant_value,
            "source_reference": self.source_reference, "abi_index": None,
        }


class Step:
    __slots__ = ("origin_reference", "action_kind", "operation", "inputs",
                 "output", "source_type_id", "value_type_id", "address",
                 "metadata")

    def __init__(self, origin_reference, action_kind, operation, inputs,
                 output, source_type_id, value_type_id, metadata,
                 address=None):
        self.origin_reference = origin_reference
        self.action_kind = action_kind       # tool / memory
        self.operation = operation
        self.inputs = inputs                 # value keys
        self.output = output                 # value key
        self.source_type_id = source_type_id
        self.value_type_id = value_type_id
        self.address = address
        self.metadata = metadata

    def to_json(self, idx, slots):
        src_w = type_info(self.source_type_id)[1]
        val_w = type_info(self.value_type_id)[1]
        _kind = type_info(self.value_type_id)[0]
        return {
            "index": idx,
            "origin_reference": self.origin_reference,
            "action_kind": self.action_kind,
            "operation": self.operation,
            "input_values": list(self.inputs),
            "input_slots": [slots[k] for k in self.inputs],
            "output_value": self.output,
            "output_slot": slots[self.output] if self.output else None,
            "source_type_id": self.source_type_id,
            "source_width": src_w,
            "value_type_id": self.value_type_id,
            "type_kind": "pointer" if _kind == "pointer" else "integer",
            "logical_width": val_w,
            "address": self.address,
            "metadata": self.metadata,
            "next_action": None, "true_action": None, "false_action": None,
            "next_slot_renames": [], "true_slot_renames": [],
            "false_slot_renames": [],
        }


# ---------------------------------------------------------------------------
# 3. 计划编译器
# ---------------------------------------------------------------------------
class PlanCompiler:
    def __init__(self, function_name, blocks, region_gaps=False):
        self.fn = function_name
        self.blocks = blocks            # [[Inst]]
        self.region_gaps = region_gaps  # 任务 E：区域间哑索引（默认关闭
                                        # 以保持 t1/t2 金标准 0 差异）
        self.values = {}                # key -> Value（std::map 语义：排序遍历）
        self.steps = []
        self.objects = {}               # alloca ref -> object dict
        self._windows = {}              # access window objects（oid -> dict）
        self.def_inst = {}              # ssa name -> Inst
        self.regions = []               # [(start_step, count, [Inst], region_id)]

        # 指令引用编号：block 索引 + 块内指令序号（含终结符）
        for bi, block in enumerate(self.blocks):
            for ii, inst in enumerate(block):
                inst.block_idx, inst.inst_idx = bi, ii
                inst.ref = (f"function:{self.fn}:block:unnamed_block_{bi}"
                            f":inst:{ii}")
                if inst.ssa:
                    self.def_inst[inst.ssa] = inst

    # ---- 值注册 ----------------------------------------------------------
    def ssa_value(self, inst, suffix=None, key=None, type_id=None):
        """注册/取一条 SSA 指令的结果值（可带综合后缀/类型覆盖）。

        修正:alloca 产物的 SSA 实际类型恒为指针,inst.type 只是所分配
        元素的存储类型。原实现把元素类型(如 %struct.CRYPT_SHA2_256_Ctx
        或 i64)直接记为值类型,导致 (a) to_json 的 type_info 对结构体
        抛 NotImplementedError;(b) 内联后含结构体局部的函数(如
        always_inline 展开的 pub_kdf_wbp_environment)无法编译计划;
        (c) 标量 live-in 导出时 i64 vs ptr 类型错配。此处对 alloca 一律
        记 PTR_TYPE_ID,指针宽度与 i64 编码字节数一致,布局不变。"""
        k = key or (inst.ref + suffix if suffix else inst.ref)
        if k not in self.values:
            _eff = type_id or inst.type
            if inst.opcode == "alloca":
                _eff = PTR_TYPE_ID
            elif inst.opcode == "icmp":
                # 修正:icmp 的 inst.type 是被比较操作数的类型,而 SSA
                # 结果恒为 i1。原实现把操作数类型(常为 i64)记为值类型,
                # 标量 live-in 导出时走 i64 直存分支 → "defined with
                # type 'i1' but expected 'i64'" 编译错误(首个暴露:
                # stub_loader 的 validate_probe_read 跨区 icmp)。
                _eff = "i1"
            v = Value(k, "ssa", _eff, source_reference=inst.ref)
            v.origin_inst = inst
            self.values[k] = v
        return self.values[k]

    def const_value(self, width, val):
        """注册常量：const:i<width>:<hex>（小写、无前导零、宽度内模值）。"""
        masked = val & ((1 << width) - 1) if width < 64 else val & ((1 << 64) - 1)
        type_id = f"i{width}"
        k = f"const:{type_id}:{format(masked, 'x')}"
        if k not in self.values:
            self.values[k] = Value(k, "constant", type_id,
                                   constant_value=masked)
        return self.values[k]

    def ptr_const(self, val=0):
        """指针常量（null）：const:ptr:0，constant_value=null。"""
        k = f"const:ptr:{format(val, 'x')}"
        if k not in self.values:
            self.values[k] = Value(k, "constant", PTR_TYPE_ID,
                                   constant_value=None)
        return self.values[k]

    def arg_index_of(self, ssa):
        for i, (_, name) in enumerate(FUNC_SIGS.get(self.fn, [])):
            if name == ssa:
                return i
        return None

    def arg_value(self, idx, type_id):
        """函数参数 → live-in 值（function:<fn>:arg:<idx>）。"""
        k = f"function:{self.fn}:arg:{idx}"
        if k not in self.values:
            v = Value(k, "live-in", type_id, source_reference=k)
            self.values[k] = v
        return self.values[k]

    def live_in_value(self, inst):
        """原生指令结果被区域引用 → live-in 值。"""
        v = self.ssa_value(inst)
        v.kind = "live-in"
        return v

    def operand_value(self, inst, tok_kind, tok_val):
        """把指令操作数解析成值 key。"""
        if tok_kind == "ptr-const":
            return self.ptr_const(tok_val).key
        if tok_kind == "const":
            return self.const_value(type_info(inst.type)[1], tok_val).key
        src = self.def_inst.get(tok_val)
        if src is None:
            ai = self.arg_index_of(tok_val)
            if ai is not None:
                ty = FUNC_SIGS[self.fn][ai][0]
                if ty in ("ptr", PTR_TYPE_ID):
                    ty = PTR_TYPE_ID
                return self.arg_value(ai, ty).key
            raise NotImplementedError(f"unknown operand {tok_val}")
        if src.opcode in NEURAL_OPCODES \
                and id(src) in getattr(self, "_lowered", set()):
            return self.ssa_value(src).key
        # 原生定义（call 结果/被屏障的神经指令等）→ live-in
        return self.live_in_value(src).key

    # ---- 区域化 ----------------------------------------------------------
    def regionize(self):
        """每块取极大可神经化指令序列 → region（控制流留原生）。

        引擎 whibo 真值规则：
        - gep 透明（不截断 run——ef_collect R0=[store,gep,store] 实证）
        - 内存步分类：**栈对象常量地址**（alloca 直取/常量 gep 链）可并入
          run（t2/hashmix 载证）；**外部窗口 / 动态地址**（arg/phi/load 基
          指针、变下标 gep）独立成 region（引擎逐访问隔离——同步点语义）
        - 基指针为本 run 内神经 load 结果的访问必然隔离（同步源需原生）
        - 不可神经化的神经类指令（如 ashr）按原生屏障处理
        """
        for bi, block in enumerate(self.blocks):
            run = []
            for inst in block:
                if inst.opcode == "getelementptr":
                    continue                  # 透明
                if inst.opcode in NEURAL_OPCODES:
                    if not self._neuralizable(inst):
                        if run:
                            self.regions.append((len(self.steps), 0, run))
                        run = []
                        continue
                    if inst.opcode in ("load", "store"):
                        if self._isolated_memory(inst):
                            if run:
                                self.regions.append(
                                    (len(self.steps), 0, run))
                            self.regions.append(
                                (len(self.steps), 0, [inst]))
                            run = []
                            continue
                    run.append(inst)
                else:
                    if run:
                        self.regions.append((len(self.steps), 0, run))
                    run = []
            if run:
                self.regions.append((len(self.steps), 0, run))

    def _isolated_memory(self, inst):
        """窗口/动态地址内存访问 → 独立成 region（引擎逐访问隔离）。

        栈直取（alloca 指针，alloca 恒在入口支配）可并入 run；其余
        （gep/arg/phi/load 基指针——含 alloca 基的动态下标 gep）一律
        独立：边界必须发射在同步指针（gep 等）定义之后（支配性）。
        引擎对 alloca 基动态下标用 radix router（可并入）；我方无
        router 走窗口同步 → 必须隔离（已记录为偏差）。
        """
        d = self.def_inst.get(inst.ptr)
        if d is None:
            return True                       # arg 基 → 窗口
        if d.opcode == "alloca":
            return False                      # 栈直取 → 可并入
        return True                           # gep/phi/load 基 → 窗口

    def _neuralizable(self, inst):
        """能力判定子集：整数宽度、谓词、load/store 地址可归因。"""
        if inst.opcode == "icmp":
            if inst.pred not in ("eq", "ne", "ult", "ugt",
                                 "slt", "sgt", "sle", "sge"):
                return False
            if inst.type in ("ptr", PTR_TYPE_ID):
                return True
            if type_info(inst.type)[1] not in (1, 8, 16, 32, 64):
                return False
            return True
        if inst.opcode in ("load", "store"):
            if any(k == "global" for k, _v in inst.operands):
                return False             # 全局常量存值 → 原生屏障
            return self._base_ref_of(inst) is not None
        if inst.opcode in ("sdiv", "srem", "udiv", "urem"):
            return type_info(inst.type)[1] == 32
        if inst.opcode == "ptrtoint":
            return inst.value_width == 64
        if inst.opcode in ("trunc", "zext", "sext"):
            w_from = getattr(inst, "value_width", None)
            w_to = type_info(inst.type)[1]
            return (w_from in (1, 8, 16, 32, 64)
                    and w_to in (1, 8, 16, 32, 64))
        if inst.opcode in ("shl", "lshr"):
            if inst.operands[1][0] in ("const",):
                k = inst.operands[1][1]
                return 1 <= k <= 63
            # 非常量移位量 → log-tree（任务 E 新增）
            return type_info(inst.type)[1] == 32
        if inst.opcode == "ashr":
            return False
        if inst.type in ("ptr", PTR_TYPE_ID):
            return True
        w = type_info(inst.type)[1]
        return w in (1, 8, 16, 32, 64)

    def _base_ref_of(self, inst):
        """load/store 的基指针引用（alloca/gep/phi/load 结果或函数参数）。

        返回 (pointer_reference, kind)；不可归因返回 None。
        kind ∈ {alloca, gep, phi, load, arg}。
        """
        ptr = getattr(inst, "ptr", None)
        if ptr is None or not ptr.startswith("%"):
            return None
        d = self.def_inst.get(ptr)
        if d is not None:
            if d.opcode in ("alloca", "getelementptr", "phi", "load"):
                return (d.ref, d.opcode)
            return None                     # call/其他结果不可归因
        ai = self.arg_index_of(ptr)
        if ai is not None:
            return (f"function:{self.fn}:arg:{ai}", "arg")
        return None

    # ---- 指令降级 --------------------------------------------------------
    def lower(self):
        self.regionize()
        # 已实际降级的指令集（NEURAL 谓词但被屏障拦下的不算——其结果按
        # live-in 原生直通）
        self._lowered = {id(i) for _, _, run in self.regions for i in run}
        fixed = []
        for ridx, (_, _, run) in enumerate(self.regions):
            start = len(self.steps)
            deferred = []             # 周期微程序（MUL/DIVREM）浮到区域尾
            for inst in run:
                if (self.region_gaps and inst.opcode in
                        ("mul", "sdiv", "srem", "udiv", "urem")
                        and not self._result_consumed_in_region(inst, run)):
                    deferred.append(inst)
                    continue
                self._lower_inst(inst)
            for inst in deferred:
                if inst.opcode in ("sdiv", "srem", "udiv", "urem"):
                    sib = None
                    for other in deferred:
                        if (other is not inst
                                and other.opcode in
                                ("sdiv", "srem", "udiv", "urem")
                                and other.operands == inst.operands
                                and (other.opcode in ("sdiv", "udiv"))
                                != (inst.opcode in ("sdiv", "udiv"))):
                            sib = other
                            break
                    self._divrem_sibling = sib
                    self._lower_inst(inst)
                    self._divrem_sibling = None
                else:
                    self._lower_inst(inst)
            fixed.append((start, len(self.steps) - start, run))
        self.regions = fixed
        if self.region_gaps:
            self._respace_regions()

    # ---- 区域索引重排（任务 E）-------------------------------------------
    # 引擎的 hybrid 运行时（template nnobf_execute_range）：非连续入口
    # （start != next_pc，含全部回边）从 region_q[start] 重载入口潜态。
    # 在相邻区域之间留 1 个哑索引（永不执行的 COPY 步），使每个区域的
    # 入口状态与前一区域的 rollout 解耦 —— 周期性微程序（除法/乘法逐位
    # 循环）因此无需"数循环次数"，q 行数折叠到 ~周期+前缀。
    def _result_consumed_in_region(self, inst, run):
        """指令结果是否被同区域的非延迟指令消费（延迟会破坏数据流）。

        无消费者或消费者全部是可延迟微程序 → False（可安全延迟）。
        """
        result_ssa = inst.ssa
        consumers = [i for i in run
                     if i is not inst and result_ssa in
                     [tok for _, tok in i.operands]]
        if not consumers:
            return False
        defer_ops = ("mul", "sdiv", "srem", "udiv", "urem")
        non_defer_consumers = [c for c in consumers
                               if c.opcode not in defer_ops]
        return bool(non_defer_consumers)

    def _respace_regions(self):
        if len(self.regions) <= 1:
            return
        zero = self.const_value(32, 0)
        new_steps = []
        new_regions = []
        for ridx, (start, count, run) in enumerate(self.regions):
            if ridx > 0:
                # 哑步：占用 1 个索引（永不执行；教师为 COPY 自环）
                dk = f"nnobf:gap:{ridx}"
                if dk not in self.values:
                    self.values[dk] = Value(dk, "ssa", "i32",
                                            source_reference=dk)
                dv = self.values[dk]
                step = Step(f"nnobf:gap:{ridx}", "layout", "COPY",
                            [zero.key], dv.key, "i32", "i32",
                            {"derived_from": "region-gap", "stage": "gap"})
                new_steps.append(step)
            r_start = len(new_steps)
            new_steps.extend(self.steps[start:start + count])
            new_regions.append((r_start, count, run))
        self.steps = new_steps
        self.regions = new_regions

    def _emit(self, inst, operation, inputs, output_key, out_type_id,
              metadata, source_type_id=None, origin=None, address=None):
        src_tid = source_type_id or (inputs and self._type_of(inputs[0])) \
            or out_type_id
        step = Step(origin or inst.ref,
                    "memory" if operation == "LOAD" else "tool",
                    operation, inputs, output_key, src_tid, out_type_id,
                    metadata, address)
        self.steps.append(step)
        return step

    def _type_of(self, key):
        return self.values[key].type_id

    def _lower_inst(self, inst):
        op = inst.opcode
        ref = inst.ref

        if op == "icmp":
            self._lower_icmp(inst)
        elif op == "load":
            self._lower_load(inst)
        elif op == "store":
            self._lower_store(inst)
        elif op == "ptrtoint":
            # ptrtoint → COPY（ptr 槽 64bit 位型直传；引擎 whibo 实测）
            src = self.operand_value(inst, *inst.operands[0])
            self._emit_copy(inst, src, self.ssa_value(inst).key,
                            64, type_info(inst.type)[1],
                            src_tid=PTR_TYPE_ID)
        elif op in ("add", "sub"):
            self._lower_arith(inst)
        elif op == "mul":
            self._lower_mul(inst)
        elif op in ("sdiv", "srem", "udiv", "urem"):
            self._lower_divrem(inst)
        elif op in ("trunc", "zext", "sext"):
            self._lower_cast(inst)
        elif op in ("and", "or", "xor"):
            a, b = [self.operand_value(inst, *o) for o in inst.operands]
            self._emit(inst, op.upper(), [a, b], self.ssa_value(inst).key,
                       inst.type, {"source_width": type_info(inst.type)[1]})
        elif op in ("shl", "lshr"):
            if inst.operands[1][0] == "const":
                self._lower_shift(inst)
            else:
                self._lower_varshift(inst)
        elif op == "select":
            self._lower_select(inst)
        else:
            raise NotImplementedError(op)

    # icmp eq → (ULT a,b)(ULT b,a)(OR→unequal)(XOR 1→eq)；ne → 前 3 步；
    # ult → 单步。（结果类型恒为 i1）
    # icmp 降级（whibo 引擎真值形态）：
    #   eq  → (ULT a,b)(ULT b,a)(OR→unequal)(XOR 1→eq) 4 步
    #   ne  → 前 3 步；ult → 单步；ugt → 单步（操作数交换）
    #   slt(a,b) → XOR(a,M) XOR(b,M) ULT(l^M, r^M)（符号偏置宏）
    #   sgt(a,b) → slt(b,a)（左右交换）；sle(a,b) → NOT(slt)（negate 步）
    # ptr 操作数（含 null）→ const:ptr:0 / ptr 值槽（宽 64）
    def _lower_icmp(self, inst):
        a = self.operand_value(inst, *inst.operands[0])
        b = self.operand_value(inst, *inst.operands[1])
        pred = inst.pred
        is_ptr = inst.type in ("ptr", PTR_TYPE_ID)
        w = 64 if is_ptr else type_info(inst.type)[1]
        tid = PTR_TYPE_ID if is_ptr else inst.type
        if pred in ("eq", "ne"):
            left = self.ssa_value(inst, ":icmp:left-lt",
                                   type_id="i1").key
            right = self.ssa_value(inst, ":icmp:right-lt",
                                   type_id="i1").key
            self._emit(inst, "ICMP_ULT", [a, b], left, "i1",
                       {"predicate": "ult", "source_width": w},
                       source_type_id=tid)
            self._emit(inst, "ICMP_ULT", [b, a], right, "i1",
                       {"predicate": "ult", "source_width": w},
                       source_type_id=tid)
            unequal = self.ssa_value(inst, ":icmp:unequal",
                                     type_id="i1").key
            or_out = unequal if pred == "eq" \
                else self.ssa_value(inst, type_id="i1").key
            self._emit(inst, "OR", [left, right], or_out, "i1",
                       {"derived_from": "icmp", "predicate": "ne"},
                       source_type_id="i1")
            if pred == "eq":
                one = self.const_value(1, 1).key
                self._emit(inst, "XOR", [unequal, one],
                           self.ssa_value(inst, type_id="i1").key, "i1",
                           {"derived_from": "icmp", "predicate": "eq"},
                           source_type_id="i1")
        elif pred in ("ult", "ugt"):
            ins = [b, a] if pred == "ugt" else [a, b]
            self._emit(inst, "ICMP_ULT", ins,
                       self.ssa_value(inst, type_id="i1").key,
                       "i1", {"predicate": pred, "source_width": w},
                       source_type_id=tid)
        elif pred in ("slt", "sgt", "sle", "sge"):
            # sgt(a,b) → slt(b,a)；sle(a,b) → NOT(slt(b,a))——两者都交换；
            # sge(a,b) → NOT(slt(a,b))——不交换（与引擎 BITP7 偏置比较语义
            # 对齐；whibo 实测 sle(pos, file_len) 曾因缺交换被翻成 a>=s b）
            if pred in ("sgt", "sle"):
                l, r = b, a
            else:
                l, r = a, b
            mask = self.const_value(w, 1 << (w - 1)).key
            lb = self.ssa_value(inst, ":signed:left:biased").key
            rb = self.ssa_value(inst, ":signed:right:biased").key
            self._emit(inst, "XOR", [l, mask], lb, f"i{w}",
                       {"derived_from": "signed-icmp",
                        "stage": "sign-bias-left"}, source_type_id=tid)
            self._emit(inst, "XOR", [r, mask], rb, f"i{w}",
                       {"derived_from": "signed-icmp",
                        "stage": "sign-bias-right"}, source_type_id=tid)
            ult_md = {"derived_from": "icmp-shared-macro-v1",
                      "predicate": "ult",
                      "lowering_origin": "signed-icmp",
                      "primitive_schedule":
                          "predicate-specific-word-compare",
                      "internal_shared_alu_calls": 1,
                      "macro_cost_model":
                          "shared-alu-call-count-v16-sext-broadcast"}
            if pred in ("slt", "sgt"):
                self._emit(inst, "ICMP_ULT", [lb, rb],
                           self.ssa_value(inst, type_id="i1").key,
                           "i1", ult_md, source_type_id=f"i{w}")
            else:                      # sle / sge → NOT(slt/sgt)
                strict = self.ssa_value(inst, ":signed:strict",
                                        type_id="i1").key
                self._emit(inst, "ICMP_ULT", [lb, rb], strict, "i1",
                           ult_md, source_type_id=f"i{w}")
                one = self.const_value(1, 1).key
                self._emit(inst, "XOR", [strict, one],
                           self.ssa_value(inst, type_id="i1").key, "i1",
                           {"derived_from": "signed-icmp",
                            "stage": "negate"}, source_type_id="i1")
        else:
            raise NotImplementedError(f"icmp predicate {pred}")

    def _lower_arith(self, inst):
        a, b = [self.operand_value(inst, *o) for o in inst.operands]
        md = {"nuw": "nuw" in inst.flags, "nsw": "nsw" in inst.flags,
              "source_width": type_info(inst.type)[1]}
        self._emit(inst, inst.opcode.upper(), [a, b],
                   self.ssa_value(inst).key, inst.type, md)

    # shl/lshr K → funnel(0xK 逐 lane 复制) + AND(2^w-1)
    # K ∈ {1,2,4} 单档直发（t2 金标准字节形态）；其余 K 按 {4,2,1} 档位复合。
    def _lower_shift(self, inst):
        """常量移位（引擎 whibo 真值形态）。

        K = 8q + r：
        - r > 0：funnel 链（r 的置位档 1,2,4 升序）；**首个** funnel 吸收
          整车道偏移（da=q·dir, db=(q+1)·dir）；后续 (0, dir)；末尾单次
          AND 掩码（K=63 实证：f1(da=7,db=8) f2 f4 AND）
        - r = 0：byte-route OR(x, 0, da=q·dir)（binary-lanes）+ AND
        """
        a = self.operand_value(inst, *inst.operands[0])
        k = inst.operands[1][1]
        w = type_info(inst.type)[1]
        lanes = encoded_bytes(w)
        delta = -1 if inst.opcode == "shl" else 1
        operation = "SHIFT_SHL" if inst.opcode == "shl" else "SHIFT_LSHR"
        self.const_value(w, 0)
        self.const_value(w, k)
        mask_const = self.const_value(w, (1 << w) - 1).key
        q, r = k >> 3, k & 7
        cur = a
        if r == 0:
            zero = self.const_value(w, 0).key
            bkey = self.ssa_value(inst, ":shift:fixed:byte-route").key
            self._emit(inst, "OR", [cur, zero], bkey, inst.type,
                       {"derived_from": "shift-funnel-core-v1",
                        "stage": "shift:fixed:byte-route",
                        "input_layout": "binary-lanes",
                        "lane_delta_a": q * delta, "lane_delta_b": 0,
                        "lane_delta_c": 0},
                       origin=f"{inst.ref}:shift:fixed:byte-route")
            cur = bkey
        else:
            first = True
            for s in (1, 2, 4):
                if not (r & s):
                    continue
                if first:
                    da, db = q * delta, (q + 1) * delta
                    first = False
                else:
                    da, db = 0, delta
                funnel_const = self.const_value(
                    w, int("%02x" % s * lanes, 16)).key
                fkey = self.ssa_value(inst, f":shift:fixed:funnel:{s}").key
                self._emit(inst, operation, [cur, cur, funnel_const], fkey,
                           inst.type,
                           {"derived_from": "shift-funnel-core-v1",
                            "stage": f"shift:fixed:funnel:{s}",
                            "input_layout": "ternary-lanes",
                            "lane_delta_a": da, "lane_delta_b": db,
                            "lane_delta_c": 0},
                           origin=f"{inst.ref}:shift:fixed:funnel:{s}")
                cur = fkey
        self._emit(inst, "AND", [cur, mask_const],
                   self.ssa_value(inst).key, inst.type,
                   {"derived_from": "shift", "stage": "shift:fixed:result"},
                   origin=f"{inst.ref}:shift:fixed:result")

    def _lower_select(self, inst):
        c = self.operand_value(inst, *inst.operands[0])
        t = self.operand_value(inst, *inst.operands[1])
        f = self.operand_value(inst, *inst.operands[2])
        w = type_info(inst.type)[1]
        self._emit(inst, "SELECT", [c, t, f], self.ssa_value(inst).key,
                   inst.type, {"source_width": w}, source_type_id=inst.type)

    # ------------------------------------------------------------------
    # 任务 E 新增降级：组合整数算子（MUL/SDIV/SREM/UDIV/UREM）、
    # 变长移位 log-tree、trunc/zext/sext 强转。
    # 设计约束：微程序对（周期性）槽位模式复用 + 仅用已实证共享 ALU 算子
    # （ADD/SUB/AND/OR/XOR/SELECT/ICMP_ULT/SHIFT_{1,2,4}/COPY），使零训练
    # 闭式拟合的有效动作数（类数）受控（≤ 控制器输入维 97）。
    # ------------------------------------------------------------------
    def _synth_key(self, inst, suffix, type_id=None):
        return self.ssa_value(inst, suffix, type_id=type_id).key

    def _shift_stages(self, amount):
        """amount → barrel 档位序列（funnel 核 exact_s={1,2,4}）。"""
        out = []
        for st in SHIFT_STAGES:
            out += [st] * (amount // st)
            amount %= st
        return out

    def _shift_fixed(self, inst, key, amount, direction, w, tag,
                     final_out=None):
        """常量移位（funnel+mask 复合；每档一次 funnel+AND，档位 ∈ {4,2,1}）。

        final_out：若给定，最后一级 AND 直接落到该值键（省一步 COPY）。"""
        cur = key
        delta = -1 if direction == "shl" else 1
        operation = "SHIFT_SHL" if direction == "shl" else "SHIFT_LSHR"
        lanes = encoded_bytes(w)
        self.const_value(w, 0)
        self.const_value(w, amount)
        stages = self._shift_stages(amount)
        for i, k in enumerate(stages):
            funnel_const = self.const_value(
                w, int("%02x" % k * lanes, 16)).key
            mask_const = self.const_value(w, (1 << w) - 1).key
            fkey = self._synth_key(inst, f":{tag}:stage{i}:funnel:{k}")
            origin = f"{inst.ref}:{tag}:stage{i}:funnel:{k}"
            self._emit(inst, operation, [cur, cur, funnel_const], fkey,
                       f"i{w}",
                       {"derived_from": "shift-funnel-core-v1",
                        "stage": f"shift:fixed:funnel:{k}",
                        "input_layout": "ternary-lanes",
                        "lane_delta_a": 0, "lane_delta_b": delta,
                        "lane_delta_c": 0}, origin=origin)
            last = i == len(stages) - 1
            rkey = final_out if (last and final_out) else \
                self._synth_key(inst, f":{tag}:stage{i}:result")
            self._emit(inst, "AND", [fkey, mask_const], rkey,
                       f"i{w}",
                       {"derived_from": "shift", "stage": f"{tag}:result"},
                       origin=f"{inst.ref}:{tag}:stage{i}:result")
            cur = rkey
        return cur

    def _lower_varshift(self, inst):
        """非常量移位：km = k & 31 → log-tree（SELECT 链，档位 1,2,4,8,16）。"""
        x = self.operand_value(inst, *inst.operands[0])
        k = self.operand_value(inst, *inst.operands[1])
        w = type_info(inst.type)[1]
        zero = self.const_value(w, 0).key
        km = self._synth_key(inst, ":varshift:amount-masked")
        self._emit(inst, "AND", [k, self.const_value(w, 31).key], km,
                   f"i{w}", {"derived_from": "varshift",
                             "stage": "varshift:amount-masked"},
                   origin=f"{inst.ref}:varshift:amount-masked")
        y = x
        for amount in (1, 2, 4, 8, 16):
            test = self._synth_key(inst, f":varshift:test:{amount}")
            self._emit(inst, "AND", [km, self.const_value(w, amount).key],
                       test, f"i{w}",
                       {"derived_from": "varshift",
                        "stage": f"varshift:bit-test:{amount}"},
                       origin=f"{inst.ref}:varshift:test:{amount}")
            cond = self._synth_key(inst, f":varshift:cond:{amount}",
                                   type_id="i1")
            self._emit(inst, "ICMP_ULT", [zero, test], cond, "i1",
                       {"predicate": "ult", "source_width": w,
                        "derived_from": "varshift",
                        "stage": f"varshift:cond:{amount}"},
                       source_type_id=f"i{w}",
                       origin=f"{inst.ref}:varshift:cond:{amount}")
            shifted = self._shift_fixed(inst, y, amount, inst.opcode, w,
                                        f"varshift:shift:{amount}")
            nkey = self._synth_key(inst, f":varshift:acc:{amount}")
            self._emit(inst, "SELECT", [cond, shifted, y], nkey, f"i{w}",
                       {"derived_from": "varshift",
                        "stage": f"varshift:select:{amount}"},
                       source_type_id=f"i{w}",
                       origin=f"{inst.ref}:varshift:select:{amount}")
            y = nkey
        self._emit_copy(inst, y, self.ssa_value(inst).key, w, w,
                        "varshift:result")

    def _lower_mul(self, inst):
        """MUL：常量乘数 → 档位移位+加法；双变量 → 周期性 shift-add 微程序。"""
        a = self.operand_value(inst, *inst.operands[0])
        b = self.operand_value(inst, *inst.operands[1])
        w = type_info(inst.type)[1]
        zero = self.const_value(w, 0).key
        out = self.ssa_value(inst).key

        if inst.operands[1][0] == "const":
            x, cval = a, self.values[b].constant_value
        elif inst.operands[0][0] == "const":
            x, cval = b, self.values[a].constant_value
        else:
            x, cval = None, None

        if cval is not None:
            # 常量乘数：对每个置位 bit 累加 (x << bit)
            acc = None
            for bit in range(w):
                if (int(cval) >> bit) & 1:
                    term = x if bit == 0 else self._shift_fixed(
                        inst, x, bit, "shl", w, f"mul:term:{bit}")
                    if acc is None:
                        acc = term
                    else:
                        nkey = self._synth_key(inst, f":mul:c{bit}")
                        self._emit(inst, "ADD", [acc, term], nkey, f"i{w}",
                                   {"derived_from": "mul-const",
                                    "stage": f"mul:const:bit:{bit}"},
                                   origin=f"{inst.ref}:mul:const:{bit}")
                        acc = nkey
            if acc is None:            # 乘 0
                self._emit_copy(inst, zero, out, w, w, "mul:zero")
            else:
                self._emit_copy(inst, acc, out, w, w, "mul:result")
            return

        # 双变量：32 轮周期 shift-add。每个循环变量用**单一值键**
        # （槽位机原位更新语义）→ 各轮教师签名完全一致 → q 行数折叠到
        # ~周期。acc 即指令 SSA（每轮覆写，末轮值即结果）。
        tk = self._synth_key(inst, ":mul:t")
        termk = self._synth_key(inst, ":mul:term")
        bvk = self._synth_key(inst, ":mul:bitv")
        condk = self._synth_key(inst, ":mul:cond", type_id="i1")
        selk = self._synth_key(inst, ":mul:sel")
        self._emit_copy(inst, b, tk, w, w, "mul:init:t")
        self._emit_copy(inst, a, termk, w, w, "mul:init:term")
        self._emit_copy(inst, zero, out, w, w, "mul:init:acc")
        one_c = self.const_value(w, 1).key
        for bit in range(w):
            self._emit(inst, "AND", [tk, one_c], bvk, f"i{w}",
                       {"derived_from": "mul-var",
                        "stage": f"mul:bit:{bit}"},
                       origin=f"{inst.ref}:mul:bitv:{bit}")
            self._emit(inst, "ICMP_ULT", [zero, bvk], condk, "i1",
                       {"predicate": "ult", "source_width": w,
                        "derived_from": "mul-var",
                        "stage": f"mul:cond:{bit}"},
                       source_type_id=f"i{w}",
                       origin=f"{inst.ref}:mul:cond:{bit}")
            self._emit(inst, "SELECT", [condk, termk, zero], selk, f"i{w}",
                       {"derived_from": "mul-var",
                        "stage": f"mul:sel:{bit}"},
                       source_type_id=f"i{w}",
                       origin=f"{inst.ref}:mul:sel:{bit}")
            self._emit(inst, "ADD", [out, selk], out, f"i{w}",
                       {"derived_from": "mul-var",
                        "stage": f"mul:acc:{bit}"},
                       origin=f"{inst.ref}:mul:acc:{bit}")
            self._emit(inst, "ADD", [termk, termk], termk, f"i{w}",
                       {"derived_from": "mul-var",
                        "stage": f"mul:term:{bit}"},
                       origin=f"{inst.ref}:mul:term:{bit}")
            self._shift_fixed(inst, tk, 1, "lshr", w, "mul:t",
                              final_out=tk)

    def _emit_copy(self, inst, src_key, out_key, from_w, to_w, stage=None,
                   src_tid=None):
        """COPY 布局步。stage=None → 引擎朴素形态（{"source_width"} + 平凡
        origin；trunc/zext/ptrtoint）；带 stage → 自研宏中间值形态。"""
        if stage is None:
            self._emit(inst, "COPY", [src_key], out_key, f"i{to_w}",
                       {"source_width": from_w},
                       source_type_id=src_tid or f"i{from_w}",
                       origin=inst.ref)
        else:
            self._emit(inst, "COPY", [src_key], out_key, f"i{to_w}",
                       {"derived_from": "layout-copy",
                        "stage": stage, "source_width": from_w},
                       source_type_id=src_tid or f"i{from_w}",
                       origin=f"{inst.ref}:{stage}")
        # Step.action_kind 修正为 layout
        self.steps[-1].action_kind = "layout"

    def _lower_cast(self, inst):
        from_w = getattr(inst, "value_width", 32)
        to_w = type_info(inst.type)[1]
        src = self.operand_value(inst, *inst.operands[0])
        out = self.ssa_value(inst).key
        if inst.opcode in ("trunc", "zext"):
            self._emit_copy(inst, src, out, from_w, to_w)
            return
        # sext：零扩基值 + 符号位测试 + 高位掩码 OR
        base = self._synth_key(inst, ":sext:base")
        self._emit_copy(inst, src, base, from_w, to_w, "sext:base")
        half = (1 << (from_w - 1)) - 1
        cond = self._synth_key(inst, ":sext:cond", type_id="i1")
        self._emit(inst, "ICMP_ULT",
                   [self.const_value(to_w, half).key, base], cond, "i1",
                   {"predicate": "ult", "source_width": to_w,
                    "derived_from": "sext", "stage": "sext:cond"},
                   source_type_id=f"i{to_w}",
                   origin=f"{inst.ref}:sext:cond")
        mask = ((1 << (to_w - from_w + 1)) - 1) << (from_w - 1)
        hi = self._synth_key(inst, ":sext:hi")
        self._emit(inst, "SELECT",
                   [cond, self.const_value(to_w, mask).key,
                    self.const_value(to_w, 0).key], hi, f"i{to_w}",
                   {"derived_from": "sext", "stage": "sext:hi"},
                   source_type_id=f"i{to_w}",
                   origin=f"{inst.ref}:sext:hi")
        self._emit(inst, "OR", [base, hi], out, f"i{to_w}",
                   {"derived_from": "sext", "stage": "sext:result"},
                   origin=f"{inst.ref}:sext:result")

    def _lower_divrem(self, inst):
        """SDIV/SREM/UDIV/UREM（i32）：恢复除法微程序（周期化设计）。

        结构（signed；unsigned 去符号段）：
          [符号段 7 步] [32 × 周期 15 步] —— 周期内含商/余数的符号修正
          SELECT（前 31 轮为死步，仅末轮消费；死步使各轮教师签名一致，
          末轮直接写指令 SSA → 周期行为无退出分叉，q 行数折叠到 ~周期）。
        sdiv+srem 同操作数共享一次展开：末轮 q-SELECT 写 sdiv 的 SSA、
        r-SELECT 写 srem 的 SSA（无别名 COPY 尾步）。除数非零由样本守卫
        （C 除零为 UB）。
        """
        memo = getattr(self, "_divrem_memo", None)
        if memo is None:
            memo = self._divrem_memo = {}
        a = self.operand_value(inst, *inst.operands[0])
        b = self.operand_value(inst, *inst.operands[1])
        w = type_info(inst.type)[1]
        signed = inst.opcode in ("sdiv", "srem")
        is_quotient = inst.opcode in ("sdiv", "udiv")

        mk = (a, b, signed)
        if mk in memo:
            return                      # 配对指令已共享展开（SSA 已直写）

        # 配对指令（同操作数的商/余另一半）——其 SSA 作为末轮直写目标
        sibling = getattr(self, "_divrem_sibling", None)
        quo_out = self.ssa_value(inst).key if is_quotient else None
        rem_out = self.ssa_value(inst).key if not is_quotient else None
        if sibling is not None:
            if sibling.opcode in ("sdiv", "udiv"):
                quo_out = self.ssa_value(sibling).key
            else:
                rem_out = self.ssa_value(sibling).key
        if quo_out is None:
            quo_out = self._synth_key(inst, ":divrem:quo")
        if rem_out is None:
            rem_out = self._synth_key(inst, ":divrem:rem")
        memo[mk] = True

        zero = self.const_value(w, 0).key
        top = self.const_value(w, (1 << (w - 1)) - 1).key
        if signed:
            sa = self._synth_key(inst, ":divrem:sign-a", type_id="i1")
            self._emit(inst, "ICMP_ULT", [top, a], sa, "i1",
                       {"predicate": "ult", "source_width": w,
                        "derived_from": "divrem", "stage": "divrem:sign-a"},
                       source_type_id=f"i{w}",
                       origin=f"{inst.ref}:divrem:sign-a")
            na = self._synth_key(inst, ":divrem:neg-a")
            self._emit(inst, "SUB", [zero, a], na, f"i{w}",
                       {"derived_from": "divrem", "stage": "divrem:neg-a"},
                       origin=f"{inst.ref}:divrem:neg-a")
            ua = self._synth_key(inst, ":divrem:abs-a")
            self._emit(inst, "SELECT", [sa, na, a], ua, f"i{w}",
                       {"derived_from": "divrem", "stage": "divrem:abs-a"},
                       source_type_id=f"i{w}",
                       origin=f"{inst.ref}:divrem:abs-a")
            sb = self._synth_key(inst, ":divrem:sign-b", type_id="i1")
            self._emit(inst, "ICMP_ULT", [top, b], sb, "i1",
                       {"predicate": "ult", "source_width": w,
                        "derived_from": "divrem", "stage": "divrem:sign-b"},
                       source_type_id=f"i{w}",
                       origin=f"{inst.ref}:divrem:sign-b")
            nb = self._synth_key(inst, ":divrem:neg-b")
            self._emit(inst, "SUB", [zero, b], nb, f"i{w}",
                       {"derived_from": "divrem", "stage": "divrem:neg-b"},
                       origin=f"{inst.ref}:divrem:neg-b")
            ub = self._synth_key(inst, ":divrem:abs-b")
            self._emit(inst, "SELECT", [sb, nb, b], ub, f"i{w}",
                       {"derived_from": "divrem", "stage": "divrem:abs-b"},
                       source_type_id=f"i{w}",
                       origin=f"{inst.ref}:divrem:abs-b")
            negq = self._synth_key(inst, ":divrem:negq", type_id="i1")
            self._emit(inst, "XOR", [sa, sb], negq, "i1",
                       {"derived_from": "divrem", "stage": "divrem:negq"},
                       origin=f"{inst.ref}:divrem:negq")
        else:
            ua, ub, negq, sa = a, b, None, None

        one1 = self.const_value(1, 1).key
        one = self.const_value(w, 1).key
        # 单一键循环变量（槽位机原位更新）→ 各轮教师签名一致
        tk = self._synth_key(inst, ":divrem:t")
        remk = self._synth_key(inst, ":divrem:rem")
        quok = self._synth_key(inst, ":divrem:quo")
        hik = self._synth_key(inst, ":divrem:hi", type_id="i1")
        hbk = self._synth_key(inst, ":divrem:hb")
        c1k = self._synth_key(inst, ":divrem:c1")
        candk = self._synth_key(inst, ":divrem:cand")
        ltk = self._synth_key(inst, ":divrem:lt", type_id="i1")
        gek = self._synth_key(inst, ":divrem:ge", type_id="i1")
        redk = self._synth_key(inst, ":divrem:red")
        qbk = self._synth_key(inst, ":divrem:qb")
        q1k = self._synth_key(inst, ":divrem:q1")
        self._emit_copy(inst, ua, tk, w, w, "divrem:init:t")
        self._emit_copy(inst, zero, remk, w, w, "divrem:init:rem")
        self._emit_copy(inst, zero, quok, w, w, "divrem:init:quo")
        if signed:
            nqk = self._synth_key(inst, ":divrem:nq")
            nrk = self._synth_key(inst, ":divrem:nr")
        for i in range(w):
            self._emit(inst, "ICMP_ULT", [top, tk], hik, "i1",
                       {"predicate": "ult", "source_width": w,
                        "derived_from": "divrem", "stage": f"divrem:bit:{i}:hi"},
                       source_type_id=f"i{w}",
                       origin=f"{inst.ref}:divrem:b{i}:hi")
            self._emit(inst, "SELECT", [hik, one, zero], hbk, f"i{w}",
                       {"derived_from": "divrem", "stage": f"divrem:bit:{i}:hb"},
                       source_type_id=f"i{w}",
                       origin=f"{inst.ref}:divrem:b{i}:hb")
            self._emit(inst, "ADD", [remk, remk], c1k, f"i{w}",
                       {"derived_from": "divrem", "stage": f"divrem:bit:{i}:shl-rem"},
                       origin=f"{inst.ref}:divrem:b{i}:c1")
            self._emit(inst, "ADD", [c1k, hbk], candk, f"i{w}",
                       {"derived_from": "divrem", "stage": f"divrem:bit:{i}:cand"},
                       origin=f"{inst.ref}:divrem:b{i}:cand")
            self._emit(inst, "ICMP_ULT", [candk, ub], ltk, "i1",
                       {"predicate": "ult", "source_width": w,
                        "derived_from": "divrem", "stage": f"divrem:bit:{i}:lt"},
                       source_type_id=f"i{w}",
                       origin=f"{inst.ref}:divrem:b{i}:lt")
            self._emit(inst, "XOR", [ltk, one1], gek, "i1",
                       {"derived_from": "divrem", "stage": f"divrem:bit:{i}:ge"},
                       origin=f"{inst.ref}:divrem:b{i}:ge")
            self._emit(inst, "SUB", [candk, ub], redk, f"i{w}",
                       {"derived_from": "divrem", "stage": f"divrem:bit:{i}:red"},
                       origin=f"{inst.ref}:divrem:b{i}:red")
            self._emit(inst, "SELECT", [gek, redk, candk], remk, f"i{w}",
                       {"derived_from": "divrem", "stage": f"divrem:bit:{i}:next-rem"},
                       source_type_id=f"i{w}",
                       origin=f"{inst.ref}:divrem:b{i}:rem")
            self._emit(inst, "SELECT", [gek, one, zero], qbk, f"i{w}",
                       {"derived_from": "divrem", "stage": f"divrem:bit:{i}:qb"},
                       source_type_id=f"i{w}",
                       origin=f"{inst.ref}:divrem:b{i}:qb")
            self._emit(inst, "ADD", [quok, quok], q1k, f"i{w}",
                       {"derived_from": "divrem", "stage": f"divrem:bit:{i}:shl-quo"},
                       origin=f"{inst.ref}:divrem:b{i}:q1")
            self._emit(inst, "ADD", [q1k, qbk], quok, f"i{w}",
                       {"derived_from": "divrem", "stage": f"divrem:bit:{i}:next-quo"},
                       origin=f"{inst.ref}:divrem:b{i}:quo")
            if not signed:
                # unsigned：每轮 COPY 别名到 SSA（死步设计，末轮值即结果；
                # 与 signed 符号修正同构 → 区域末步为 t 自更新，行折叠级联成立）
                self._emit_copy(inst, quok, quo_out, w, w, "divrem:quo-out")
                self._emit_copy(inst, remk, rem_out, w, w, "divrem:rem-out")
            # ---- 周期内符号修正（每轮覆写商/余 SSA；末轮值即结果）----
            if signed:
                self._emit(inst, "SUB", [zero, quok], nqk, f"i{w}",
                           {"derived_from": "divrem",
                            "stage": f"divrem:bit:{i}:neg-quo"},
                           origin=f"{inst.ref}:divrem:b{i}:nq")
                self._emit(inst, "SELECT", [negq, nqk, quok], quo_out,
                           f"i{w}",
                           {"derived_from": "divrem",
                            "stage": f"divrem:bit:{i}:quo-signed"},
                           source_type_id=f"i{w}",
                           origin=f"{inst.ref}:divrem:b{i}:sq")
                self._emit(inst, "SUB", [zero, remk], nrk, f"i{w}",
                           {"derived_from": "divrem",
                            "stage": f"divrem:bit:{i}:neg-rem"},
                           origin=f"{inst.ref}:divrem:b{i}:nr")
                self._emit(inst, "SELECT", [sa, nrk, remk], rem_out,
                           f"i{w}",
                           {"derived_from": "divrem",
                            "stage": f"divrem:bit:{i}:rem-signed"},
                           source_type_id=f"i{w}",
                           origin=f"{inst.ref}:divrem:b{i}:sr")
            self._emit(inst, "ADD", [tk, tk], tk, f"i{w}",
                       {"derived_from": "divrem",
                        "stage": f"divrem:bit:{i}:shl-t"},
                       origin=f"{inst.ref}:divrem:b{i}:t")

    def _lower_load(self, inst):
        self._lower_memory(inst, "LOAD")

    def _lower_store(self, inst):
        self._lower_memory(inst, "STORE")

    def _resolve_base(self, inst):
        """load/store 基指针 → (ref, object, constant_offset, sync_ssa)。

        sync_ssa = 边界同步用的原生指针 SSA（栈对象 = 根 alloca；窗口 =
        基指针本身）。
        """
        ptr = inst.ptr
        d = self.def_inst.get(ptr)
        if d is not None:
            if d.opcode == "alloca":
                return (d.ref, self._object_for(d), 0, d.ssa)
            if d.opcode == "getelementptr":
                cur, off = d, 0
                hops = 0
                while cur is not None and cur.opcode == "getelementptr" \
                        and hops < 8:
                    idx = self._gep_const_index(cur)
                    if idx is None:
                        # 窗口模型（引擎实测）：同步 load/store 的**叶指针**
                        # SSA（gep 链含常量尾时叶≠动态基——同步基会丢
                        # +k 偏移，窗口对象被绑到 base+0）
                        return (d.ref, self._window_for(d, inst), 0,
                                d.ssa or ptr)
                    off += idx * self._gep_stride(cur)
                    base = self.def_inst.get(cur.ptr)
                    if base is not None and base.opcode == "alloca":
                        return (base.ref, self._object_for(base), off,
                                base.ssa)
                    cur = base
                    hops += 1
                return (d.ref, self._window_for(d, inst), 0, d.ssa or ptr)
            if d.opcode in ("phi", "load"):
                return (d.ref, self._window_for(d, inst), 0, d.ssa)
            return None
        ai = self.arg_index_of(ptr)
        if ai is not None:
            ref = f"function:{self.fn}:arg:{ai}"
            return (ref, self._window_for_ref(ref, inst), 0, ptr)
        return None

    def _gep_const_index(self, gep_inst):
        """gep 末索引为常量 → 值；否则 None（动态）。"""
        raw = getattr(gep_inst, "raw", "") or ""
        m = re.search(r",\s*i\d+\s+(-?\d+)\s*$", raw)
        if m:
            return int(m.group(1))
        consts = [v for k, v in gep_inst.operands if k == "const"]
        return consts[-1] if consts else None

    def _gep_stride(self, gep_inst):
        """gep 步长：源类型字节数（i8=1 / %struct.S=sizeof / [N x T]=N*T）。"""
        raw = getattr(gep_inst, "raw", "") or ""
        m = re.match(r"getelementptr\s+(?:inbounds\s+)?(?:nuw\s+|nsw\s+)*"
                     r"(\[[^\]]+\]|%[\w.$-]+|[\w:]+)\s*,", raw)
        if m:
            try:
                sz, _al = alloca_size_align(m.group(1), STRUCT_TYPES)
                return sz
            except NotImplementedError:
                return 1
        return 1

    def _window_for(self, native_inst, inst=None):
        return self._window_for_ref(native_inst.ref, inst)

    def _window_for_ref(self, ref, inst=None):
        """access:<fn>:<sha256(ref)[:12]> 外部镜像窗口（引擎 object_id 算法）。"""
        digest = hashlib.sha256(ref.encode()).hexdigest()
        oid = f"access:{self.fn}:{digest[:12]}"
        if oid not in self._windows:
            size, align = 8, 8
            if inst is not None:
                size = type_info(inst.type)[2]
                align = max(inst.align, 1)
            self._windows[oid] = {
                "object_id": oid, "kind": "external-mirror",
                "lifetime": "external", "coherence": "mirrored",
                "size_bytes": size, "alignment": align,
                "storage_bytes": size, "address_space": 0,
                "source_reference": ref, "owner_function": self.fn,
                "alias_set": [], "initial_bytes": [], "read_only": False,
            }
        else:
            # 多访问窗口：取最大尺寸/对齐
            if inst is not None:
                w = self._windows[oid]
                w["size_bytes"] = max(w["size_bytes"],
                                      type_info(inst.type)[2])
                w["alignment"] = max(w["alignment"], inst.align)
        return self._windows[oid]

    def _lower_memory(self, inst, op):
        rb = self._resolve_base(inst)
        ref, obj, offset, sync_ssa = rb
        loaded = type_info(inst.type)
        addr = {
            "pointer_reference": ref,
            "object_id": obj["object_id"],
            "constant_offset": offset,
            "dynamic_terms": [],
            "source_type": "opaque-access-window"
                if obj["kind"] == "external-mirror" else inst.type,
            "address_space": 0,
            "guaranteed_alignment": max(inst.align, 1),
            "provenance": ref,
            "lifetime": obj["lifetime"],
            "router_id": None, "router_stride": 0, "router_slots": 0,
            "router_kind": "dense", "router_radix": 0,
            "router_index_bias": 0,
            "schema": "nnobf-address-expression-v1",
        }
        if op == "LOAD":
            self._emit(inst, "LOAD", [], self.ssa_value(inst).key,
                       inst.type, {"alignment": max(inst.align, 1)},
                       address=addr)
        else:
            val = self.operand_value(inst, *inst.operands[0])
            self._emit(inst, "STORE", [val], None, inst.type,
                       {"alignment": max(inst.align, 1)}, address=addr)
            self.steps[-1].action_kind = "memory"

    def _object_for(self, alloca_inst):
        """stack:<fn>:<sha256(ref)[:12]>（与引擎 object_id 算法一致）。"""
        if alloca_inst.ref not in self.objects:
            digest = hashlib.sha256(alloca_inst.ref.encode()).hexdigest()
            if alloca_inst.type.startswith("[") \
                    or alloca_inst.type.startswith("%"):
                size, align = alloca_size_align(alloca_inst.type,
                                                STRUCT_TYPES)
            else:
                t = type_info(alloca_inst.type)
                size, align = t[2], t[3]
            self.objects[alloca_inst.ref] = {
                "object_id": f"stack:{self.fn}:{digest[:12]}",
                "kind": "stack",
                "lifetime": "function-activation",
                "coherence": "mirrored",
                "size_bytes": size, "alignment": align,
                "storage_bytes": size, "address_space": 0,
                "source_reference": alloca_inst.ref,
                "owner_function": self.fn, "alias_set": [],
                "initial_bytes": [], "read_only": False,
            }
        return self.objects[alloca_inst.ref]

    # ---- 槽分配 ----------------------------------------------------------
    def assign_slots(self):
        used = set()
        for s in self.steps:
            used.update(s.inputs)
            if s.output is not None:
                used.add(s.output)

        # 1) 初始槽：常量 + live-in，按键字典序（std::map 序）
        initial = sorted(k for k, v in self.values.items()
                         if v.kind in ("constant", "live-in") and k in used)
        slots = {}
        next_slot = 0
        for k in initial:
            slots[k] = next_slot
            self.values[k].slot = next_slot
            next_slot += 1

        # 2) last-use（含被原生指令消费/跨区域 → 延寿至计划尾）
        n_steps = len(self.steps)
        last_use = {k: -1 for k in self.values}
        for i, s in enumerate(self.steps):
            for k in s.inputs:
                last_use[k] = max(last_use[k], i)
            if s.output is not None:
                last_use.setdefault(s.output, -1)
        native_used = self._native_used_keys()
        for k in native_used:
            if k in last_use:
                last_use[k] = n_steps     # 边界值：延寿到计划尾

        # 3) 工作槽线性扫描：输出取最低空闲槽
        #    占用区间 [def, last_use]，last_use 步内先读后写 → 该步即可复用。
        #    单一键循环变量（微程序原位更新）只在其首次写出时分配一次。
        slot_free_at = {}                 # slot -> 再次可分配的步号
        for i, s in enumerate(self.steps):
            if s.output is None:
                continue
            v = self.values[s.output]
            if v.kind != "ssa":
                continue
            if v.slot is not None:
                continue                  # 已分配（多写单键变量）
            chosen = None
            for slot in range(next_slot, next_slot + 64):
                if slot_free_at.get(slot, 0) <= i:
                    chosen = slot
                    break
            slots[s.output] = chosen
            v.slot = chosen
            slot_free_at[chosen] = last_use[s.output]
        self.n_slots = max(slots.values()) + 1 if slots else 0
        return slots

    def _native_used_keys(self):
        """被原生指令（br/ret/phi/call/switch/gep）引用的步输出值。"""
        keys = set()
        lowered_refs = {id(i) for _, _, run in self.regions for i in run}
        for block in self.blocks:
            for inst in block:
                if id(inst) in lowered_refs:
                    continue
                for kind, tok in inst.operands:
                    if kind == "ssa":
                        src = self.def_inst.get(tok)
                        if (src is not None
                                and src.opcode in NEURAL_OPCODES
                                and id(src) in lowered_refs):
                            keys.add(self.ssa_value(src).key)
        return keys

    # ---- 上下文 / 区域 / 边界 --------------------------------------------
    def build_context(self):
        slot_types = {i: set() for i in range(self.n_slots)}
        for v in self.values.values():
            if v.slot is not None:
                slot_types[v.slot].add(v.type_id)
        temp_slots = []
        for i in range(self.n_slots):
            tids = sorted(slot_types[i])
            cap = max(encoded_bytes(type_info(t)[1]) for t in tids)
            temp_slots.append({"slot": i, "capacity_bytes": cap,
                               "allowed_type_ids": tids})
        objects = sorted(list(self.objects.values())
                         + list(self._windows.values()),
                         key=lambda o: o["object_id"])
        return {
            "schema": "nnobf-neural-context-v2",
            "temp_slot_capacity": self.n_slots,
            "temp_slot_width_bytes": 4,
            "temp_slots": temp_slots,
            "persistent_objects": objects,
            "controller_kind": "static-mlp",
            "control_stack_capacity": 0,
            "thread_local": True,
            "frames": [
                {"frame_id": "module", "layer": "module", "temp_slots": [],
                 "object_ids": [], "control_stack_capacity": 0,
                 "reentrant": True},
                {"frame_id": "thread", "layer": "thread", "temp_slots": [],
                 "object_ids": [], "control_stack_capacity": 0,
                 "reentrant": True},
                {"frame_id": "call", "layer": "call", "temp_slots": [],
                 "object_ids": [o["object_id"] for o in objects],
                 "control_stack_capacity": 0, "reentrant": True},
                {"frame_id": "region", "layer": "region",
                 "temp_slots": list(range(self.n_slots)), "object_ids": [],
                 "control_stack_capacity": 0, "reentrant": True},
            ],
        }

    def _encoded_arg_keys(self):
        """encoded-value 参数的值键（call_begin 已入槽 → 非区域 live-in）。"""
        out = set()
        for i, (ty, _name) in enumerate(FUNC_SIGS.get(self.fn, [])):
            if ty in ("ptr", PTR_TYPE_ID):
                continue
            k = f"function:{self.fn}:arg:{i}"
            v = self.values.get(k)
            if v is not None and v.slot is not None:
                out.add(k)
        return out

    def build_regions(self):
        out = []
        produced = {}                    # value key -> region index
        for ridx, (start, count, run) in enumerate(self.regions):
            for inst in run:
                if inst.ssa:
                    produced[self.ssa_value(inst).key] = ridx
            out.append({
                "index": ridx,
                "region_id": f"{self.fn}:region:{ridx}",
                "action_start": start,
                "action_count": count,
                "instruction_references": [i.ref for i in run],
                "live_in_values": [],       # 下方填充
                "live_out_values": [],
                "entry_block": None, "exit_block": None, "region_blocks": [],
                "entry_slot_bindings": [],
                "resident_in_values": [], "resident_out_values": [],
                "resident_phi_edges": [],
            })
        # live-in / live-out（encoded-value 参数已在 call_begin 入槽 → 排除）
        native_used = self._native_used_keys()
        encoded_args = self._encoded_arg_keys()
        for ridx, (start, count, run) in enumerate(self.regions):
            step_keys = set()
            for s in self.steps[start:start + count]:
                step_keys.update(s.inputs)
            live_in = sorted(k for k in step_keys
                             if k not in encoded_args
                             and (self.values[k].kind == "live-in"
                                  or (self.values[k].kind == "ssa"
                                      and produced.get(k, ridx) != ridx)))
            out[ridx]["live_in_values"] = live_in
            defs = {self.ssa_value(i).key for i in run if i.ssa}
            live_out = sorted(
                k for k in defs
                if k in native_used
                or any(k in s.inputs
                       for r2 in range(ridx + 1, len(self.regions))
                       for s in self.steps[self.regions[r2][0]:
                                           self.regions[r2][0] +
                                           self.regions[r2][1]]))
            out[ridx]["live_out_values"] = live_out
        return out

    def build_outputs_boundary(self, regions):
        """outputs=ret 直接消费的区域产物；boundary=其余跨向原生的 live-out。"""
        ret_operand = None
        for block in self.blocks:
            for inst in block:
                if inst.opcode == "ret" and inst.operands:
                    ret_operand = inst.operands[0][1]
        outputs, boundary = [], []
        ret_key = None
        if ret_operand:
            src = self.def_inst.get(ret_operand)
            if src is not None and src.opcode in NEURAL_OPCODES:
                ret_key = self.ssa_value(src).key
        for r in regions:
            for k in r["live_out_values"]:
                if k == ret_key:
                    outputs.append(k)
                else:
                    boundary.append(k)
        return sorted(outputs), sorted(boundary)

    def build_tool_contracts(self):
        """工具契约：tool_id 小写操作名；签名取 StableTool 规范形态
        （ADD 为三输入双输出：a/b/进位i1 → 值/进位i1；SELECT 条件在前）。"""
        def sig(op, src):
            if op in ("ADD", "SUB"):
                return [src, src, "i1"], [src, "i1"], ["value", "carry"]
            if op == "ICMP_ULT":
                return [src, src], ["i1"], ["predicate"]
            if op == "SELECT":
                return ["i1", src, src], [src], ["value"]
            if op in ("SHIFT_SHL", "SHIFT_LSHR"):
                return [src, src, src], [src], ["value"]
            return [src, src], [src], ["value"]     # AND/OR/XOR/MUL

        seen = {}
        for s in self.steps:
            if s.operation in ("LOAD", "COPY"):
                continue
            src = s.source_type_id
            tid = f"stable:{s.operation.lower()}:{src}->{s.value_type_id}"
            if tid not in seen:
                in_tids, out_tids, roles = sig(s.operation, src)
                seen[tid] = {
                    "tool_id": tid,
                    "operation": s.operation,
                    "input_type_ids": in_tids,
                    "output_type_ids": out_tids,
                    "output_roles": roles,
                    "recursive_safe": True,
                    "max_external_refiner_passes": 0,
                    "required_precisions": ["fp32", "fp16"],
                    "schema": "nnobf-stable-tool-contract-v1",
                }
        return [seen[k] for k in sorted(seen)]

    def build_types(self):
        tids = sorted({v.type_id for v in self.values.values()})
        out = []
        for t in tids:
            kind, w, storage, align = type_info(t)
            out.append({
                "type_id": t, "kind": kind, "storage_bytes": storage,
                "alignment": align, "bit_width": w, "floating_format": None,
                "address_space": 0, "element_type_id": None,
                "element_count": 0, "field_type_ids": [], "field_offsets": [],
                "schema": "nnobf-neural-type-v1",
            })
        return out

    # ---- 顶层组装 --------------------------------------------------------
    def build_abi_parameters(self):
        """abi_parameters（call_begin 参数绑定；引擎 whibo 形态）。

        整型参数且为计划输入值 → encoded-value（call_begin word_encode 入槽）；
        其余（指针/未消费）→ native-passthrough。
        """
        out = []
        for i, (ty, _name) in enumerate(FUNC_SIGS.get(self.fn, [])):
            if ty in ("ptr", PTR_TYPE_ID):
                tid, tkind, lw = PTR_TYPE_ID, "pointer", None
            else:
                tid = ty
                ti = type_info(ty)
                tkind, lw = ti[0], ti[1]
            vkey = f"function:{self.fn}:arg:{i}"
            encoded = (tkind != "pointer"
                       and vkey in self.values
                       and self.values[vkey].kind == "live-in"
                       and self.values[vkey].slot is not None)
            out.append({
                "index": i, "type_kind": tkind,
                "logical_width": lw if encoded else None,
                "binding_kind": "encoded-value" if encoded
                                else "native-passthrough",
                "type_id": tid,
                "value_key": vkey if encoded else None,
                "object_id": None, "size_bytes": None,
                "address_space": 0,
            })
        return out

    def compile_plan(self):
        self.lower()
        slots = self.assign_slots()
        regions = self.build_regions()
        outputs, boundary = self.build_outputs_boundary(regions)
        inputs = sorted(v.key for v in self.values.values()
                        if v.kind == "live-in")
        initial = [self.values[k].to_json() for k in
                   sorted(self.values)
                   if self.values[k].kind in ("constant", "live-in")
                   and self.values[k].slot is not None]
        values = [self.values[k].to_json() for k in sorted(self.values)]
        return {
            "schema": "nnobf-neural-ir-v8",
            "controller_action_schema": "nnobf-controller-action-v7",
            "function": self.fn,
            "rewrite_kind": "hybrid-regions",
            "context": self.build_context(),
            "controller": {
                "cell_id": f"static-mlp:{self.fn}",
                "kind": "static-mlp",
                "action_schema": "nnobf-controller-action-v7",
                "state_width": 64,
                "condition_type_id": "i1",
                "event_kinds": EVENT_KINDS,
                "context_summary_fields": [],
                "action_mask_required": False,
                "max_rollout_steps": len(self.steps),
                "schema": "nnobf-controller-cell-v1",
            },
            "types": self.build_types(),
            "tool_contracts": self.build_tool_contracts(),
            "abi_parameters": self.build_abi_parameters(),
            "inputs": [self.values[k].to_json() for k in inputs],
            "initial_values": initial,
            "values": values,
            "steps": [s.to_json(i, slots) for i, s in enumerate(self.steps)],
            "regions": regions,
            "boundary_values": [self.values[k].to_json() for k in boundary],
            "outputs": [self.values[k].to_json() for k in outputs],
            "capability_gaps": [],
            "floating_environment": None,
            "entry_action": 0,
            "control_flow_kind": "linear",
        }

    def compile(self, module_identifier):
        plan = self.compile_plan()
        return {
            "schema": "nnobf-neural-ir-module-v2",
            "module_identifier": module_identifier,
            "functions": [self.fn],
            "plans": [plan],
            "module_objects": [],
            "sync_specs": [],
            "capability_gaps": [],
        }


# ---------------------------------------------------------------------------
# 4. CLI
# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description="ANANSI IR→module_plan 参考实现")
    ap.add_argument("input", help="输入 input.ll（文本 IR）")
    ap.add_argument("-o", "--output", help="输出 JSON 路径（缺省打印 stdout）")
    ap.add_argument("--function", default=None,
                    help="待编译函数（缺省取第一个 define）")
    ap.add_argument("--functions", default=None,
                    help="逗号分隔多函数清单（或 @file）→ 单 module 多 plans"
                         "（action 索引按函数独立从 0 重启；引擎多函数形态）")
    ap.add_argument("--module-identifier", default="",
                    help="module_identifier 字段（引擎为临时目录路径）")
    ap.add_argument("--region-gaps", action="store_true",
                    help="任务 E：相邻区域间插入哑索引（入口潜态经 "
                         "region_q[start] 重载，解耦周期微程序链）")
    args = ap.parse_args()

    text = open(args.input).read()
    functions = parse_llvm_ir(text)
    if not functions:
        sys.exit("no define found in input")

    if args.functions:
        spec = args.functions
        if spec.startswith("@"):
            spec = open(spec[1:]).read()
        fn_list = [x.strip() for x in
                   spec.replace(",", " ").split() if x.strip()]
        missing = [f for f in fn_list if f not in functions]
        if missing:
            sys.exit(f"functions not found: {missing}")
        plans = []
        for fn in fn_list:
            compiler = PlanCompiler(fn, functions[fn],
                                    region_gaps=args.region_gaps)
            plans.append(compiler.compile_plan())
            print(f"plan {fn}: {len(compiler.steps)} steps, "
                  f"{len(plans[-1]['regions'])} regions, "
                  f"{compiler.n_slots} slots", file=sys.stderr)
        module = {
            "schema": "nnobf-neural-ir-module-v2",
            "module_identifier": args.module_identifier,
            "functions": fn_list,
            "plans": plans,
            "module_objects": [],
            "sync_specs": [],
            "capability_gaps": [],
        }
        js = json.dumps(module)
        if args.output:
            open(args.output, "w").write(js + "\n")
            print(f"wrote {args.output}: {len(plans)} plans, "
                  f"{sum(len(p['steps']) for p in plans)} steps",
                  file=sys.stderr)
        else:
            print(js)
        return

    fname = args.function or next(iter(functions))
    if fname not in functions:
        sys.exit(f"function {fname} not found; have {list(functions)}")
    compiler = PlanCompiler(fname, functions[fname],
                            region_gaps=args.region_gaps)
    plan = compiler.compile(args.module_identifier)
    js = json.dumps(plan)
    if args.output:
        open(args.output, "w").write(js + "\n")
        print(f"wrote {args.output}: {len(compiler.steps)} steps, "
              f"{compiler.n_slots} slots", file=sys.stderr)
    else:
        print(js)


if __name__ == "__main__":
    main()
