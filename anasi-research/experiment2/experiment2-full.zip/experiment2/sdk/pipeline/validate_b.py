#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ANANSI 自研管线（B 阶段）总验收：A1/A2/A3 回归 + B1/B3/B5 金标准对拍。

验收矩阵（全部用 Python 字节比较——宿主 PATH 中的 OpenHarmony diff 不可靠）：
  A1  plan_compiler        两轮 module_plan 全字段 0 差异（回归）
  A2  runtime_codegen      两轮三 TU byte-identical（回归）
  A3  normalize+raw 前端   轮1 raw→normalized 链 byte-identical（docker 回归）
  B3  instrument_ll        两轮 transformed.ll byte-identical（票号/tag/ModuleID
                           作为输入表——RNG 值引擎本身不可复现）
  B1  protect.py 一条命令  轮2：input.ll/transformed.ll/三 TU 全 byte-identical；
                           轮1（--frontend raw + fp16 profile）：transformed.ll
                           byte-identical
  B5  四方跑批             51 输入 native/prot2/my_prot 三方一致 + 引擎存档
                           exit_codes.tsv 交叉核对

用法：python3 src-repro/validate_b.py  （在仓库 RUN_DIR 根下执行）
"""

import json
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

R1 = os.path.join(ROOT, "artifacts/engine-trace/prot.build/run-6qdudb")
R2 = os.path.join(ROOT, "artifacts/engine-verify2/prot2.build/run-fL5D2U")
VERIFY_B = os.path.join(ROOT, "verify-b")

R1_INPUT = os.path.join(R1, "input/program/input.ll")
R1_TRANSFORMED = os.path.join(
    R1, "work/function_0/work/program/transformed.ll")
R1_RUNTIME = os.path.join(
    R1, "work/function_0/work/program/full_controller_runtime")
R1_SRC = os.path.join(ROOT, "artifacts/engine-trace/t.c")
R1_RAW_GOLD = os.path.join(R1, "input/program/input.raw.ll")
R1_NORM_GOLD = os.path.join(R1, "input/program/normalized.ll")

R2_INPUT = os.path.join(R2, "input/program/input.ll")
R2_TRANSFORMED = os.path.join(
    R2, "work/attempt_01/program/transformed.ll")
R2_RUNTIME = os.path.join(
    R2, "work/attempt_01/program/full_controller_runtime")
R2_SRC = os.path.join(ROOT, "artifacts/engine-verify2/t2.c")

TICKETS_R1 = {"0": 1360580669965750588}
TICKETS_R2 = {"0": 2659911325400107137, "1": 9485348196553556760}
TAG_R1, TAG_R2 = "7da23e53349a43d6", "91ab756d3b57d9f3"
MODID_R1 = "/tmp/anansi-7VnhQ3/work/function_0/input/program/input.ll"
MODID_R2 = "/tmp/anansi-ufWz4U/input/program/input.ll"
MODID_R1_NORM = "/tmp/anansi-7VnhQ3/input/program/input.ll"

RESULTS = []


def check(label, ok, detail=""):
    RESULTS.append((label, bool(ok)))
    print(f"[{'PASS' if ok else 'FAIL'}] {label}"
          + (f"  ({detail})" if detail else ""))
    return bool(ok)


def same_bytes(a, b):
    return open(a, "rb").read() == open(b, "rb").read()


def py(*argv):
    return subprocess.run([sys.executable] + list(argv), check=True,
                          capture_output=True, text=True)


def docker(script, mounts):
    argv = ["docker", "run", "--rm", "--platform", "linux/amd64",
            "-v", os.path.expanduser(
                "~/Downloads/anansi-linux-20261022-x86_64") + ":/dist:ro"]
    for host, cont in mounts:
        argv += ["-v", f"{os.path.join(ROOT, host)}:{cont}"]
    argv += ["anansi-verify-amd64", "sh", "-c", script]
    proc = subprocess.run(argv, capture_output=True, text=True)
    if proc.returncode != 0:
        print(proc.stdout[-2000:], proc.stderr[-2000:], file=sys.stderr)
        raise SystemExit(f"docker step failed: {script[:80]}")
    return proc.stdout


# ---------------------------------------------------------------------------
def a1():
    r = py(os.path.join(HERE, "validate_against_gold.py"))
    ok = "RESULT: PASS" in (r.stdout + r.stderr)
    check("A1 plan_compiler 两轮 0 字段差异（回归）", ok,
          (r.stderr + r.stdout).strip().splitlines()[-1])


def a2():
    out2 = "/tmp/opencode-b/.a2_r2" if os.path.isdir("/tmp/opencode-b") \
        else "/tmp/.a2_r2"
    os.makedirs(out2, exist_ok=True)
    py(os.path.join(HERE, "runtime_codegen.py"),
       "--weights", os.path.join(ROOT, "src-neural-wip",
                                 "_anansi_t2_module_weights.npz"),
       "--profile", os.path.join(HERE, "runtime_codegen_data",
                                 "profile_fp32_t2.json"),
       "--out", out2, "--verify", R2_RUNTIME)
    out1 = out2 + "_r1"
    os.makedirs(out1, exist_ok=True)
    py(os.path.join(HERE, "runtime_codegen.py"),
       "--weights", os.path.join(ROOT, "src-neural-wip",
                                 "_anansi_module_weights.npz"),
       "--profile", os.path.join(HERE, "runtime_codegen_data",
                                 "profile_fp16_t1.json"),
       "--out", out1, "--verify", R1_RUNTIME)
    # 6/6 byte-identical（--verify 自身打印 byte-identical: True）
    r2ok = all(same_bytes(os.path.join(out2, f),
                          os.path.join(R2_RUNTIME, f))
               for f in ("runtime_0_main.c", "runtime_weights.c",
                         "runtime_module_state.c"))
    r1ok = all(same_bytes(os.path.join(out1, f),
                          os.path.join(R1_RUNTIME, f))
               for f in ("runtime_0_main.c", "runtime_weights.c",
                         "runtime_module_state.c"))
    check("A2 runtime_codegen 两轮 6/6 TU byte-identical（回归）", r2ok and r1ok)


def a3():
    out = os.path.join(VERIFY_B, "a3")
    os.makedirs(out, exist_ok=True)
    # 轮1 raw 前端（attempt_01 旗标）+ 归一化，与金标准逐字节比对
    script = (
        "mkdir -p /out /tmp/anansi-7VnhQ3/input/program && "
        "cp /art/engine-trace/t.c /out/t.c && "
        "/dist/bin/clang -include stdio.h -S -emit-llvm -x c -O1 "
        "-Xclang -disable-lifetime-markers -fno-inline "
        "-fpatchable-function-entry=5,0 -fstack-protector-strong -fno-inline "
        "-mno-red-zone -Xclang -disable-llvm-passes -fno-jump-tables "
        "/out/t.c -o /tmp/anansi-7VnhQ3/input/program/input.ll && "
        "cp /tmp/anansi-7VnhQ3/input/program/input.ll /out/raw.ll && "
        "/dist/bin/clang -S -emit-llvm -O1 -x ir "
        "/tmp/anansi-7VnhQ3/input/program/input.ll -o /out/normalized.ll"
    )
    docker(script, [("artifacts", "/art"), (os.path.relpath(out, ROOT),
                                            "/out")])
    check("A3 轮1 raw 前端 → input.raw.ll byte-identical（回归）",
          same_bytes(os.path.join(out, "raw.ll"), R1_RAW_GOLD))
    check("A3 轮1 归一化 → normalized.ll byte-identical（回归）",
          same_bytes(os.path.join(out, "normalized.ll"), R1_NORM_GOLD))


def b3():
    out = os.path.join(VERIFY_B, "b3")
    os.makedirs(out, exist_ok=True)
    t2 = os.path.join(out, "transformed_r2.ll")
    t1 = os.path.join(out, "transformed_r1.ll")
    py(os.path.join(HERE, "instrument_ll.py"), R2_INPUT, "-o", t2,
       "--tag", TAG_R2, "--tickets", json.dumps(TICKETS_R2),
       "--module-id", MODID_R2)
    check("B3 instrument_ll 轮2 transformed.ll byte-identical",
          same_bytes(t2, R2_TRANSFORMED))
    py(os.path.join(HERE, "instrument_ll.py"), R1_INPUT, "-o", t1,
       "--tag", TAG_R1, "--tickets", json.dumps(TICKETS_R1),
       "--module-id", MODID_R1)
    check("B3 instrument_ll 轮1 transformed.ll byte-identical",
          same_bytes(t1, R1_TRANSFORMED))


def b1_round2():
    build = os.path.join(VERIFY_B, "accept.build")
    bin_ = os.path.join(VERIFY_B, "accept_my_prot")
    py(os.path.join(HERE, "protect.py"),
       "--source", os.path.relpath(R2_SRC, ROOT),
       "--output", os.path.relpath(bin_, ROOT),
       "--workdir", os.path.relpath(build, ROOT),
       "--module-id", MODID_R2)
    check("B1 轮2 input.ll byte-identical",
          same_bytes(os.path.join(build, "input.ll"), R2_INPUT))
    check("B1 轮2 transformed.ll byte-identical（金 ModuleID 参数）",
          same_bytes(os.path.join(build, "transformed.ll"), R2_TRANSFORMED))
    check("B1 轮2 三运行时 TU byte-identical",
          all(same_bytes(os.path.join(build, "runtime", f),
                         os.path.join(R2_RUNTIME, f))
              for f in ("runtime_0_main.c", "runtime_weights.c",
                        "runtime_module_state.c")))
    return bin_


def b1_round1():
    build = os.path.join(VERIFY_B, "accept_r1.build")
    bin_ = os.path.join(VERIFY_B, "accept_my_prot_r1")
    py(os.path.join(HERE, "protect.py"),
       "--source", os.path.relpath(R1_SRC, ROOT),
       "--output", os.path.relpath(bin_, ROOT),
       "--workdir", os.path.relpath(build, ROOT),
       "--frontend", "raw",
       "--profile", "src-repro/runtime_codegen_data/profile_fp16_t1.json",
       "--weight-npz", "src-neural-wip/_anansi_module_weights.npz",
       "--tickets", json.dumps(TICKETS_R1),
       "--module-id", MODID_R1)
    check("B1 轮1（raw 前端+归一化）transformed.ll byte-identical",
          same_bytes(os.path.join(build, "transformed.ll"), R1_TRANSFORMED))
    # 轮1 语义：scanf("0") 恒 !=1 → 恒 42
    rc = docker("for x in 3 0 abc; do printf \"%s\\n\" $x | /mine "
                ">/dev/null 2>&1; echo $?; done",
                [(os.path.relpath(bin_, ROOT), "/mine")])
    ok = all(int(x) == 42 for x in rc.split())
    check("B1 轮1 my_prot_r1 语义（scanf 失败路径 → 42）", ok,
          f"rc={rc.split()}")


def b5(bin_):
    r = py(os.path.join(HERE, "verify_battery.py"), "--mine", bin_,
           "-o", os.path.join(VERIFY_B, "battery.tsv"))
    out = r.stdout
    line = [l for l in out.splitlines() if "three-way agree" in l]
    ok = line and "mismatch=0" in line[0] and "total=51" in line[0]
    check("B5 四方跑批 51/51（native==prot2==my_prot）", ok,
          line[0] if line else "no summary")
    ok2 = "match engine archive" in out
    check("B5 引擎存档 exit_codes.tsv 交叉核对", ok2)


def main():
    os.makedirs(VERIFY_B, exist_ok=True)
    print("===== ANANSI 自研管线总验收 =====")
    a1()
    a2()
    a3()
    b3()
    bin2 = b1_round2()
    b1_round1()
    b5(bin2)
    n_pass = sum(1 for _, ok in RESULTS if ok)
    print(f"\n===== RESULT: {n_pass}/{len(RESULTS)} PASS =====")
    for label, ok in RESULTS:
        if not ok:
            print("  FAILED:", label)
    return 0 if n_pass == len(RESULTS) else 1


if __name__ == "__main__":
    sys.exit(main())
