#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""任务 E：三方差分器（native vs orig_prot vs my_prot）。

对输入电池的每个输入，在同一 docker 环境实测三个二进制的
exit code + stdout + stderr 三通道全比对。判据对齐引擎差分验证器
（mode=native-vs-protected-program-differential-v1）。

用法：
    python3 diff3.py --native NATIVE --orig ORIG --mine MY_PROT \
        --inputs inputs.txt [-o result.tsv]
    （--orig 可省略：引擎拒保样例（hello/loops 引擎失败轮）做两方比对）
"""

import argparse
import os
import subprocess
import sys

DIST = os.path.expanduser("~/Downloads/anansi-linux-20261022-x86_64")
IMAGE = "anansi-verify-amd64"


def main():
    ap = argparse.ArgumentParser(description="任务 E 三方差分器")
    ap.add_argument("--native", required=True)
    ap.add_argument("--orig", default=None)
    ap.add_argument("--mine", required=True)
    ap.add_argument("--inputs", required=True, help="每行一个输入（整行喂 stdin）")
    ap.add_argument("--timeout", type=int, default=60)
    ap.add_argument("-o", "--output", default=None)
    args = ap.parse_args()

    here = os.getcwd()
    slots = {}
    paths = {}

    def mount(key, path):
        apath = os.path.abspath(path if os.path.isabs(path)
                                else os.path.join(here, path))
        d = os.path.dirname(apath)
        if d not in slots:
            slots[d] = "/m%d" % len(slots)
        paths[key] = slots[d] + "/" + os.path.basename(apath)
        return d

    dirs = [mount("native", args.native), mount("mine", args.mine)]
    if args.orig:
        dirs.append(mount("orig", args.orig))
    dirs.append(mount("inputs", args.inputs))
    for k in ("native", "mine") + (("orig",) if args.orig else ()):
        host = (args.native if k == "native" else
                args.mine if k == "mine" else args.orig)
        os.chmod(os.path.abspath(host), 0o755)

    bins = f"N={paths['native']}" + (f" O={paths['orig']}" if args.orig else "") \
        + f" M={paths['mine']}"
    # 每输入跑三二进制，三通道捕获（base64 -w0：单行，防 tsv 断行）
    script = f"""
run_one() {{ printf '%s\\n' "$1" > /tmp/in; timeout {args.timeout} "$2" < /tmp/in > /tmp/o 2> /tmp/e; rc=$?; 
  printf '%d|%s|%s' "$rc" "$(base64 -w 0 < /tmp/o)" "$(base64 -w 0 < /tmp/e)"; }}
while IFS= read -r x; do
  [ -z "$x" ] && continue
  n=$(run_one "$x" {paths['native']})
  m=$(run_one "$x" {paths['mine']})
  if [ -n "{paths.get('orig', '')}" ]; then
    o=$(run_one "$x" {paths.get('orig', '/bin/true')})
  else
    o="SKIP"
  fi
  if [ "$n" = "$m" ] && {{ [ -z "{paths.get('orig', '')}" ] || [ "$o" = "$n" ]; }}; then
    echo "PASS $x"
  else
    echo "FAIL $x | N=$n | O=$o | M=$m"
  fi
done < {paths['inputs']}
"""
    argv = ["docker", "run", "--rm", "--platform", "linux/amd64",
            "-v", f"{DIST}:/dist:ro"]
    for d in slots:
        argv += ["-v", f"{d}:{slots[d]}"]
    argv += [IMAGE, "sh", "-c", script]
    print("+ docker diff3 run", file=sys.stderr)
    proc = subprocess.run(argv, capture_output=True, text=True)
    if proc.returncode != 0:
        sys.stderr.write(proc.stderr)
        raise SystemExit(f"diff3: docker run failed rc={proc.returncode}")
    lines = proc.stdout.strip().splitlines()
    n_pass = sum(1 for l in lines if l.startswith("PASS"))
    n_fail = sum(1 for l in lines if l.startswith("FAIL"))
    for l in lines:
        print(l[:400])
    print(f"\ndiff3: PASS={n_pass} FAIL={n_fail}"
          f"{'' if args.orig else ' (两方比对：引擎无产物)'}")
    if args.output:
        open(args.output, "w").write(
            "\n".join(lines) + f"\nPASS={n_pass} FAIL={n_fail}\n")
    sys.exit(0 if n_fail == 0 else 1)


if __name__ == "__main__":
    main()
