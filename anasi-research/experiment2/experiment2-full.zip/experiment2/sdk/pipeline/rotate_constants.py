#!/usr/bin/env python3
"""rotate_constants.py — v0.5 P0-C：每构建轮换全部密钥材料。

从构建种子确定性派生新的挑战常量，生成 crackme_rotated.c：
  SEED（XOR 种子）、MUL1/MUL2（乘法常数）、TARGET（期望值）、
  KEY（合法 key）、密文（flag 加密体）、校验和。

效果：上一轮攻击者的 codec.py / solve.py / 常量表对新构建直接失效
（v0.4 攻击中"上轮资产零成本复用"的最大倒退点被消除）。

用法：python3 rotate_constants.py <seed> [--flag TEXT] [-o output.c]
"""
import argparse
import sys

M32 = 0xFFFFFFFF


def mix32(x):
    x ^= x >> 16
    x = (x * 0x7FEB352D) & M32
    x ^= x >> 15
    x = (x * 0x846CA68B) & M32
    x ^= x >> 16
    return x


def rotl(x, n):
    return ((x << n) | (x >> (32 - n))) & M32


def derive_constants(seed):
    """从种子确定性派生全部挑战常量。"""
    import random
    rng = random.Random(seed)

    # 合法 key：随机 32 位值（保证非零）
    key = rng.getrandbits(32) | 1

    # XOR 种子：随机 32 位
    xor_seed = rng.getrandbits(32)

    # 乘法常数：必须是奇数（保证 mod 2^32 可逆）
    mul1 = rng.getrandbits(32) | 1
    mul2 = rng.getrandbits(32) | 1

    # 期望值：mix32(key ^ xor_seed) 用新乘法常数计算
    def new_mix(x):
        x ^= x >> 16
        x = (x * mul1) & M32
        x ^= x >> 15
        x = (x * mul2) & M32
        x ^= x >> 16
        return x

    target = new_mix(key ^ xor_seed)

    return {
        "key": key,
        "xor_seed": xor_seed,
        "mul1": mul1,
        "mul2": mul2,
        "target": target,
        "new_mix": new_mix,
    }


def derive_ciphertext(c, flag_text):
    """用新常量派生密钥流并加密 flag。"""
    key = c["key"]
    new_mix = c["new_mix"]
    s = key
    ct = []
    for i, ch in enumerate(flag_text):
        s = new_mix((s + 0x9E3779B9 + i) & M32)
        ct.append(ch ^ ((s >> 24) & 0xFF))
    # 校验和
    chk = 0
    for b in flag_text:
        chk ^= b
    c["checksum"] = chk
    c["ciphertext"] = ct
    return c


TEMPLATE = r'''/* ctf_crackme_rotated.c — 由 rotate_constants.py 生成（seed={seed}）
 * 常量已轮换：上轮攻击者的脚本/常量表对本构建无效 */
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stddef.h>

static unsigned int __sdk_churn_state[32][4] = {{
{churn_init}
}};

static unsigned int __sdk_churn_epoch = 0;

void __sdk_churn_step(long delta)
{{
    unsigned int d = (unsigned int)delta
                     ^ (__sdk_churn_epoch++ * 0x9e3779b9u);
    for (int i = 0; i < 32; i++) {{
        unsigned int *w = __sdk_churn_state[i];
        unsigned int t = w[0] + d + (unsigned int)i;
        w[0] = t;
        w[1] ^= t >> 3;
        w[2] += w[1] + 0x85ebca6bu;
        w[3] ^= w[2] << 7;
        d = w[3] ^ (w[0] >> 11);
    }}
}}

static uint32_t mix32(uint32_t x)
{{
    x ^= x >> 16;
    x *= {mul1}u;
    x ^= x >> 15;
    x *= {mul2}u;
    x ^= x >> 16;
    return x;
}}

static uint32_t derive_and_decrypt(uint32_t key, uint8_t *out, size_t out_len)
{{
    static const uint8_t ct[{ct_len}] = {{
        {ct_bytes}
    }};
    uint32_t s = key;
    uint32_t chk = 0;
    for (size_t i = 0; i < out_len && i < sizeof(ct); i++) {{
        s = mix32(s + 0x9e3779b9u + (uint32_t)i);
        out[i] = (uint8_t)(ct[i] ^ (uint8_t)(s >> 24));
        chk ^= out[i];
    }}
    return chk;
}}

static int hexval(int c)
{{
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}}

int main(void)
{{
    char buf[64];
    uint8_t flag[24];
    puts("=== ANANSI Neural Crackme v1 ===");
    printf("Enter serial key (8 hex): ");
    fflush(stdout);
    if (scanf("%63s", buf) != 1) {{
        puts("ACCESS DENIED");
        return 1;
    }}
    if (strlen(buf) != 8) {{
        puts("ACCESS DENIED");
        return 1;
    }}
    uint32_t v = 0;
    for (int i = 0; i < 8; i++) {{
        int d = hexval(buf[i]);
        if (d < 0) {{
            puts("ACCESS DENIED");
            return 1;
        }}
        v = (v << 4) | (uint32_t)d;
    }}
    if (mix32(v ^ {xor_seed}u) != {target}u) {{
        puts("ACCESS DENIED");
        return 1;
    }}
    memset(flag, 0, sizeof(flag));
    if (derive_and_decrypt(v, flag, {ct_len}) != {checksum}u) {{
        puts("ACCESS DENIED");
        return 1;
    }}
    printf("ACCESS GRANTED\nflag{{%s}}\n", flag);
    return 0;
}}
'''


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("seed", type=int)
    ap.add_argument("--flag", default="n3ural_pr0tect_w1ns!")
    ap.add_argument("-o", "--output", default=None)
    a = ap.parse_args()

    c = derive_constants(a.seed)
    flag_bytes = a.flag.encode("utf-8")
    derive_ciphertext(c, flag_bytes)

    # churn 初始状态也从种子派生
    import random
    rng = random.Random(a.seed ^ 0xC47)
    churn_rows = []
    for i in range(32):
        ws = [f"0x{rng.randrange(1 << 32):08x}u" for _ in range(4)]
        churn_rows.append("    {" + ", ".join(ws) + "},")

    src = TEMPLATE.format(
        seed=a.seed,
        churn_init="\n".join(churn_rows),
        mul1=f"0x{c['mul1']:08x}",
        mul2=f"0x{c['mul2']:08x}",
        xor_seed=f"0x{c['xor_seed']:08x}",
        target=f"0x{c['target']:08x}",
        ct_len=len(flag_bytes),
        ct_bytes=", ".join(f"0x{b:02x}" for b in c["ciphertext"]),
        checksum=f"0x{c['checksum']:02x}",
    )

    if a.output:
        open(a.output, "w", encoding="utf-8").write(src)
    else:
        print(src)

    # 答案输出到 stderr（不进产物）
    print(f"# ANSWERS (seed={a.seed}):", file=sys.stderr)
    print(f"#   key = {c['key']:08X}", file=sys.stderr)
    print(f"#   flag = {a.flag}", file=sys.stderr)
    print(f"#   xor_seed = 0x{c['xor_seed']:08x}", file=sys.stderr)
    print(f"#   mul1 = 0x{c['mul1']:08x}", file=sys.stderr)
    print(f"#   mul2 = 0x{c['mul2']:08x}", file=sys.stderr)
    print(f"#   target = 0x{c['target']:08x}", file=sys.stderr)


if __name__ == "__main__":
    main()
