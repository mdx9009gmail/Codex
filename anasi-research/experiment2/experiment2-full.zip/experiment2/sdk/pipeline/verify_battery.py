#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ANANSI 自研管线 B5 验证器：native / prot2（原引擎）/ my_prot（自研）跑批对拍。

对 battery_inputs.txt 的每个输入，在同一 docker 环境实测三个二进制的退出码，
产出四方表（input | native | prot2 | my_prot | 一致性）并与引擎存档真值
exit_codes.tsv 交叉核对。比较维度对齐引擎差分验证器（FUN_004742b0，
mode=native-vs-protected-program-differential-v1）：termination + returncode。

用法：
    python3 verify_battery.py --mine verify-b/my_prot [-o verify-b/battery.tsv]
"""

import argparse
import os
import subprocess
import sys

DEFAULTS = dict(
    battery="artifacts/engine-verify2/battery_inputs.txt",
    native="artifacts/engine-verify2/native2",
    prot="artifacts/engine-verify2/prot2",
    gold_tsv="artifacts/engine-verify2/exit_codes.tsv",
)

SCRIPT_TMPL = """
run_one() {{ echo "$1" | "$2" >/dev/null 2>&1; echo $?; }}
while read -r x; do
  [ -z "$x" ] && continue
  n=$(run_one "$x" {native}); p=$(run_one "$x" {prot}); m=$(run_one "$x" {mine})
  echo "$x $n $p $m"
done < {battery}
"""


def main():
    ap = argparse.ArgumentParser(description="ANANSI 四方对拍验证器（B5）")
    ap.add_argument("--battery", default=DEFAULTS["battery"])
    ap.add_argument("--native", default=DEFAULTS["native"])
    ap.add_argument("--prot", default=DEFAULTS["prot"])
    ap.add_argument("--mine", required=True, help="自研 my_prot 二进制")
    ap.add_argument("--gold-tsv", default=DEFAULTS["gold_tsv"])
    ap.add_argument("--dist",
                    default=os.path.expanduser(
                        "~/Downloads/anansi-linux-20261022-x86_64"))
    ap.add_argument("--image", default="anansi-verify-amd64")
    ap.add_argument("-o", "--output", default=None, help="结果 TSV 路径")
    args = ap.parse_args()

    here = os.getcwd()
    slots = {}                     # host dir -> /mN
    paths = {}

    def mount(key, path):
        apath = os.path.abspath(path if os.path.isabs(path)
                                else os.path.join(here, path))
        d = os.path.dirname(apath)
        if d not in slots:
            slots[d] = "/m%d" % len(slots)
        paths[key] = slots[d] + "/" + os.path.basename(apath)
        return d

    dirs = [mount("battery", args.battery), mount("native", args.native),
            mount("prot", args.prot), mount("mine", args.mine)]
    os.chmod(os.path.abspath(os.path.join(here, args.mine))
             if not os.path.isabs(args.mine) else args.mine, 0o755)

    script = SCRIPT_TMPL.format(native=paths["native"], prot=paths["prot"],
                                mine=paths["mine"], battery=paths["battery"])
    argv = ["docker", "run", "--rm", "--platform", "linux/amd64",
            "-v", f"{args.dist}:/dist:ro"]
    for d in slots:
        argv += ["-v", f"{d}:{slots[d]}"]
    argv += [args.image, "sh", "-c", script]
    print("+ docker battery run (mounted: %s)" % ", ".join(slots),
          file=sys.stderr)
    proc = subprocess.run(argv, capture_output=True, text=True)
    if proc.returncode != 0:
        sys.stderr.write(proc.stderr)
        raise SystemExit(f"verify_battery: docker run failed rc={proc.returncode}")

    gold = {}
    if args.gold_tsv and os.path.exists(os.path.join(here, args.gold_tsv)
                                        if not os.path.isabs(args.gold_tsv)
                                        else args.gold_tsv):
        gpath = args.gold_tsv
        if not os.path.isabs(gpath):
            gpath = os.path.join(here, gpath)
        for ln in open(gpath):
            parts = ln.rstrip("\n").split("\t")
            if len(parts) == 3:
                gold[parts[0]] = (int(parts[1]), int(parts[2]))

    rows, n_ok, n_bad, gold_mismatch = [], 0, 0, []
    for ln in proc.stdout.splitlines():
        parts = ln.split()
        if len(parts) != 4:
            continue
        x, n, p, m = parts[0], int(parts[1]), int(parts[2]), int(parts[3])
        agree = n == p == m
        tag = "OK" if agree else "MISMATCH"
        if agree:
            n_ok += 1
        else:
            n_bad += 1
        if x in gold and gold[x] != (n, p):
            gold_mismatch.append(x)
            tag = "GOLD-DIFF"
        rows.append((x, n, p, m, tag))

    out_lines = ["input\tnative\tprot2\tmy_prot\tverdict"]
    for r in rows:
        out_lines.append("%s\t%d\t%d\t%d\t%s" % r)
    table = "\n".join(out_lines) + "\n"

    if args.output:
        open(args.output, "w").write(table)
        print(f"verify_battery: wrote {args.output}", file=sys.stderr)
    sys.stdout.write(table)
    print("\n===== SUMMARY =====")
    print(f"total={len(rows)}  three-way agree={n_ok}  mismatch={n_bad}")
    if gold_mismatch:
        print(f"WARNING: {len(gold_mismatch)} rows differ from gold tsv: "
              f"{gold_mismatch[:10]}")
    elif gold:
        print("gold tsv cross-check: all measured rows match engine archive")
    return 0 if (n_bad == 0 and not gold_mismatch) else 1


if __name__ == "__main__":
    sys.exit(main())
