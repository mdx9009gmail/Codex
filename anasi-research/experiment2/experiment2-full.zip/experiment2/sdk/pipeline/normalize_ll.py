#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ANANSI 引擎 IR 归一化 —— 可运行参考实现（任务 A3 交付物 2）。

还原自引擎管线函数 FUN_001f5c10（f_001f5c10.c:4084-4160）：归一化阶段不是
自研 LLVM pass，而是**再起一次捆绑 clang 重编译 IR**：

    <clang> -S -emit-llvm -O1 -x ir <input.ll> -o <normalized.ll>

随后引擎做两份拷贝（f_001f5c10.c:4147-4160，std::filesystem::copy_file）：
    copy_file(input.ll  -> input.raw.ll)              # 归档 raw 前端产物
    copy_file(normalized.ll -> input.ll, overwrite)   # 原位替换
（normalized.ll 本身保留为归档副本，与替换后的 input.ll 字节一致。）

argv 证据（.rodata 字符串 + 反编译装配序，Ghidra VA）：
    0x743c2b "-S"  0x743c2e "-emit-llvm"  0x743c39 "-x"  0x743c3c "-O1"
    0x743ccc "-o"   "ir" 字面量            （f_001f5c10.c:4084-4100 装配，
    FUN_005f7f40 子进程执行，FrontendError 错误码 4000）

触发条件：仅"raw 前端档案"（集成保护模式，clang 带 -Xclang -disable-llvm-passes，
见 f_001f5c10.c:1688-1695 的旗标装配）之后运行；纯 neural 前端档案（clang 直接
-O1，无 raw 旗标）**跳过归一化**（轮2 实证：input.ll 的 ModuleID 仍为 '/out/t2.c'，
无 raw/normalized 归档）。

用法：
    python3 normalize_ll.py INPUT.raw.ll -o normalized.ll [--clang /dist/bin/clang]
        [--keep-moduleid PATH]

验收（已在 docker 容器 + 发行包捆绑 clang 22.1.8 下通过，三产物全字节一致）：
    python3 normalize_ll.py run-6qdudb/input/program/input.raw.ll \
        --clang /dist/bin/clang --moduleid /tmp/anansi-7VnhQ3/input/program/input.ll \
        -o normalized.ll
    cmp normalized.ll run-6qdudb/input/program/normalized.ll   # 一致

说明：clang 会把输出 ModuleID 设为**输入文件路径**（归一化器读回的就是
input.ll，故金标准 ModuleID = '/tmp/anansi-7VnhQ3/input/program/input.ll'）。
本脚本默认先把输入复制到 --moduleid 指定的临时路径再编译，以复现该行为；
不给 --moduleid 则直接编译（ModuleID = 输入文件实际路径）。
"""

import argparse
import os
import shutil
import subprocess
import sys
import tempfile


def normalize(raw_path: str, out_path: str, clang: str,
             moduleid: str | None = None, workdir: str | None = None) -> str:
    """input.raw.ll -> normalized.ll：复现引擎的 clang -O1 IR 重编译。

    返回实际使用的输入路径（决定输出 ModuleID）。
    """
    if not shutil.which(clang) and not os.path.isfile(clang):
        raise FileNotFoundError(f"clang not found: {clang}")

    tmp = workdir or tempfile.mkdtemp(prefix="normalize-ll-")
    os.makedirs(tmp, exist_ok=True)

    if moduleid:
        # 引擎语义：归一化器读取的文件就是 input.ll 本身（raw 已被 copy 到该路径）
        target = moduleid
        os.makedirs(os.path.dirname(target) or ".", exist_ok=True)
        shutil.copyfile(raw_path, target)
        compile_input = target
    else:
        compile_input = os.path.abspath(raw_path)

    argv = [clang, "-S", "-emit-llvm", "-O1", "-x", "ir",
            compile_input, "-o", os.path.abspath(out_path)]
    proc = subprocess.run(argv, capture_output=True, text=True)
    if proc.returncode != 0:
        sys.stderr.write(proc.stderr)
        raise RuntimeError(f"normalizer clang failed (rc={proc.returncode})")
    if proc.stderr.strip():
        sys.stderr.write(proc.stderr)  # 前端警告（如 -Wformat-extra-args）照常透传
    return compile_input


def frontend_raw(source: str, out_path: str, clang: str,
                 include: str | None = "stdio.h") -> None:
    """可选：复现轮1 raw 前端档案 clang 命令（f_001f5c10.c:1619-1695 装配序）。

    集成保护模式（raw 档案）完整旗标面；attempt_01 起补 -include stdio.h。
    """
    argv = [clang]
    if include:
        argv += ["-include", include]
    argv += ["-S", "-emit-llvm", "-x", "c", "-O1",
             "-Xclang", "-disable-lifetime-markers",
             "-fno-inline",
             "-fpatchable-function-entry=5,0",
             "-fstack-protector-strong",
             "-fno-inline",
             "-mno-red-zone",
             "-Xclang", "-disable-llvm-passes",
             "-fno-jump-tables",
             os.path.abspath(source), "-o", out_path]
    proc = subprocess.run(argv, capture_output=True, text=True)
    if proc.returncode != 0:
        sys.stderr.write(proc.stderr)
        raise RuntimeError(f"frontend clang failed (rc={proc.returncode})")
    if proc.stderr.strip():
        sys.stderr.write(proc.stderr)


def main() -> int:
    ap = argparse.ArgumentParser(description="ANANSI IR normalizer reference impl")
    ap.add_argument("input", help="input.raw.ll（raw 前端产物）或 .c 源（配 --frontend）")
    ap.add_argument("-o", "--output", default="normalized.ll")
    ap.add_argument("--clang", default="clang",
                    help="clang 可执行文件（发行包内为 /dist/bin/clang，LLVM 22.1.8）")
    ap.add_argument("--moduleid",
                    help="复现金标准 ModuleID 所需的输入路径（如 "
                         "/tmp/anansi-7VnhQ3/input/program/input.ll）")
    ap.add_argument("--frontend", action="store_true",
                    help="先跑 raw 前端档案命令（.c -> raw .ll）再归一化")
    ap.add_argument("--frontend-include", default="stdio.h",
                    help="raw 前端 -include 头（diagnostic-driven 修复产物）")
    ap.add_argument("--gold", help="验收：与金标准文件逐字节比对")
    args = ap.parse_args()

    tmp = tempfile.mkdtemp(prefix="normalize-ll-",
                           dir=os.path.dirname(os.path.abspath(args.output)) or None)
    try:
        if args.frontend:
            raw = os.path.join(tmp, "input.raw.ll")
            frontend_raw(args.input, raw, args.clang, args.frontend_include)
        else:
            raw = args.input

        used = normalize(raw, args.output, args.clang, args.moduleid)
        print(f"normalized: {args.output} (ModuleID <- {used})")

        if args.gold:
            same = open(args.output, "rb").read() == open(args.gold, "rb").read()
            print(f"acceptance vs {args.gold}: "
                  f"{'BYTE-IDENTICAL' if same else 'MISMATCH'}")
            return 0 if same else 1
        return 0
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
