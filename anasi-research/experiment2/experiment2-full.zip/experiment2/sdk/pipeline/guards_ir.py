#!/usr/bin/env python3
"""guards_ir.py — SDK 反模拟器/反篡改守护（CHAMELEON l3.sensors + l3.integrity 忠实移植）。

机制出处与语义（与 CHAMEALEON-main/modules/ir/{sensors,integrity} 对齐）：

anti-emu (l3.sensors, "double-read XOR delta"):
    每个 crown 函数入口对 ≥2 个 ISA 架构不变量（x86-64: cpuid.0 的
    ebx/ecx/edx；AT&T 内联汇编，$0=输出操作数、$$0=字面量立即数）各读
    两次，XOR 得 delta —— 忠实 CPU/qemu 两读相同 → delta=0；弱模拟器
    （桩化/漏建模 cpuid 的片段模拟器）→ delta≠0。delta 折进整数返回值
    （无 ret 折叠点时折进一次整数 store）：x ^ 0 == x，忠实环境恒等；
    永不分支、无可检测谓词、无补丁点；弱环境静默污染数据（状态级
    oracle 拒绝）。

integrity (l3.integrity, "distributed mutually-verifying guards"):
    守卫集 = main + crown（确定性顺序）。每守卫入口 XOR 自身 64 位键到
    全局 token @__sdk_ig_tok，每个返回再 XOR 还原（净零）→ token 恒等于
    当前调用栈上的守卫集。非局部检查挂在"祖先最多且返回整数"的 crown
    的 return 处（远离守卫本体）：token != C（C=该函数祖先键异或，构建
    期常量）→ 置 @__sdk_ig_fail 并返回显式拒绝值 0。删除/割断任一守卫
    即改变期望 token → 拒绝（显式失败，绝不静默错值）。

用法：
    python3 guards_ir.py input.ll -o output.ll --crown f1 f2 \\
        [--guards anti-emu,integrity] [--seed N]
"""
import argparse
import random
import re
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import instrument_ll as IL  # noqa: E402  (复用 .ll 解析骨架)

# ---------------------------------------------------------------------------
# x86-64 传感器信号（移植自 CHAMEALEON targets/x86_64/target_x86_64.cpp）
#
# M1（chame-antidebug v0.2 §4.1）：信号源 3→7——leaf-0 的 ebx/ecx/edx/eax
# （厂商串 + 最大叶号）+ leaf-1 的 eax/ecx/edx（family/model/stepping 与特征
# 位），与 CHAMÆLEON X86SensorBackend::signals() 逐条一致。leaf-1 EBX 明确
# 排除：含 per-core APIC ID（bits 31:24），进程核迁移时双读可能不一致 →
# 假阳性折叠（源文档 §5a 同款决策）。
# ---------------------------------------------------------------------------
CPUID_CC = "=r,~{eax},~{ebx},~{ecx},~{edx},~{dirflag},~{fpsr},~{flags}"
SIGNALS = [
    ("cpuid.0:ebx", "mov $$0, %eax\\0A\\09cpuid\\0A\\09mov %ebx, $0"),
    ("cpuid.0:ecx", "mov $$0, %eax\\0A\\09cpuid\\0A\\09mov %ecx, $0"),
    ("cpuid.0:edx", "mov $$0, %eax\\0A\\09cpuid\\0A\\09mov %edx, $0"),
    ("cpuid.0:eax", "mov $$0, %eax\\0A\\09cpuid\\0A\\09mov %eax, $0"),
    ("cpuid.1:eax", "mov $$1, %eax\\0A\\09cpuid\\0A\\09mov %eax, $0"),
    ("cpuid.1:ecx", "mov $$1, %eax\\0A\\09cpuid\\0A\\09mov %ecx, $0"),
    ("cpuid.1:edx", "mov $$1, %eax\\0A\\09cpuid\\0A\\09mov %edx, $0"),
]

TOK = "@__sdk_ig_tok"
FAIL = "@__sdk_ig_fail"
CHURN_DECL = "declare void @__sdk_churn_step(i64)"
TRACER_DECL = "declare i32 @__sdk_tracer_check()"


def i64_lit(v):
    return str(v if v < (1 << 63) else v - (1 << 64))


def parse_module_functions(text):
    lines = text.split("\n")
    fns, i = [], 0
    while i < len(lines):
        m = re.match(r"define\s+.*?@([\w.$-]+)\s*\(", lines[i])
        if m:
            j = i + 1
            while j < len(lines) and not lines[j].startswith("}"):
                j += 1
            fns.append([m.group(1), i, j, lines])
            i = j
        i += 1
    return fns


def fn_body_slice(fns, name):
    for fname, d, e, lines in fns:
        if fname == name:
            return lines, d, e
    return None


def call_graph(fns, name):
    _, d, e = fn_body_slice(fns, name)
    lines = fns and [f[3] for f in fns if f[0] == name][0]
    callees = set()
    for i in range(d + 1, e):
        for m in re.finditer(r"call\s+[^@]*@([\w.$-]+)", lines[i]):
            callees.add(m.group(1))
    return callees


RET_RE = re.compile(r"\s*ret\s+(i\d+)\s+(.+?)\s*$")
RETV_RE = re.compile(r"\s*ret\s+void\s*$")
STORE_RE = re.compile(
    r"\s*store\s+(i\d+)\s+(%[\w.$-]+|\S+?),\s*ptr\s+(%[\w.$-]+|@[\w.$-]+)")


def events_of(lines, d, e):
    """[(kind, lineno, match)] 整数/void ret 与整数 store。
    void ret 的 match=None（ret void 无返回值；integrity 需在其站点做
    token 出口还原——v0.3 修复：原版只匹配整数 ret，void guard 函数
    只剩入口 XOR、无还原 → 每次调用 token 永久泄漏一个键 → 后续
    checkF 全局误拒，--bind-machine 链暴露（无绑定时 checkF 宿主
    从不执行故未显）。"""
    evs = []
    for i in range(d + 1, e):
        m = RET_RE.match(lines[i])
        if m:
            evs.append(("ret", i, m))
            continue
        if RETV_RE.match(lines[i]):
            evs.append(("ret", i, None))
            continue
        m = STORE_RE.match(lines[i])
        if m:
            evs.append(("store", i, m))
    return evs


def sensor_entry_ir(chosen):
    L, acc = [], None
    for k, i in enumerate(chosen):
        asm = SIGNALS[i][1]
        L.append(f'  %gu.sa{k} = call i32 asm sideeffect "{asm}", "{CPUID_CC}"()')
        L.append(f'  %gu.sb{k} = call i32 asm sideeffect "{asm}", "{CPUID_CC}"()')
        L.append(f'  %gu.sd{k} = xor i32 %gu.sa{k}, %gu.sb{k}')
        L.append(f'  %gu.sz{k} = zext i32 %gu.sd{k} to i64')
        if acc is None:
            acc = f"%gu.sz{k}"
        else:
            L.append(f'  %gu.sacc{k} = xor i64 {acc}, %gu.sz{k}')
            acc = f"%gu.sacc{k}"
    return L, acc


def delta_cast(pre, delta, w, sfx=""):
    """i64 delta → i{w} 值（返回 (前置行, 值名)）。"""
    if w == 64:
        return pre, delta
    if w > 64:
        pre.append(f"  %gu.dz{sfx} = zext i64 {delta} to i{w}")
        return pre, f"%gu.dz{sfx}"
    pre.append(f"  %gu.tr{sfx} = trunc i64 {delta} to i{w}")
    return pre, f"%gu.tr{sfx}"


def integrity_entry_ir(k):
    return [
        f"  %gu.t0 = load i64, ptr {TOK}",
        f"  %gu.t1 = xor i64 %gu.t0, {i64_lit(k)}",
        f"  store i64 %gu.t1, ptr {TOK}",
    ]


def ret_site_ir(fname, m, is_crown, delta, is_guard, is_checkf, k, CS, sfx):
    """统一 ret 站点重写：anti-emu 折叠 + integrity 还原/门控 + ret。
    sfx=站点序号（保证 SSA 名函数内唯一）。
    CS=checkF 期望 token 的**语境值集合**（多调用语境安全，见
    context_token_values）；单语境走原 IR 形态（测试断言兼容）。"""
    if m is None:                       # ret void：只做 token 出口还原
        seq = []
        if is_guard:
            seq += [
                f"  %gu.tk{sfx} = load i64, ptr {TOK}",
                f"  %gu.t2{sfx} = xor i64 %gu.tk{sfx}, {i64_lit(k)}",
                f"  store i64 %gu.t2{sfx}, ptr {TOK}",
            ]
        seq.append(f"  ret void")
        return seq, False
    ty, val = m.group(1), m.group(2).strip()
    w = int(ty[1:])
    seq = []
    v = val
    if is_crown and delta is not None:
        seq, dv = delta_cast(seq, delta, w, sfx)
        seq.append(f"  %gu.rv{sfx} = xor {ty} {val}, {dv}")
        v = f"%gu.rv{sfx}"
    if is_guard:
        seq.append(f"  %gu.tk{sfx} = load i64, ptr {TOK}")
        if is_checkf and CS:
            if len(CS) == 1:
                C = CS[0]
                seq += [
                    f"  %gu.ok{sfx} = icmp eq i64 %gu.tk{sfx}, {i64_lit(C)}",
                    f"  %gu.bad{sfx} = xor i1 %gu.ok{sfx}, true",
                    f"  %gu.tam{sfx} = zext i1 %gu.bad{sfx} to i8",
                    f"  %gu.f0{sfx} = load i8, ptr {FAIL}",
                    f"  %gu.f1{sfx} = or i8 %gu.f0{sfx}, %gu.tam{sfx}",
                    f"  store i8 %gu.f1{sfx}, ptr {FAIL}",
                    f"  %gu.t2{sfx} = xor i64 %gu.tk{sfx}, {i64_lit(k)}",
                    f"  store i64 %gu.t2{sfx}, ptr {TOK}",
                    f"  %gu.sel{sfx} = select i1 %gu.ok{sfx}, {ty} {v}, {ty} 0",
                    f"  ret {ty} %gu.sel{sfx}",
                ]
                return seq, True
            # 多语境：ok = tok ∈ CS（or 链）
            for j, cv in enumerate(CS):
                seq.append(f"  %gu.okv{j}.{sfx} = icmp eq i64 %gu.tk{sfx}, "
                           f"{i64_lit(cv)}")
            okv = f"%gu.okv0.{sfx}"
            for j in range(1, len(CS)):
                seq.append(f"  %gu.any{j}.{sfx} = or i1 {okv}, "
                           f"%gu.okv{j}.{sfx}")
                okv = f"%gu.any{j}.{sfx}"
            seq += [
                f"  %gu.bad{sfx} = xor i1 {okv}, true",
                f"  %gu.tam{sfx} = zext i1 %gu.bad{sfx} to i8",
                f"  %gu.f0{sfx} = load i8, ptr {FAIL}",
                f"  %gu.f1{sfx} = or i8 %gu.f0{sfx}, %gu.tam{sfx}",
                f"  store i8 %gu.f1{sfx}, ptr {FAIL}",
                f"  %gu.t2{sfx} = xor i64 %gu.tk{sfx}, {i64_lit(k)}",
                f"  store i64 %gu.t2{sfx}, ptr {TOK}",
                f"  %gu.sel{sfx} = select i1 {okv}, {ty} {v}, {ty} 0",
                f"  ret {ty} %gu.sel{sfx}",
            ]
            return seq, True
        seq += [
            f"  %gu.t2{sfx} = xor i64 %gu.tk{sfx}, {i64_lit(k)}",
            f"  store i64 %gu.t2{sfx}, ptr {TOK}",
        ]
    seq.append(f"  ret {ty} {v}")
    return seq, False


def opaque_entry_ir(x_i64, sfx, rng):
    """Lane 5：数论不透明谓词入口块（BLA tarpit/opaque-predicates 移植）。

    mod-7 二次剩余：7x²-1 == y² 在整数上无解（-1 非 mod 7 的二次剩余）
    → 谓词恒假 → decoy 块永不执行；LLVM instcombine 无法证明（超出其
    数论推理能力），-O3 下存活。decoy 块做似是而非的"密钥混合"运算并
    volatile 写 @__sdk_ig_fail（防死代码消除），对反编译器呈现一条
    不可判定的假控制流。
    返回（入口插入行, cont 标签名）。"""
    c = rng.randrange(1 << 32) | 1
    k = rng.randrange(1, 97)
    cont = f"gu.opq.cont.{sfx}"
    decoy = f"gu.opq.decoy.{sfx}"
    sq = f"%gu.opq.sq{sfx}"
    m7 = f"%gu.opq.m7{sfx}"
    lhs = f"%gu.opq.lhs{sfx}"
    y = f"%gu.opq.y{sfx}"
    sq2 = f"%gu.opq.sq2{sfx}"
    eq = f"%gu.opq.eq{sfx}"
    d1 = f"%gu.opq.d1{sfx}"
    d2 = f"%gu.opq.d2{sfx}"
    d3 = f"%gu.opq.d3{sfx}"
    L = [
        f"  {sq} = mul i64 {x_i64}, {x_i64}",
        f"  {m7} = mul i64 7, {sq}",
        f"  {lhs} = sub i64 {m7}, 1",
        f"  {y} = add i64 {x_i64}, {k}",
        f"  {sq2} = mul i64 {y}, {y}",
        f"  {eq} = icmp eq i64 {lhs}, {sq2}",
        f"  br i1 {eq}, label %{decoy}, label %{cont}",
        f"{decoy}:",
        f"  {d1} = xor i64 {lhs}, {c}",
        f"  {d2} = mul i64 {d1}, {d1}",
        f"  {d3} = xor i64 {d2}, {sq}",
        f"  store volatile i64 {d3}, ptr {FAIL}",
        f"  br label %{cont}",
        f"{cont}:",
    ]
    return L, cont


def apply_guards(text, crown, guards_on, seed):
    rng = random.Random(seed)
    fns = parse_module_functions(text)
    fnames = {f[0] for f in fns}
    crown = sorted(set(crown) & fnames)
    describe = {"crown": crown, "guards": list(guards_on)}

    # 调用图 + main 可达性（对齐 l3.integrity v2：仅活的守卫）
    cg = {f[0]: call_graph(fns, f[0]) for f in fns}
    live = set()
    if "main" in fnames:
        live.add("main")
        wl = ["main"]
        while wl:
            x = wl.pop()
            for c in cg.get(x, ()):
                if c not in live:
                    live.add(c)
                    wl.append(c)

    def reaches(a, b):
        vis, wl = set(), [a]
        while wl:
            x = wl.pop()
            for c in cg.get(x, ()):
                if c == b:
                    return True
                if c not in vis:
                    vis.add(c)
                    wl.append(c)
        return False

    guard_set = ([] if "main" not in fnames or "main" in crown else ["main"]) + \
                [c for c in crown if not live or c in live]
    keys = {g: rng.getrandbits(64) for g in guard_set}

    # 反向调用边（TU 内全部 define 函数，含未插桩的 native 壳）
    callers = {}
    for f in fnames:
        for g in fnames:
            if f in cg.get(g, ()):
                callers.setdefault(f, []).append(g)

    def context_token_values(c, limit=64):
        """checkF 候选 c 的全部调用语境 token 值（ret 站点检查时刻的 tok
        = XOR(当前调用栈上各 guard 的入口键，含 c 自身)）。

        多调用语境安全（v0.3 修正）：原实现 C=XOR(静态全祖先键) 隐含
        "checkF 只在唯一守卫链内被调用"假设——链外/native 壳直调（如
        wbp stub 的 check_machine_binding 直调 stub_hex_digit，仅
        --bind-machine 时执行）或分叉调用（两条 guard 路径）下 tok≠C
        → select 误拒 → 返回值破坏（machine-id hex 解析全 0 → 指纹必
        不匹配）。本函数反向 DFS 枚举从 TU 入口（无调用者函数）到 c 的
        每条路径的实际键 XOR；穿过 native 函数不改值。语境值/路径超限
        → None（候选放弃：误拒风险优先于检测能力）。路径每函数至多
        一次（防环；递归语境近似）。"""
        vals, budget = set(), [4096]

        def dfs(f, acc, path):
            budget[0] -= 1
            if budget[0] < 0 or len(vals) > limit:
                return False
            if not callers.get(f):        # f 即入口（被 TU 外/asm 调入）
                vals.add(acc)
                return True
            for g in callers.get(f, []):
                if g in path:
                    continue
                nacc = acc ^ keys[g] if g in guard_set else acc
                if not callers.get(g):
                    vals.add(nacc)
                    continue
                if not dfs(g, nacc, path | {g}):
                    return False
            return True

        if not dfs(c, keys.get(c, 0), {c}):
            return None
        return sorted(vals) if vals else None

    # 检查宿主：返回整数的 crown 中祖先最多者（同数取字典序后者，>= 语义）；
    # 前置条件：语境值可枚举（context_token_values 非 None）。全部放弃 →
    # checkF=None（integrity 退化为 XOR 对称 + FAIL 审计，无 select 拒绝）。
    checkF, best, CS = None, 0, None
    for c in crown:
        if live and c not in live:
            continue
        sl = fn_body_slice(fns, c)
        has_ret = any(ev == "ret" and mm is not None
                      for ev, _, mm in events_of(*sl))
        if not has_ret:
            continue
        anc = {c} | {g for g in guard_set if g != c and reaches(g, c)}
        if len(anc) < best:
            continue
        vals = context_token_values(c)
        if not vals:
            continue
        best, checkF, CS = len(anc), c, vals

    if checkF is not None:
        describe["integrity"] = {
            "guards": len(guard_set), "check_in": checkF,
            "expected_token": hex(CS[0]) if len(CS) == 1 else None,
            "context_values": [hex(v) for v in CS],
            "contexts": len(CS), "response": "explicit_deny"}
    else:
        describe["integrity"] = {"changed": False,
                                 "reason": "no enumerable-context crown"}

    # 模块级全局：插在第一个 define 前
    lines = text.split("\n")
    need_fail = ("opaque" in guards_on
                 or ("integrity" in guards_on and guard_set))
    if need_fail:
        at = fns[0][1] if fns else len(lines)
        lines[at:at] = [f"{TOK} = internal global i64 0",
                        f"{FAIL} = internal global i8 0", ""]
        fns = parse_module_functions("\n".join(lines))
    if "churn" in guards_on and crown:
        # 仅当 __sdk_churn_step 不在模块中已有 define 时才插入 declare
        # （源文件内联 churn 并纳入 --functions 时已有 define，重复
        # declare 会导致 "invalid redefinition" 编译错误）
        has_define = any(
            re.match(r"define\s+.*@__sdk_churn_step\b", l)
            for l in lines)
        if not has_define:
            at = fns[0][1] if fns else len(lines)
            lines[at:at] = [CHURN_DECL, ""]
            fns = parse_module_functions("\n".join(lines))
        # __sdk_tracer_check 始终是外部原生函数（不可神经化——需 syscall）
        has_tracer = any(
            re.match(r"define\s+.*@__sdk_tracer_check\b", l)
            for l in lines)
        if not has_tracer:
            at = fns[0][1] if fns else len(lines)
            lines[at:at] = [TRACER_DECL, ""]
            fns = parse_module_functions("\n".join(lines))

    stats = {"funcs_folded": 0, "folds": 0, "returns_gated": 0}
    # 倒序就地修改共享行表：后部函数先改写，前部函数的 [d,e] 索引不受影响
    for fname, d, e in [(f[0], f[1], f[2]) for f in reversed(fns)]:
        is_crown = fname in crown
        is_guard = fname in guard_set and "integrity" in guards_on
        if not (is_crown or is_guard):
            continue
        evs = events_of(lines, d, e)
        has_ret = any(ev == "ret" and mm is not None for ev, _, mm in evs)

        # ① 入口序列（非终结指令）：传感器 delta + churn + integrity 键
        entry, delta = [], None
        opq_x = None
        if is_crown and "opaque" in guards_on:
            import zlib as _zl
            sfx = _zl.crc32(fname.encode()) & 0xFFFF
            for ty, nm, _a in IL.parse_define_params(lines[d]):
                if ty.startswith("i") and ty[1:].isdigit():
                    w = int(ty[1:])
                    if w == 64:
                        opq_x = (nm, sfx, [])
                    elif w < 64:
                        opq_x = (f"%gu.opq.x{sfx}", sfx,
                                 [f"  %gu.opq.x{sfx} = zext {ty} {nm} to i64"])
                    else:
                        opq_x = (f"%gu.opq.x{sfx}", sfx,
                                 [f"  %gu.opq.x{sfx} = trunc {ty} {nm} to i64"])
                    break
            if opq_x is None and evs:
                # 无整数参数的 crown：内联汇编读 %rsp（真实运行时值；nop 不
                # 定义输出会被视为 undef 而折叠——已实测）；谓词恒假，语义安全。
                # 注意 LLVM 汇编模板用单 % 寄存器名（%% 是 C 宏约定）
                opq_x = (f"%gu.opq.x{sfx}", sfx,
                         [f'  %gu.opq.x{sfx} = call i64 asm sideeffect '
                          f'"movq %rsp, $0", "=r"()'])
        if is_crown and "churn" in guards_on and fname != "__sdk_churn_step":
            import zlib
            fd = zlib.crc32(fname.encode()) & 0x7fffffff
            # v2 周期复查 + 静默腐化（对照攻击报告 P1-1.2/P2-1）：
            # 每次受保护函数调用时调 __sdk_tracer_check()（读 TracerPid
            # + 返回 __sdk_guard_poison 含 seal 摘要），结果 XOR 进
            # churn 输入 → 被跟踪/文件被改 → churn 偏移 → VM 算垃圾
            entry.append("  %gu.tracer = call i32 @__sdk_tracer_check()")
            entry.append(f"  %gu.churn_in = xor i32 %gu.tracer, {fd}")
            entry.append("  %gu.churn_z = zext i32 %gu.churn_in to i64")
            entry.append("  call void @__sdk_churn_step(i64 %gu.churn_z)")
        if is_crown and "anti-emu" in guards_on and evs:
            chosen = [i for i in range(len(SIGNALS)) if rng.random() < 0.66]
            while len(chosen) < min(2, len(SIGNALS)):
                c = rng.randrange(len(SIGNALS))
                if c not in chosen:
                    chosen.append(c)
            ir, delta = sensor_entry_ir(sorted(chosen))
            entry += ir
        if is_guard:
            entry += integrity_entry_ir(keys[fname])

        # ② 事件站点（先处理——原始索引，倒序替换）
        gated_here = False
        site = 0
        for ev, i, m in reversed(evs):
            if ev == "ret":
                seq, gated = ret_site_ir(
                    fname, m, is_crown and "anti-emu" in guards_on, delta,
                    is_guard, fname == checkF, keys.get(fname),
                    CS if fname == checkF else None, site)
                lines[i:i + 1] = seq
                if is_crown and delta is not None:
                    stats["folds"] += 1
                if gated:
                    gated_here = True
            elif (ev == "store" and is_crown and "anti-emu" in guards_on
                  and delta is not None and not has_ret):
                ty, val, ptr = m.group(1), m.group(2), m.group(3)
                w = int(ty[1:])
                seq, dv = delta_cast([], delta, w, site)
                seq.append(f"  %gu.sv{site} = xor {ty} {val}, {dv}")
                seq.append(f"  store {ty} %gu.sv{site}, ptr {ptr}")
                lines[i:i + 1] = seq
                stats["folds"] += 1
            site += 1

        # ③ 入口序列插入（统一平移）
        if entry:
            lines[d + 1:d + 1] = entry

        # ④ opaque：入口块尾部分块（原终结符移入 cont；phi 前驱补丁）
        if is_crown and "opaque" in guards_on and opq_x is not None:
            x, sfx, pre = opq_x
            # 入口块 = d+1 .. 首个标签行（或函数尾）；终结符 = 块内最后一条指令
            t = None
            for i in range(d + 1, e + len(entry) + 2):
                if i >= len(lines) or lines[i].startswith("}"):
                    break
                s = lines[i].split(";")[0].strip()   # 注释容忍（clang 标签带 ; preds）
                if not s:
                    continue                          # 空行/纯注释：跳过
                if re.match(r"^[\w.$-]+:$", s):
                    break                             # 首个标签：t 已定格
                t = i                                 # 最后一条非空指令行
            if t is not None and t > d:
                term = lines[t]
                opq, cont = opaque_entry_ir(x, sfx, rng)
                decoy_start = next(k for k, s in enumerate(opq)
                                   if s.startswith("gu.opq.decoy"))
                pred_lines = opq[:decoy_start]           # 谓词 + br
                decoy_lines = opq[decoy_start:-1]        # decoy: ... br cont
                cont_line = opq[-1]                      # cont:
                lines[t:t + 1] = pre + pred_lines + decoy_lines + [cont_line, term]
                # phi 前驱补丁：入口块不再是直接前驱 → cont（仅本函数内）。
                # 未标号入口块在 phi 中的引用名 = %<未命名参数数>（LLVM 槽位
                # 序：参数占 0..k-1，首个块占 k）。%0 只对全命名参数的函数
                # 成立（单函数 t2 即如此）；多参函数（如 wbp stub 27 函数
                # 合并 TU 的 decrypt_str_blob_impl，5 参 → 入口 = %5）引用名
                # 是编号，只补 %0 会漏 → phi 前驱失配、LLVM 拒编译
                n_unnamed = sum(1 for ty, nm, _a in
                                IL.parse_define_params(lines[d])
                                if re.fullmatch(r"%\d+", nm))
                entry_lbl = f"%{n_unnamed}"
                end2 = d
                while end2 < len(lines) and not lines[end2].startswith("}"):
                    end2 += 1
                pat = re.compile(r"(\[\s*[^,\]]+?\s*,\s*)"
                                 + re.escape(entry_lbl) + r"(\s*\])")
                for i in range(d + 1, end2):
                    if " = phi " in lines[i]:
                        lines[i] = pat.sub(rf"\1%{cont}\2", lines[i])
                stats.setdefault("opaque_blocks", 0)
                stats["opaque_blocks"] += 1
        if gated_here:
            stats["returns_gated"] += 1
        if is_crown and delta is not None:
            stats["funcs_folded"] += 1

    describe.update(stats)
    return "\n".join(lines), describe


def main():
    ap = argparse.ArgumentParser(description="SDK guards (anti-emu + integrity)")
    ap.add_argument("input")
    ap.add_argument("-o", "--output", required=True)
    ap.add_argument("--crown", nargs="*", default=[])
    ap.add_argument("--guards", default="anti-emu,integrity")
    ap.add_argument("--seed", type=int, default=0x5EED)
    a = ap.parse_args()
    guards_on = [g.strip() for g in a.guards.split(",") if g.strip()]
    text = open(a.input, encoding="utf-8").read()
    out, desc = apply_guards(text, a.crown, guards_on, a.seed)
    open(a.output, "w", encoding="utf-8").write(out)
    import json
    print(json.dumps(desc, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
