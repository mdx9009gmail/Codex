#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ANANSI 引擎「计划 → 模块权重包」装配线复现（任务 D1）。

================================================================================
输入:  module_plan.json + production 权重库 (+ storage 档位 fp16/fp32)
输出:  模块权重 npz（与 src-neural-wip/_anansi_*_module_weights.npz 同键同形）

装配线对应引擎 neural-fitting / runtime-materialization 阶段。反编译锚点：
FUN_002dde50（神经 IR 重写内核）→ FUN_00681df0/FUN_00680300（模型装载）
→ FUN_0067c770（codec 固定 QR 共轭）/FUN_007419b0（3 张量右乘 X）
→ FUN_002f5720/FUN_003a1cc0（ragged basis + route_projection 装配）
→ FUN_00539810/FUN_00531430（opaque option 表 / bipolar 槽码本）
→ FUN_00666780（Controller 拟合驱动）→ FUN_0033a790/FUN_00346420（C 物化）。
详见 decomp/notes-weight-composer.md。

张量分类（对两锚点全量实测）：
  [A] 引擎/库常量（确定性，逐位复现）
      codec 12 张量 = bundle neural_codec_weights.npz 的 9 张直接拷贝 +
      3 张（encoder_w3/encoder_b3/decoder_w1）右乘引擎固定正交共轭 X
      （X = FUN_0067c770: 32×32 Gaussian → dgeqrf/dorgqr QR，种子源自
      production 模型束，跨 build 不变；两锚点 codec 逐位相同为证）。
  [B] 计划派生尺寸（确定性公式，derive_architecture()）。
  [C] 生产库拷贝: ragged ALU term = models/production/stable_{op}_weights.npz
      12 张量原样拷贝（可整体取负存储）。term 顺序/±号 = build 会话随机
      （正交路由指派的副产品，与 tag 同类）；按会话材料或种子重建。
  [D] build 会话随机 + 拟合产物: ragged_M / q 轨迹 / 三塔权重 /
      option conditioner / slot 码本 / fmt 置换表 / 效应通道指派。
      引擎路径 = 种子驱动 RNG + 拟合（t1: supervised-ce-regression,
      seed_source=derived；t2: least-squares, seed_source=continued-plan-rng；
      种子记录于 prot.json accepted_fit.seed）。本生成器提供等价的
      零训练解析构造（synthetic_fit()：闭式最小二乘精确插值）。

用法:
  组装:      python3 weight_composer.py --plan <module_plan.json> --out m.npz
  锚点验收:  python3 weight_composer.py --plan <plan> \
               --verify-anchor src-neural-wip/_anansi_module_weights.npz
"""
import argparse
import base64
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
RUN = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EMBED = 32
Q_DIM = 64
CONDITION_DIM = 32
CONTROLLER_INPUT_DIM = 96
HIDDEN = 64
OPTION_DIM = 64
ROUTE_DIM = 16
OC_OUT = 34          # enabled(1)+route(16)+fmt(4)+aux(4)+ct(1)+effect(8)
FMT_COUNT = 4
# 修正:原为原作者 Mac 绝对路径(/Users/system-security/Downloads/...),
# 本机不存在且无回退,导致多函数模式/selftest T3/profile_gen 失败。
# 改为 SDK 内 weights/ 相对路径(HERE=pipeline, RUN=SDK 根)。
DEFAULT_PRODUCTION = os.path.join(RUN, "weights", "production")
DEFAULT_CODEC = os.path.join(RUN, "weights", "codec",
                             "neural_codec_weights.npz")
T1_PLAN = os.path.join(RUN, "artifacts/engine-trace/prot.build/run-6qdudb/"
                      "work/function_0/work/program/module_plan.json")
T2_PLAN = os.path.join(RUN, "artifacts/engine-verify2/prot2.build/run-fL5D2U/"
                      "work/attempt_01/program/module_plan.json")

# ---------------------------------------------------------------------------
# [A] codec 的引擎固定正交共轭常量（FUN_0067c770/FUN_007419b0）。
#   模块 codec = bundle codec 的 9 张直接拷贝 + 3 张（encoder_w3/
#   encoder_b3/decoder_w1）右乘引擎固定正交阵 X（32×32 Gaussian →
#   dgeqrf/dorgqr QR，种子源自 production 模型束，跨 build 不变——
#   两锚点这三张量逐位相同为证）。X 的生成位流（"NumPy pool4" PRNG +
#   randomkit ziggurat normal）未逐位还原；f32 sgemm 舍入使 lstsq 反解
#   无法达逐位精度，故以「引擎常量」形态内嵌三张共轭张量（base64=f32
#   little-endian；自锚点提取，t1≡t2 逐位一致），共轭关系由
#   verify_codec_conjugation() 以 1e-7 容差复核。
# ---------------------------------------------------------------------------


# 计划 operation → ragged 基底（ICMP_* 经 SUB 借位；LOAD 无基底）
OP_BASE = {
    "ICMP_ULT": "SUB", "ICMP_EQ": "SUB", "ICMP_NE": "SUB",
    "ICMP_SGT": "SUB", "ICMP_SGE": "SUB", "ICMP_SLT": "SUB",
    "ICMP_SLE": "SUB", "ICMP_UGT": "SUB", "ICMP_UGE": "SUB",
    "ICMP_ULE": "SUB",
}
OP_CORE = {
    "ADD": "add_byte", "AND": "and_byte", "OR": "or_byte", "XOR": "xor_byte",
    "SUB": "sub_byte", "SELECT": "select_byte", "SHIFT_SHL": "shl_byte",
    "SHIFT_LSHR": "lshr_byte", "BIT_INDEX": "bit_index",
}
LAYOUT_CODE = {"binary-lanes": 0, "ternary-lanes": 2, "select-lanes": 1}
# 效应通道语义（8 通道；指派 = build 会话随机「structural_effect_codes」，
# 派发优先级固定：TOKEN > RENAME > HALT > STORE > LOAD > COPY > ALU）。
# 两档观测指派（rollout effmax 通道实测；本生成器 canonical 取对应档）：
CANONICAL_CHANNELS = {"STORE": 4, "LOAD": 2, "COPY": 7, "TOKEN": 3,
                      "RENAME_A": 1, "RENAME_B": 5, "HALT": 6, "ALU": 0}
T2_CHANNELS = {"STORE": 4, "LOAD": 2, "COPY": 7, "TOKEN": 3,
               "RENAME_A": 1, "RENAME_B": 5, "HALT": 6, "ALU": 0}


# =========================================================================
# 1. 计划 → 架构尺寸公式（问题 1；两锚点全字段验证）
# =========================================================================
_MEM_WIDTH_BYTES = {"i8": 1, "i16": 2, "i32": 4, "i64": 8, "ptr": 8}


def _memory_unions(plans):
    """内存动作三表的计划并集（引擎实测规则）：

    - BYTE_OFFSETS：[-1]（ALU/COPY 无地址）∪ {0} ∪ {constant_offset}
      （引擎 whibo 模块：{-68,-2,-1,0,1}——我方计划无动态 router 项，
      静态并集 {-1,0,1}；t2 单函数 {-1,0} 与 R2 锚点逐字一致）
    - ACCESS_WIDTHS：[0]（非内存）∪ {内存步的字节宽}
      （引擎 {0,1,2,4,8}；t2 {0,4}）
    - ALIGNMENTS：[0] ∪ {guaranteed_alignment}（t2 {0,4}）
    """
    widths, aligns, offs = {0}, {0}, {-1, 0}
    for pl in plans:
        for s in pl["steps"]:
            if s["action_kind"] != "memory":
                continue
            vt = s.get("value_type_id") or s.get("source_type_id")
            n = _MEM_WIDTH_BYTES.get(vt)
            if n is None and isinstance(vt, str) and vt.startswith("ptr"):
                n = 8
            if n is None:
                n = (s["source_width"] + 7) // 8
            widths.add(n)
            aligns.add(int(s["address"]["guaranteed_alignment"]))
            offs.add(int(s["address"]["constant_offset"]))
    byte_offsets = sorted(offs)
    access_widths = sorted(widths)
    alignments = sorted(aligns)
    return dict(byte_offsets=byte_offsets,
                byte_offset_choices=len(byte_offsets),
                access_widths=access_widths,
                access_width_choices=len(access_widths),
                alignments=alignments, alignment_choices=len(alignments))


def derive_architecture(plan, n_classes=None):
    """module_plan.json → 全部架构尺寸。

    公式（t1: 8 动作/8 槽/fp16；t2: 17 动作/14 槽/fp32 双锚点验证）：
      v_slots         = context.temp_slot_capacity
      max_actions     = controller.max_rollout_steps = len(steps)
      region_rows     = max_actions + 1          （q 轨迹 = 动作数+入口行）
      action_states   = 2 * max_actions          （prot.json action_states）
      slot_choices    = v_slots + 1              （含无效哨兵）
      slot_encoding   = v_slots ≤ 8 ? categorical : build-local-bipolar-code
                        （f_00651ed0/f_001b595c 的 +0x1a 布尔）
      slot_code_dim   = categorical ? slot_choices
                        : (slot_choices ≤ 15 ? 12 : 2^ceil(log2(slot_choices)))
                        （≤15 槽沿用 t2 实测 12 维；更大槽计数取 Walsh 维数，
                          保证码本两两正交 → 分离约束自动满足）
      lane_deltas     = sorted(set(steps.lane_delta_* ∪ {0}))
      option_hidden   = max_actions              （= action_states/2；需 ≥
                        不同 option 数）
      selector_rank   = max(v_slots ≤ 8 ? 8 : 16, n_classes - 1)
                        （n_classes = 动作等价类数；sel 头经 rank 维 latent
                          精确插值需 rank ≥ 类数-1。t2: 17 类 → 16 ✓ 锚点不变）
      controller_hidden = max(64, n_classes)     （qnext 直连头精确插值需
                        hidden ≥ 类数-1；t2: 17 类 → 64 ✓ 不变）
      ragged_terms    = distinct ALU 基底数
      selector_heads  = 4*slot_code_dim + 4 + 3*n_widths + 3*len(lane_deltas)
                        + 4*2 + 1
      controller_heads = selector_heads + 64 + 64
    """
    p = plan["plans"][0]
    steps = p["steps"]
    v_slots = p["context"]["temp_slot_capacity"]
    max_actions = p["controller"]["max_rollout_steps"]
    assert max_actions == len(steps), "max_rollout_steps != len(steps)"

    deltas = {0}
    for s in steps:
        md = s.get("metadata") or {}
        for k in ("lane_delta_a", "lane_delta_b", "lane_delta_c"):
            if k in md:
                deltas.add(int(md[k]))
    lane_deltas = sorted(deltas)

    term_ops = []
    for s in steps:
        if s["action_kind"] != "tool":
            continue
        op = OP_BASE.get(s["operation"], s["operation"])
        if op not in term_ops:
            term_ops.append(op)

    bipolar = v_slots > 8
    slot_choices = v_slots + 1
    if not bipolar:
        slot_code_dim = slot_choices
    elif slot_choices <= 15:
        slot_code_dim = 12
    else:
        d = 16
        while d < slot_choices:
            d *= 2
        slot_code_dim = d
    base_rank = 8 if v_slots <= 8 else 16
    widths = sorted({s["source_width"] for s in steps}
                    | {s["logical_width"] for s in steps} | {1, 32})
    n_widths = len(widths)
    mem_unions = _memory_unions([p])
    arch = dict(
        v_slots=v_slots, max_actions=max_actions,
        region_entry_rows=max_actions + 1,
        action_states=2 * max_actions,
        slot_choices=slot_choices, slot_code_dim=slot_code_dim,
        slot_encoding="build-local-bipolar-code" if bipolar else "categorical",
        lane_deltas=lane_deltas, lane_delta_choices=len(lane_deltas),
        option_hidden=max_actions,
        selector_rank=base_rank, controller_hidden=64,
        ragged_terms=len(term_ops), term_ops=term_ops,
        selector_heads=0,
        controller_heads=0,
        widths=widths, n_widths=n_widths, rewrite_kind=p["rewrite_kind"],
        boundary_values=len(p["boundary_values"]),
        # 对象头：n 个持久对象 + 1 个哨兵（t1/t2 单对象 → oc=2/sentinel=1
        # 与引擎锚点一致；多对象沿 E 冲刺 fix#8 的 n+1/n 约定）
        object_sentinel=len(p["context"]["persistent_objects"]),
        object_choices=len(p["context"]["persistent_objects"]) + 1,
        **mem_unions,
    )
    if n_classes is not None:
        arch["selector_rank"] = max(base_rank, n_classes - 1)
        arch["controller_hidden"] = max(64, n_classes)
        assert arch["controller_hidden"] <= 4096, "controller hidden overflow"
    arch["selector_heads"] = _selector_heads(arch)
    arch["controller_heads"] = (arch["selector_heads"] + OPTION_DIM + Q_DIM)
    arch["head_dims"] = _head_dims(arch)
    arch["head_offsets"] = {}
    off = 0
    for name, dim in arch["head_dims"].items():
        arch["head_offsets"][name] = off
        off += dim
    assert off == arch["selector_heads"]
    return arch


def _selector_heads(arch):
    d, n, nw = arch["slot_code_dim"], arch["lane_delta_choices"], \
        arch["n_widths"]
    # 4 槽码头 + input_layout 4 + input_span/source/target 各 nw +
    # 3×lane_delta + object/byte/aw/align 各自维度（计划并集）+ ct 1
    return (4 * d + 4 + 3 * nw + 3 * n + arch.get("object_choices", 2)
            + arch.get("byte_offset_choices", 2)
            + arch.get("access_width_choices", 2)
            + arch.get("alignment_choices", 2) + 1)


def _head_dims(arch):
    d, n, nw = arch["slot_code_dim"], arch["lane_delta_choices"], \
        arch["n_widths"]
    return {"read_a": d, "read_b": d, "read_c": d, "write": d,
            "input_layout": 4, "input_span": nw,
            "lane_delta_a": n, "lane_delta_b": n, "lane_delta_c": n,
            "source_width": nw, "target_width": nw,
            "object": arch.get("object_choices", 2),
            "byte_offset": arch.get("byte_offset_choices", 2),
            "access_width": arch.get("access_width_choices", 2),
            "alignment": arch.get("alignment_choices", 2),
            "control_transform": 1}


# =========================================================================
# 2. [A] codec：bundle 9 拷贝 + 3 张量 ×X 共轭
# =========================================================================
_CONJ_B64_ENC_W3 = (
    "/8/FPYoH8TyxPu47Mz8RvrRbBjwAt7Y9x5DivagCbD3T0eG9ZjsiveZ4qj2mM408P6s8PdF4FTxSf2E8gwq0vY2TXj3HFYw9iE92"
    "O4uJoD0OVWk+dtE9PIzIID7N2vw96xXhvdwOST1/OPW9oMy6uZDRKj08LKy9mOJkvd0Wbr3VqZG9mWQYvKgBh7xvJ8K8ygJGveXC"
    "kb01/jq9GbR1PCdXtT3oeCy9jyPCPa8zgLwUab488d0UPSVUwDgYS1y9t179PAmoC75qiXi8LwTxO3bz9zyvG7C8VVnBPO8uf7w4"
    "GZ28Ce4OvK1rqLxtj1C9ee3yPBpNWj22DW48JWOIvYCXPb2Ls6m98f6WvaV0Xr0ySwC+eSbUPPkZizx91nC9B8kePUgD/bw5key9"
    "Ne6IvVgijLsNwL+9yxrbPHXd6L0iDiQ+KBYmPQYEdz1oSpU8SLIAPtOk47xtEfW8Sus8vV9zqD2Eslo9XNy0PciaSL3xuV49JToJ"
    "PMe9Kz78xkq8WDeEPbKbC73+BdO6WvXrvW/au7txIBS90dvTPUlmwbx8x0e+6G6rvRy4A76AXEg+eWlcPoKE4TxZIak9MM7MvVV4"
    "hDsKCCA9rlVJPfQVPr7Sdig+u+NBPWy9OT6b9Fg+f1GNPaqT3r1j4tM9APTQPSGO5rywtaA9xmTJvTnKq73XzWq9TFwqPq+dHr1C"
    "aR4+Q3fIvebr0D01zNg9H64tvcbVSb4exzw+teYlvTXNr72DfpY9VA0ZPjU7rjySPa+8mwj9PYOAN72BGgS8YX6zvNvrSL6ThzG9"
    "2A5LO4vA/bzabgK9VWMOPiAdiTzQ92q+TgXvPcXxbD5ydWa8ioHmvROVkb0Taeq9RRc5vfjCvr0YdRk7TvPhPEesNj2gb8g5TDYU"
    "vV9teby2OFw9WHQbvf4o+Dy6YBA98wTpPO2wszz7jkq9CJ5kPW0saD3y7oA9bCJ9vOHQbL172B890wY3vQzMoz2/DCy9CSWaPYUH"
    "Uj2cgoo9E7fLPX+1yrsI5sO81mioPRJiJT0YPVW9vKa6vT20Fz4oEs89f6BCPkdXBr3woJ891GFUPJheLz0MlxQ9DxaSvOIhFD5i"
    "kBY+8QOGvatGKD2GaGW9wCAhvqzHfL4Borw97j7XvL/+uj2TZsM9aMgSvf62FDwUeu686WU/PmCXFL6ynEG9LosGvVmpSr38VJu8"
    "nsAXvWOHO71yLwq+2WNUvTzTpT2ODQi84h72vfmTtb32Qfq9tIvIvIEv9Lszshu+DLewPf7UKr6U+Iy9uBkIvq0r5DxmMho8SHXh"
    "PSE16zwCwTw9ak/rvbvRHLxzrMS9IOq2vIOOd71sS408MDtDPfnRFb2oUyI5FrIlvpXqdL35ObW8wlQJvgDAlz2sp/W765nNvcJ6"
    "Xb267PU6b8s7PWKE1DyVH5e9Bsc6PSbEFL2UWEe8KcyWveiTFbs8kzo9plkcPCY8bL2k84a9xiK0vO6q7DxWjo06bkjcuwFaRb0i"
    "LlY85tGqPNgqZj1bNa89i0a0PD4Ckj248Da8xbQFPeC/Hr1Q8sa7jYeivYiU8bwFQCW9RKM8PUP/mT3aLN69+BVhPPorc73pabG9"
    "86AFPgT1yzy8K7S9DAcivquPxb3EDqQ8bUcmPmV9JD4ebO09rScEPtuzrb3Nkos7mNpmPX41qb1xDC89C/CQvEmthz0c4hG8hOmT"
    "PTXlk71aqf29vQpmPUYQuz31vkO+w3aPPDIw9T0JYKW7B87LvaUFnT0cACC+13SCPSx3z7y5IV29zATqPYqm0TybHbI92sTEvVOd"
    "NL3hTJW8jxD5vCoRcD25tFi+PBLAOueVL748yi89cnuTPfndpjw1nJM9jfnavI89GL5/JA2+MQRAvRznzL2Z7Zw8OPryufzfSb1o"
    "QTc9dlwVvSR8g73dagS9iAH5u/kIyb1clqq9z9/QPYis1rnhWzw9hshNvQalIr282I29zzVvPUB0wjtISE29+vt5PIpxPz3BnVU8"
    "qSMLvb+hsT0GkMC8G/mUPBpGr70u6o27tP7AuxIfqztrfN08sF6DPGNTjD7/sh6+5CjBvWKZFT1bfmM9Kxuovf5E6DtHff69bIzu"
    "vS1rLTzprY49E9eKvq4YTD70yFI9MRPZvTwhZ7y+X7m9iCkCvCuQeb0om0u+lIJWPpK3771GCGI+rNMavoqc2LxLams9DemoPY90"
    "h71jQkw8wU8LPgEURb3DJKW8bvy5vByEUrycJrG8OD0lPdL3Xj0rBgu+UkwjPXRTizzqgF+8+aVKvXU/8Tv0dEo9X1I9vbzoBj12"
    "+sQ9bSMPPfaO4b1c5/s7aiAdvUhup73YCMS8QjmsPSyklDverZc9BNasPGSCeTxzv/+8S/0QPVDtJ7zvIoC9gigWvbdMJb47Tn49"
    "IB9qu0hKR75/8qC9btAjPhPho73YMRI9QZXMvTaWzbxqYw496JV7vFsQKjzbilC9l3IPPfMneb3hXYw9eSo4vZIUfrzF3VO+Ggqz"
    "O5oGsb2Ti8S9tEcAPnLHHj0yW5M8EOw3PtVY8L1mhU09jIhnPQ5Yjz22NqA9z5ifvPvOhD31Vri9Yr4FPfiLEr2fXTK+KMpCPJwO"
    "LD6EjQE8ovQpvO3M1j0vOuG8bwiqPOVsOL5Aw4Q+nuzivCxzGj7l2C0+t6IBPmyXZ70Jfiw9P8L7PZj4Qj6UuUY+eLepvfNwdL1l"
    "UVI9Fm+kPPE/Rr720IM9xeWaPeMFwj1Y30w9UmS9vDh+CTvvokg+7Q9yPl4uAL35VZ09exR/PYBSmrkYYcO93pqvvU/5gr0KdnU+"
    "8JdOuzq9rb2rOze+nD6vvJi9Sz1NTMA9f55ZPjzILL2Gmaw8bhE8PtiDATyYmEI9SzQpvc++vzw6Bww9ei+UPeBBwryALTw8EH+F"
    "vXqxhj2kQKS7qH2suxa4eL0Y4sc9XNwxvNykrDwHfNk8aF+ZvLQRPbxQvWc9FbOBPbYDy7tODDA8fVIQveAuqD3nNrO8eLmfvbvU"
    "Rz3SXZc8xmJMPaeliL0apJM97NJKvHGyJr0tseu84+hAPZ7qBL0GWrq82c5ovQgZDL0cKcS9OltFvPDVkj1Idam842YfvMobHL22"
    "4jG9MORYvDzr/7y+kM88PD4WvQsAhz0svJW8yoIzPBOkg71s8m88DnYEvLOpMj0ktXs9Hgg4va1+1j3iFFG9c6+pvP3LxD0ro6a9"
    "UYzju5zCXL3q1ty7hZpavWZGpDtms7u8BRwGvOQ2pTxvqIK9WWTrPB33yLxgqnY6eoEOPOy4T72nf529bm3nvEaykj2olre6Qe+A"
    "PBJ8VL3zYPq9NroAPeNLIL1j6+u8VulcvJm52ry+q3w8MMmavKq6ML3nafS9rDElvY6RHz2Ogzy8wFoEPJhbpDlaBMw8dtJhvbpc"
    "jj13BPm86NVQu2myY75Bfao9Qq6HvRCi6Dx78M88nxBCPKUljz3MY6i9bgO/vSWvkT0xSiW9+KpGvQbOFL5vycU9aXDSPGWwCT1I"
    "9FC8wis6vR+ni7xvK0m9CTNgvbFstD0vgKy9XLOoPaBrB73FwgQ9q7MCu+ZbUL1geze+ke0aPskxSbx87gS+EQKlPdIag706Ida9"
    "7/ahPdXQ8z2KkPu9QGUqvcN8jzx7ZPK8NMBLPLQGDL13mL29qKPsvNiK2j0S0Ny6EKTvuvXmdb7ffPA9Gmb7PScUKD4E0ri64joK"
    "vBSS+L0WkQq+3jdhvc+i6DwHM5q9uiWNup6Su72zOW+9gEQBODtmu73LZXo9+mnbva26AL7UEt+8zn65OzzjDL67JwI9T5HyvGtt"
    "sD1Knqa7gH/Ivf8sur0XuKM9HNaovS9VTT3w4pq9C0IHvg5A4T1MIgY+h56oPeYtgTs4uRG+sq4xvdaxrL0+UqS8kJLpvSSQxL3T"
    "JOw8tijivbwrib2H/4g9PjEWvEHntz3gxXS+a0GmvJtJkT6S7SW+Op91vm/qjL3Opwa832N1vXcADT4cNRe+pwlIPjh65r3yMrC9"
    "yRqVPbIMOT2ugnq96KsFPvWcED5h6C89S5LkvalT5r1fW569HzDMu2IYFb7PhHI9b1drvr1TFD077tK9OuBbvIj9C77hbWi75iw8"
    "PUb4k71sJCG9FnKvvsVP2r2Vzw4+Pq03vdh9jD5Kqlu9GxdUvS25yj3WqK69y6vpvdYdpL2WJkG9kkW8vfqWirzIsb09mL3LPK28"
    "ZD2cDl49nP6NPFS2Nz74sfC8opAMvh2QdT1LuBK+GEY9vhFkEj7SnE69IHkCPhQ75DyUIrQ8a+P6Pa71Nz0HO7c9/S5NvUyIYjtF"
    "HN68ZhbovTPtCD5C07O8koEjPmhhir39lpU9dpsaPvsA4b0ZkYw+UlfUveeWlr3n+L68qyRWvY95gLz0Etw9MebZPZ0Ov7yADr69"
    "7p5AvQj9Rz61O8Q9MGgxPJyun73EyEi8NH+EujZwCLv3GIQ+2MBjvd0CQL2Gblq9IN5dPe1qYr5gntu9oAUFPjnDcL3914Q+IBqP"
    "vNJs/b2ugWQ+hNmAvaYifT5cxNC8jGLeO7SwET1wkQC6R/BYveDg8z2waiO+l4mZPUHA6r02Mgo9oRk6PnxPpr3sGak8kRIrvoxK"
    "GbxQWpE9wY6APakerT1mWpY76pHyPKZ9PLxxrwQ+o+myvcioH76bwiy+8mDkPLt+7b1YG/C5BeiqPS7a4zzlq6S8JAjZvWDDsDk8"
    "zrK9oWHQvfkqib3mMAi+HEofPEdUnb26Wce68qyxPVAI6bwRUy49tHWBvRQWCDyC/RQ+EDiKPQehd70xgLI9vd+4PRraQT0wNT49"
    "UhxfPf/d1z0r5Ym9w04rPUXvor29wxa+cylOPf6nQz5dOUO91BQyPXqZxz0WYaO91K4cPYzUrD20tsY7JQERvtxQqD1zQsS8jZD+"
    "vFU0QT4Om7o9onUhvJleXD0X0jE+nkYkvQzbPTzCLcC8UIBjPYDPJr55Y748EGQ2vKDyt7zBbfG98rkDve9SEbyUddi9kReiPfbP"
    "frz5V3U8+er5PUIi2r1aZ7C9Av4hvFrhCz37ISY+usMKvmZKH70OEu+9XjWDvOLtoT3rd0G+VcNrPa9evT1jsqk9Kw/tPYpUED4M"
    "yx2+viQSPCf1j72hlFm9qdfpPEHDpz3pZAW+orMHvlXW3b3qdKi9YV0qvrDA5DzA33Y9ebbRvUhImbxMxRy98L29vT/EWz2glg4+"
    "HBTdu/qcrj02myQ95305Pa0Umr1Ri2K9uZn1PYEeur0gnzE+vVeDvZ7LMb1kj7I9FOK+vUaYAL6sU3I8glYoPv8p6j1ytw29CcG6"
    "PZn+Cb6d1D09S1pKPq9Hxz1OswM9TPE8PKC/fzk00Gg+5fXUPEUacjyHiXW9sSIXvhv9jr34hOg9UHGBvdrwIrxh+Ru+GkEYviRx"
    "Rb06lAW8JUtvPUI7Zz3K79q97RqivHhsfr0ZH3c+Zxs5vbLLKj5tvq092miAOyB9Zb01h6o9a6gEPvJPnr13JU2+r3L0vD/QPb0l"
    "Svq81M2NvVWQkbwZ9WC9qvbUPBjT1r1A/NC8CYD8PaBSXDtMBOU89aKMvc5H4D1msf+9Q7QWPR4iKb1+0iQ9k0ZXPSZM0z09nAI8"
    "okUxvHwZlr2V4vC9Ym2OPQzYzj2+yUi9tt7NvF2yTb0kftI8FjEavkqEarwBMEY9uyEMu0H/dz2YE+88tfLHvNjXgT2G7um8XFat"
    "PBDscTx7Jri8ixHTu+L6PLu/Eyi9QqElPfBAPD2bxCg9FjVQPQRwbz2npxq89rmjvannJT1Ugoq994RWPGNh1bzdDso9SISEvM4O"
    "Fr3MLQm+oIyMPFGrEjy//tq8LEiXvo64Kb1aJQq+hA0TPa6pBL38QD29KCmSPUDWcDx2Wgy+5HU+vKsO7T3wb4m9EyQ3PnbXCT04"
    "kfw9a9eKvZgH4T0J5qu9wIuruUfL3z3gMWI9NSqPvMeFRL1YXqe9WqSJvYpGl70AN+c8ZpmAPXyDSb2y61m8Dps6vRLHKr3oIJg7"
    "uHfjPDfVu7uTlTQ9jIyBvQnMhzui2U29Q6HaPBTnAD1AHie5NNiJPByqej3retY9L9HjO4mVx7zlt7G9g5iJvEqXkzzFkKC75JGo"
    "vNs2AT2mBqY7QbTdPdTAHr00Egw9vf2sPFeYlTsIAhy91dBdvcZjjj1rLWw9EFOVPZYPMz3BNmK96uOSvXfgbLzQwQA+xebtPaQC"
    "9D0VUJ28t8zUPWwPKzxmO8W9ulQtPq1f0T2exZC9Zon/vPLD/D3+4tY9FEhNPe1IVDuahCi9HO81PRWs0b03q4Q9U/6TvYp1wrwP"
    "kxW8+YMGvcPP5Tysrfk9cyBIvqBk7r1DlDU9PgOKvJBy4Lt9y249OZAyvkxLdLze8Dg+PChCvqTLmDx3s1Q9HtFavda3xL2Aj9s5"
    "CK7zvSsRF76065M7T45iPlxcBL1E4w4+XDn6OzCrPLzHrTy+gz4OvV182r15hRA9sQRZvCd5Hb2o2SG9o0OZvVwMuD2YhSU9xAcc"
    "PpO2oT1Lcvi9NgdKvDZQ+D0xmvq9dL1LvkjzbD3GYMU7hvGnPPvoWD720JS9qArOPYyzT7o1nwk+vwdjPKa/Lr1I4iW9OeO1PbT8"
    "FL5Mdrc+1jaxvCWihj1O9I+9pIAoPXNjzzzItWs9NrvIvFfjpr1TU2y9juDjvPjvhDyDGRI9tFM+vanTar3Iwyk99hjCvfy+dL2K"
    "4t+7jmPQPLCo3ztiFaO9XDsKPsHnFL6bjyc9Vm0XvZY6oj3l17C9JPhTvVuAZL172OA9ls44vKzw2L1RnVC94qqBPQTmiTx/gOk9"
    "gn7bvXjMzbxiL5K7GkSHvb0ssT2yP6A9rKMMPTQZnT228gE9vImmPXYDorx0rgi9mZKmvcpRt7wcVbw8xdDnvIuPhz1APbQ9OnmQ"
    "vc8/jD1mFAe+jV8WviSfrL1wuIM9UJLFuswfcD2oQxa97iIxvqiUV70wV/q78JxAvThx2r3YGS49LOofPICwmjy6MrA9e6VlvaKV"
    "Vr6RsmI9gHPmPUCEur1gQx48RKoBPoob6L0FNYy9AE+JvWB3K7sK4jK8GhXaPcGe+Twlczk9d/uQPe9oED2dIuO8j3fTvYJL2rw4"
    "9MS9ShAePvsLvbzvMMk9m9/qPVcl/D2jCss91i6bPOveCb5eAJG7PM6+PaYCXr0BgnK8Wf8BPXLEUz0BokS9JqVUvOmfRz7cgB89"
    "C6qhPfvsaT7z+I69at22PXgYpTziYI29tj7uva6TWLzsu7a9TvkGPZRqRD1wIIi9Xwgevkwezz3f5g69/rSBPRymqbz6oP29Z4Uq"
    "vKfKXr0pRgu+SIyHPTztH73MmCY+hIjqvIdWiL2Nzoc9332lPZrNhD11QR28WD78PdJ1SbyAYW49n15bvbXTqjweJRq9f94lvXj2"
    "k726iYU7VNOnPeN/DT1qRgi+k7SAvTF3hDxXTSe9wl05veqp5zzfLNm9ZTyYvV2hBb63WM09HQ2WvWnU7r1M8O890UTmvR2TVT2F"
    "1co9w5/vvPX9sj34T0A9Acc8vZA24zxAENe5xq2uPSrdBD3qZOu9XfyXvayfxrxoCti8Jil1PQYLmj0k5HG9y0s2PREbuzwx8Jw9"
    "R5+LPeb3ob3y5Qa+DpvPPa8+Bj3Vdoa8UdrJPe9TNzx2shQ98PKvPI2TQz0QfNO9jHMIPTdPvr1JagY9aVGqPW72az2ssx29n4Ea"
    "PfJoCL1QJ8q8avwoPO3dRb2E0ye9PDyROsRP2z1C7309qrravSlpLz3oGeU8xtTDPR67vT1AEvc9RSC/vf7Idz2Syo47J0t/Pex4"
    "Hb2+8aI8VOCau2XpK773+4893tyRPYcTSL4Ad8a5PANtPAQacz0Q1xc+66zzPeyTb70w+Mw9chKQvUR0Gr3oYWq9HEj+PfhQRbwg"
    "6+a85aWGPoR0aT29V06+1DiAPRRnBb6xYj0+Ov9zvdz5XD6QIw++JYk6vvbl0r3eBZc9DzlHvmKn/jxDNoo8eXcLvr9G+ru2Eio+"
    "1PpavmJpqT3IXwO9L1NBPsK9Sz4AIDA+nYrTPVZewj2LAWc9OUFQPSALM702A/S7sq6LPSMft70Ts2I+4sVpvSHI6T13cKA87MJJ"
    "vgcz9T0IkHW+9gAaPSMll70L1Q6+IqHau0CqW7oXrzy8zxwJvqz2Sj0f4SS+0Vg7vT4y9z1vNoo9M4JnvfdCUT10Lhs+ld6AvR5K"
    "kb3ujN29Li7ZPCwaoT0x7IK9QMQUvIyqkLy7wUo9Dn7ZOyvKDz2ZL348dmaTvLai6Dxx6Cq9FqgoPfhOr7xoFZK8VxF2O9pa0Dv8"
    "66Y7lWdPvX4kDL1LPIy92Wa/vMo2Dr2SarQ9agOYvIF1rr3qhVK9+CKMO2HrSD2gUQo+eYNaPqi66zzd3Qm9ohFnPZYoiTv0dKW8"
    "NoImPkcd5zzrVpW9sKCDvOZ61r3qRE69ZftJPUyylb18Q9e8wAq3vdssFr0vwiq9FlTnvc/5Hb4GIhm9w2vCvXNXCL4SRqQ7FFsy"
    "vi2i2LyS9jM9iu1HvchN6TxC9kg+XCAjPVU5Az5yxDa+TessvYkoPL5clY29O1ACvYAXZ7x0pvy7ywEWPt9D2L0QPhG9gu9ovF/b"
    "ij2i57278t8wvVLhGzu9mBq97olwvcpO9b3wrfw7QW2tPd6ObT0nkoW5MJ9vvdfJKT3boLa9yY0HvjhGyj244SK+KDydOpKwajwr"
    "t7S8e7AYvb5nPj6N4rU7q1kbvhlL0b2Jx4c90F0Rvedv+z3EqJs91zYbvhXPAz6B3cO98+0ovXGIjz0MS/28yjoGvdr9f73WT8o8"
    "hB+cu7grDL42LLm928SBPXrbNb4Gijq+930VvPu7PT022ie9MLt1varPOb5Qhd87g2pxPfFcID2P/kg+8EyAvfHR1zxBNgC9mu0r"
    "veS1dL1LhRg9wupVvfTrer33vZ08+hQmvbrDibycfQk+WpAEPb20MD3x5Ba+QtuovHVSd704fKu9pyeCvUrKnzzPFQY8+exFPmzZ"
    "WL0Uuko8//gHPemYSb4rQbM8ijhuvBQNRD1UBaG6TWYpvQwiF75H4Qc+sQuFPd59kjzQ/jQ9cNN8PaxOujuuTrg9scw0vhtwGT2r"
    "Wk4+uQqnvTwef77EMs09tUIKvVRA8j2+uzq9LjlLvQDYnbd9MtQ9SqMhvXPN970IwA0+l9hEvdJVdb1KIIA9gIa2PPeksr12Dvc9"
    "ZQTyvYabB77x35+9lH1NPvwm2r3OWm884CuJPVDZbz2LFJe9blSvPIi5yDyw/869TPOfPSi0pTpobKe8i0jKvJgKBr4A0TO+Id2A"
    "vjI89DxCvmG92o0uvrcVUD5G6cK9lO/kPdSGxDrJucq9UdMzPTl60b1cS9a9c3yiPFvdtz0mbSm953EHPugIT7zAJG676gk7vfS1"
    "Nb1khhw+Ze7kvf/8nr3XBi09DKxZvvbcMD5cHFA+PC4GvPRCAb2FSb89hyoLviAwwjnYSzE++qxmPRUrEj3YaAo+ij8nvbWYvz0D"
    "n6Q9/KfSuzSgPL3Ai985KuLrPW2JKz5EPOm9L/IdPWF1a73qqd09HjyTPPQvrLxl4tS90RQbvb6aRT1lc9K98GXbu9jTertBzYk9"
    "0AhmvfwU1z2ygbm94PYZvUmYlTx28k68m2icvQpJnj3eFhK9f1sfvZrrlT1Oq9a86EKeO3y3+ztWnIk8S5gePTVUrL0+0Nc855yy"
    "PcreKD0gprG9z4HwPNFSlz3g7P69j7pEvDSC7DtPU3I9uYwDPm5bEb7ueE09mIYkPe1TJz1JHxi+UVeIux+Wyj2AlqA9POT9Oxjd"
    "Sr21dOw8/k4PPuh63bwli5I+3cEAPqydgL1jfI89ztSGvWFbtD2yCUA9zUSAvNdlXz2GpTo9qSOGvUY9gT3WFAo+Ln5cvdduVD3M"
    "kuw85LmTvc0Nmjz+shK9bdcEPCw7Az1jQ108iW0iPKlsXD075CY8b1q0PeHQQj0r1zi9IsMvvWNWJL6ool0+RmPPvZal9j1LJiE8"
    "7Q+yPEm6oD3pVdA8/pBxvOG12L34QTs9lwtmPSkR4735spk8XhHUvRdKgj3nCte9xOMaPIUbNb30aKI9H9K9vFidMD7sLEM+ILAs"
    "vXtypj24PP86iGrwPPgDFz1HYrE92e+3vYsrGz1450+9df4kPDIPAz7UJ7a95nY6Phn6hL190UK9qO4/PZXyibxs1Yo9xy0+vSKW"
    "NTxFDBe9UVOGvamTIj6+kAq+N6VUPSfNUjz4qBs9dI4GvntMpz38dG88hWwivuV0j77anGO9tOMVvDWNdryO0pu93xs1vSzslz0l"
    "xZK9logfvmt8Qr5/T6A9AFUZPieqnz2yphA+MfcdPk/rSb3kBp88dOzavBCykTywfwk8f03Nu7qpcb1ByXo+Ox4dvpAWkz11pVq9"
    "15TdPQ2jPj1N7za9INwvO+xLxz0ACLm9Tm4tvkWjsT3EHcG87EgqPcQ6xbySp1g9mj2+vNnMrDz56i4+d8sevlkTOL2CUI29v7j0"
    "PZxVUL4akIY8JryaPQ27Dz0ee3E8fB3wPbLfGz34qnA9ev+2PNRWKzxDOx2+wxYWPoWWXD2kf749etbCvV4GUD3nDIm9obN9PGbV"
    "tDySkoW9TnG2vTsHbLzJRqy9BDJUPsYNlDyZkye8+rQUPsdkBT5/zCE9mvMIPrb1BL0JyFY+RC2nO8hvdTxAQMa5q9kePuRKHD6c"
    "f5G9FsYGPiUsOjxsjDc+UNT+PMYEPz0a9K29bqZ2vCEy+73R3ps9PbIuPXVwHz2a2iw94Yi6PKZZYT0Aqmi80wzmPPYc1j3iXiK9"
    "fouyOzLbsz1sq5Q8bcXNvTyFpDxXzn+9p2jtvMiopbzEVyC9z3wHvTxugz16tjE94dq0PenCBz1HfdA89sYjPFTFpj3btAC92AiL"
    "PCoR1TysxoM8rMZjvQJ1gT10CQq961kjvkHRlzwFSqO8Lg3cPSkiUD0jTDI9utaVvsH1UT4Syzy9CFItvuaS8z2pNCc+CagsvZJD"
    "Dr3Dax09hlSrvV1jAL7Dju48mD+QvVRvET6MPLW9Qhu+vXqhnb1uRtg9AlodPXlqQj4umxM++BZ/PCTFM75H07S9HB0evSFi0LyU"
    "uNg9YFAyvVHV7rzyBHw98PGnPVjVVL2mjFc99p6AvZsKb72Bvow85g2gPEAF3TvdDGu7jpIFvVhq1LzUJpQ7MIUWvMTrd7r2fAq9"
    "Or/nO++xwr3tfHM9cD5LPHb2tj2i9Dc8fXsGvYublbwcZP88w1kivZzGb70LVjG7smPZPErUtr3cxBK9bfNgvjJfRbw1sI08iKPw"
    "PU3Vbj2HqLy8uSABvkATjD3ORUO+eaUUvgyuQDx9UBE9KMEOvYoRPr2kh9E9eqoDvky097tUp9o9edBXvcwOFD5Bd/i9flCUPG6j"
    "grzqe8W99TWzPNge/L0FUNC9tHeOPcsRtL03tyk9KL+3Pfck2DwzTtY86q/1PWcbiDx0YAg9Zp7sPcRlwr3nMEA9zymBPOlHkT3W"
    "llk9oZ/SvcvFGD3yrC89qvO2u3Tluz0vTJI84nwGvprbEz2a5xG+uur2PbCEsD3Rti8+NeedvVuOKT2dfh69DaZ7vcLzYj5Egbs8"
    "4uJKPIKpQz2YI9u8VVOfvZN+Dj3K6aE8Z2MrPe5s+ryPEEu+U1+PvXQQD72ibqe9aMMDvXpTur02Wb2987rfvcW9Ej68dBS+OFAx"
    "PbQpt7yBovO86p0su67MDLzy8ao8exZRvUy40L2CA5u9j7AvPtRRnz2petY9S1fOvf+T0T04fiG9UKTvPfILM70UEEG9DCe7PE1D"
    "CL06Hw+9NWVQvIzvrzuxpfY8TnQaPoIOKL5KNYW8BtNvPO6MM76ASIi9QrTLPTNw0z07fAK9AKSmPRkgmj0PoC+9gPlOOxoTnjyL"
    "d3a9Z+lhO+s5Er7WNBY+1ZJPPdr6jj0HCrM7BKgdPsLJCzyadA69fQ/rPZRhvjwmgcE7c7eHPJZhIz5cpJ29SdU0PS5TR75qiJq9"
    "mDrbPcKVuD2xNY29twgSPn71NL3Az4C8FCejvTIjl7wd4h2+1aQLPaVtlDzaSRI9e0tpPeXvAj61l5a9n9WVPTEUNT3fTuc8GQ3f"
    "PHiZ2LwPu169RDzevGz6Cz1Ttyu92XWSPJhuVTz98iu81cFAvJ6wb72cUcS9/cbFPYV1tL1k5sG9lnMGPT7EtrwEGZC96MB9vTIx"
    "Lj5c7Im+/tqWvOR5AjwlPty9jJ58vCyr6r02owi9UjYJvjoCFL4fODi9+KcxvrfE67wUfce7apOsvTRBBL2rylK9RG8UO62l+bzH"
    "yQy87wZuPdA/krvHfte9nMeuvKIowTuTQjm+t7TlPTR0D77ybIM9UmO3PTYntL0bdWq9ZG3mvIPAtL0gCRo6vmEKPudoCj06KN08"
    "+ZTrPLorCr100CY9CilgPe30jL1Gd8i9ctWVvRNIu7woLqY8QzakvDtddrywAg69eEAEvncgXz3A79+9kCILvKarjr3jQAq+fKCC"
    "PW5rKj6Em8i9LuCSPGKEQTxPZ6Q8qoEDvsrkb7043/S9NxmyvN7rx72iCsM87VfPPZ7bqT0/8Es94tRrvvW8zr2qSaY9rO5hPBld"
    "sL3y9xM8zrmQvSX5/L2mAmW90wfEPSt6KD2Ntg6+RdcQvhKmVz5nzly8PW0kvoDl7bzblKO9x0C6PQ4xRz5YVyq+bZMoPd8jAb4v"
    "/CO+LHCLPTYrfT3GQ+k9VCJ4vYdu4z2vAa09V6zEvVJbwz2mxu48UVEcPdwqQ75jkns9d3S6vOTu8TtE9pO9S0+lvY9Blj2fCIq9"
    "60quPda2Sr4zL6G9ogmPvuIEV74/eMq865fsPAQzUT39jlK9vVxTvDTon7xQB0A8xSEhvW4IQTzWiBC8aWzivL5/Jj0SMlc9YNBn"
    "OQPl+z2OoRE+xPp1Paak9Ls+Mbq9FM0fPXkO+TwnY0I8xznrvWLiWr3s2tk8lrwlvJqtjTwNDAi+x3QMvWJFbj2yag29d7mXPevj"
    "g73W5SU9H/jGPa/UGT2dLrY9JhMHPbhenL0mvHG9FY6+vZ7hFj6mbu49sWGOPfmWlL1twR+9XP8Cvtx+xD2TwdC902SmPZ1+sj2o"
    "iTq7ShmnPDeAsL04HC88nNz3vNZHqj1z5cG9Vd36O7nT7j22iI496XM3Ppow1TygMHo9RXf8PfCY3D24v0Q+2dchvg+/irzLn7U+"
    "RIQKvuTjoL3uRFE9d9uJvb2yiz2eA8o9Q7WjPXLYir5pdDk+NrbFPfuKC71gB80+ZeA4vhDD1b00w4U902xXvr5vsTyOXF893/gL"
    "vmutdb73V6i9lbIRPo/At71K/bS9PLgEvRzQSb7qHqq8dGcEvlXNj71w6lg9IEz9vHjGxL2/fFU9B6yuvVUSxD3E2L08zJMtPnln"
    "mT3Wwe48uZUBPrYM+jtFswo+rv6MvciXLr3wqKI9gtq5vTwGGT1ttsc9jFVGPDcxeD39IjO+YPkIvNTZjbwk6NS9Bg2QvUB47DzU"
    "S+G8rpwJPIm3S77EwsC9dztAPh4e+T2raZu90uM1Phyrib0U9VC7MekQvpHChz19oFq9D1zwPTUJ3z3JNYs9zKQePotiDj6eZIk9"
    "n4tBveax4Dwc8RQ9vkevvDSftL20uNy8EnbPvS5nlr3gXcC9Z5noPbZ2pzomTva9wuEdvNuD4L27UKm9hDA+vRv+BL4Ooai9pC+W"
    "PSSMzr1uyco9TvM1Ped2Eb00Meq9QsOBuzoUazyn0/o9a/nnvVjWI72g3TI8ruARProjET1XZ9e72WaYPVdJsj1eoCq9GmrAO5Ca"
    "Yz1fyOq96Da8vf5vYb3gT+a8UfaWvO4Nvbt/yjg9GmssPhWDFD2coFU9QW27vAOL+L3VIAO92VMlPtUVi72H7Og8jb+oPfkWdb22"
    "JOS9ZuqrPfZ9Tb31AGm9zJcSu9pCn73YhuS8D1VcPBTQ6ztex0e9ML5mPGg8q73Oe569k2HKPTr+ez3RJBI9muQzPB/lW71ToQg8"
    "wDaSvUAvbDyuCRS9Iu4kvDp0lb2G7Kw6rffcvaj/Cb4YXxs9MuCaPLGmMrwoRd69NBF+PPRHhj2pYv+8XbNDvC3kaT2tSxi9fhCy"
    "vIFFqT0XbxW9WUmSPMTLgrxEtBm9m/N2Pa5RkjuqHhc9h+0fPSs+fD3cyJW9iICRvWVbCL64Iwo+sRyUvcqQdD2imEm+7U4JvuXc"
    "bT0aXKm6jxBHvvIQBj5ID9q9zqu6vMu3Kb7ELIq9cAEjPnLmmb07dTU+fbB/vYtO4j1MG6W86GZMvtAlrz0VQQa9s+zHPSqi3Tuy"
    "4Ae9EHQKPjRPAr7gL5e9L5gIPjroIj51df68NzSkPPzEXLxOEW08vgkKPtc9Mb2wuMs8mqbVu9KCi7t22g89ErCYPRqYjDzQGso7"
    "M/m5PVzlGL5/lsC9TNvKPZcCWDzbEqg9lIq+PR7eYDwJX8E8xXiXPHsMtL3ZH3y9XtoCvNjGBj3/WYw8orWLPZAaILuL6qM98LUM"
    "PkmprDwo/AE+OWqzPaoUOD2PBDC9rnr6PINK9bwQFle9RhpxvWXlxL1Oyfe972EEPt2bD7r8CFo9UPNSPvV2wDweMBu+5UdZPNib"
    "Qr2bFxS9AsTGPUnNuT32uDe9RaHkPXhtzD1mI0a8ZRyIvNZ4A71yGsY9ZroGPTPMVL4HYhy+lT0wvSbgErxz34G9Zxw/PcCAoL0t"
    "UJO9puLEPTuJiL72RJw9IU5GvS2Gyr1rmvu7Hq0bPtesvr2+FTE+2oXkvfwH3r3iS7S9VkHqOz0cN704fdC6CjvhPMhkn7yOTqS+"
    "W8aUPUnYwLr9hDk+9NmKvh+dvL12ULa8iPh9PRybC74M0ZM8oLdEvS606D0C14w960+3PH5STb23cwq9T2mEveRnrD1NwGW9jBJg"
    "PYtJtD0z6EG9n3blvdFUob0nlv69oKdRPkh1zDz3Bia9kfp7PPEUqT1BEiG9q7++vA3mbT26Ht+9kv+aPeoou73+sOg9teTfvUpv"
    "oLyZLOq87LJ1vQzc3Dyys4E8ZYyiPJuotzxl6Cu96E3OvOWfoD2FCI88ax7/PB5CJ72fRzU9CmfHvRfaWjz0iIM9ZBhHPQFjxryW"
    "OTe8rNY7vH+qEb0gdS69QvDpPXTDhL0ub+i8eGfNPZWN7TzeN9W6aLKZvaGWyb3CB8O75kMzvRdbTD0q9ec8OhcEvLf4FD7CiIY+"
    "0FCvPUCzTL6wqF49slwxPgiVLL4Ce1C8pFMkPhZ6K74qM7M9bZSnvT4khD5QTQI9w4sIvedFdz24Yvq8XpiZvMwWuLwWdiK+lBoG"
    "PQe0oD0DuoY9qfiLPQ7lfbznoj+9NpJiPg3zy72kF6I+ZpoMveLzkT56kRo+pG86PRPl5byfx1C9AAfGvJQ0czt+5Tq99daXPRSY"
    "Br2V9z89aGosvCQL7Dsr19s9QtSWva59cT0o1P68P7mOvU32Tz2iiMu9QiIfPdC/LjzM+4w8kjSuvKvN6juPW5O9sKwhvePzoDzb"
    "8LI9d78OPaDvpjzo4Y29rFFnPP5Hm7wFw4A92zZUvIiIqj3Cudw99r0tvbz6yDsKl6+9sxSNvWAhN7oog309kcCDPSNzsT1uH8C8"
    "R/SivYiuA711Spw8FY2bPdiIdzxu7fs8bsyAPGc5Bj4Fahe9+vocPitQtj1Lp9k8+kGaO1I+HDwdJfm84qsoPq20Zr52WK87u3JW"
    "PU36p70NvwI+asa0vfRDGr4uCsM9L4w6PcJw6D2oqZ69rpfzvUNwQr6if9695a26vN5Hnb2P+rQ9pxsyPra9Pb7B+bu9imV9PeKq"
    "Vz4Zmae9EkkWPW1PPr455c09B3wdPkdnoL2muKA85IqGPa6ngD0ePC8+wqDkvWUN3j08ky6+iKInvpeSC71N6yE+GymwPquy372n"
    "VOy9Z33zPQnBCL7od4K+i/TWPcK+AL3r1Yc86cFhPSGCAr4bqpa8aOBWvINE3zs2Nl08N1wVPpEb8z0yTV28pF9NvvHFbDyxIuG9"
    "ZFIGPtZcqLuJDME9zEB/PMPZrz1B4jW92L9Avmvz+736YIe7ZhzbPQo/2b3w2js+VQvdPeSaiD2z4hE+BuxQPT4e87ytGoe9uql6"
    "PaaUFb5Qcf29ZPI5PRxJlbweJQW9VL04veMuLz04dJm79WGsvfHA+L3HObu8BM2avOvi0r2oE+a6LaEsvViPf73+FjQ+stOYvZMe"
    "170YnrY9U8vmvI/89j0xdu09luPAPfcQMT7UDtW88q7WvWeN+D2SyTg+ugJ1vQGaHr1tDoU97LcTvnGwSj3k6rA92hRqPDRWaL6u"
    "fSK9oDmkPRS2Qb3BnVg97dO2vQByDzw4LHi98q0dvmYmHzyiZhq+Cp4cvvgABj797YS9QvfcvCDooD03o8C8aCevPSa7uTyd9wM9"
    "dk2rPbzksL0LZb29mgSSvfR/MT0wQX28jGXnPcYmH76gM4+9e66QPd8Ror1QYh45kZ4fveC1xT2o77q7GqqXPQNZn73TZz29OV8G"
    "PKrwqr3VKiq8AKZpPJ6Bg7zgY029CMm2vW9y7burHBy9AG3wPZq3sz3GFZq9kEk8vTWnl73n1609S+M5Ptf2IL7e0R69NXTtvZPf"
    "FD5w7uE8FE63vbw3rj0WmAc+8BYbviaEcT2yT569wQKFPGreqb2RHvs9JH2LPStqwzuk2P68EicPvfgufj0bpAE+ZfwJvaJIVj4s"
    "R8k9JmwQvSUeC74QHK88mNlNPTQCojrk8WW8HVcevighlb68DZi9NSE3PbzJKr2fVAQ9Q7QMPKbw1DwDFGc9LAkCvWANJb5yS3w+"
    "L9MjvbwFrryOe1Y9XvrTvRtYer3wFb88GZCWvfPrmz3uy7S9ZHmSPevEP71GD0A7qKb7vTtTCb4v+mC++dA2varuvb3LwLm94Kq2"
    "uP7BcL1RbVY8wO+9u1r4xDyfM9a8jWOOPSgOP7wC16A80ENZvHcv/Lz9n8u8eTYaPbLaaD01IQW++4uXPTYE8zwzNoY95GESPT4F"
    "5zuMOJG9gPX7PFnVy7yXMei8PGjcPcVCA70XKqU9xceHvDN1QDxVAf08sHm9PbblwrxyTrs8uKDkPT0Qiz2ksNk9l+bavaa2R72b"
    "Gxi9p7G1vRKmFj4e3wm+TZb5PaaTVj0AchQ92SKFPhzidL0NlR0+jeKavd5mOT3uO0k7OUgwvibKrbxktMM8oHpXvmY+0Ltyg6Y9"
    "vRfcvY2IEz7FYyo+268Evi5JIb2Fwf292sCIPVnoiT1TnTo9+pZqvXaK+zzc8aY9WVUBvhyTTr2SSGk9lJHnPXbitT3yLf68x4+g"
    "vWVHlz7fgBO+3gqvPaC6sb2J6z28RzfUPESSBz5vQe09dMbkPAHzbD0Yp/i8gM85vmVlA76MULo8kt7AvUnKq73alku9Z3G9vVRj"
    "jbqs2wY+Asr5PbZF7T2zHZS9mCb9PY9Kdj68jgQ+bCW4Pb5zvDzhZ0o+t1nOPd9qqT1LP+y9YOP+PGNeUD4Ihwu7+iWmPaQz4D1c"
    "nqY8EhNwviYiRr3gIIs92EU7PqB0kj0YhlS7CsXHvdG+iz2I6dO9pCebPcNi5r2Yfyc9fKqcPbjBtzz4Ay++G3w0vA16Ar7GR+49"
    "UcO1Pimj7j3MysA78BBOvTfBkT2cd/M9TlbZvV4y2bwSDca8qTUtPDGN9T3klVQ9ts3OvXpLh71Ilhc9QHnOPDimiz3irEE9RjEW"
    "PYFGBD7giq6+ycGDPvGmWL3yKE8797HTPdvLcL1INkK9+lAQvnkIOL0GFAW9CuzFveR3+r2+kyq+eVExvS5iH7wABjk5yzbFPZK/"
    "Ub3s3YO91z8BvjVCzL1wt/e6yz4DvFKaj72WRlG89+z4vLBDdT1MFMA9CnNPPCTAqD0iFA29jOoivhww373liC09ym7SvaXhXD38"
    "SnC9JHPHvYYT5DzvRMC8DFEFPcCmAb36N+y8zzfLvBBGAT7hpf+9BICHvVghTLwg/9a8Das5Pf4rSzxLg6M9DU5QvfDegLs115C7"
    "EBl6Oyb4sLwwRYs7Vv15vEvq2T0UI787CGMLPcPzG731WRw9xrVcvCZcRD2wzrE72udMPYD7GD2jJkK9vKlsPYFZG70PWle9TEdg"
    "vrvChD2Joe6914oEPa03jj7r6Hk9F1+hPfGojDzWmcU94M86vqg/dD0Efsk9TVWDvrWMzr3MKuo86JDCui3jvz2q1Ly9iwjYvcfg"
    "uD2Ukye+bPvEvYuBab68ytM9t81gPp4uTL4LZxy+/3McPqxThT6+SCo9NwQZPWT4GboMknS8vUeZPei/m71eDRO9836MvR7bnTx+"
    "Efy8JB8hPYNhP7xWvwo9c9S5PV5r5bwgc7s5TzOaPTimJj14NrU8DmlOvUhhg7yl9vE9Wkpuvc10rzx0E8i8kgxePXzYkz12DjC8"
    "mMg4vaYEdj2+lpe9lig3PSJImjz45l08GJ7gvocOAD3MQ/e8/Tl4PXEzfT6X8Qm+Sm4hPUtkSD5I03M82KLuPH8r2D38lNG9yp7G"
    "vSHKi77bHeY9zSWgO1CoPz126xI90kYTPjHaEz5LUs897EZKvd6FSLyteM+7WoJ/PRmluz33U6A9nxGXPNJ5L75N8QG9zSP4vdGD"
    "FrwxENG9H5k7Pdr4JT0LJY694teNPRTOgT1G8TS8wE8dPWY+zj2wMCW9AqDPvX+pIr5fsAu9RN9BvVT62r1J5tC9mtcHvHymtb39"
    "zQs8VawtPYfSFb2LYJi8jphtvvgBRr7MKYM724wqPi/oP73XFIm8RokVPnJ6Ur1cWus9n0wBvT72pb1HzoK8usyKu7I0Db1DHXC9"
    "ruL0PcWOpLyQxkU9jh/TvRJnAL3OTyi9xtrEvSNJBDxoHki96AkWvjxGnL0aZ1q+3A3kvbd/vT3ggHG8DvF7verNR769ELW9zeY3"
    "vgFePj1pXPq9XM+OPev+2DwAqTA9wAeKvbzMyjt7R0692mFLPaIhab2aVRO+KLAEvsY62TugDxc+GnNcPTnN0z1yAO08/YEkPrbF"
    "qL3ep+69pBNPvlBRKr2wZPy9mrLpPbj4mzrQJO+8HTOUva4JFz1uuwK+Fip5PSTjWrvOJTy+kBrwvTtRnD2EJL+9l4kevujDujuy"
    "DKs9jG4tPjmwmb2PN/W8JFTyvDKuG70Z69I8ZUcfPI3AwLyKHiU9SwUtPBRdMr2w31Y9UegJvSMzYDzol7C83fJcvQJj5D3X5q09"
    "gGvkvM2Yojze/sk8QtpcvfKeEL0SHtM9BbYYvYa3WL1ceN08MH2qvQV89zyTF5c98YyAvdVwOjw1UZ+8cawpPZWtOryVAzA89tbS"
    "PDBNjLzZbeM8Waakvdfim73Lzle9tG51PS2AgT1+82Q8uE/VPcsszD2GDhM8S3skPkhT9zxYuj8+I9OKPDitdr3qEME8rUDdPVzx"
    "VL0YeSy9M6nBPcuYBD4abSE9yb2yvX6bV708u2a+csffPJ6bBL6wtLs9p8ofvf4z070UgRQ+AN21PUMXAL68iG88T2N2vnZptjuD"
    "1Ui9Z+krvSf9Rj3pVKk9v5FOvHc9br52/xy652gaPrlf5j30IBY+y0fJPCVq8rwVsyA+qWIBvt01OT3z3rw90IU3vT1gjD2IR1k9"
    "iFeLvXuuHD5/mQm+VYlPvR7Cyz3Fl3g9M/UwPovR6DqHmA4+2lXQPX00Hz3veFy8ka5uPcDLL77uckO9RBqvvS2tfD132+i7zq2w"
    "vf6meD3B6dE85e26va70Wj0u2hc9yTXhvYsHA74NvSG+CCRrPLNdbL1w2Aa+lYGAPVULpb0YVEA9J+LSPZTeiz1rjxY9ub4MO/Jt"
    "mj2BgOM9Sv4kPmFy4T2GOjY8oTtxvQo3aT2WpP48TVWlvTUncj0cccs8kJDZva06sr2M4sk9m7fVPUo/DL4il7k+R6LhvbElLL7S"
    "3ik+S2P1PK+Lgz1/Xoo+RrccvMgDoTy5zxU8Q7IAvggIFzzYyny8WV2LvZYO2Tww7Ju9Nhv2vcCLJL2GB9I9/D6kuxyKP77kJl29"
    "Vq4Zvp9TPb3rJyG9R0LBPX4hwT1gZA69F85XvJzaNr5hBpk9RsrZPSDWBz6sB6c8YNuCuoyZrr1MCY49nOBfvHXHwzy0TAE8HwtH"
    "Pd1izT2Sv0K9iWKCvZeKfL2QKtG9vgrXvW0s07tI3wC98TVNvdhIuzub2BI+Kd3pPFC0lj2OMlK7MzMWvY++jb2MQnu7CjGsuwVY"
    "yDxz8bk9eFmQPSFECb3iXrs8ja+cvVD9kL11XFQ9lFhku6oeEL0SKjq99WAOPXNkmT0ZZ1A9JNZfvArrIb3GWWK8QBeiOaOsoj3c"
    "i4U9avmnPKM9cD10wBk8jeIEPgT4KT5Y6IE9kyqaPD4P175dfJ89/eOnPHzGEzzP5yo+zR2ZPswoWj5465M9tKBHvZrhzj0IoEe9"
    "Je7wPZKlJj6H37k9/g6zPcQTrDzep9y73Z12PlB4V735d0o+Iv/PvQ29Y756ZDU+WPgXvNQjgb5FNFg+eKRwPDafFLzY+q+99myD"
    "vIxRjD7hJJc9xt4GPim1Cz2qbL49fHgmPOSJhLxRWZK9gBPZPUaW1j0Ai5e903zrvTZJor3utjK+HNMSvkGT8TwJWZA9l7QdPtAe"
    "l71+HLo8JIwovdrt1Dt+T6i9yWgrPqf6hL3EbFw9+Da9vWpX3L0/+049ZfCDvvEY1b3+mjK+aBPxvTL8I70Md/K9WzyxPQfl8L3w"
    "eaW9xtPEvSBiprszZke9nO7GvU1pKr2Z5VG+om5fvJ+ZqLwS6fA8hWwaPrgdxL0jRgm9Z1kWvII1iD3WD0Q9cq7rvVeQG77Jyus7"
    "cYdAvbBSSz3vFaA9WWjxO3duRD6EiOg8CYGnvbjV2r1YLTM96UPkPUTPgzyc0YC9yRRBPiA/Pb7CmzG9rtCZPP0mNz2OtzA+z0el"
    "vfqIiDyMAHg9KAJyPGtJKb59POy8Ya7APRLL0z0cEwI9Fv+4PbRbR71Kt4C90H7ZObo3Rz5Wjru9HEysvYSjkT3ZNN68jG6UvTqd"
    "a75hV/W9qKdIvc3h1jyQ36E9ECiPvfY6xL1tYrU9ktlvvVTkobqma589PIRMvv1SBr38DI+8yoMrPm7Fvr3Fhx88Zq+UvIsJLj1+"
    "4Pw9cq8LPTSmgD1MRbU9rH8kvvyq6T1XsLm9/ZGTPeELzr20Oe+98l3ivaiXgb0DnQ08c8tSPp9w1Tzhe469r/Y4vS/UI71tF2q9"
    "9xTCvB5RIL4SbcO9GJdMPFwWJbw4giG+tRyCPmPoQL1Uuri9fP5/PXbmJL6HH4++trArPbo3lzuSBbA9yY7mvdanDj1wtuw83hGY"
    "vP6kYr0j2Jo9BDfLvWS+t7p4ooW9sHskvT70x7zEOCU9opY3vVSpGzxGuvq6XisdPOfSibwdfxW9IvTivZ4XHL7R56q9BrWkPNHC"
    "yT3OAwK9x6/HPXE3OL4bfr08H+jZPQ+eAD7kuAQ9yEWiPYTYEL3x9RM9z8EPPq8A1D2ihle8vPGYvMCXST3A9em7STLNPaq+/j0d"
    "c4E9iSERvlDPDj7flKY7TrKaPntsjD3VOrA7OMyFPbewg7zO3GC8ghL4PQVi3L1KEcE8IS6JPA/HnbveyDs95LV7vdCFgD2An/A9"
    "gi86Pt1kv718qaW9q1yovej/N74rMqq8mwznPZ1Y/D2NT6E96taPvZJecT2hJxM+BGydPUKSAz021nW+laHavWgi8D0YbE28+ptd"
    "vSmsLD2TKeo9JA9EvVGVPjxgATE8hadlvgnqp73cu569uFXuPOBozr0BZa09GVA1PcnJAj3o2cS8SVkIPbZpHz1s7MW9qNG3vTME"
    "Vr5uixC9DioXPgbqqjumTxG+CTA5PY7jG72PVCU8iSbLvQ=="
)

_CONJ_B64_ENC_B3 = (
    "hAQePECqUblUONY9zh10PE+ghL344aI7XqutveF11D0Iqsc8p/9/vVBzDD1834I7v+zevbHzdT0vcbc889CEvJNSczzHbDa80EbC"
    "PLSO6bw6xKm8wc+vPDBksbyYyCM8JMpmvNpzOj20tlM9iLncOmSFGLtO+Bi9JFYXPXj7vTw="
)

_CONJ_B64_DEC_W1 = (
    "MaQCPrlDCb/NnwK/yvbePRjKdL6OGWY9SP5MP13/3j0mq1Y9OLlRvvFyBz6j8Qg+hKXUvGRVo7uLO+w+rHDdPRSm377TPzu+kV5O"
    "PvxowT2Ucbq9FoPaPWTRpj44vvq8z5QIPlv2w73Edje+ZtGWPceQkz6xLna97Z4XPdfgF70O9mG+vPn1vtS7dT6yEcq9xGgqvmON"
    "qD2DItU+XisAvlN5TL37CI2+oFqqPBSOFz1rGoa9CnSuPXZQoL7DyWw+oEDtvQvwKL2NyjM9yDcJPRM9U71hw3o+9hkPvA4Z8L5D"
    "gbq9Y2f0PcaIjL5FQMq9mAKWPawjHr7NQfA9tKzpPtpa1bzVKjS+b+iOvnO6tL2nMhw+RW8RvjyKSLxFRlO+8OmuvhfTkj6+3Go9"
    "i932vfCHfD2mASa+fCACPn4lhT3YWWO+S3CEPjU63j5XAm2+ibQlPqmlj72pTi0/XqzGPpf8RL4Ioes9Vu1SPi3upj0CFlQ9Oo2b"
    "vk4VCz76HHG92M/iPei2AD6Z1Y09/+uNvdD6yT2I0+49HaqIvqg4vTvESCc84EAJPHrsPL0stIS9NIaLvQWRkLwFNRY/UsGDvZmt"
    "Ar6CtDY9cMRRPpmuG75LQ9E+4BIMvrmzhT7TTKY94ivNPt7vHz0YQFO+4gKZvkgWUD6/lTG9ed9DvrK2bDs96Tk9c0XcPE3VlTxa"
    "6is9vLdSvsNwyTzyXtk9vJpxPLGiDD6uHzW+OWQWPhIrIz1Sijo+7UmCvu9w9T2YXRu+OtWiPUVfVT5keqM+R9i6PXhLyD0tIrc9"
    "BtdZPnO4Cj5LG2A9osxBPqN2r7xkfGE+798XPqqIUL6yxvY9EbsnPpgPeT5LRpK8DvkkPiUSiD1UaAo+lEV/Pebwsj1QjB4+tBmH"
    "vEWwPT6KZDe+CaaCvgpTwz3duyu+0ZEWPn3jxj0pglq8EFsuvXNXRD0qK0G93TfZPf6sh77Uqv89MB4rPhpZO73Ubzi+6DFSve6O"
    "ljwfwgo+M58rvkorjj6EEh0+FnfFPcWGiT6ODQq+XnBxvajRojoAlQs+Au48Pg9bMT5fvcc9hicbPnk2az00Y809nbL/PXBHVr3o"
    "9WS+ZVZdPeKeYT7IcSc+CD5PO5MtQj3tQ8e8mUP+vJciAj6AeI89cMBEvYRlkj1MoGM+uFoGvjSULT6LPlg+e/oRPuJ3mz2dVgw9"
    "ljwcPi72Oj5rf4E+Z0pvPqYNRDyFtBQ+SDZPvtj1UT7oxC8+dS8EPGdUij4FT4Q+G8WLPSftbD5ptyI9Coa0vTfPRz7FuHW7HokY"
    "vv7Ie77+wKU851UFPXQIRT4V5w09S6wEPoIykj7Gfvk9l0lcPv/kED5LJEa+dOUGPmkCzz2wfjY+kWZIvl7PMju7Q6y+8Oobvs5/"
    "5Dzoobi9vMWwPVeCNr6tWYa9lvc3vZnsU70CZf09z+ezPRl/5r3BiNK9ExH3PXMhYD79P1+8ijMWvRK9Qj5mAIc9ozsUvhCj5D3M"
    "l568BuqXPZDXJb3paxo+t3oiPsrReT3yBE09sMU9vTJvRr72TRI9nWe5PShQ97wbFZo94tUWvkz9dD1rBNy9DMZiPjaTAr59s8s8"
    "ngVIPVPMET1rSye+4JPqPfh8Kz7rfJQ9MmN1vRY/BT1Pl0K+Vgh8vZOIw70FdiQ9ei0NvrPiV76DKG0+GGmKPE82Zr3oEG87akWP"
    "PiIFAT6oFfm9/93hPXqUej3m44s9lYyhPMQc272GpAy+HNLWPXGx8T3KV4s+Q5SXPXY3471GGqK9/vPlPalIoL1oGXq8q6gcPa4t"
    "Aj7xnOS9M2PtPcSBcj6j2KS9YqlfPZTIgj6a9em67hPFvTqqAD1U7pK+aIyCviUulr3u/ZC9GFMrPYgcGL6y4vO9zhO4vH76Q7zg"
    "t4e9ijWDvR5kTL0msRO+QEtvPv88ab32eCu+Eo0lvrpWkj3MxBM+KcqnPRo/FT6ToSS+XXtzPSArvL6Rwus9Za3JPfQB0r2rJEs+"
    "/scZPgUzkTuRjb484RsRvRmACr1HLAu+Dn0pPrZ9S77Vnuu9CEB+PmcNkr6I+eq+luSWvbIWcT6MJbK+ZYiPPrgebbzhKpo9rZfV"
    "PWYzdr4HxH6+FujrvF4l6j1sDze+MOkfvv70zT6aVjg9gp9KPsmrXD4mxgS+gnwxPq7F7T3EzsA9l87AvTjXgT5wcZm+iHLwvcAk"
    "Wj7B9zs+NmOPvIaEfD0WgtW91AkHvvhTGD3Wyom9uHgVviHrvT5RmZo+tmcMPsv/PD78eJS96ELSPXs9Gb3sfyY+0JrUvXQNXD6A"
    "uPg9i1JIPt5PmL7VEgm9JakjvkKMpr6FK0e+70yPPcMpjj4eX7E8cCmTviTtGr0Lpbw9wvs8PghAL74Myqm9sWjFPk7eHzwz7tw9"
    "wh/8vZql3L3dI9s92w9KPsxrDD5cnHK8qyRmPsQpI76Q9yY9tMIjvSxaQb5la7Y8pn23vuhljj6u5OI8yBKIPIZ6Nr7WhgG+sOMe"
    "ux5r+b3dJpI9UZtsvSXwCb5rkzK+q/QHPF+NbT1crc89G7KbvVaViz1bkTO+sayWvmuWrz5NrjA+/NyFPspdxL0yPTe9LU6kPPb5"
    "sb3F/OY9WzcQvfbosr0soiw80DZDPhoNGz50mpa+3NYJvRRBnr5hC4+8ByHMPZ/QEj01dXa+em7/vFlVGz1g0wu91wkDPt8I1T3+"
    "DyS+n0t9PhOApL1fw5m+bwjqPugO2T6CLe+9GtVdvdBguz5In5C9gASzOg0iIL0Y1xi+Nbf9vGfBzzxMopo+R+irvckXY77VF9w9"
    "MzDBvuAL2TxFfzq+MazUPtzrqD3aI/C9jDAPPqBEkbqoyWC+hbAavnL2gD5I9bC+8loWPZYdjD2MhpU+qL0+vtQDAD5mugQ+GjBp"
    "PfbUHT6NpYg+Rrc0vol9CL7874U+MSd4PDx7Cj6wCpU8BDlZPg70mzxW7SQ+sm4CvvR0WD4kZbW9DJFvvl52mb60BbS9jRbJvtpx"
    "ur06VTO+fsYPPrYnlD0Ilde+jYwDP8Dwfb0i8ZS+Cfi1PrhMs73g3e88KzaRPqydrb4PsIu+RjHovhoFVz5sRFE7kDvPPTKJnL7Q"
    "bQu+oJrVO4abAD+zuOY+2lUFvbO5wb22mee98J3jvDOnuD2CRMq8bC2QPhVF6j1Fjkw9xpGPvcrhez2GPpy+wPliunj3Tj4mJE++"
    "8x4QPrZunb66wSK+H/hmvvPH2D36c1I+5FkfvMI2Xj2Sfrm9Ku/RvsgugT1f9xo+HP76vfTVIT5abTs95trMvDyOc77ar3Y9Oi+b"
    "PuDxZT7z5fE+/gRTvr4MRr5noh0+FOUBvcze9L0mHSM+AluvvkZzHb7pdJc9ktcnPWS5nL5APyu9JRUFvsotgj3rChw+VDCMvrsp"
    "vL7Hfss+sIWBux6hD746LsE++XBaPgpSND6RWQq+rIrQPX7tCj3rDcE9NaJivdqZCr085Go+NhrdvHd7mj3PjBC+2djIPXiRJD52"
    "2pW93CRHPfdFwb2yiSo+VbW/vQAaWT3w+Q09+rqkPZDGTjwo85O9FHloO5QbJT0hieW8LbFTvtckFT7GA4Q9BDiWPvbRnj70wyS8"
    "TrZPvcONsj3gRyS906kRPs8aGj670z++Ejd5PohN9D0LJ1A9BwWqvdxqrT0U2nc9sRSfPeM77b1/ax69Uwp/PjhKCb4a7wo+6hiv"
    "PLv+DT1ttyk9kJTVvMaR+byCAF29FIr/PdyEcj0yvw0+xl4YPicfzj2t0qu+kmozPa/lNr7dFRo9koGbPdz7Fr25ST0+P4yyPbcJ"
    "Jr4WiRI9mHvaPUODAj3s8+8989DqPSiFgryL7xc+ZdppPe36KT5yg6A+ZcFuvSvGcr5UQPg8/WZDvf8lkr7iU3g+qSWFvg4l7byq"
    "HUy9Q3iAvXfeiD17sQA93R4CPp/pt7wI5PY9Vr+3PqDswj05jjW+VsZAPaLMFT2wpwA8nosDPpCXUz4pRIE+l5yDPm4PxDzHnXm9"
    "JEQzPd+poz4qJCY+e2m5ve5wLD5ySos+xGdevh2mST5C2cS97flcvssVdDw4Sby9h+QmPvN5yr0s6xy+uchQvuNosz36eYM9sNfG"
    "vfekILyVeiE+mIixvhJQdD6n3Du+Q6gCvfmyi76RA3Y+nJhDPvkcbL4DcWg9gqJavSQSpL2oBcK7U8O4PcgGxD1aViM+8DmwPcxt"
    "Pb4pFBK+LsdXvuiTzr0EXpq9WCWcvTqjj715JQC+3nbLvRZ7F7xpSyA+ts1XvV0bl76COHS9fluMPemBjL5lCz6+Y0KCvTa2+D0r"
    "ma28OHskvFllx73kAV49+NJ/vOYdmr70GNI9utIBv6o/jjyT3TA9AKnIPbSzkL4VWai8AOLEvNt7jrtyvsO9/N7LvgZglz4JQWQ9"
    "z2Udvo4aFL5ISUe7xelTvti7Qj3OJUS+MU8EPNsO571viKK+lj4rvlJpXj6a2Mq8OgyoPT/biD3C1Um+nLAFvkNz377FmmO+7xj7"
    "PY3pib3zUii+sdE8vpHIar69Vcs8aq6hvbAeCb1VvmC+cEk9vlymgD1EiWS94SvPvYrQLL4R65u8snErvhS2rr1IIBs+KCfWvZjb"
    "Xz2+RoS+zoM0vvyilDxCyzI+KZ0+vHu5Tj0wn8u+gAdivuqdJj6eDTS9YlPovODiTb2IslQ90CPpvfoOCb2TQpc99eqGvkzjCb7O"
    "0wQ+rrldPsvuGb76Xb2+5TPePYUsjb5VxLe96VUpPe0IMb6cFlG9DqlcvvkoMj0QJUS+kMdKO7HRHD7rIqO9aBUsPmqMPj55Ty08"
    "6+4jvt4HSb1dO7y8kFQVvTfwh779PMG+Vh0EPSu0gzyx7Vc91dGIPS/MHb7YMCI+l5AvPoAAWT5FfC0+ntv4vYqYHL2kqaG+NI4a"
    "PIWjhT58sGU+8IqKvodkyLy5m/68UD08PQFj1Lu35sY98uvKPaZvoj08NwI9E1CNvkHlmL7DdAi+ICNUPfwKE77KttG9ZViyPda2"
    "NT6gWGg7sOirvV+tu74IXJC9HDpNvaOoAr1PJ+y9uH2YPgGnK772szW+aLUwPTCwSry3Ds89Pn0uPrB8wrsHE2q+pspuu5yoyr04"
    "N5K8YVmBvnR9ED7Zxma9nHrOvavMrr48Ix48ulWNPL78XL0GbYK+Cmf5O9l+dD3Cnx4+c7f/vTEjR75eZQa++pcHPgqaVb75XZg9"
    "w7/OPXqAp73joXa++FhWPt+dhL6+r02+tV1QvlzkED0ZZ3S+PHI9vcdTLr18VBk+H6cyviA3ebxvwPm7pGh/PgKft73mFse9nFxW"
    "viUbNj4l4r+9r8WMvXInlT3rWwi+63aEvgBRwD0alyE+E9iAPpHkLz4g4kM+/MxPvinT4D4OsK48sM8eOymrMb3yHDA+zJ16vTBh"
    "G712Vhi+rJ6HvjUz5D2id1U9/tgDvvHnNb74uou+ju6PPRxqoj69vxG+bQ/1vW0plr7Xquu9B9p2PoS/Ab4VcrY90hpxPScWED5t"
    "Spa990KfvT0Eoj5nLQW+nTlmPsZZz70xwhg+vKNAPrtR6D3jcve9oesVPh81xL7ySxy+KaRePYLRiD0EIMs92/RMvmhlJr6hQOy9"
    "uT+APaZI0b27D16+5r+mvtpv/jz39qe+YFFTPhMGMT5VoNg8YMMMvfEwIj3NOvK9FMoyPYUz8b3LK969FO7nPYCkH75HkhU+1Gxv"
    "Pltmh74QSMw877GBvdjedT0+hcY9TPA/PBigdr1Rp7e8Dt9yPolUcL7gBXi++ePJvcv3WzznKe+7Z/QEvrIDaj0U7jY+4c5BvrPF"
    "ob7EQ8Q9mH6wPZV+ST7zcYk9zHAMvgij7Lu0CFu+Eg8bvmPapb4ErZq9XIAfPQvq1byk4NA8ad4DvC/Viz6JxtW95VNfvhr7ZL5Q"
    "xLY9FbQkvmVlpT0eSJ++Z2JGPqKmjDznuz6+Nw85vvaifr5WQG+92qO3vZxZST0URR2+KP1WPd682b1CXpK9tLJKvQyaHb7aF768"
    "Ic0mvp3fNb35Zd29Pu9zvmY8KjwGSYq+zpC4PfK4hj4DcBe+vhqGO6o2PL5+kxc84L9BvssRkL4UuyC+U4/SPe1OFb0H9qI+bx3/"
    "vciwLb30eSe+owQqvZWyBD479lS+T31evd9rRT4n7HG+7dydPgLeqL5Y9Fa+LAxvPjAI0b2sdAk9tOdyvPKu0bxdnJK9Wkq1viwD"
    "nj6mwMO9d/yWvvAVJL2agpY9hHWqvSjFKT47Csy9VFYjPmi//LyWyuw+4Narveqd7r2spVy9HYtDvnKAAr7JM6A9uWOivaNvnT0m"
    "9yO+iOJEPv6pRb1ru3K+o4dPvZCjZD12sh69n0yQvbLepT70epk9pIwdvth6ID46YRk+m+RqPZSAS7whCrC9+VMevgTq97yq/LE9"
    "+G93vFp1LT3o8Cs92r5QPRPwbrwGUxk+Bm4AvL0x8b0Ch/E9wAUVvPycIr2e+5w+aM0wvgRvnr6D8fi920QOPg4Goz6DL/g8TIQW"
    "PlJ1ED4gA3I9jEsYPTlvbT79g+e8ZvEBPSjRSb6Rawu8EHhSuz68Rj7pHpu9zJPOvQKNBj607ja+YWMBvfwlwr0bFwG+UGoDvS/N"
    "R7yLwzc+Ex3xvWS5fr3c8mY++F4Svl6AG76UcRg+sDDJvYrFsj7GDhu+7TwsPv5QB77GLXY92oksPtBIJD1byzM+gc40PlRnxj0V"
    "rzU+2vgOPXfnOj65Boc9E1pTPteIt71xVYu94QuzPak66b0X9hY+xtQ6vrWqgz1EaRQ93ZSdPuwzYj4AZKI7go+rPSJXEb2We3O9"
    "eb1OPXxuLD52W6Q7stGNPpvgN77R3JS+ijsiPIMohr5oMqQ7FJqnvVtLGz1TlnE+3J0mPb6vLb6RWZm+6CvSPZYesD2yZre9Y4aD"
    "PQiSzL0++DK+PVqPvuDOoL2wsRY+H8f2PWZCEL26Hse8nMHzvAGnJr1IfxQ+QItkPcPVerszfAK+KDuCPbGVqD18S0K9m5ssPZUH"
    "SD60yZ8936z2vQBONr0g8nE8EEgxvuCNNrya3wK9xGAnPs6wab1OFwi+O8S4vfL+8z0E6A2++B0jPYiSlLxADYQ+sJtaPt+dcb5z"
    "Uiw9FlsFvh0XpD1MhAo+LnOfvqIYAT6Tsc+9Fy6CPAIZhL1CcKa9JMIzPvNqSj5QgBi9dPwivrWSnb7mtZi+vF4SvD4ytj15QR2+"
    "RLCQvHy4Lb7FRTQ+0fBRvokZPb5MMhK+OApVvhB2ZjzC+Ro+FMeqvczlUz4Ibo682RGRPgef9LyOEKo+7vEBvoznnL3721+8RKid"
    "PUntBj2yYr69qkp4vlo7CL5LGho+Dba4vdnlNb3PrwQ+k6xtvv88V71VzRm9gl/HPfcSMr4CH3G9h8wbvR60vT36BFG+o2Wyvcj9"
    "Fbybp789lkcovUbYBj+GhkC+W90LvtflAL52SOo8uKUrPvCADL02xSw+QGJpvpQbVj1GaHO9JOstvpAho7wuhOi+MrNfvdhYuj2Y"
    "3D290CCOPfZIuT1J9wI+5sfovrXEAb67P4c98ADavX5P0T2WBb49rWifPXSxSr44foO8Sy3JvOtBU760pXK+/AqLvNjRi73ACCu+"
    "qNvsvtJXnbu1hUA+ABafvf7ntz0rKwq9+PCmvu+AuL2dFQK+msu1vABFObyXI1W+Ilg5vO/Jvr1W/pw8mSCcvFj42b7g5QU9ukIs"
    "PdipND2QdQS+cUK3PRjUJb7v2Hm+XWVUviIV2rwsa6M+zZynvTu1Xj0iGAc9TXykvs96270A6kq3FuvjPed7w74cex68OLXUPVxy"
    "LT0FcfS9+zgrvr6ISj3x3E6+HUXnvUusAr4OsRm+vOWPvRvt77zVAYy+7NyBPT7gjL0kWdi57JRsvkcLnb1o5ow9Scm2vRIXa72p"
    "oEy9mMLXvafulb60y6m+oSSVPnlwAL65hPK86U4AvqC1Cb66Zgq+1suKPetFCL4nuru9d5K1Pfk3iT4rQAG+t1YvvQFeub3YK9o8"
    "rlj5vV+tvb0K6XO+g6gnPIRl9r0d2z69qp+fvUwLZ77mbYK9LS6YPACg4b3NvEW9gdaFvV5JKb4cBoa+CCY0vYbryL0kHzE+Ewab"
    "vbEJhD29pIg8zXw1vvr6VL1y5ds9MUCHvVzNWb2+iiE+yyXFvrUJdr7onV0+qes2uyN7kz3ORku+lbNvvn7EMz4O+VO+hdpKvkot"
    "dj6/GCC9oFdlvcxEFr5leOw8XUpQvhrCEr1EU2G9SE1nPoFSlz2F/6u+kyWxPpw66r3P9a49n/tVPhnGnj6Jnc4+0PYcvjySy7uI"
    "5Jy9wIYdviMedT5ZfDU+vtVNvjhP+D19zpc+iW4Ovr2K3r3Dh0A+R42sPpMSjr5IDHE8+TeOPqvNUb3llRK9MmScu5J/r7147Zc+"
    "DKdzvb/wP73xVss+7IuTvE+ng74uJOu8/qfMvn7eIr6XBp0+bv7TPZapAL4g0g8+zASHvsu2Rj7BI0m+TGHkvn6WJz4E2xS+x5ZN"
    "PjSskTxzn4y9zjkjvvvihT6aY82+MZHvvbsXS77IPKY8DmxNvgmgjL3E+DY+WidMPeW9bj4QI308ZtPhPO2EwDwYf7s+eAkEPjjD"
    "T7xSCKo+ijFzvmUV+b3vOSg+4LCyvUGJk77wXcM9tBO2PmKiNb7QuBM+wfcrPlB1iD6ZPhU+CPqHviLFZb1BYqo8dv2NPTMwmT3M"
    "6J09nlsRvbjHUj6Tm5M+OGlZvgIXqD0vi/y9V/YqPvV6CT4KA2u9km5fPuSP+LzvOZg+wC7rvktXXj4iF+u+lAzaPMGYM7zRoPo9"
    "NYbuPcpylD0CWaC+hR+GPiucaD2S47g9Oe5GPG5pJb5TMY4+J8hoPgTBnz2R64C+5hGOPqmoZr3/enG+SHI9uwz0WD5ztkW+SS6Y"
    "PfzoRro8wzc+Z+fIvQj8yD1dYZ09ACeJvVXDEz5VEQw9ghG3PRCxlb2OYI8+q3ZuPnIHGj7DTJE9I4GUPYDph76nC5a+wPbOPRCm"
    "Er3rdAS+Yrj0PQbGw72cyMK+9dz3PQPGCj52CDu+11IOvlNiOj03iIu9EEm9vdwDwb1lrJ++pV8ivoiNXL58pu895nqjvhoqrb4r"
    "TvK8Ynwyvg0eSD62SQe+AbwAPnLc8z3kF4Q+upo8vR/6GDzEi3y+8JoXvhbZNb5K2Fi+XaDGPuyYEb4jXZa9jQNovbkU8b1ZdVm+"
    "mPG0PdwJSrzqR+o8ga+ku2emGb7uS6W+etATPijbCD4poUQ+HpgXvgqpH75xFgK+RtmLvcunrjuYoNa8gP8KvguGSz6tcpy+fKlu"
    "vouUhL6wMFo8Mpd/PhDK8TxmHa4+l+bpvYCgWb6Aq7a+o3c4vdXgQL665vy8eq+bvQgfTruRn6S9cPRxOR548b5FcJC+AL5VuFbL"
    "hDw1rBy+8OxBvp0uir77c4U+fRofPmvRAT53Cs49TzaPvrYE4T1hqUC+2tZFPhVngj7eAqq+3msVvjk7lL17Gk4+gG0Ivs4kU74n"
    "ClU+DNySvtrLxr12YVI+1mIyvqhwC73uFPa8H6SBvca+2b1kYAC+uhwivqQDEL5VBt+9CoQxvkzg/L7WP/G9bnwwvVUzDb6Ktwq9"
    "DgTNPP1wpb603+G9aSnwvZ44mTygvLe+vNZwvU6MKD0gPSS+zwuavqLd+T0QmT++GjWnPpCMzr2c4As7xLZlvbxvgzwxhj4+RDWr"
    "vWNMrb01Jgq+xpd/Pr0kq75rxfo90Qv+PdDD67y8B549C+w3vk8bNT5Rht89SJqsvvpQSzyRcPW9wlCDvYucL76RkLy+IPs1PqYw"
    "PDzmM509KH6dvbaRA764k/G9TL7MvaLFZj6Op7Y9Y1Rjvnx0SL67OMU91O09vLRTA76GUEW+F7IYPjzTxj3prqK8pNe6u/x8+L0O"
    "4Nm9BcGkPd5irD10TCA+/Si1vPo2lb5CMra9zYUkvk2ssL0Bhby9Nw3KvabYOD0BM0w+G0PtvJSjSz4Y7Fe9ulbLPc55ur0NgJi+"
    "fVSAPgbPrD25eSM8moaivscWIT4Ia6G99+eqPhX2Fb2z3A69selIvds73jt70bC+l/4dvgtxML6zWG69H4DLvtynKL6xCYA9MOiJ"
    "PYQBUzsMwQ6+oHKyusx3xb0uhYy+cEQUPl+GAD4KOBK++j+tPZi/PD3hBuG9YLalPF4jSL7zcp++KDWQvkB74L0Ntzm93+kFve7w"
    "Jr60QGi+ZfdzvWlk0z33iR8+LNaxPcOMozy+GHM+Csc+vOCqHr7F8Rq9yrMXPsDL3brW/yc+/92VPpTrhzwmkKK8eB2XvWA72D1E"
    "Xos+Zoeevci78bsUk3S+HlYVvTQU7b1P4Tg+ZBYiPfomIb4/tr49rngRPRDXtT1byIy9dBP0vb7AS71KcTq9jNGlvU2Piz1+PJO+"
    "7KhzPn7gwT2RLp69VK6uvfdD773uAhs+8Oo/vZCnhT4D8Ly9CxXOve7Lfz2CVGY9r6Y7Pj+5ZT64fE2+jPhfPcAeCz6gZbo9g3wr"
    "PmHqTT0KSQA+BNQSvW0YNL5FB2Y9KDSHPodI7754tuY8pZ9xPoFo/r28um09t4XrvXqegz02diC+Ql5TvVKfjL2UI1C+nn9VPl4V"
    "rz0525A9sEr6u5R+Bz2apM+9tgT3vqQpqL0dExS9oO0RvWA2JD50Wqe8YqUevdkFNT5S3Rc9gEkzvRi9Tj7K71o9oul9PcHyKj6A"
    "1E0+w6NKPTlnJj641DU+vuFtvQYnKj5ASng6PFfrPMBVuD5j2pk+ahykPuw/oj04pzi8gdIaPSDAGz1IigY7tzyhvQAJ+T3JkqQ+"
    "FManvrFqGT7QJGa+EUFpPbEYED6s20U9IIYPPho/Mz6g8JK6a5t8Pk7iJT6nrZ0+q1K8PRveID4oeHM9HBc1Pm2KOD3dsjg+O9r2"
    "vUAye72vN2i+z/5gPuTjOD2171w+Vp1+Pb1oLr7OGGC+V9sPvv0hkT2kEV+9RuKLvYkPob7wzdK+KQyJvfdvUD5KYLw9KqUUPvjk"
    "yT1jEg0+ECIrPv8YE74vo7k+lC09Pl95Aj7YK08+heWzPjDuqz0PtNs9+BBTPthhlD5GSYA+xIx9PgYqqT1QE1e+0AfXPaOwPT4z"
    "NoE92SQnPsjgzDlT1nk+jpygPtXNCL6dqnO9GrqVPrTeD74aQ4u+C4revY5X8L07/ZM+AUQTPrdfyT3igD29nI06PsiUzD2EgZQ+"
    "6A9nvaLkqD1Jf4o+5t90vZNWgj3OpQO+gPqXvm4f5r3WqVq9pIMEvmhWkj0M0gc+hvw8Pmrx7Lxu/Kg9tbR8PTRmNrwmspc9hejC"
    "PWaLT75TE8s8jdWoPrRXCj6AWuM8Z9zavdCeoD6GZDM+wKgGPBYP3b0kkLQ+9hOIPYaO9z28C9i9TaAFPjAxYr6UK2S+wcuhvVFJ"
    "uT6hThs+kKX7O8PHIT5CzWQ+ofiOvIcJmL0ZuWC+h40/Pp1PZj6V7UA99Z9KPmTx+juuL5e+2P8nuzDHGr3Mxzq+z8atvpI/Rr1p"
    "Dc4+FTicPRTbKD5pGaq9hEPZva6zA70vjSW/eIdtPq3J+73ZXUW9emSSPpVgfz2HlQA95pCRPDSZNT6P6XK+gKWeOYZVrz5P+XU9"
    "ZKUtPqICiz0qAWk+mF+WvSm+xb0Sc9k97N0fPqSeZj4ChZk+UkK3PYZGAb243Oa99DWVPnWiezyC6PQ9Ar17vpa4SD3EaJy+ozqC"
    "ParmhL6a69q9LlaOvq41GL4cQQA+RJplPqYbjL0yv9A92GGcPd0RVL6HF4Q+VJ0+Pv71Fb7Vzsi9E8zUPeIhEj5xsWm+ePbuvb4j"
    "HL6pCJS8clcFvjpCJD7UkPg9zOoKvhxOvD0J87O9TYLzvtb8+TzHsY09WWYhvg5z+L2tD6S+cOjluyLgmr7MoPe96wA2vv3JmbsF"
    "l8w8yNCyPSev+LxOt+u+4wtvvokqOb7Wo4Q9x7+rvcDiRDyosXs6ArMaPWNJJL6Am6u6+VgOPnjDrDxOGAS9vgudviQoj7xfDcq9"
    "nLoWvnxjfD4sRzK8EGuRPUve7b5dsXo8uj3lvWgviT3KEBa+vokVPtrt9zwlSUo+yNnFPJdrhL1MW9k8KNJWvnyUkj26AtW8bCem"
    "PvZhnr2VfTw9t2iHvoIl+73c3Xg+au0BPtJ0GT4gnuq8+O3pvX1CPb74dWS9hLi5PM2Xlj4gm/e8lI8kPAhHkb7pfUU9vobBvaDz"
    "KL54xB2+QIdAvirlMD+WkCE+owlzvmBWPr4tIYO+YZGTvl/5bD4VfZi+QK1PPYHGoD1iQs89C9oEvvl7sj4+KiE+Xb6UPcOIqT5C"
    "RFY+e/ZxvR6xmD2i/km9ZEMEv0tzpD2SbmE+P4ZXPhIwYL5XC6q+e4oJPmBxMjoUx22+S+sPPnwS1D1qdMs9t7Yrvq7Yhb2qAzA9"
    "FWA3Pra1M70zyp49uC6BvuYdDT71Yn++3lPpvGPZCj0bS8c9/EaHOw6Xar0BJbE98vbaPoI+Cj4PcJe9dFRLPvZuur3PpjO+2jIt"
    "PpSGyL2r8Rg+aTqiPQDyAbzK0Yq9HzHEve7lKj439b49QNusPbs8mL3q3q49KgqkvVBJ0L3ReAq+Ba3ZvZeLKj1Ol/E8dTMOPnj+"
    "mr16pGo9MEayPQWZFT6mQKu+9SWMPYXyjT4hG949d4ZFPgOmhryGeb09THiXPbgQLT7kWBE93xL3PNYKgTx6YCK93AjOPSjCDD4f"
    "dr284L39ulOD7b26QSo9kZwCvtdDuL4C2c68w//TPCyniT7PKyy+7KaKO2HQHD6xE6C++hGdvkcXCT5U6J49t+ApPhRM6rw5LL09"
    "t+qPvmjCz73VTpo97FpPPVl7tL1bZjW+qsLLPfCc/71UBJs7ONKWPuKc1bxYoG0+8ebVvuhpNj794B6/K9S/vQ9VPL0ocSU9gjHF"
    "Pg+IIr2bBl49wiuKvfemgr4CvaG9/botvRi/y71Mj1Y8Rb+NPv/0r70NV0u+4EN4Pk1GID0Wiyw9W2jsPfFgGD+hy9G8bmofPe1n"
    "6r0wa1C+xwpRPpOFoj0PFTo+4k59voZ91DuK16C9F/d1PigS2L6SxQ6+AzZ7PjfDDb58sHe9c70tPktwL75S536+YAXLvZSkPD00"
    "ZY6+ACgKPo9cDT26g9K9/5FDPlkChz4xoFq+4UFlPvj+wL1wqI8+SBepuxPmmr0HxJC9HxhcvjoJCj1WmQW+uN21Ps7dW77Y4kE+"
    "2LVaPljETL62bRy9yuilPXrR+b1zwyw+N4wMvY75LDyuiii+v1wMvlJHrr30Sim9YNgtPitGjD7qHw8+8kNMPgCVYrzwl9o7d/tR"
    "Po7uR740mII+BfMfPrXeNb46o5K99XVEvR1oBT7EdRY+rrWYPdBjOT5nFOM+Ie5Dvt6FbT3M2kO+3qRPvptlET0u9me+OHGrPXgA"
    "6b1tmFE+vyTvPCiIaL42EBu+fqjrvadSLb7fr9i+iI6RvcIAe74mW6C966gVvl5cK7wiUyk+OduWPQnYN74qchg9S3+cPW80Oz6S"
    "QHg+TKumvglzwz2VCfo9uBabvbP+TD04C0W8029GvnRIDT1gLVy9zRWsPcxLhb5IGVW9CtatPUAQp771ddM81vP+PaU7ED5vi+Y9"
    "gPXmuPwRj74oba49GUOAvWCBCb5Gjoa+mJ5qvg4Blr0xYjg9jkQ0PoiMIr6H5qc+GfhGPhYlLD3a19Y9Rr9iPqyvs77IOsQ+7Jgo"
    "PgEOWD7JtqQ94QmQPuITrj5OvrY96jELPjm8gT5mYw2+nDMTPhAghr5Epjg+P9NYPbnSgr1Y5pw+0+WNPnhpjb7QWeo8fRiWPl39"
    "7T3+h0w++5iyPvg3db7FWxE+in+yPg/aBj+Q/HQ8S32PPhTgMD4EGZa+uqLoPfc1Hj2iyt09Bou8PWgaUT1Qr0a7YJ0jPV1bSj76"
    "uHI+ejTaPb4+Uz7co5i96B4ivZOttT2XFEU+XK2DvXD6Gj06V0W8gZkAPupBAz7iq0M+vNTCPUagTz4ieSE/SKVEvnZ7nT6dE4W+"
    "GzxWPhZHPT524Dm9LC5pPif6wD0CqQ8+sB+dPWDIBj5B8+89Xmg7PrtKLj7bX6w+Q5roPp4Jlz6UQoQ9uJeWPrQKjT0EKT69bDKy"
    "PiV1Dz45p109FYpevlG1Qr7AGOE+44anPTXjPj3XgYA+7q9KvBgOgj6DaR8+XrsDPkS1Tz3AgCk+8P/Cu9Zdkz1Gg5w97sC6PWg/"
    "yz2+0bE++PEmPgM/ID6auxa+YAR6PqypxL0R9gU+32W0vtss/T1IBQo/HNa/PSEIgz0/QHA+EI8Gvj3MPz3eQIk8RBOjPqzO/jzA"
    "QSG7/EPmPoQbQD4FqII+FDYtvl0Ppj6U3ec+VhapPKRXUj1gdoY+pgszvTq3gT6KZgI+2XkGPrJFiz62hE2+teOiPJvmhD439Gs+"
    "4b9SvkKuiD1vAow9ab1HPetrZD5Ma6W85vQNPr1YBD6em409L1soPbsaXj6YYFQ+bj6kvoNjGj2bK+c+r9oOPlbpBb5eC5M9e8Hq"
    "PRFsSL7gZOU9qrKAPjjvKb0x6++8ieefvayI6b2tPxY+ddo8Po22tj3TdVy+BG+MPqThPj3ie4M9LPTPPeqJBL78Bii9LT6XPom5"
    "Cr4PsUM+4HRAPXqlLr2bR/I963Emvhh0+L3Ac9C6bUQHPhbOgb6Kq4C+toGjPZsLI75POPK82JNevOkWxTxecry9xWoQPkYV57zf"
    "KSO9ywm3Pgf7AT1up6s99jb4vKFuIz28P0K9/v7QPbxJ+T0EgyC8tmv/PYKgDb5cxwk9rrLqPStEZz5RwYy+at4mvqR4RD5go9O6"
    "CU9Bvps4jb1PekY9KweJvabWKD4MCv09Br63vS3Iiz0/vTw+QlK+vbTJWD1pPgs+L0sOPtZsrz3Oe8S9M3WfvsuLdT7I4js+4LEj"
    "vjLPOr7RLFU9oZYgvmLtZL5cVnA+woeGvghhET5yWJy+pKU1PcrlEz5156Q8smtwPhDe/jwQQeW87DsbPTev2T3ImCG9HtcRvqD8"
    "0j3BeAg9CitbPs4wlj31p3s+Oc45vi6uK77kcVe9M44xvaikbT4x61A94jNDviahDT4cPbO+nY7fPdEdhz2yXSQ+UTqgve7lLz0m"
    "6Ay+kZqXvkVG4D1Vb9A+mz0Wvn24Vz5syKo9oZ2JvhEAAz1/3048zvLIvs/nE7237eK7NomqPTpqCT34VO89X1KqvdZi4r1Jfac9"
    "KMxavg3hKb5JOA+9kKzHPbg5x72O+0O9ob7kPr2HF70QcKG9AmxhvXwee71colS+ZrFdvhPsPD7UTiY9VDlovma8mL7PRFA+R3jf"
    "PTyWNr7J65W9ZtmYvsrxMr7mVBy+Pac8vjBj8DstjYK+9vzFPiZus73ef6K7RTptvrAhIL72xNi9uTEGPX+ltr0ZcIa+/ivgPtMs"
    "Kb4AYmY3qmZlvg8sML6D+o49QMSEvChhlr1sDpM+IIkkvoOgoT2ebeS9e7vWu5spCz6PBrg8WN1mPo4ph70yyK29EYcCvd0yvT6K"
    "gse9ckkTvsizG7m4SvG9KveCPc5qFTtnFfc9LxIavT/KjLx4/YA99UnEvCp1Gj6CVYy9uQcAvnKygD57lE++d3ErvfDYeDo4oBu9"
    "LO+Gvd6MFD45ieK919SPvpM/PD0VNh29gf3EvYiK070gOvg7VgS6vQLQLT0hao299TeWvS4aQT4Tr6m+9keSvTYfCr6X5yU+coOe"
    "PkhNMDw6Z4s+m3Jlvs6t0D2DhSo8BQkyPpzUir50ikY+4k9PvlcLpL1QWvM97qyhvf0fj731lIC+6PjEPRamErv1u/89act5vsBT"
    "jT1AOgU6wDO8PXl5YD7oY8E9YbKdPMPxOr7LfxW9HoCAPrK6Mj4Kb+e9+PkDPYQbj74URN68pt5bPqKgBj6ydR69bx1NvWPQzLx8"
    "/UU92+yBvJP8Xz7DjCQ+vrHbva7EHL4ea5G+N+fvvFAZBj1y0cu9wIJcvn4Bi77CTTK+9b6fvV+uvD0Etjk+VjS3uzcBdj44AP49"
    "gPhbvnlDOj5xC3q9lWBhPF59HT401Wo9imKFvoyiMD7cBcO+rtB5vaQ+nL5Ps7+9U18zvn1igr0aIAU+DaL6PFurdj7lbMe9Em8p"
    "vdD2oj0utOQ9k1mmPhU77j39uyq+YstjPPQOAz6lMZE9m4enPUoTI76ct5g9kF/WvuEBm71dtvq9gC2gPgegl73Vewc+EqtSvSRx"
    "hT7OLI29a6IPPYzujL2rkxa99+pTvs7WSr2/GWy+wOhxPTP4Kb76Ypk734tLvrtqQL10bx++vYy1vcvOAr7A55m+kuXKvajGPL5L"
    "aC0+17RUvpR8Wj5UTQQ9B/DbvkbGpb3ajIq+hHaHvuIsWr6IrCy9SN9BPjGNS72gF+e923kZvgAAnz7uGzg+PPmTvKREtT5yYzA+"
    "286wPKiZ0b0vDHU+xVWJvl8WCL7g2Cu9FArSPFhL5rystFa97thoPE1s/T2gDkQ9LEYbPtQQDD0HSI29R/0/Ped3GD5A0P65VfrV"
    "PPTtOj4aVLu9bukAPAx1pz16NYM++R7NvJzCjr0j/08+6vsoPVrvJ72vAco9L1NrPlM3VD76Po8+KEA8PRL/VL5lLuw92nMpvpEi"
    "dDyCU7e82wELvsVNrD1g3Iu901H2PaEUPb6el+y9wa01PkGy273PmH0+DDCWvQns+j3NrnW+DI26PQPrZT4YcAe9TGWJPZfqRr4m"
    "Jpm98LzrvBVMuD2wXZ095Ojou6I/Az6IWnK+seH4vVzpDj2xcmq+CQF7PplJv76XI8U9tTF9Pj1ehr0YzWk9fpFlvooKWb2za2A+"
    "oNmZvt5zkL6Pzz8+HJrbPZFht75A3qq54vJRPq/fGb2WGFC+P+nwPfjCiD7U2N69jmQ2vmrsGb0eUJa+9DB0POHXhrxdeFa9dpWg"
    "PYFdRj6xdTI9JUmlvgjxgL05lae8OqNsPV8wBj5yGY28OhP7PF4DNj2nuBS+TmrWvo6TiLz/Jxe+jNvNPWD0Ez2mFvc91sVVvo1w"
    "uD0f7su+niu7O+mX2D0C+2E9Yj2vvF2TPj4lnLc9f8IOPqY8Cj1idZ29oACdvXIh57z6WN690hC2PcXGbT6K0rY9cAixuwfTiL36"
    "mp++szFsPm6Pjj6coyi+mmMqvhjHNj7pXz8+OTd9PrIKQb2yvAY9enYZPXLCkD1efvO9KYlVvcK3iDydexC+lEMUPrJubj2jUHS+"
    "cNd4PXX32TyV4HK85kxRPcW5LD5yHcu7N6uivZCVhD7vdp4+ZVmKvWaawL6cJd69KA0zvTaOzL1cSys+kY0bPnjmBT3YuSY+Gx2X"
    "vtIjSr04DR8+uWNMPkQ8Ij6mJww+hd9/PmVvXL5o3e49BIOuvsr3sT0eEOw9hRVNPlhlUD5wAc89ggKmO7tPgj3TeZQ+ZPkCvdz/"
    "X7736Ge+15w3Pa38iD59kki9PBZevgLyqr0QbzQ9t8QRvspXR704gAE+vsz7PXlq0j0P8oU+XzLAPipWnD7jpyE+Empevb4qkb3x"
    "RKq+i2ZnvludjT41YRC9VdN5vB6GJb5M0oO+kloLPrGCgj20DVu8BtE0PoghbL0R1vm9wBMPvhQnv70BJJe9Aa8cvoqTXT34oEg9"
    "ZM8jvutq5T2zL8W9yPuHvoO1Er6FvoE+/Z8wvJSFsj1www8+MR4hvsPOKb6Xoyq9ot/2PHr31TtaAr++FvC+PbNoKr5djWm+dy90"
    "PuaWE75gTp099T2bvpRxjLwGMic+yFLDve45q711Y60+DBEdPu+X0j1AwgU+aCiQPm8hl77mDIm9ifNIPWponb4YXYg+qO83vkB9"
    "bj5ceI67byGyPCEALL6Q+je+xarQvZCz5L22OkA+zG2DPayaw75OoTo9HpfsvXBSlT4cu1k9Li4yPVwDBL7NO8c781VOvXG/QD2K"
    "fyE+0h0OPiLkFr4wiBi+Q3IGPili8j7g8+u7G3p7vW+VRj6iG569VKz5PDZFoT7GtFG9YnVEvV3nG74PKhm+lHBivh5nH777I2U9"
    "tMQcveztAT45102+m+MmPm1p0r2Y5DA+WPS+vv0VUz44SeA9a0Arvs3DCr43cwM+FHWDvucUR757ILc+rsQ9vuNWIj6YvMS9OR27"
    "vb88nL6Yf649InykvtoPdj7TWSy+oTCmvjLRqz2zQK88bXPSvn5TQ7zDsiq+rV/YPZZgjb5g0uy9cAWmva3HNT6bW9G9BRK3PWI+"
    "Abt6gYg9AV5cvi6d6T3AhoC8piquPGt3Y76Agky+rxEiPttSRz5K8xK+CqTYvKcPDb2ZHmo+1QlIPb/iy7xZwju+sfexvuNzbL6q"
    "InY9Q3fUvbQxr70ymTY8sJxbvYiXf76Fpm6+iSGwvqjd1r3E86G9tmEnvusVor3P1cq9INUXvp5KnzxJpk090IqpPT3xor6ieJY8"
    "R3pGPmMaCT5VjVE9//LNvgE9/r2gnT+6Tt5NvQOtYb7TbhO+Z9+DPcDX+z40MLe9K4msPrz8y70Kx8Y9aSNUPvhgPD39oxk9ldFg"
    "PSkIET0BuLM9zOcQvnlNUb2voam+qqXJPAqbTz719tc9IHEgup3ZbT5sehQ8mhF+vj1ftD1RmFG9aSQ+Pp/ssr3Wf2E+gRwWvgGU"
    "rz1mas88ggWjvoD2YD6J0gc+HVSOPg1tq72mKPe8WlnsPUzVST5KKda9Qo/EvBVeET4d4dw9ikP4vTBpRj7/lhM9BMoivnsVq76B"
    "T4c+Yv6TPIVSTj2lIk4+PFE2PZgUXL1PD149gdc6vlMzAz4OlKO8aP6RPqL+yT1gY6m9mTKOPlvgVr5UTDo+MveEPORlwD1EMce+"
    "GkQIPJxK27130tG8LU3LvUl4Gz4stAm+1vEwPd4DxL357G09gxLbvcJVmL1l9/c9nGhkPWTWoz3qvfK8pV2IPkY7ZT1ZQac9zCwZ"
    "PrGFE74kvUa9bgghPoKELL0bIAc+QCDcPUc8zLwuxBo+k/C5PTgjtD2dh4i+cFyPPS4mDD4njL+9rS7XvJXACT53g528bPwqvocH"
    "yL0ctbC9Dko/PkS4JT6Uqjs+PCsxPv7yZz1lS8g99Lg1Phlf7b2o0VK+a2SSviHFHz6k6UI+vx5Tvqd5y7w4BdQ9asyrPTBFsjqd"
    "dpq+jqgFPagMLb3gUQ0+TlqZvS9hzD3iQLa94gnGvnASvr6HX4m+ZGXXvdazNr5DZCq+WGeBvhqEm73H6sO9o/psvImnAr7ZjKy+"
    "+Dh8vrZdgr0oU4U8eUhbPZg0Yr7g2OQ9/LKsPKoxozxikI486fafvnEyD76qs4m8vNbjusOuhD0d83M+nLAQPRQszr3i4tQ+4veV"
    "vZRg5r5sGVG+cmP+PXRbUz7SYMo8pGmsvJjMjT3jrSa+mDpWPfeKhb4l1I48ak5EvhhDA74f3d6+w+FavoEEg77g+Ri+4020vlBH"
    "Fr4orXE+lQUwvpV82b5d8ka+nX0ZvieBM755n7c9o0aVvXnbrT6GWoY9NGURPSj2aj7l+Wu+4n8vPp8Vj776Bmi+7CACvnMptb0M"
    "3G68Nr3/PdVXSr63xDS+e6AmvhAh3L0Cv+O9CXK/PmRc7r3UgMG8gl1WPfzSyDy7IIK+L/y8vk72nz5G2xg+zYLCvUKYQr45I3w+"
    "s9tavirVlL5lkhS+Q58Cvqxehb4fnUC+zvlQvsrKkDyiZNW9r6aJvjJ/Mz0LP6U9ZPncvqDNgb7Q3829xeulPTrRAr1Rvxg+4VEi"
    "vvZTtT3Xjrc8/qa7vs5wYLy6xTe+brMLvsBi1buPkD29l20RPnh2lr3oHmi9Sh3dvZOR975ccKM7o3PkvoSeuLygRYy+9KvivVd4"
    "gj5Ij0s+XtsYvgEUe72wz+u9GGAiPjKYlL3mqXW9qQCUvrBynL42E5M+Gv/ovQ4Vgz6QOJG+phY+vQCU2b3MDcI+KepmPmANYb6i"
    "k+69cIJBPTucW77iX3i+pECDvtxAPT4weIe+MksHPqfbFz0LHJO9The/vti3qb25ALC+MSK4vIwnL7436na+tBZYPYjliL7AODs+"
    "UqrKPFj+1r1SLRW+0y3JPat0Y77vadK9pvwyvo+vl75mRZ6+xBVGvXfj/r1EKBq+fpVTPE51TL0KRCG9Y8x6vqE4or1AkPM+m96p"
    "vaHXmz2f9KO+Bl5svj1FWb7YjPm+czxtvI0BZT0s8uA6KEOSupD+Ar60/Ts9YrmCvXeUWr6kIge8axHDveBwyj2T86C9tBQvPkoi"
    "db2AGum7CH0TPo+RQb7h7ri+WUwevVGfW74zp0c9eAi8vhsNgr7JYjI++Ja8O8Jpsb464Us+6AlWPSMxaL6osoc9AQNTvY07572q"
    "hLQ+RlxlvZxgKz7K7ra98LhwPl9kRr6KDXO9lIalvdT/o77FblK+iCtsPswEiL7tQww+jwEoPTaiXr4XRim+bfKNvNfeyT0CHZ69"
    "Do82vilt8z5kZDK+jb3VvmnVcT7gwL2+gIIUvhuJILyx3De+DsDcPfDBXTsKt0I+8i3QPA44qj7WvHy+9fDLPkSZOr1Fo7M9jmis"
    "vQU6rL1ev3w+RGMQPs79Kj2kqhu+oIGcPaG7FT46QKg9K3KNPu3lDjxPRZs+j/UoPof5B74JCxw+PIrGvfOJFr5sXAM9y8VlPmbE"
    "Pr0BmsQ9dN+aPcp8kLwiZLO8JA/zPZRWHDpjIY6+aJ5hPveE7zwY7hQ+EIG5PdeSsz1q/CI9rgEjPsAy2D5bFV49eqC+PqG1hD3N"
    "hJM+gF74PFgbTj4onDm9CD5ePI/imjxa72q9EhzIvsf6FD2mjs88Le/LPWPzvD040rA8mu2QPp+gMr4gjEK9VeCyvNLKEb85mFK+"
    "hHptPrGahb5Eb68+728IPn1zzD6otAk+5wX0OoAP9jyxV5y9iZHUPR7VBb0lb409N5BAvhMNwD4Ygfs9kDMNPtffoT65Aru+JgUr"
    "vcZspT6qmlS9f8s3PsMG8j3xHrC9RWqYvuaDWz7Xk8Y+oiadPjS52L3QMM09B2U1PkviHb1hipo+UEmKPqPDHj5uioY++MqxO6fF"
    "uj5yUZU+ElufPUBLpz7Jwgs+shG2vbqqrb16ubo9HfFHPvsBlz4MuZ09MdQoPjU/HT3W9pk7QHAgvrRhL71rfXq+tJjuPaJ1Jr69"
    "Dyg9YkidPry3rjujnDw+QoaaPub8gD6kXJA+7ckEP56jwD5EvE4+gITuveLjDTz3EZg9TCvYu5BVk75lPQ6+HmZgvpKvNr23+SI+"
    "fS+5vYTBrb55TSu+EnMmvBEQjz0gOh+9FiAhPOdJHT2OFKI9Da1avlHslr3TCyC9mptvvDtgBL5OyG4+fHP0PSmPnr7OPJa7AMqh"
    "vdll0737JE++tqtqvmrHjz0E7bS8+vSvvsV5C74ZDq68P1iJPeINLb4Zem29BnOXvWSYED7K8d89uNQrvoT4QL007SC+88s/PRWB"
    "j71phQc+D+9/vuPDXb5Mdwy+uI29PR43N760n7+9wxiTvda/CLxSjQ4+TkSNvr2J1r4TWxK+VpBUvhkOJL4r2Qe9S5ePvbzLMT5U"
    "HpG6XYrevImTDz2oLA2+QjgbPrfdFb5R4j49NRK4u7ff4Lx7Iqy+1pMuvApTr72cAlE9MudlvXLUVL2mZ4o8hN8APma4RL7S5Mu9"
    "tuQCPZuhKb69rpe99B0LvmF2dT7rY2g+RlrMvPbE0Dy8wAE+qo8cvnglib5uB3i+NB0Ovqc64js1REe9mV9PvaCQlLxf8Za+hQue"
    "vWVcrD1ukWC+H790vorwLb49hbY9oV2ivVyEEr5g2oG5Rz9pvpWGSD6r+kK9NXgkvgU/xb3Wt4u9TPa2vbsueT1OqC48/ko8Ppgb"
    "bTxloNq8V4ASvXQ7LL7DXKy9PouHvkr5Dj4kfGy90IYvvg=="
)


def _load_conj(name, shape):
    raw = base64.b64decode(name)
    v = np.frombuffer(raw, dtype="<f4").astype(np.float64)
    return v.reshape(shape)


CODEC_KEYS = [
    ("enc_w1", "encoder_w1", False), ("enc_b1", "encoder_b1", False),
    ("enc_w2", "encoder_w2", False), ("enc_b2", "encoder_b2", False),
    ("enc_w3", "encoder_w3", True), ("enc_b3", "encoder_b3", True),
    ("dec_w1", "decoder_w1", True), ("dec_b1", "decoder_b1", False),
    ("dec_w2", "decoder_w2", False), ("dec_b2", "decoder_b2", False),
    ("dec_w3", "decoder_w3", False), ("dec_b3", "decoder_b3", False),
]


def compose_codec(codec_npz):
    """模块 codec = bundle 9 张直接拷贝 + 3 张引擎固定共轭常量。"""
    conj = {
        "enc_w3": _load_conj(_CONJ_B64_ENC_W3, (128, EMBED)),
        "enc_b3": _load_conj(_CONJ_B64_ENC_B3, (EMBED,)),
        "dec_w1": _load_conj(_CONJ_B64_DEC_W1, (EMBED, 128)),
    }
    out = {}
    for mk, bk, is_conj in CODEC_KEYS:
        out[mk] = (conj[mk] if is_conj
                   else np.ascontiguousarray(
                       np.asarray(codec_npz[bk], dtype=np.float64)))
    return out


def _enc_dec(codec):
    def dense(x, w, b, relu=False):
        y = x @ w + b
        return np.maximum(y, 0) if relu else y

    def enc(v):
        bits = np.array([(int(v) >> i) & 1 for i in range(8)], dtype=np.float64)
        return dense(dense(dense(bits, codec["enc_w1"], codec["enc_b1"], True),
                           codec["enc_w2"], codec["enc_b2"], True),
                     codec["enc_w3"], codec["enc_b3"])

    def dec(c):
        lg = dense(dense(dense(c, codec["dec_w1"], codec["dec_b1"], True),
                         codec["dec_w2"], codec["dec_b2"], True),
                   codec["dec_w3"], codec["dec_b3"])
        return sum(1 << i for i in range(8) if lg[i] >= 0)
    return enc, dec


def verify_codec_conjugation(codec, codec_npz):
    """复核共轭关系：module ≈ bundle ⊗ X（X 由 lstsq 反解，容差 f32 舍入）。"""
    X, *_ = np.linalg.lstsq(
        np.asarray(codec_npz["encoder_w3"], dtype=np.float64), codec["enc_w3"],
        rcond=None)
    e1 = np.abs(np.asarray(codec_npz["encoder_w3"], dtype=np.float64) @ X
                - codec["enc_w3"]).max()
    e2 = np.abs(np.asarray(codec_npz["encoder_b3"], dtype=np.float64) @ X
                - codec["enc_b3"]).max()
    e3 = np.abs(X.T @ np.asarray(codec_npz["decoder_w1"], dtype=np.float64)
                - codec["dec_w1"]).max()
    orth = float(np.abs(X @ X.T - np.eye(EMBED)).max())
    return max(e1, e2, e3), orth


def verify_codec(codec, production_dir):
    enc, dec = _enc_dec(codec)
    rt = sum(1 for v in range(256) if dec(enc(v)) == v)
    add = np.load(os.path.join(production_dir, "stable_add_byte_weights.npz"))

    def dense(x, w, b, relu=False):
        y = x @ w + b
        return np.maximum(y, 0) if relu else y

    ok_add = 0
    for a, b in ((13, 244), (255, 255), (128, 128), (0, 0), (200, 100)):
        o = dense(dense(dense(np.concatenate([enc(a), enc(b), enc(0)]),
                             add["w1"], add["b1"], True),
                       add["w2"], add["b2"], True), add["w3"], add["b3"])
        r1 = dense(o[:EMBED], add["rw1"], add["rb1"], True)
        r2 = dense(r1, add["rw2"], add["rb2"], True)
        ok_add += int(dec(o[:EMBED] + dense(r2, add["rw3"], add["rb3"]))
                      == (a + b) & 0xff)
    return rt, ok_add


# =========================================================================
# 3. [C] ragged term：production 拷贝（±号）+ 正交路由投影 M
# =========================================================================
def compose_ragged_terms(arch, production_dir, session):
    tensors = []
    for op in session["term_ops"]:
        core = np.load(os.path.join(production_dir,
                                    f"stable_{OP_CORE[op]}_weights.npz"))
        t = {k: np.asarray(core[k], dtype=np.float64) for k in
             ("w1", "b1", "w2", "b2", "w3", "b3",
              "rw1", "rb1", "rw2", "rb2", "rw3", "rb3")}
        if session["signs"][op] < 0:
            t = {k: -v for k, v in t.items()}
        tensors.append(t)
    M = np.zeros((len(tensors), ROUTE_DIM), dtype=np.float64)
    for i, op in enumerate(session["term_ops"]):
        s = 1.0 if session["signs"][op] > 0 else -1.0
        M[i] = s * np.asarray(session["routes"][op], dtype=np.float64) / 16.0
    return tensors, M


def pack_alu_region(arch, tensors, M, ctrl):
    """alu_region = ragged N 项 14 槽打包 + controller 尾部（前缀和布局）。

    ragged 项槽序（GW_LEFT/GW_RIGHT 物理缺席；两锚点 offsets 表验证）：
      W1,B1,W2,B2,W3,B3,RW1,RB1,RW2,RB2,RW3,RB3 —— 逐项连续、无对齐。
    controller 尾部张量序：
      ragged_M, ctrl_w1, ctrl_b1, [slot_codes], sel_w2l, sel_w2r, sel_lat_b,
      qnext_w2, heads_b(sel‖qnext), cond_w, cond_b, q_init, region_q, oc_w1,
      oc_b1, oc_w2, oc_b2, fmt_perm, fmt_sign, ct_perm, ct_sign
    """
    pieces = []
    for t in tensors:
        for k in ("w1", "b1", "w2", "b2", "w3", "b3",
                  "rw1", "rb1", "rw2", "rb2", "rw3", "rb3"):
            pieces.append(t[k].ravel())
    tail = [M.ravel(), ctrl["ctrl_w1"].ravel(), ctrl["ctrl_b1"].ravel()]
    if arch["slot_encoding"] == "build-local-bipolar-code":
        tail.append(ctrl["slot_codes"].ravel())
    tail += [
        ctrl["sel_w2l"].ravel(), ctrl["sel_w2r"].ravel(),
        ctrl["sel_lat_b"].ravel(), ctrl["qnext_w2"].ravel(),
        np.concatenate([ctrl["sel_heads_b"], ctrl["qnext_heads_b"]]).ravel(),
        ctrl["cond_w"].ravel(), ctrl["cond_b"].ravel(),
        ctrl["q_init"].ravel(), ctrl["region_q"].ravel(),
        ctrl["oc_w1"].ravel(), ctrl["oc_b1"].ravel(),
        ctrl["oc_w2"].ravel(), ctrl["oc_b2"].ravel(),
        ctrl["fmt_perm"].ravel(), ctrl["fmt_sign"].ravel(),
        ctrl["ct_perm"].ravel(), ctrl["ct_sign"].ravel(),
    ]
    pieces.extend(tail)
    return np.concatenate(pieces)


# =========================================================================
# 4. 教师：计划 steps → 逐步目标（两锚点 rollout 逐字段实测映射）
# =========================================================================
def _mem_indices(arch, s):
    """内存步的 byte_offset/access_width/alignment 头目标索引
    （值→arch 并集表下标；t2 兼容：{-1,0}/{0,4}/{0,4} 下
    memory 偏移 0/宽 4/对齐 4 → 索引 1/1/1 与旧硬编码一致）。"""
    vt = s.get("value_type_id") or s.get("source_type_id")
    n = _MEM_WIDTH_BYTES.get(vt)
    if n is None and isinstance(vt, str) and vt.startswith("ptr"):
        n = 8
    if n is None:
        n = (s["source_width"] + 7) // 8
    return (arch["byte_offsets"].index(int(s["address"]["constant_offset"])),
            arch["access_widths"].index(n),
            arch["alignments"].index(
                int(s["address"]["guaranteed_alignment"])))


def build_teachers(plan, arch, session):
    p = plan["plans"][0]
    objects = p["context"]["persistent_objects"]
    obj_ids = [o["object_id"] for o in objects]
    sentinel = arch.get("object_sentinel", 1)
    out = []
    for s in p["steps"]:
        md = s.get("metadata") or {}
        slots = list(s["input_slots"]) + [-1] * (3 - len(s["input_slots"]))
        if s["action_kind"] == "memory":
            layout = 0
            bo_i, aw_i, al_i = _mem_indices(arch, s)
            obj_i = obj_ids.index(s["address"]["object_id"])
            sem = "LOAD"
            op, route = None, None
            fmt_pair = (0, 0)
        elif s["action_kind"] == "layout":
            # COPY 布局步（trunc/zext/恒等）：GUARD2 效应通道，无 ALU 路由
            layout, bo_i, aw_i, al_i = 0, 0, 0, 0
            obj_i = sentinel
            sem = "COPY"
            op, route = None, None
            fmt_pair = (0, 0)
        else:
            layout = LAYOUT_CODE.get(md.get("input_layout", ""), 0)
            if s["operation"] == "SELECT":
                layout = 1
            obj_i, bo_i, aw_i, al_i = sentinel, 0, 0, 0
            sem = "ALU"
            op = OP_BASE.get(s["operation"], s["operation"])
            route = session["routes"][op]
            fmt_pair = session["default_fmt_pair"]
        out.append(dict(
            read_a=slots[0] if slots[0] is not None and slots[0] >= 0 else -1,
            read_b=slots[1] if slots[1] is not None and slots[1] >= 0 else -1,
            read_c=slots[2] if slots[2] is not None and slots[2] >= 0 else -1,
            write=s["output_slot"] if s["output_slot"] is not None else -1, layout=layout, span=s["source_width"],
            target=s["logical_width"],
            lda=md.get("lane_delta_a", 0), ldb=md.get("lane_delta_b", 0),
            ldc=md.get("lane_delta_c", 0), sw=s["source_width"],
            obj=obj_i, bo=bo_i, aw=aw_i, al=al_i,
            semantic=sem, base_op=op, route=route,
            fmt=fmt_pair[0], aux=fmt_pair[1], enabled=(sem == "ALU"),
            effect_channel=session["channels"][sem],
        ))
    return out


# =========================================================================
# 5. 零训练路径：闭式解析拟合（与引擎 least-squares 拟合同构，无迭代）
# =========================================================================
def step_classes(teachers, region_bounds=None):
    """动作行指派（自右向左贪心；周期微程序折叠为 ~周期+前缀 行数）。

    可共享 q 行的判定（比 DFA 最小化弱）：
      (1) 教师（动作目标）相同；
      (2) 行内所有**有后继**的成员其后继行一致；后继约束在区域末步与
          哑索引处解除（运行时非连续入口从 region_q[start] 重载入口
          潜态，链不跨区域边界）。
    region_bounds：[(action_start, action_count)]；缺省 = 全链（t2 兼容）。

    返回 (row_of_step, n_rows, succ_of_row)。
    """
    N = len(teachers)
    if N == 0:
        return [], 0, {}

    def _sig(th):
        parts = []
        for k, v in sorted(th.items()):
            parts.append((k, tuple(v) if isinstance(v, list) else v))
        return tuple(parts)

    sigs = [_sig(th) for th in teachers]
    # 后继约束解除集：区域末步且与下一区域之间有索引缺口（运行时从
    # region_q[start] 重载入口潜态）；哑索引（无区域覆盖）恒解除；
    # 全局末步解除（qnext 不被消费）。连续区域（t2 形态）保持全链。
    free = set()
    if region_bounds and N:
        bounds = sorted(region_bounds)
        covered = set()
        for start, count in bounds:
            covered.update(range(start, start + count))
        for i, (start, count) in enumerate(bounds):
            if count == 0:
                continue
            end = start + count
            if i + 1 < len(bounds):
                if bounds[i + 1][0] != end:
                    free.add(end - 1)
            else:
                free.add(end - 1)
        for t in range(N):
            if t not in covered:
                free.add(t)
    elif N:
        free.add(N - 1)

    rows = []                       # [sig, succ_row or None（未钉定）]
    row_of = [None] * N
    for t in range(N - 1, -1, -1):
        s = sigs[t]
        want = row_of[t + 1] if (t + 1 < N and t not in free) else None
        hit = None
        for r, (rs, rsucc) in enumerate(rows):
            if rs == s and rsucc is not None and rsucc == want:
                hit = r
                break
        if hit is None:
            for r, (rs, rsucc) in enumerate(rows):
                if rs == s and rsucc is None:
                    hit = r
                    if want is not None:
                        rows[r][1] = want       # 钉定
                    break
        if hit is None:
            rows.append([s, want])
            hit = len(rows) - 1
        row_of[t] = hit
    # 按步序首次出现重编号（确定性）
    order = {}
    for t in range(N):
        if row_of[t] not in order:
            order[row_of[t]] = len(order)
    row_of = [order[r] for r in row_of]
    succ = {}
    for old, new in order.items():
        s_old = rows[old][1]
        succ[new] = order[s_old] if s_old is not None else new
    return row_of, len(order), succ


def synthetic_fit(plan, arch, session, codec, seed, verbose=False):
    rng = np.random.default_rng(seed)
    N = arch["max_actions"]
    teachers = build_teachers(plan, arch, session)
    enc, _ = _enc_dec(codec)
    token = enc(0)

    # ---- slot 码本（bipolar；先于 selector 教师生成；可被锚点材料覆盖）----
    slot_codes = None
    if arch["slot_encoding"] == "build-local-bipolar-code":
        slot_codes = (np.asarray(session["slot_codes"], dtype=np.float64)
                      if session.get("slot_codes") is not None
                      else _make_slot_codes(arch, rng))
    session["_slot_codes_for_targets"] = slot_codes

    # ---- q 轨迹 ----
    if session.get("region_q") is not None:
        # 锚点材料路径：沿用锚点逐行轨迹（tier-2 复核用）
        region_q = np.asarray(session["region_q"], dtype=np.float64).copy()
        q_init = region_q[0].copy()
        rows = region_q[:N]
        n_rows = N
    else:
        # 行折叠路径：每行一 ±4 q；周期性动作流折叠为少量行
        bounds = [(r["action_start"], r["action_count"])
                  for r in plan["plans"][0]["regions"]]
        row_of, n_rows_c, succ_rows = step_classes(teachers, bounds)
        # 容量上限放宽：selector_rank/controller_hidden 随类数线性扩容
        # （引擎对 689 步程序同样扩 rank，权重仅 +35%）；语义重放兜底验证。
        if n_rows_c > 4096:
            raise RuntimeError(
                f"action classes {n_rows_c} exceed extended capacity 4096 "
                f"— restructure lowering for more periodicity")
        import sys as _s
        print(f"[debug] n_rows_c={n_rows_c} N={N} regions={[ (r['action_start'], r['action_count']) for r in plan['plans'][0]['regions'] ]}", file=_s.stderr)
        q_rows = []
        while len(q_rows) < n_rows_c:
            cand = rng.choice([-4.0, 4.0], Q_DIM)
            if not any(np.array_equal(cand, r) for r in q_rows):
                q_rows.append(cand)
        class_rows = np.stack(q_rows)         # 行表（行 → q）
        # 完整轨迹：full[t] = 行 q；末行 = 末步行后继（未被钉定则自身）
        last_row = row_of[N - 1]
        tail = class_rows[succ_rows[last_row]]
        full = np.stack([class_rows[row_of[t]] for t in range(N)] + [tail])
        first_of = {}
        for t, r in enumerate(row_of):
            first_of.setdefault(r, t)
        session.update(_class_rows=class_rows, _class_of_step=row_of,
                       _n_classes=n_rows_c, _first_of=first_of,
                       _succ_rows=succ_rows)
        region_q = full
        q_init = full[0].copy()
        rows = class_rows
        n_rows = n_rows_c

    # ---- condition 投影（build-seeded-q-conditioned）----
    cond_w = rng.normal(0, 0.3, (Q_DIM, CONDITION_DIM))
    cond_b = rng.normal(0, 0.1, CONDITION_DIM)

    def refresh(q):
        gate = 1.0 if q[0] >= 0 else 0.0
        return np.tanh(q @ cond_w + cond_b + gate * token)

    conds = np.stack([refresh(rows[t]) for t in range(n_rows)])
    X_in = np.concatenate([rows[:n_rows], conds], axis=1)   # (n,96)

    # ---- 单塔第一层：构造性精确（Ht := tanh(A·W0)，任意行数成立）----
    # 旧法（随机 Ht + lstsq）要求 n_rows ≤ 输入维+1=97（过定即残差）；
    # 新法以 W0 为第一层，Ht 由构造恒等命中，容量解除。缩放 W0 防 tanh
    # 饱和丢失行区分度。
    HIDDEN = arch["controller_hidden"]
    A = np.concatenate([X_in, np.ones((n_rows, 1))], 1)
    Wb = rng.normal(0, 0.5 / np.sqrt(CONTROLLER_INPUT_DIM + 1),
                    (CONTROLLER_INPUT_DIM + 1, HIDDEN))
    Ht = np.tanh(A @ Wb)
    ctrl_w1, ctrl_b1 = Wb[:CONTROLLER_INPUT_DIM].copy(), Wb[CONTROLLER_INPUT_DIM].copy()
    resid1 = float(np.abs(np.tanh(A @ Wb) - Ht).max())
    if resid1 > 1e-7:
        raise RuntimeError(f"layer-1 construction residual {resid1:.2e}")

    # ---- option 目标向量（任意 distinct）----
    Opts = rng.normal(0, 1.0, (n_rows, OPTION_DIM))

    # ---- option conditioner：两层精确插值（教师带 margin）----
    oc_h = arch["option_hidden"]
    Zt = np.tanh(rng.normal(0, 1.0, (n_rows, oc_h)))
    A = np.concatenate([Opts, np.ones((n_rows, 1))], 1)
    Wb = np.linalg.lstsq(A, np.arctanh(np.clip(Zt, -0.999, 0.999)),
                         rcond=None)[0]                      # (65,oc_h)
    oc_w1, oc_b1 = Wb[:OPTION_DIM].copy(), Wb[OPTION_DIM].copy()
    # 第一层超定（类数 > 64+1）时 Zt_target 不可精确插值 —— 用**实际**隐层
    # 值重算 Zt，第二层针对实际值精确插值（欠定 → 零残差）
    Zt_actual = np.tanh(np.concatenate([Opts, np.ones((n_rows, 1))], 1) @ Wb)
    if not np.allclose(Zt_actual, Zt, atol=1e-6):
        Zt = Zt_actual
    oc_teacher = np.zeros((n_rows, OC_OUT))
    for t in range(n_rows):
        th = teachers[t if session.get("_class_of_step") is None
                      else session["_first_of"][t]]
        oc_teacher[t, 0] = 1.0 if th["enabled"] else -1.0
        if th["route"] is not None:
            oc_teacher[t, 1:17] = np.asarray(th["route"], float)
        oc_teacher[t, 17 + th["fmt"]] = 1.0
        oc_teacher[t, 21 + th["aux"]] = 1.0
        for j in range(8):
            oc_teacher[t, 26 + j] = 1.0 if j == th["effect_channel"] else -1.0
    A = np.concatenate([Zt, np.ones((n_rows, 1))], 1)
    Wb = np.linalg.lstsq(A, oc_teacher, rcond=None)[0]      # (oc_h+1,34)
    oc_w2, oc_b2 = Wb[:oc_h].copy(), Wb[oc_h].copy()

    # ---- selector 低秩头：latent 精确插值 ----
    sel_t = _selector_targets(
        teachers if session.get("_class_of_step") is None
        else [teachers[session["_first_of"][t]]
              for t in range(session["_n_classes"])],
        arch, slot_codes)
    rank = arch["selector_rank"]
    sel_w2l = rng.normal(0, 0.5, (HIDDEN, rank))
    sel_lat_b = rng.normal(0, 0.1, rank)
    latent = Ht @ sel_w2l + sel_lat_b
    A = np.concatenate([latent, np.ones((n_rows, 1))], 1)
    if np.linalg.matrix_rank(A) < n_rows:
        raise RuntimeError("degenerate latent; retry another seed")
    Wb = np.linalg.lstsq(A, sel_t, rcond=None)[0]           # (rank+1,heads)
    sel_w2r, sel_heads_b = Wb[:rank].copy(), Wb[rank].copy()

    # ---- 直连头（option ‖ q_next 符号目标）----
    qnext_t = np.zeros((n_rows, OPTION_DIM + Q_DIM))
    qnext_t[:, :OPTION_DIM] = Opts
    if session.get("_class_of_step") is None:
        qnext_t[:, OPTION_DIM:] = np.where(
            region_q[1:] >= 0, 1.0, -1.0)
    else:
        succ_rows = session["_succ_rows"]
        class_rows = session["_class_rows"]
        for r in range(n_rows):
            nxt = class_rows[succ_rows[r]]
            qnext_t[r, OPTION_DIM:] = np.where(nxt >= 0, 1.0, -1.0)
    A = np.concatenate([Ht, np.ones((n_rows, 1))], 1)
    Wb = np.linalg.lstsq(A, qnext_t, rcond=None)[0]         # (hidden+1,128)
    qnext_w2, qnext_heads_b = Wb[:HIDDEN].copy(), Wb[HIDDEN].copy()

    ctrl = dict(ctrl_w1=ctrl_w1, ctrl_b1=ctrl_b1, sel_w2l=sel_w2l,
                sel_w2r=sel_w2r, sel_lat_b=sel_lat_b,
                sel_heads_b=sel_heads_b, qnext_w2=qnext_w2,
                qnext_heads_b=qnext_heads_b, cond_w=cond_w, cond_b=cond_b,
                q_init=q_init, region_q=region_q, oc_w1=oc_w1, oc_b1=oc_b1,
                oc_w2=oc_w2, oc_b2=oc_b2, slot_codes=slot_codes,
                fmt_perm=np.stack(session["fmt_perm"]),
                fmt_sign=np.stack(session["fmt_sign"]),
                ct_perm=np.array([np.arange(EMBED)], dtype=np.float64),
                ct_sign=np.ones((1, EMBED), dtype=np.float64))
    if verbose:
        n_cls = session.get("_n_classes")
        print(f"  [fit] closed-form: rows={n_rows} "
              f"{'classes=' + str(n_cls) + ' ' if n_cls else ''}"
              f"rank={rank} hidden={HIDDEN} oc_h={oc_h} "
              f"slot={arch['slot_encoding']}/{arch['slot_code_dim']}")
    return ctrl


def _selector_targets(teachers, arch, codes=None):
    N = len(teachers)
    out = np.zeros((N, arch["selector_heads"]))
    ld = arch["lane_deltas"]
    sc = arch["slot_code_dim"]
    nw = arch["n_widths"]
    for t, th in enumerate(teachers):
        row = out[t]

        def onehot(name, idx, n):
            o = arch["head_offsets"][name]
            row[o:o + n] = -1.0
            row[o + idx] = 1.0

        for name, val in (("read_a", th["read_a"]), ("read_b", th["read_b"]),
                          ("read_c", th["read_c"]), ("write", th["write"])):
            off = arch["head_offsets"][name]
            idx = val if val >= 0 else arch["slot_choices"] - 1
            if arch["slot_encoding"] == "categorical":
                row[off:off + sc] = -1.0
                row[off + idx] = 1.0
            else:
                row[off:off + sc] = 2.0 * codes[idx]
        onehot("input_layout", th["layout"], 4)
        onehot("input_span", arch["widths"].index(th["span"]), nw)
        onehot("lane_delta_a", ld.index(th["lda"]), arch["lane_delta_choices"])
        onehot("lane_delta_b", ld.index(th["ldb"]), arch["lane_delta_choices"])
        onehot("lane_delta_c", ld.index(th["ldc"]), arch["lane_delta_choices"])
        onehot("source_width", arch["widths"].index(th["sw"]), nw)
        onehot("target_width", arch["widths"].index(th["target"]), nw)
        onehot("object", th["obj"], arch.get("object_choices", 2))
        onehot("byte_offset", th["bo"], 2)
        onehot("access_width", th["aw"], 2)
        onehot("alignment", th["al"], 2)
        row[arch["head_offsets"]["control_transform"]] = 0.0
    return out


def _make_slot_codes(arch, rng):
    """bipolar 槽码本：±4×dim，两两 |dot| ≤ ‖c‖²/2（分离约束）。

    引擎（FUN_00531430）：seeded RNG 抽样 + 拒绝（"failed to construct
    compact slot codebook" / "compact slot code lacks information capacity"）。
    槽计数 > 15 时随机拒绝采样不可行（组合爆炸），改用 Walsh 正交码
    （两两点积恒 0，分离约束自动满足；dim 取 2^ceil(log2(n))）。
    """
    n, d = arch["slot_choices"], arch["slot_code_dim"]
    assert d >= int(np.ceil(np.log2(n))), "slot code lacks information capacity"
    if d > 12 and (d & (d - 1)) == 0:
        # Walsh：d 维正交行的 ±4 缩放（前 n 行）
        H = np.ones((1, 1))
        while H.shape[0] < d:
            H = np.block([[H, H], [H, -H]])
        return 4.0 * H[:n]
    for _ in range(20000):
        cand = rng.choice([-4.0, 4.0], (n, d))
        G = cand @ cand.T
        np.fill_diagonal(G, 0)
        if G.max() <= d * 16 / 2 and len({tuple(r) for r in cand}) == n:
            return cand
    raise RuntimeError("failed to construct compact slot codebook")


# =========================================================================
# 6. 会话材料（build 会话随机件的参数化）
# =========================================================================
def hadamard16():
    H = np.ones((1, 1))
    while H.shape[0] < ROUTE_DIM:
        H = np.block([[H, H], [H, -H]])
    return H


def canonical_session(arch, seed, channels=None):
    rng = np.random.default_rng(seed)
    sess = dict(
        term_ops=list(arch["term_ops"]),
        signs={op: 1 for op in arch["term_ops"]},
        channels=dict(channels or CANONICAL_CHANNELS),
        default_fmt_pair=(0, 0),
        routes={op: hadamard16()[i].tolist()
                for i, op in enumerate(arch["term_ops"])},
    )
    perms, signs = [np.arange(EMBED)], [np.ones(EMBED)]
    for _ in range(FMT_COUNT - 1):
        perms.append(rng.permutation(EMBED))
        signs.append(rng.choice([-1.0, 1.0], EMBED))
    sess["fmt_perm"] = [p.astype(np.float64) for p in perms]
    sess["fmt_sign"] = [s.astype(np.float64) for s in signs]
    return sess


def anchor_session(z, arch, production_dir):
    """从锚点 npz 反解会话材料（term 对撞 production；路由/符号自 M 反解）。"""
    sys.path.insert(0, os.path.join(RUN, "src-neural-wip"))
    import neural_core as nc
    n = z["ragged_M"].shape[0]
    shapes = nc.RAGGED_SHAPES if n == 6 else nc.T2_RAGGED_SHAPES
    offs = nc.RAGGED_OFFSETS if n == 6 else nc.T2_RAGGED_OFFSETS
    rag = nc._slice_ragged(z["alu_region"], shapes, offs)
    M16 = z["ragged_M"] * 16.0
    ident = []
    for t in range(n):
        for op in arch["term_ops"]:
            pz = np.load(os.path.join(production_dir,
                                      f"stable_{OP_CORE[op]}_weights.npz"))
            if all(np.array_equal(rag[t][k], pz[k]) for k in rag[t]):
                ident.append((op, 1))
                break
            if all(np.array_equal(rag[t][k], -pz[k].astype(np.float64))
                   for k in rag[t]):
                ident.append((op, -1))
                break
        else:
            raise RuntimeError(f"anchor term{t} unidentified")
    return dict(
        term_ops=[op for op, _ in ident],
        signs={op: s for op, s in ident},
        routes={op: (M16[i] * (1 if s > 0 else -1)).astype(int).tolist()
                for i, (op, s) in enumerate(ident)},
        channels=None,          # 由 anchor_channels() 从 rollout 观测
        default_fmt_pair=(0, 0),
        fmt_perm=[r for r in z["fmt_perm"]],
        fmt_sign=[r for r in z["fmt_sign"]],
        region_q=z["region_q"],
        slot_codes=(z["slot_codes"] if "slot_codes" in z.files else None),
        _anchor=True,
    )


def anchor_channels(z, arch, plan):
    """锚点效应通道指派（rollout 的 effmax 通道观测）。"""
    sys.path.insert(0, os.path.join(RUN, "src-neural-wip"))
    import neural_core as nc
    mw = {k: z[k] for k in z.files if k != "alu_region"}
    ctrl = (nc.Controller(mw) if arch["slot_encoding"] == "categorical"
            else nc.ControllerV7(mw))
    sel_h = (nc.SELECTOR_HEADS if arch["slot_encoding"] == "categorical"
             else nc.SELECTOR_HEADS_V7)
    enc, _ = _enc_dec(mw)
    q = ctrl.q_init.copy()
    cond = ctrl.refresh_condition(q, enc(0))
    ch = {}
    for s in plan["plans"][0]["steps"]:
        h = ctrl.forward(q, cond)
        prof = (nc.option_profile if arch["slot_encoding"] == "categorical"
                else nc.option_profile_v2)
        _, route, _, _, _, eff = prof(mw, h[sel_h:sel_h + OPTION_DIM])
        sem = "LOAD" if s["action_kind"] == "memory" else "ALU"
        ch[sem] = int(np.argmax(eff))
        q = np.where(h[sel_h + OPTION_DIM:] >= 0, 4.0, -4.0)
        cond = ctrl.refresh_condition(q, enc(0))
    if len(set(ch.values())) != len(ch):
        raise RuntimeError("channel observation degenerate")
    return ch


def ragged_offsets(tensors):
    """ragged 前缀和表（与部署 NNOBF_W 宏块同构；GW 槽缺席）。"""
    offs, base = [], 0
    for t in tensors:
        sizes = [t["w1"].size, t["b1"].size, t["w2"].size, t["b2"].size,
                 t["w3"].size, t["b3"].size, t["rw1"].size, t["rb1"].size,
                 t["rw2"].size, t["rb2"].size, t["rw3"].size, t["rb3"].size]
        row = []
        o = base
        for s in sizes:
            row.append(o)
            o += s
        # 引擎表含 GW_LEFT/GW_RIGHT 两列缺席位（UINT32_MAX）
        offs.append([row[0], -1, -1] + row[1:])
        base = o
    return offs


def slice_ragged(alu_region, tensors, offsets):
    out = []
    for t, o in zip(tensors, offsets):
        def g(idx, n):
            return alu_region[o[idx]:o[idx] + n]
        inp, hid, outp = (t["w1"].shape[0], t["w1"].shape[1],
                          t["w3"].shape[1])
        ref = t["rw2"].shape[0]
        out.append(dict(
            w1=g(0, inp * hid).reshape(inp, hid), b1=g(3, hid),
            w2=g(4, hid * hid).reshape(hid, hid), b2=g(5, hid),
            w3=g(6, hid * outp).reshape(hid, outp), b3=g(7, outp),
            rw1=g(8, EMBED * ref).reshape(EMBED, ref), rb1=g(9, ref),
            rw2=g(10, ref * ref).reshape(ref, ref), rb2=g(11, ref),
            rw3=g(12, ref * EMBED).reshape(ref, EMBED), rb3=g(13, EMBED)))
    return out


# =========================================================================
# 7. 验证电池（合成产物与锚点同样适用）
# =========================================================================
def decode_action_generic(h, arch, mw):
    """按 arch 头布局的动作解码（= runtime_codegen emit_controller_step 的
    C 语义；对任意 slot_code_dim/n_widths/lane_deltas 成立）。"""
    off = arch["head_offsets"]

    def amax(a):
        return int(np.argmax(a))          # np.argmax 首大优先 = argmax_first

    def slot(head):
        if arch["slot_encoding"] == "categorical":
            s = amax(head[:arch["slot_choices"]])
            return -1 if s == arch["slot_choices"] - 1 else s
        d = arch["slot_code_dim"]
        scores = np.asarray(mw["slot_codes"], float) @ np.asarray(
            head[:d], float)
        s = int(np.argmax(scores))
        return -1 if s == arch["slot_choices"] - 1 else s

    widths = arch["widths"]
    ld = arch["lane_deltas"]
    oc = arch.get("object_choices", 2)
    obj = amax(h[off["object"]:off["object"] + oc])
    bo_t = arch.get("byte_offsets", [-1, 0])
    aw_t = arch.get("access_widths", [0, 4])
    al_t = arch.get("alignments", [0, 4])
    bo = bo_t[amax(h[off["byte_offset"]:off["byte_offset"]
                                   + len(bo_t)])]
    aw = aw_t[amax(h[off["access_width"]:off["access_width"]
                                   + len(aw_t)])]
    al = al_t[amax(h[off["alignment"]:off["alignment"]
                                  + len(al_t)])]
    return dict(
        read_a=slot(h[off["read_a"]:]), read_b=slot(h[off["read_b"]:]),
        read_c=slot(h[off["read_c"]:]), write=slot(h[off["write"]:]),
        input_layout=amax(h[off["input_layout"]:off["input_layout"] + 4]),
        input_span=widths[amax(h[off["input_span"]:
                                off["input_span"] + arch["n_widths"]])],
        lane_delta_a=ld[amax(h[off["lane_delta_a"]:
                              off["lane_delta_a"] +
                              arch["lane_delta_choices"]])],
        lane_delta_b=ld[amax(h[off["lane_delta_b"]:
                              off["lane_delta_b"] +
                              arch["lane_delta_choices"]])],
        lane_delta_c=ld[amax(h[off["lane_delta_c"]:
                              off["lane_delta_c"] +
                              arch["lane_delta_choices"]])],
        source_width=widths[amax(h[off["source_width"]:
                                  off["source_width"] +
                                  arch["n_widths"]])],
        target_width=widths[amax(h[off["target_width"]:
                                  off["target_width"] +
                                  arch["n_widths"]])],
        object_index=(-1 if obj == arch.get("object_sentinel", 1) else obj),
        byte_offset=bo,
        access_width=aw,
        alignment=al,
        control_transform=amax(h[off["control_transform"]:
                                 off["control_transform"] + 1]),
    )


def verify_module(mw, arch, plan, session, production_dir, tag, tensors=None,
                  skip_semantic_replay=False):
    # 修正:neural_core.py 位于 SDK 根的 neural/ 目录,原代码未把该目录
    # 加入 sys.path,独立运行 weight_composer(如 selftest T3)时
    # ModuleNotFoundError。此处按文件位置动态插入。
    _neural_dir = os.path.normpath(os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "..", "neural"))
    if _neural_dir not in sys.path:
        sys.path.insert(0, _neural_dir)
    import neural_core as nc
    checks = {}

    def chk(name, ok, detail=""):
        checks[f"{name}"] = (bool(ok), detail)

    chk("q_init_pm4", set(mw["q_init"].tolist()) <= {-4.0, 4.0})
    rq = mw["region_q"]
    chk("region_q_shape", rq.shape == (arch["region_entry_rows"], Q_DIM),
        str(rq.shape))
    chk("region_q_pm4", set(rq.ravel().tolist()) <= {-4.0, 4.0})
    chk("q_init_eq_region_q0", np.array_equal(mw["q_init"], rq[0]))
    if session.get("_class_of_step") is None:
        chk("region_q_rows_distinct",
            len({tuple(r) for r in rq}) == arch["region_entry_rows"])
    M = mw["ragged_M"]
    chk("M_entries_pm1/16", set(np.abs(M).ravel().tolist()) == {0.0625})
    R16 = M * 16
    G = R16 @ R16.T
    chk("M_routes_orthogonal",
        np.array_equal(G, 16 * np.eye(M.shape[0])),
        f"diag={np.diag(G).astype(int).tolist()}")
    fp, fs = mw["fmt_perm"].astype(int), mw["fmt_sign"]
    chk("fmt_perm_valid", all(sorted(r.tolist()) == list(range(EMBED))
                              for r in fp))
    chk("fmt_sign_pm1", set(fs.ravel().tolist()) <= {-1.0, 1.0})
    chk("fmt_row0_identity", (fp[0] == np.arange(EMBED)).all()
        and (fs[0] == 1).all())
    chk("ct_identity",
        (mw["ct_perm"][0].astype(int) == np.arange(EMBED)).all()
        and (mw["ct_sign"][0] == 1).all())
    if "slot_codes" in mw:
        c = mw["slot_codes"]
        chk("slot_codes_shape", c.shape == (arch["slot_choices"],
                                            arch["slot_code_dim"]),
            str(c.shape))
        chk("slot_codes_pm4", set(c.ravel().tolist()) <= {-4.0, 4.0})
        Gc = c @ c.T
        np.fill_diagonal(Gc, 0)
        chk("slot_codes_separated", Gc.max() <= c.shape[1] * 16 / 2,
            f"max|offdiag|={Gc.max():.0f}")

    # ---- rollout == 计划（动作字段逐字段 + 路由/系数/效应通道）----
    # 区域感知：每区域入口态取 region_q[start]（连续区域即 q_init 链的
    # 自然延续；带缺口区域对应运行时的非连续重载）。
    bipolar = arch["slot_encoding"] != "categorical"
    ctrl = (nc.Controller(mw) if not bipolar else nc.ControllerV7(mw))
    enc, _ = _enc_dec(mw)
    token = enc(0)
    teachers = build_teachers(plan, arch, session)
    sentinel = arch.get("object_sentinel", 1)
    regions = plan["plans"][0]["regions"]
    bounds = [(r["action_start"], r["action_count"]) for r in regions]
    rq = mw["region_q"]
    n_ok, q_chain_ok = 0, True
    if bounds:
        for start, count in bounds:
            q = rq[start].copy()
            for t in range(start, start + count):
                th = teachers[t]
                cond = ctrl.refresh_condition(q, token)
                h = ctrl.forward(q, cond)
                act = decode_action_generic(h, arch, mw)
                ok_f = (act["read_a"] == th["read_a"]
                        and act["read_b"] == th["read_b"]
                        and act["read_c"] == th["read_c"]
                        and act["write"] == th["write"]
                        and act["input_layout"] == th["layout"]
                        and act["input_span"] == th["span"]
                        and act["lane_delta_a"] == th["lda"]
                        and act["lane_delta_b"] == th["ldb"]
                        and act["lane_delta_c"] == th["ldc"]
                        and act["source_width"] == th["sw"]
                        and act["target_width"] == th["target"]
                        and act["object_index"] == (-1 if th["obj"] == sentinel
                                                    else th["obj"])
                        and act["byte_offset"] == (
                            arch["byte_offsets"][th["bo"]])
                        and act["access_width"] == (
                            arch["access_widths"][th["aw"]])
                        and act["alignment"] == (
                            arch["alignments"][th["al"]]))
                option = h[arch["selector_heads"]:
                           arch["selector_heads"] + OPTION_DIM]
                prof = (nc.option_profile if not bipolar
                        else nc.option_profile_v2)
                en, route, fmt, aux, ct, eff = prof(mw, option)
                ok_o = (en == th["enabled"]
                        and int(np.argmax(eff)) == th["effect_channel"])
                if th["route"] is not None:
                    term, coef = nc.ragged_choose(
                        mw, np.asarray(route, float))
                    want = np.asarray(th["route"], float)
                    s = 1.0 if session["signs"][th["base_op"]] > 0 else -1.0
                    ok_o = (ok_o
                            and np.array_equal(np.asarray(route, float),
                                               want)
                            and coef == s
                            and term == session["term_ops"].index(
                                th["base_op"]))
                n_ok += int(ok_f and ok_o)
                if not (ok_f and ok_o):
                    import sys as _s
                    print(f"[mismatch] step={t} op={plan['plans'][0]['steps'][t]['operation']} "
                          f"ok_f={ok_f} ok_o={ok_o} "
                          f"act={act} th={dict(th)}",
                          file=_s.stderr)
                q = np.where(
                    h[arch["selector_heads"] + OPTION_DIM:] >= 0,
                    4.0, -4.0)
                if t + 1 < start + count:
                    if not np.array_equal(q, rq[t + 1]):
                        q_chain_ok = False
                elif t + 1 < len(rq):
                    # 区域末步：仅当下一区域连续（无缺口）时链必须延续
                    nxt = None
                    for s2, c2 in bounds:
                        if s2 == t + 1:
                            nxt = s2
                            break
                    if nxt is not None and not np.array_equal(
                            q, rq[t + 1]):
                        q_chain_ok = False
    else:
        q = ctrl.q_init.copy()
        for t, th in enumerate(teachers):
            cond = ctrl.refresh_condition(q, token)
            h = ctrl.forward(q, cond)
            act = decode_action_generic(h, arch, mw)
            ok_f = (act["read_a"] == th["read_a"]
                    and act["read_b"] == th["read_b"]
                    and act["read_c"] == th["read_c"]
                    and act["write"] == th["write"])
            n_ok += int(ok_f)
            q = np.where(
                h[arch["selector_heads"] + OPTION_DIM:] >= 0, 4.0, -4.0)
    chk("rollout_matches_plan",
        n_ok == sum(c for _, c in bounds),
        f"{n_ok}/{sum(c for _, c in bounds)} steps "
        f"({len(teachers) - sum(c for _, c in bounds)} gap idx skipped)")
    chk("region_q_is_rollout", q_chain_ok)

    # ---- 语义重放（端到端；仅 t1/t2 锚点语义有手写期望；新样例经运行时
    #      三方差分验证，npz 级重放跳过。t1 重放硬编码 t1 引擎通道
    #      （STORE=0/ALU=fallthrough），会话通道不匹配时跳过）----
    if skip_semantic_replay:
        chk("semantic_replay", True, "skipped (runtime differential instead)")
    elif (arch["boundary_values"] != 2
            and session["channels"].get("STORE") != 0):
        chk("semantic_replay", True,
            "skipped (t1 replay needs t1 channels; session uses t2)")
    else:
        got, tot = _replay(mw, plan, arch, tensors)
        chk("semantic_replay", got == tot, f"{got}/{tot}")
    return checks, all(ok for ok, _ in checks.values())


def _replay(mw, plan, arch, tensors=None):
    import neural_core as nc
    p = plan["plans"][0]
    rng = np.random.default_rng(20261027)
    if mw.get("ragged") is None:
        if tensors is not None:
            mw = dict(mw)
            mw["ragged"] = slice_ragged(mw["alu_region"], tensors,
                                        ragged_offsets(tensors))
        else:
            # 锚点 npz：按 neural_core 已验证布局切 ragged 区
            n = mw["ragged_M"].shape[0]
            mw = dict(mw)
            mw["ragged"] = nc._slice_ragged(
                mw["alu_region"],
                nc.RAGGED_SHAPES if n == 6 else nc.T2_RAGGED_SHAPES,
                nc.RAGGED_OFFSETS if n == 6 else nc.T2_RAGGED_OFFSETS)
    if arch["boundary_values"] == 2:
        r = nc.ProgramReplayT2(mw, nc.Codec(mw), nc.FormatBank(mw),
                               nc.ControllerV7(mw), plan)
        N = 400
        sc = rng.integers(0, 2, N)
        x = rng.integers(0, 2 ** 32, N).astype(np.uint64)
        got, _ = r.run(sc, x)
        exp = np.where(sc == 1, _t2_expect(x), 99)
        return int((got == exp).sum()), N
    r = nc.ProgramReplay(mw, nc.Codec(mw), nc.FormatBank(mw),
                        nc.Controller(mw))
    N = 400
    args = rng.integers(0, 2 ** 32, N)
    mems = rng.integers(0, 2 ** 32, N)
    args[:40] = 1
    got = r.run(args, mems)
    exp = np.where(args == 1, (mems * 2) & 0xFFFFFFFF, 42)
    return int((got == exp).sum()), N


def _t2_expect(x):
    """t2.c: y=x+0x1234; y^=x>>2; y=(y<<1)|(y&1); if(y<100) y+=7; return y%256"""
    y = (x + 0x1234) & 0xFFFFFFFF
    y ^= (x >> 2) & 0xFFFFFFFF
    y = ((y << 1) | (y & 1)) & 0xFFFFFFFF
    y = np.where(y < 100, (y + 7) & 0xFFFFFFFF, y)
    return (y & 0xFF).astype(np.uint32)


# =========================================================================
# 8. 主流程
# =========================================================================
def compose(plan_path, production_dir, codec_npz_path, storage, seed,
            verbose=True, channels="auto", skip_semantic_replay=False,
            arch_out=None):
    plan = json.load(open(plan_path))
    # 先用基准 arch 构造会话（term_ops/通道），再按动作类数定 rank/hidden
    arch0 = derive_architecture(plan)
    if channels == "auto":
        channels = ("t2" if arch0["boundary_values"] == 2
                    else "canonical")
    if channels == "t2":
        chan = T2_CHANNELS
    elif channels == "canonical":
        chan = None
    else:
        raise SystemExit(f"weight_composer: unknown channels {channels!r}")
    sess = canonical_session(arch0, seed, channels=chan)
    sess_arch = dict(arch0)
    n_classes = None
    if sess.get("region_q") is None:
        teachers = build_teachers(plan, arch0, sess)
        bounds = [(r["action_start"], r["action_count"])
                  for r in plan["plans"][0]["regions"]]
        _, n_classes, _ = step_classes(teachers, bounds)
        arch = derive_architecture(plan, n_classes=n_classes)
        sess_arch = arch
    else:
        arch = arch0
    if verbose:
        print(f"[arch] v_slots={arch['v_slots']} "
              f"max_actions={arch['max_actions']} "
              f"classes={n_classes} "
              f"heads={arch['controller_heads']} "
              f"(sel {arch['selector_heads']}+64+64) "
              f"rank={arch['selector_rank']} hidden={arch['controller_hidden']} "
              f"slot={arch['slot_encoding']}/{arch['slot_code_dim']} "
              f"oc_h={arch['option_hidden']} terms={arch['ragged_terms']} "
              f"lane_deltas={arch['lane_deltas']} widths={arch['widths']}")
    if arch_out:
        sidecar = {k: v for k, v in arch.items()}
        json.dump(sidecar, open(arch_out, "w"), indent=1, default=list)
    codec = compose_codec(np.load(codec_npz_path))
    rt, ok_add = verify_codec(codec, production_dir)
    resid, orth = verify_codec_conjugation(codec, np.load(codec_npz_path))
    if verbose:
        print(f"[codec] roundtrip {rt}/256, production ADD {ok_add}/5; "
              f"conjugation residual {resid:.1e} (|XX^T-I|={orth:.1e}; "
              f"X = engine-fixed QR, f32-rounded)")

    tensors, M = compose_ragged_terms(arch, production_dir, sess)
    ctrl = synthetic_fit(plan, arch, sess, codec, seed, verbose=verbose)
    alu = pack_alu_region(arch, tensors, M, ctrl)
    out = dict(codec)
    out["ragged_M"] = M
    out.update({k: v for k, v in ctrl.items() if k != "slot_codes"})
    if ctrl["slot_codes"] is not None:
        out["slot_codes"] = ctrl["slot_codes"]
    out["alu_region"] = alu
    checks, ok = verify_module(out, sess_arch, plan, sess, production_dir,
                               "synthetic", tensors=tensors,
                               skip_semantic_replay=skip_semantic_replay)
    return out, sess_arch, sess, plan, tensors, checks, ok


def compare_anchor(composed, anchor_path):
    """确定性张量逐位对比；随机张量清点。"""
    z = np.load(anchor_path)
    det = [k for k, _, _ in CODEC_KEYS] + ["ct_perm", "ct_sign"]
    report, n_ok = [], 0
    for k in det:
        ok = (k in composed and np.array_equal(
            np.asarray(composed[k], np.float64), np.asarray(z[k], np.float64)))
        n_ok += int(ok)
        report.append((k, "deterministic", "EXACT" if ok else "MISMATCH"))
    rand = []
    for k in z.files:
        if k in det:
            continue
        a, b = composed.get(k), z[k]
        if k == "alu_region":
            # 区域含随机件；结构另证
            rand.append((k, f"size {a.size} vs {b.size}"))
            continue
        ok_shape = a is not None and a.shape == b.shape
        rand.append((k, f"shape {'OK' if ok_shape else 'BAD'}"))
    return report, n_ok, len(det), rand


def main():
    ap = argparse.ArgumentParser(description="ANANSI weight composer (D1/E)")
    ap.add_argument("--plan", default=T1_PLAN)
    ap.add_argument("--production", default=DEFAULT_PRODUCTION)
    ap.add_argument("--codec-npz", default=DEFAULT_CODEC)
    ap.add_argument("--storage", default="fp16", choices=["fp16", "fp32"],
                    help="存储档位（npz 数值两档恒等；fp16 仅影响下游 C TU "
                         "文本变体——notes-weight-composer.md §4）")
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--out", default=None)
    ap.add_argument("--arch-out", default=None,
                    help="架构 sidecar JSON（profile_gen 输入；含 "
                         "selector_rank/controller_hidden/term_ops）")
    ap.add_argument("--channels", default="auto",
                    choices=["auto", "t2", "canonical"],
                    help="效应通道指派（build 会话随机材料；t2=与 "
                         "profile_gen 的 eff 表一致）")
    ap.add_argument("--skip-semantic-replay", action="store_true",
                    help="跳过 npz 级语义重放（新样例改由运行时三方差分"
                         "验证）")
    ap.add_argument("--module", action="store_true",
                    help="强制模块组装路径（compose_module；单函数计划经"
                         " circuit_share 变换后形态偏离 t2 锚点，须走通用"
                         "模块路径——protect.py 多函数机制透传）")
    ap.add_argument("--verify-anchor", default=None, metavar="NPZ")
    args = ap.parse_args()

    sys.path.insert(0, os.path.join(RUN, "src-neural-wip"))
    # 多计划模块（>1 plans 或 --module）→ 模块组装路径
    plan_probe = json.load(open(args.plan))
    if args.module or len(plan_probe.get("plans", [])) > 1:
        out, arch, sess, plan, tensors, = compose_module(
            args.plan, args.production, args.codec_npz, args.storage,
            args.seed, channels=args.channels, arch_out=args.arch_out,
            skip_verify=args.skip_semantic_replay)
        print(f"[compose:module] storage={args.storage} tensors={len(out)} "
              f"alu_region={out['alu_region'].size} floats")
        if args.out:
            np.savez(args.out, **out)
            print(f"[out] {args.out}")
        return
    out, arch, sess, plan, tensors, checks, ok = compose(
        args.plan, args.production, args.codec_npz, args.storage, args.seed,
        channels=args.channels,
        skip_semantic_replay=args.skip_semantic_replay,
        arch_out=args.arch_out)
    print(f"[compose] storage={args.storage} tensors={len(out)} "
          f"alu_region={out['alu_region'].size} floats")
    if args.out:
        np.savez(args.out, **out)
        print(f"[out] {args.out}")

    print(f"[verify:synthetic] {'ALL PASS' if ok else 'FAIL'}")
    for name, (o, d) in checks.items():
        print(f"   {'ok  ' if o else 'FAIL'} {name} {d}")

    if args.verify_anchor:
        z = np.load(args.verify_anchor)
        plan_a = json.load(open(args.plan))
        arch_a = derive_architecture(plan_a)
        sess_a = anchor_session(z, arch_a, args.production)
        sess_a["channels"] = anchor_channels(z, arch_a, plan_a)
        checks_a, ok_a = verify_module({k: z[k] for k in z.files}, arch_a,
                                       plan_a, sess_a, args.production,
                                       "anchor")
        print(f"[verify:anchor] {'ALL PASS' if ok_a else 'FAIL'}")
        for name, (o, d) in checks_a.items():
            print(f"   {'ok  ' if o else 'FAIL'} {name} {d}")
        rep, n_ok, n_det, rand = compare_anchor(out, args.verify_anchor)
        print(f"[anchor-compare] tier1 (plan+library+engine constants): "
              f"{n_ok}/{n_det} EXACT")
        for k, kind, d in rep:
            print(f"   {kind:14s} {k:14s} {d}")

        # ---- Tier-2: 用锚点会话材料重组 → 更多张量逐位一致 ----
        sess2 = canonical_session(arch_a, args.seed)
        sess2.update(term_ops=sess_a["term_ops"], signs=sess_a["signs"],
                     routes=sess_a["routes"], channels=sess_a["channels"],
                     fmt_perm=sess_a["fmt_perm"], fmt_sign=sess_a["fmt_sign"],
                     region_q=sess_a["region_q"],
                     slot_codes=sess_a["slot_codes"])
        t2_ = []
        for op in sess2["term_ops"]:
            core = np.load(os.path.join(
                args.production, f"stable_{OP_CORE[op]}_weights.npz"))
            t = {k: np.asarray(core[k], dtype=np.float64) for k in
                 ("w1", "b1", "w2", "b2", "w3", "b3",
                  "rw1", "rb1", "rw2", "rb2", "rw3", "rb3")}
            if sess2["signs"][op] < 0:
                t = {k: -v for k, v in t.items()}
            t2_.append(t)
        M2 = np.zeros((len(t2_), ROUTE_DIM))
        for i, op in enumerate(sess2["term_ops"]):
            s2 = 1.0 if sess2["signs"][op] > 0 else -1.0
            M2[i] = s2 * np.asarray(sess2["routes"][op], float) / 16.0
        ctrl2 = synthetic_fit(plan_a, arch_a, sess2, out, args.seed + 7)
        tier2_keys = ["ragged_M", "fmt_perm", "fmt_sign", "q_init",
                      "region_q"]
        if sess2["slot_codes"] is not None:
            tier2_keys.append("slot_codes")
        n2 = 0
        for k in tier2_keys:
            v = (M2 if k == "ragged_M" else ctrl2[k])
            ok = np.array_equal(np.asarray(v, np.float64),
                                np.asarray(z[k], np.float64))
            n2 += int(ok)
            print(f"   tier2         {k:14s} {'EXACT' if ok else 'MISMATCH'}")
        # ragged term 值（production 拷贝，顺序/符号取锚点材料）
        import neural_core as nc
        n_ = z["ragged_M"].shape[0]
        anc_rag = nc._slice_ragged(
            z["alu_region"], nc.RAGGED_SHAPES if n_ == 6 else nc.T2_RAGGED_SHAPES,
            nc.RAGGED_OFFSETS if n_ == 6 else nc.T2_RAGGED_OFFSETS)
        term_ok = all(
            all(np.array_equal(anc_rag[i][k], t2_[i][k]) for k in t2_[i])
            for i in range(n_))
        print(f"   tier2         ragged terms   {'EXACT ×12×N' if term_ok else 'MISMATCH'}"
              f" ({n_} terms × 12 arrays)")
        fit_keys = ["ctrl_w1", "ctrl_b1", "sel_w2l", "sel_w2r", "sel_lat_b",
                    "qnext_w2", "sel_heads_b", "qnext_heads_b", "cond_w",
                    "cond_b", "oc_w1", "oc_b1", "oc_w2", "oc_b2"]
        print(f"[anchor-compare] tier2 (+measured session material): "
              f"{n2}/{len(tier2_keys)} keys EXACT + ragged terms "
              f"{'EXACT' if term_ok else 'MISMATCH'}; "
              f"tier3 fit tensors {len(fit_keys)} = build-seeded fit output "
              f"(numerically random; structural battery + zero-training "
              f"replacement above)")




# =========================================================================
# 6. 多计划模块组装（whibo 多函数；引擎真值：共享 NN + 每函数
#    q_init 64 floats + 每函数 region_q 表；共享控制器解码全部函数）
# =========================================================================
def derive_module_arch(plans):
    """33 plans → 模块级架构（引擎 whibo 实测：SLOT_CHOICES=74= max+1、
    HIDDEN=1023=总步数、OBJECT_CHOICES=max+1、宽度/车道并集）。"""
    v_slots = max(p["context"]["temp_slot_capacity"] for p in plans)
    max_actions = sum(len(p["steps"]) for p in plans)
    deltas = {0}
    widths = {1, 32}
    term_ops = []
    for p in plans:
        for s in p["steps"]:
            md = s.get("metadata") or {}
            for k in ("lane_delta_a", "lane_delta_b", "lane_delta_c"):
                if k in md:
                    deltas.add(int(md[k]))
            widths.add(s["source_width"])
            widths.add(s["logical_width"])
            if s["action_kind"] == "tool":
                op = OP_BASE.get(s["operation"], s["operation"])
                if op not in term_ops:
                    term_ops.append(op)
    lane_deltas = sorted(deltas)
    slot_choices = v_slots + 1
    bipolar = v_slots > 8
    if not bipolar:
        slot_code_dim = slot_choices
    elif slot_choices <= 15:
        slot_code_dim = 12
    else:
        d = 16
        while d < slot_choices:
            d *= 2
        slot_code_dim = d
    base_rank = 8 if v_slots <= 8 else 16
    object_choices = max(len(p["context"]["persistent_objects"])
                         for p in plans) + 1
    arch = dict(
        v_slots=v_slots, max_actions=max_actions,
        region_entry_rows=sum(len(p["steps"]) + 1 for p in plans),
        action_states=2 * max_actions,
        slot_choices=slot_choices, slot_code_dim=slot_code_dim,
        slot_encoding="build-local-bipolar-code" if bipolar else "categorical",
        lane_deltas=lane_deltas, lane_delta_choices=len(lane_deltas),
        option_hidden=max_actions,
        selector_rank=base_rank, controller_hidden=64,
        ragged_terms=len(term_ops), term_ops=term_ops,
        selector_heads=0, controller_heads=0,
        widths=sorted(widths), n_widths=len(sorted(widths)),
        rewrite_kind=plans[0]["rewrite_kind"],
        boundary_values=max(p.get("boundary_values") and
                            len(p["boundary_values"]) or 0 for p in plans),
        object_sentinel=object_choices - 1,
        object_choices=object_choices,
        n_plans=len(plans),
        **_memory_unions(plans),
    )
    arch["selector_heads"] = _selector_heads(arch)
    arch["controller_heads"] = arch["selector_heads"] + OPTION_DIM + Q_DIM
    arch["head_dims"] = _head_dims(arch)
    arch["head_offsets"] = {}
    off = 0
    for name, dim in arch["head_dims"].items():
        arch["head_offsets"][name] = off
        off += dim
    assert off == arch["selector_heads"]
    return arch


def build_teachers_multi(plans, arch, session):
    """全模块教师序列（连接序）+ 全局区域界 + 每函数起止步。"""
    teachers, bounds = [], []
    fn_spans = []
    g = 0
    for p in plans:
        start = g
        objs = [o["object_id"] for o in p["context"]["persistent_objects"]]
        for s in p["steps"]:
            md = s.get("metadata") or {}
            slots = list(s["input_slots"]) + [-1] * (3 - len(s["input_slots"]))
            if s["action_kind"] == "memory":
                layout = 0
                bo_i, aw_i, al_i = _mem_indices(arch, s)
                obj_i = objs.index(s["address"]["object_id"])
                sem = "LOAD" if s["operation"] == "LOAD" else "STORE"
                op, route = None, None
                fmt_pair = (0, 0)
            elif s["action_kind"] == "layout":
                layout, bo_i, aw_i, al_i = 0, 0, 0, 0
                obj_i = arch["object_sentinel"]
                sem = "COPY"
                op, route = None, None
                fmt_pair = (0, 0)
            else:
                layout = LAYOUT_CODE.get(md.get("input_layout", ""), 0)
                if s["operation"] == "SELECT":
                    layout = 1
                obj_i, bo_i, aw_i, al_i = arch["object_sentinel"], 0, 0, 0
                sem = "ALU"
                op = OP_BASE.get(s["operation"], s["operation"])
                route = session["routes"][op]
                fmt_pair = session["default_fmt_pair"]
            teachers.append(dict(
                read_a=slots[0] if slots[0] is not None and slots[0] >= 0
                else -1,
                read_b=slots[1] if slots[1] >= 0 else -1,
                read_c=slots[2] if slots[2] >= 0 else -1,
                write=s["output_slot"] if s["output_slot"] is not None else -1,
                layout=layout, span=s["source_width"],
                target=s["logical_width"],
                lda=md.get("lane_delta_a", 0), ldb=md.get("lane_delta_b", 0),
                ldc=md.get("lane_delta_c", 0), sw=s["source_width"],
                obj=obj_i, bo=bo_i, aw=aw_i, al=al_i,
                semantic=sem, base_op=op, route=route,
                fmt=fmt_pair[0], aux=fmt_pair[1], enabled=(sem == "ALU"),
                effect_channel=session["channels"][sem],
            ))
            g += 1
        for r in p["regions"]:
            bounds.append((start + r["action_start"], r["action_count"]))
        fn_spans.append((start, g))
        # 每函数边界步之间的"缺口"由 bounds 排序后的间隙释放
    return teachers, bounds, fn_spans


def step_classes_multi(teachers, bounds, fn_spans):
    """跨函数行折叠（后继约束在区域末步与函数末步解除）。"""
    N = len(teachers)
    region_bounds = [(r["action_start"], r["action_count"])
                     for r in [{"action_start": b[0], "action_count": b[1]}
                              for b in bounds]]
    covered = set()
    for start, count in bounds:
        covered.update(range(start, start + count))
    # 全局 free 集：区域间缺口 + 每函数末步（跨函数链不延续）
    free = set()
    sb = sorted(bounds)
    for i, (start, count) in enumerate(sb):
        if count == 0:
            continue
        end = start + count
        if i + 1 < len(sb) and sb[i + 1][0] != end:
            free.add(end - 1)
        elif i + 1 == len(sb):
            free.add(end - 1)
    for s, e in fn_spans:
        free.add(e - 1)
    for t in range(N):
        if t not in covered:
            free.add(t)

    def _sig(th):
        parts = []
        for k, v in sorted(th.items()):
            parts.append((k, tuple(v) if isinstance(v, list) else v))
        return tuple(parts)

    sigs = [_sig(th) for th in teachers]
    rows = []
    row_of = [None] * N
    for t in range(N - 1, -1, -1):
        s = sigs[t]
        want = row_of[t + 1] if (t + 1 < N and t not in free) else None
        hit = None
        for r, (rs, rsucc) in enumerate(rows):
            if rs == s and rsucc is not None and rsucc == want:
                hit = r
                break
        if hit is None:
            for r, (rs, rsucc) in enumerate(rows):
                if rs == s and rsucc is None:
                    hit = r
                    if want is not None:
                        rows[r][1] = want
                    break
        if hit is None:
            rows.append([s, want])
            hit = len(rows) - 1
        row_of[t] = hit
    order = {}
    for t in range(N):
        if row_of[t] not in order:
            order[row_of[t]] = len(order)
    row_of = [order[r] for r in row_of]
    succ = {}
    for old, new in order.items():
        s_old = rows[old][1]
        succ[new] = order[s_old] if s_old is not None else new
    return row_of, len(order), succ


def compose_module(plan_path, production_dir, codec_npz_path, storage, seed,
                   verbose=True, channels="t2", arch_out=None,
                   skip_verify=False):
    """多计划 → 模块权重包（q_init (F,64) + region_q (Σrows,64)）。"""
    plan = json.load(open(plan_path))
    plans = plan["plans"]
    assert len(plans) >= 1
    arch0 = derive_module_arch(plans)
    chan = T2_CHANNELS if channels == "t2" else None
    sess = canonical_session(arch0, seed, channels=chan)

    teachers, bounds, fn_spans = build_teachers_multi(plans, arch0, sess)
    row_of, n_rows, succ_rows = step_classes_multi(teachers, bounds, fn_spans)
    if n_rows > 4096:
        raise SystemExit(f"module classes {n_rows} exceed 4096 capacity")
    arch = dict(arch0)
    arch["selector_rank"] = max(arch0["selector_rank"], n_rows - 1)
    arch["controller_hidden"] = max(64, n_rows)
    if verbose:
        print(f"[arch:module] plans={len(plans)} v_slots={arch['v_slots']} "
              f"max_actions={arch['max_actions']} classes={n_rows} "
              f"rank={arch['selector_rank']} hidden={arch['controller_hidden']} "
              f"slot={arch['slot_choices']}x{arch['slot_code_dim']} "
              f"objects={arch['object_choices']} terms={arch['ragged_terms']} "
              f"heads={arch['controller_heads']}")
    if arch_out:
        json.dump({k: v for k, v in arch.items()},
                  open(arch_out, "w"), indent=1, default=list)

    codec = compose_codec(np.load(codec_npz_path))
    rt, ok_add = verify_codec(codec, production_dir)
    if verbose:
        print(f"[codec] roundtrip {rt}/256, production ADD {ok_add}/5")

    # ---- 行折叠轨迹（全局类表；每函数入口/轨迹/尾）----
    rng = np.random.default_rng(seed)
    q_rows = []
    while len(q_rows) < n_rows:
        cand = rng.choice([-4.0, 4.0], Q_DIM)
        if not any(np.array_equal(cand, r) for r in q_rows):
            q_rows.append(cand)
    class_rows = np.stack(q_rows)
    # 每函数 region_q：轨迹 = 行 q；末行 = 后继行
    region_q_parts = []
    q_init = np.zeros((len(plans), Q_DIM))
    for fi, (s, e) in enumerate(fn_spans):
        rows_f = [class_rows[row_of[t]] for t in range(s, e)]
        last_row = row_of[e - 1]
        tail = class_rows[succ_rows[last_row]]
        full = np.stack(rows_f + [tail])
        region_q_parts.append(full)
        q_init[fi] = full[0].copy()
    region_q = np.concatenate(region_q_parts, axis=0)
    row_of_step = np.asarray(row_of)
    n_rows_by_fn = [e - s for s, e in fn_spans]

    # ---- 共享拟合（全部教师行；结构与单函数 synthetic_fit 相同）----
    ctrl = _fit_shared(teachers, row_of, n_rows, succ_rows, class_rows,
                       arch, sess, codec, seed)
    ctrl["q_init"] = q_init
    ctrl["region_q"] = region_q

    tensors, M = compose_ragged_terms(arch, production_dir, sess)
    alu = pack_alu_region(arch, tensors, M, ctrl)
    out = dict(codec)
    out["ragged_M"] = M
    out.update({k: v for k, v in ctrl.items() if k != "slot_codes"})
    if ctrl["slot_codes"] is not None:
        out["slot_codes"] = ctrl["slot_codes"]
    out["alu_region"] = alu
    if verbose:
        print(f"[compose:module] tensors={len(out)} "
              f"alu_region={out['alu_region'].size} floats "
              f"q_init={q_init.shape} region_q={region_q.shape} "
              f"classes={n_rows}")
    if not skip_verify:
        ok, det = verify_module_multi(out, arch, plans, sess, teachers,
                                      fn_spans, row_of, succ_rows,
                                      class_rows, production_dir)
        print(f"[verify:module-rollout] {'ALL PASS' if ok else 'FAIL'}")
        for k, v in det.items():
            print(f"   {'ok  ' if v[0] else 'FAIL'} {k} {v[1]}")
    return out, arch, sess, plan, tensors


def _fit_shared(teachers, row_of, n_rows, succ_rows, class_rows,
                arch, session, codec, seed):
    """共享控制器拟合（跨函数类表；结构 = 单函数 synthetic_fit 的行折叠
    路径，行集换为全局类）。"""
    rng = np.random.default_rng(seed + 7)
    enc, _ = _enc_dec(codec)
    token = enc(0)

    slot_codes = None
    if arch["slot_encoding"] == "build-local-bipolar-code":
        slot_codes = _make_slot_codes(arch, rng)

    rows = class_rows
    n = n_rows
    cond_w = rng.normal(0, 0.3, (Q_DIM, CONDITION_DIM))
    cond_b = rng.normal(0, 0.1, CONDITION_DIM)

    def refresh(q):
        gate = 1.0 if q[0] >= 0 else 0.0
        return np.tanh(q @ cond_w + cond_b + gate * token)

    conds = np.stack([refresh(rows[t]) for t in range(n)])
    X_in = np.concatenate([rows[:n], conds], axis=1)   # (n,96)

    HIDDEN = arch["controller_hidden"]
    A = np.concatenate([X_in, np.ones((n, 1))], 1)
    Wb = rng.normal(0, 0.5 / np.sqrt(CONTROLLER_INPUT_DIM + 1),
                    (CONTROLLER_INPUT_DIM + 1, HIDDEN))
    Ht = np.tanh(A @ Wb)
    ctrl_w1, ctrl_b1 = Wb[:CONTROLLER_INPUT_DIM].copy(), \
        Wb[CONTROLLER_INPUT_DIM].copy()

    Opts = rng.normal(0, 1.0, (n, OPTION_DIM))
    oc_h = arch["option_hidden"]
    Zt = np.tanh(rng.normal(0, 1.0, (n, oc_h)))
    A = np.concatenate([Opts, np.ones((n, 1))], 1)
    Wb = np.linalg.lstsq(A, np.arctanh(np.clip(Zt, -0.999, 0.999)),
                         rcond=None)[0]
    oc_w1, oc_b1 = Wb[:OPTION_DIM].copy(), Wb[OPTION_DIM].copy()
    Zt_actual = np.tanh(np.concatenate([Opts, np.ones((n, 1))], 1) @ Wb)
    if not np.allclose(Zt_actual, Zt, atol=1e-6):
        Zt = Zt_actual
    # 每类首个教师 → option 目标
    first_of = {}
    for t, r in enumerate(row_of):
        first_of.setdefault(r, t)
    oc_teacher = np.zeros((n, OC_OUT))
    for r in range(n):
        th = teachers[first_of[r]]
        oc_teacher[r, 0] = 1.0 if th["enabled"] else -1.0
        if th["route"] is not None:
            oc_teacher[r, 1:17] = np.asarray(th["route"], float)
        oc_teacher[r, 17 + th["fmt"]] = 1.0
        oc_teacher[r, 21 + th["aux"]] = 1.0
        for j in range(8):
            oc_teacher[r, 26 + j] = 1.0 if j == th["effect_channel"] else -1.0
    A = np.concatenate([Zt, np.ones((n, 1))], 1)
    Wb = np.linalg.lstsq(A, oc_teacher, rcond=None)[0]
    oc_w2, oc_b2 = Wb[:oc_h].copy(), Wb[oc_h].copy()

    sel_t = _selector_targets(
        [teachers[first_of[r]] for r in range(n)], arch, slot_codes)
    rank = arch["selector_rank"]
    sel_w2l = rng.normal(0, 0.5, (HIDDEN, rank))
    sel_lat_b = rng.normal(0, 0.1, rank)
    latent = Ht @ sel_w2l + sel_lat_b
    A = np.concatenate([latent, np.ones((n, 1))], 1)
    if np.linalg.matrix_rank(A) < n:
        raise RuntimeError("degenerate latent; retry another seed")
    Wb = np.linalg.lstsq(A, sel_t, rcond=None)[0]
    sel_w2r, sel_heads_b = Wb[:rank].copy(), Wb[rank].copy()

    qnext_t = np.zeros((n, OPTION_DIM + Q_DIM))
    qnext_t[:, :OPTION_DIM] = Opts
    for r in range(n):
        nxt = class_rows[succ_rows[r]]
        qnext_t[r, OPTION_DIM:] = np.where(nxt >= 0, 1.0, -1.0)
    A = np.concatenate([Ht, np.ones((n, 1))], 1)
    Wb = np.linalg.lstsq(A, qnext_t, rcond=None)[0]
    qnext_w2, qnext_heads_b = Wb[:HIDDEN].copy(), Wb[HIDDEN].copy()

    return dict(ctrl_w1=ctrl_w1, ctrl_b1=ctrl_b1, sel_w2l=sel_w2l,
                sel_w2r=sel_w2r, sel_lat_b=sel_lat_b,
                sel_heads_b=sel_heads_b, qnext_w2=qnext_w2,
                qnext_heads_b=qnext_heads_b, cond_w=cond_w, cond_b=cond_b,
                oc_w1=oc_w1, oc_b1=oc_b1, oc_w2=oc_w2, oc_b2=oc_b2,
                slot_codes=slot_codes,
                fmt_perm=np.stack(session["fmt_perm"]),
                fmt_sign=np.stack(session["fmt_sign"]),
                ct_perm=np.array([np.arange(EMBED)], dtype=np.float64),
                ct_sign=np.ones((1, EMBED), dtype=np.float64))


def verify_module_multi(mw, arch, plans, session, teachers, fn_spans,
                        row_of, succ_rows, class_rows, production_dir):
    """模块级 rollout：逐函数全步动作字段对照（金标准 hashmix 同款）。"""
    # 修正:同 verify_module,neural/ 目录不在 sys.path。
    _neural_dir = os.path.normpath(os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "..", "neural"))
    if _neural_dir not in sys.path:
        sys.path.insert(0, _neural_dir)
    import neural_core as nc
    checks = {}

    def chk(name, ok, detail=""):
        checks[name] = (bool(ok), detail)

    chk("q_init_pm4", set(mw["q_init"].ravel().tolist()) <= {-4.0, 4.0})
    rq = mw["region_q"]
    chk("region_q_shape", rq.shape == (arch["region_entry_rows"], Q_DIM),
        str(rq.shape))
    chk("region_q_pm4", set(rq.ravel().tolist()) <= {-4.0, 4.0})
    row_bases = np.cumsum([0] + [e - s + 1 for s, e in fn_spans][:-1])
    chk("q_init_eq_region_q0_per_fn",
        all(np.array_equal(mw["q_init"][fi], rq[base])
            for fi, base in enumerate(row_bases)),
        str(row_bases.tolist()))

    bipolar = arch["slot_encoding"] != "categorical"
    ctrl = (nc.Controller(mw) if not bipolar else nc.ControllerV7(mw))
    enc, _ = _enc_dec(mw)
    token = enc(0)
    sentinel = arch["object_sentinel"]
    n_ok, n_tot, chain_ok = 0, 0, True
    rq_base = 0
    mism = []
    for fi, (s, e) in enumerate(fn_spans):
        p = plans[fi]
        fn_rq = rq[rq_base:rq_base + (e - s) + 1]
        for r in p["regions"]:
            start, count = s + r["action_start"], r["action_count"]
            q = fn_rq[r["action_start"]].copy()
            for t in range(start, start + count):
                th = teachers[t]
                cond = ctrl.refresh_condition(q, token)
                h = ctrl.forward(q, cond)
                act = decode_action_generic(h, arch, mw)
                ok_f = (act["read_a"] == th["read_a"]
                        and act["read_b"] == th["read_b"]
                        and act["read_c"] == th["read_c"]
                        and act["write"] == th["write"]
                        and act["input_layout"] == th["layout"]
                        and act["input_span"] == th["span"]
                        and act["lane_delta_a"] == th["lda"]
                        and act["lane_delta_b"] == th["ldb"]
                        and act["lane_delta_c"] == th["ldc"]
                        and act["source_width"] == th["sw"]
                        and act["target_width"] == th["target"]
                        and act["object_index"] == (-1 if th["obj"] == sentinel
                                                    else th["obj"])
                        and act["byte_offset"] == (
                            arch["byte_offsets"][th["bo"]])
                        and act["access_width"] == (
                            arch["access_widths"][th["aw"]])
                        and act["alignment"] == (
                            arch["alignments"][th["al"]]))
                option = h[arch["selector_heads"]:
                           arch["selector_heads"] + OPTION_DIM]
                prof = (nc.option_profile if not bipolar
                        else nc.option_profile_v2)
                en, route, fmt, aux, ct, eff = prof(mw, option)
                ok_o = (en == th["enabled"]
                        and int(np.argmax(eff)) == th["effect_channel"])
                if th["route"] is not None:
                    term, coef = nc.ragged_choose(
                        mw, np.asarray(route, float))
                    want = np.asarray(th["route"], float)
                    sg = 1.0 if session["signs"][th["base_op"]] > 0 else -1.0
                    ok_o = (ok_o
                            and np.array_equal(np.asarray(route, float),
                                               want)
                            and coef == sg
                            and term == session["term_ops"].index(
                                th["base_op"]))
                n_ok += int(ok_f and ok_o)
                n_tot += 1
                if not (ok_f and ok_o) and len(mism) < 3:
                    mism.append(f"fn={p['function']} t={t} "
                                f"op={p['steps'][t - s]['operation']}")
                q = np.where(
                    h[arch["selector_heads"] + OPTION_DIM:] >= 0,
                    4.0, -4.0)
                if t + 1 < start + count:
                    if not np.array_equal(q, fn_rq[t + 1 - s]):
                        chain_ok = False
        rq_base += (e - s) + 1
    chk("q_chain_continuity", chain_ok)
    chk("rollout_all_steps", n_ok == n_tot,
        f"{n_ok}/{n_tot}" + (f" first-mismatch: {mism}" if mism else ""))
    return (n_ok == n_tot and chain_ok and
            all(v[0] for k, v in checks.items()
                if k not in ("rollout_all_steps", "q_chain_continuity")),
            checks)


if __name__ == "__main__":
    main()
