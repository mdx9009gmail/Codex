#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ANANSI 任务 E：计划 → 运行时 profile 生成器。

输入：input.ll + module_plan.json + weight_composer 的 arch sidecar
     （composer 已定 selector_rank/term 顺序，保证两侧一致）
输出：profile.json（runtime_codegen --profile）+ tickets.json（区域票号）

boundary_cases 帧布局来自 instrument_ll.analyze（与 protect.py 的契约断言
同一实现）；常量按槽序小端展开（我方分配器保证常量连续占据低槽）。
eff 表与 t2 通道指派一致（ALU=0 兜底、LOAD=2、COPY=3→GUARD2）。

用法：
    python3 profile_gen.py --ll input.ll --plan module_plan.json \
        --arch arch.json --out profile.json --tickets tickets.json
"""

import argparse
import hashlib
import json
import os
import random
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))          # src-repro/
import instrument_ll as IL                          # noqa: E402
import plan_compiler as PC                          # noqa: E402
import weight_composer as WC                        # noqa: E402

PRODUCTION = WC.DEFAULT_PRODUCTION
T2_PROFILE_FIX = json.load(open(os.path.join(
    os.path.dirname(HERE), "runtime_codegen_data", "profile_fp32_t2.json")))

# eff 表 = t2 金标准 profile 的实测值（EFF_NOOP=3, EFF_GUARD2=7！COPY 语义
# 的效应通道是 7，NOOP 是 3 —— 不能想当然互换）。
EFF_T2 = {"EFF_NOOP": 3, "EFF_RENAME_A": 1, "EFF_RENAME_B": 5,
          "EFF_HALT": 6, "EFF_GUARD1": 4, "EFF_LOAD": 2, "EFF_GUARD2": 7}
# 与 eff 表一致的会话通道指派（新样例合成用）
SPRINT_CHANNELS = {"STORE": 4, "LOAD": 2, "COPY": 7, "TOKEN": 3,
                   "RENAME_A": 1, "RENAME_B": 5, "HALT": 6, "ALU": 0}


def gen_tags(seed):
    rng = random.Random(seed)
    h = lambda n: "%0*x" % (n, rng.getrandbits(4 * n))
    return {"TAG_W": h(12), "TAG_MOD": h(16), "TAG_IR": h(16), "TAG_K": h(12)}


def core_shape(op):
    z = np.load(os.path.join(PRODUCTION,
                             f"stable_{WC.OP_CORE[op]}_weights.npz"))
    return [int(z["w1"].shape[0]), int(z["w1"].shape[1]),
            int(z["w3"].shape[1]), int(z["rw1"].shape[1])]


def analyze_with_pc(text, fn, region_gaps=True):
    """instrument_ll.analyze 的扩展版：同时返回 PlanCompiler 内部对象。"""
    PC.parse_llvm_ir(text)               # FUNC_SIGS/STRUCT_TYPES 模块上下文
    fname, blocks, def_idx, end_idx, lines, _dl = IL.parse_function(text, fn)
    blocks_insts = [[inst for _, inst in b.items if inst is not None]
                    for b in blocks]
    pc = PC.PlanCompiler(fname, blocks_insts, region_gaps=region_gaps)
    pc.lower()
    pc.assign_slots()
    regions_json = pc.build_regions()
    specs, n_frame = IL.analyze(fname, blocks, region_gaps=region_gaps)
    return fname, pc, regions_json, specs, n_frame


def main():
    ap = argparse.ArgumentParser(description="任务 E profile 生成器")
    ap.add_argument("--ll", required=True)
    ap.add_argument("--plan", required=True)
    ap.add_argument("--arch", required=True,
                    help="weight_composer --arch-out 的 sidecar JSON")
    ap.add_argument("--out", required=True)
    ap.add_argument("--tickets", required=True)
    ap.add_argument("--function", default="main")
    ap.add_argument("--no-region-gaps", action="store_true",
                    help="与 plan_compiler 无 --region-gaps 的计划配套"
                         "（引擎多函数形态：区域间无哑索引）")
    ap.add_argument("--seed", type=int, default=None)
    args = ap.parse_args()

    plan = json.load(open(args.plan))
    arch = json.load(open(args.arch))
    if len(plan["plans"]) > 1:
        gen_module_profile(args)
        return
    plan0 = plan["plans"][0]

    text = open(args.ll).read()
    fname, pc, regions_json, specs, n_frame = analyze_with_pc(
        text, args.function, region_gaps=not args.no_region_gaps)
    if len(specs) != len(plan0["regions"]):
        raise SystemExit(f"profile_gen: {len(specs)} instrumented regions vs "
                         f"{len(plan0['regions'])} plan regions")

    seed = (args.seed if args.seed is not None else int(
        hashlib.sha256(open(args.plan, "rb").read()).hexdigest()[:12], 16))
    rng = random.Random(seed)
    tickets = {str(i): rng.getrandbits(63) for i in range(len(specs))}

    # ssa → 计划值键（pc.values 的 origin_inst.ssa 反查）。
    # 优先精确 ref 键（无后缀的主值），后缀综合值（:icmp:left-lt 等）
    # 不应覆盖主值 —— live_out 引用的是主值键。
    ssa_to_key = {}
    for k, v in pc.values.items():
        if v.origin_inst is None or not v.origin_inst.ssa:
            continue
        if k == v.origin_inst.ref:          # 精确主值键
            ssa_to_key[v.origin_inst.ssa] = k
        elif v.origin_inst.ssa not in ssa_to_key:
            ssa_to_key.setdefault(v.origin_inst.ssa, k)
    # 参数 live-in（origin_inst 为 None）：function:<fn>:arg:<i>
    # （多函数路径 gen_module_profile 同构）
    for i, (_ty, name) in enumerate(PC.FUNC_SIGS.get(args.function, [])):
        vk = f"function:{args.function}:arg:{i}"
        if vk in pc.values:
            ssa_to_key.setdefault(name, vk)
    slot_of = {k: v.slot for k, v in pc.values.items()}

    # ---- 常量（初始槽；我方分配器保证常量占据连续低槽 0..k-1） ----
    consts = sorted((v for v in plan0["initial_values"]
                     if v["kind"] == "constant"), key=lambda v: v["slot"])
    for i, v in enumerate(consts):
        if v["slot"] != i:
            raise SystemExit(f"profile_gen: constant slot gap at {i} "
                             f"(slot {v['slot']})")
    initial_constants, initial_widths = [], []
    for v in consts:
        w = v["logical_width"]
        nbytes = 1 if w <= 1 else (w + 7) // 8
        # const:ptr:0（constant_value=null）→ 全零（引擎实测，与
        # gen_module_profile 的多函数路径同构）
        cv = 0 if v["constant_value"] is None else \
            int(v["constant_value"])
        cv &= ((1 << (8 * nbytes)) - 1)
        initial_constants.append([(cv >> (8 * b)) & 0xff
                                  for b in range(nbytes)])
        initial_widths.append(w)

    # ---- 对象表 / LOAD 地址信息 ----
    objects = plan0["context"]["persistent_objects"]
    obj_index = {o["object_id"]: i for i, o in enumerate(objects)}
    object_table = []
    storage_offset = 0
    for o in objects:
        object_table.append({
            "storage_offset": storage_offset,
            "size_bytes": o["size_bytes"],
            "object_id_hash": int.from_bytes(
                hashlib.sha256(o["object_id"].encode()).digest()[:8],
                "little"),
        })
        storage_offset += o["size_bytes"]
    load_size_by_ptr = {}
    for s in plan0["steps"]:
        if s["action_kind"] == "memory":
            a = s["address"]
            load_size_by_ptr[a["pointer_reference"]] = PC.type_info(
                s["value_type_id"])[2]

    # ---- boundary_cases ----
    boundary_cases = []
    for sp, region in zip(specs, plan0["regions"]):
        case = {
            "ticket": tickets[str(sp.ridx)],
            "ptr_in": [], "scalar_in": [],
            "exec": [region["action_start"], region["action_count"]],
            "outs": [],
        }
        for ssa, frame_slot in sp.ptr_ins:
            alloca = pc.def_inst.get(ssa)
            if alloca is None or alloca.opcode != "alloca":
                raise SystemExit(f"profile_gen: ptr {ssa} not an alloca def")
            ref = alloca.ref
            if ref not in load_size_by_ptr:
                raise SystemExit(f"profile_gen: alloca {ref} never loaded?")
            case["ptr_in"].append({
                "frame": frame_slot,
                "object": obj_index[_object_id_for(pc, ref)],
                "off": 0, "size": load_size_by_ptr[ref]})
        for ssa, ty, frame_slot in sp.scalar_ins:
            key = ssa_to_key.get(ssa)
            if key is None:
                raise SystemExit(f"profile_gen: no value for scalar {ssa}")
            case["scalar_in"].append({
                "frame": frame_slot, "width": PC.type_info(ty)[1],
                "slot": slot_of[key]})
        for ssa, ty, frame_slot in sp.outs:
            key = ssa_to_key.get(ssa)
            if key is None:
                raise SystemExit(f"profile_gen: no value for out {ssa}")
            case["outs"].append({
                "frame": frame_slot, "width": PC.type_info(ty)[1],
                "slot": slot_of[key]})
        case["out"] = case["outs"][0] if case["outs"] else None
        boundary_cases.append(case)

    # head_offsets 补 option/q_next（t2 金标准 profile 形态；controller_step
    # 模板需要这两个偏移）
    head_dims = dict(arch["head_dims"])
    head_offsets = dict(arch["head_offsets"])
    head_dims["option"] = 64
    head_dims["q_next"] = 64
    head_offsets["option"] = arch["selector_heads"]
    head_offsets["q_next"] = arch["selector_heads"] + 64

    profile = {
        "tags": gen_tags(seed),
        "storage": "fp32",
        "v_slots": arch["v_slots"],
        "byte_offsets": arch.get("byte_offsets", [-1, 0]),
        "byte_offset_choices": arch.get("byte_offset_choices", 2),
        "alignments": arch.get("alignments", [0, 4]),
        "alignment_choices": arch.get("alignment_choices", 2),
        "access_widths": arch.get("access_widths", [0, 4]),
        "access_width_choices": arch.get("access_width_choices", 2),
        "controller_heads": arch["controller_heads"],
        "controller_hidden": arch.get("controller_hidden", 64),
        "selector_heads": arch["selector_heads"],
        "selector_rank": arch["selector_rank"],
        "slot_code_dim": arch["slot_code_dim"],
        "slot_choices": arch["slot_choices"],
        "lane_delta_choices": arch["lane_delta_choices"],
        "lane_deltas": ", ".join(str(d) for d in arch["lane_deltas"]),
        "option_hidden": arch["option_hidden"],
        "ragged_terms": arch["ragged_terms"],
        "region_entry_rows": arch["region_entry_rows"],
        "max_actions": arch["max_actions"],
        "head_dims": head_dims,
        "head_offsets": head_offsets,
        "width_values": arch.get("widths", [1, 32]),
        "eff": dict(EFF_T2),
        "call_end_ret": "uint64_t",
        "initial_constants": initial_constants,
        "initial_widths": initial_widths,
        "boundary_cases": boundary_cases,
        "self_test": False,
        "registry": dict(T2_PROFILE_FIX["registry"]),
        "absent_ids": list(T2_PROFILE_FIX["absent_ids"]),
        "ragged_shapes": [core_shape(op) for op in arch["term_ops"]],
        "objects": object_table,
        "module_persist_bytes": 1,
        "call_persist_bytes": storage_offset,
        "call_end_decode_slot": None,
        "id_remap": None,
    }
    json.dump(profile, open(args.out, "w"), indent=1)
    json.dump(tickets, open(args.tickets, "w"), indent=1)
    print(f"profile_gen: {len(specs)} regions, n_frame={n_frame}, "
          f"v_slots={arch['v_slots']}, max_actions={arch['max_actions']}, "
          f"rank={arch['selector_rank']}, terms={arch['term_ops']}",
          file=sys.stderr)


def _object_id_for(pc, alloca_ref):
    return pc.objects[alloca_ref]["object_id"]




# =========================================================================
# 多函数模式：module_plan(33 plans) + arch → 模块 profile + 多函数票表
# =========================================================================
def gen_module_profile(args):
    import instrument_ll as IL
    plan = json.load(open(args.plan))
    arch = json.load(open(args.arch))
    plans = plan["plans"]
    text = open(args.ll).read()

    seed = (args.seed if args.seed is not None else int(
        hashlib.sha256(open(args.plan, "rb").read()).hexdigest()[:12], 16))
    rng = random.Random(seed)

    functions = []
    manifest = []
    tags = gen_tags(seed)
    for p in plans:
        fn = p["function"]
        plan0 = p
        fname, pc, regions_json, specs, n_frame = analyze_with_pc(
            text, fn, region_gaps=False)
        if len(specs) != len(plan0["regions"]):
            raise SystemExit(
                f"profile_gen: {fn}: {len(specs)} instrumented regions vs "
                f"{len(plan0['regions'])} plan regions")
        tickets = {str(i): rng.getrandbits(63)
                   for i in range(len(specs))}

        ssa_to_key = {}
        for k, v in pc.values.items():
            if v.origin_inst is None or not v.origin_inst.ssa:
                continue
            if k == v.origin_inst.ref:
                ssa_to_key[v.origin_inst.ssa] = k
            elif v.origin_inst.ssa not in ssa_to_key:
                ssa_to_key.setdefault(v.origin_inst.ssa, k)
        # 参数 live-in（origin_inst 为 None）：function:<fn>:arg:<i>
        for i, (_ty, name) in enumerate(PC.FUNC_SIGS.get(fn, [])):
            vk = f"function:{fn}:arg:{i}"
            if vk in pc.values:
                ssa_to_key.setdefault(name, vk)
        slot_of = {k: v.slot for k, v in pc.values.items()}

        consts = sorted((v for v in plan0["initial_values"]
                         if v["kind"] == "constant"), key=lambda v: v["slot"])
        initial_constants, initial_widths = [], []
        for v in consts:
            w = v["logical_width"]
            nbytes = 1 if w <= 1 else (w + 7) // 8
            # const:ptr:0（constant_value=null）→ 全零 8 字节（引擎实测）
            cv = 0 if v["constant_value"] is None else \
                int(v["constant_value"])
            cv &= ((1 << (8 * nbytes)) - 1)
            initial_constants.append([(cv >> (8 * b)) & 0xff
                                      for b in range(nbytes)])
            initial_widths.append(w)

        objects = plan0["context"]["persistent_objects"]
        obj_index = {o["object_id"]: i for i, o in enumerate(objects)}
        object_table = []
        storage_offset = 0
        for o in objects:
            object_table.append({
                "storage_offset": storage_offset,
                "size_bytes": o["size_bytes"],
                "object_id_hash": int.from_bytes(
                    hashlib.sha256(o["object_id"].encode()).digest()[:8],
                    "little"),
            })
            storage_offset += o["size_bytes"]

        boundary_cases = []
        for sp, region in zip(specs, plan0["regions"]):
            case = {
                "ticket": tickets[str(sp.ridx)],
                "ptr_in": [], "scalar_in": [], "sync_out": [],
                "exec": [region["action_start"], region["action_count"]],
                "outs": [],
            }
            for ssa, slot, obj_id, size, wri in sp.syncs:
                ent = {
                    "frame": slot, "object": obj_index[obj_id],
                    "off": 0, "size": size}
                case["ptr_in"].append(ent)
                if wri:
                    case["sync_out"].append(ent)
            for ssa, ty, frame_slot in sp.scalar_ins:
                key = ssa_to_key.get(ssa)
                if key is None:
                    raise SystemExit(
                        f"profile_gen: {fn} no value for scalar {ssa}")
                case["scalar_in"].append({
                    "frame": frame_slot, "width": PC.type_info(ty)[1],
                    "slot": slot_of[key]})
            for ssa, ty, frame_slot in sp.outs:
                key = ssa_to_key.get(ssa)
                if key is None:
                    raise SystemExit(
                        f"profile_gen: {fn} no value for out {ssa}")
                case["outs"].append({
                    "frame": frame_slot, "width": PC.type_info(ty)[1],
                    "slot": slot_of[key]})
            case["out"] = case["outs"][0] if case["outs"] else None
            boundary_cases.append(case)

        head_dims = dict(arch["head_dims"])
        head_offsets = dict(arch["head_offsets"])
        head_dims["option"] = 64
        head_dims["q_next"] = 64
        head_offsets["option"] = arch["selector_heads"]
        head_offsets["q_next"] = arch["selector_heads"] + 64

        # ABI（call_begin 签名 + encoded-value 入槽）
        abi = []
        sig = PC.FUNC_SIGS.get(fn, [])
        for i, (ty, name) in enumerate(sig):
            is_ptr = ty in ("ptr", PC.PTR_TYPE_ID)
            vk = f"function:{fn}:arg:{i}"
            enc = None
            if not is_ptr:
                v = pc.values.get(vk)
                if v is not None and v.slot is not None:
                    enc = {"slot": v.slot, "width": PC.type_info(ty)[1]}
            abi.append({"index": i, "type": ty, "name": name,
                        "encoded": enc})

        functions.append({
            "function": fn,
            "tags": {"TAG_IR": "%016x" % rng.getrandbits(64),
                     "TAG_K": "%012x" % rng.getrandbits(48)},
            "v_slots": plan0["context"]["temp_slot_capacity"],
            "region_entry_rows": len(plan0["steps"]) + 1,
            "max_actions": len(plan0["steps"]),
            "objects": object_table,
            "object_count": len(objects),
            "call_persist_bytes": storage_offset,
            "initial_constants": initial_constants,
            "initial_widths": initial_widths,
            "abi_parameters": abi,
            "boundary_cases": boundary_cases,
            "n_frame": n_frame,
            # MAX_BYTES（引擎按计划最大值宽派生：t2 纯 i32 → 4；
            # 含 i64/ptr64 的函数 → 8；模板 uint8_t bytes[MAX_BYTES]
            # 与 word lane 都按此定容）
            "max_bytes": max(
                [4]
                + [(s["logical_width"] + 7) // 8
                   for s in plan0["steps"]]
                + [(v["logical_width"] + 7) // 8
                   for v in plan0["initial_values"]]
                + [(w + 7) // 8 for w in initial_widths]
                + [p["size"] for case in boundary_cases
                   for p in case["ptr_in"]]),
        })
        manifest.append({"function": fn,
                         "tag": functions[-1]["tags"]["TAG_IR"],
                         "tickets": tickets})

    head_dims = dict(arch["head_dims"])
    head_offsets = dict(arch["head_offsets"])
    head_dims["option"] = 64
    head_dims["q_next"] = 64
    head_offsets["option"] = arch["selector_heads"]
    head_offsets["q_next"] = arch["selector_heads"] + 64

    profile = {
        "mode": "module",
        "tags": tags,
        "storage": "fp32",
        "v_slots": arch["v_slots"],
        "byte_offsets": arch.get("byte_offsets", [-1, 0]),
        "byte_offset_choices": arch.get("byte_offset_choices", 2),
        "alignments": arch.get("alignments", [0, 4]),
        "alignment_choices": arch.get("alignment_choices", 2),
        "access_widths": arch.get("access_widths", [0, 4]),
        "access_width_choices": arch.get("access_width_choices", 2),
        "controller_heads": arch["controller_heads"],
        "controller_hidden": arch.get("controller_hidden", 64),
        "selector_heads": arch["selector_heads"],
        "selector_rank": arch["selector_rank"],
        "slot_code_dim": arch["slot_code_dim"],
        "slot_choices": arch["slot_choices"],
        "lane_delta_choices": arch["lane_delta_choices"],
        "lane_deltas": ", ".join(str(d) for d in arch["lane_deltas"]),
        "option_hidden": arch["option_hidden"],
        "ragged_terms": arch["ragged_terms"],
        "region_entry_rows": arch["region_entry_rows"],
        "max_actions": arch["max_actions"],
        "head_dims": head_dims,
        "head_offsets": head_offsets,
        "width_values": arch.get("widths", [1, 32]),
        "eff": dict(EFF_T2),
        "call_end_ret": "uint64_t",
        "module_persist_bytes": 1,
        "self_test": False,
        "registry": dict(T2_PROFILE_FIX["registry"]),
        "absent_ids": list(T2_PROFILE_FIX["absent_ids"]),
        "ragged_shapes": [core_shape(op) for op in arch["term_ops"]],
        "functions": functions,
    }
    json.dump(profile, open(args.out, "w"), indent=1)
    json.dump({"functions": manifest}, open(args.tickets, "w"), indent=1)
    print(f"profile_gen: module profile {len(functions)} functions → "
          f"{args.out}", file=sys.stderr)


def main_multi():
    ap = argparse.ArgumentParser(description="任务 E profile 生成器（多函数）")
    ap.add_argument("--ll", required=True)
    ap.add_argument("--plan", required=True)
    ap.add_argument("--arch", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--tickets", required=True,
                    help="多函数票表 manifest（instrument_ll --multi 用）")
    ap.add_argument("--seed", type=int, default=None)
    args = ap.parse_args()
    gen_module_profile(args)


if __name__ == "__main__":
    main()
