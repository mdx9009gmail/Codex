#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""plan_compiler.py 对两轮金标准 module_plan.json 的自动验收。

用法：python3 validate_against_gold.py
输出：每轮核心序列一致度 + 全字段等价判定。
"""
import json
import subprocess
import sys
import os

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, ".."))
R1 = os.path.join(ROOT, "artifacts/engine-trace/prot.build/run-6qdudb")
R2 = os.path.join(ROOT, "artifacts/engine-verify2/prot2.build/run-fL5D2U")

GOLD = {
    "round1": (os.path.join(R1, "input/program/input.ll"),
               "/tmp/nnobf-ir-compat-2210868245/input.ll",
               os.path.join(R1, "work/function_0/work/program/module_plan.json")),
    "round2": (os.path.join(R2, "input/program/input.ll"),
               "/tmp/nnobf-ir-compat-1242640673/input.ll",
               os.path.join(R2, "work/attempt_01/program/module_plan.json")),
}


def core(s):
    return (s["operation"], tuple(s["input_slots"]), s["output_slot"],
            s["origin_reference"])


def run(label, ll, ident, gold_path):
    out = f"/tmp/_{label}_plan.json"
    subprocess.run([sys.executable, os.path.join(HERE, "plan_compiler.py"),
                     ll, "--module-identifier", ident, "-o", out],
                    check=True)
    mine = json.load(open(out))
    gold = json.load(open(gold_path))
    gm, gg = mine["plans"][0], gold["plans"][0]
    mc, gc = [core(s) for s in gm["steps"]], [core(s) for s in gg["steps"]]
    n = sum(a == b for a, b in zip(mc, gc))
    print(f"[{label}] steps={len(gc)}  core-seq {n}/{len(gc)}"
          f" ({100.0 * n / max(len(gc), 1):.0f}%)")
    field_diffs = []
    for i, (a, b) in enumerate(zip(gm["steps"], gg["steps"])):
        for k in set(a) | set(b):
            if a.get(k) != b.get(k):
                field_diffs.append((i, k))
    print(f"[{label}] step 字段级差异: {len(field_diffs)} 处 {field_diffs[:8]}")
    for f in ("values", "initial_values", "regions", "boundary_values",
              "outputs", "inputs", "context", "tool_contracts", "types",
              "controller", "entry_action", "control_flow_kind"):
        if gm.get(f) != gg.get(f):
            print(f"[{label}] 字段 {f}: DIFF")
    same = json.dumps(gm, sort_keys=True) == json.dumps(gg, sort_keys=True)
    mod_same = json.dumps(mine, sort_keys=True) == json.dumps(gold,
                                                              sort_keys=True)
    print(f"[{label}] plan 全等: {same}   module 全等: {mod_same}")
    return n == len(gc)


if __name__ == "__main__":
    ok = True
    for label, (ll, ident, goldp) in GOLD.items():
        ok &= run(label, ll, ident, goldp)
    print("RESULT:", "PASS" if ok else "FAIL")
    sys.exit(0 if ok else 1)
