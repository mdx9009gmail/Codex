#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""circuit-v1 XOR 秘密共享 → 神经动作程序融合器（circuit-under-NN）。

把 AntiReverse circuit_v1 的混淆方法（XOR 秘密共享 + 分享域代数）移植到
ANANSI 计划层：module_plan.json 的数据值被拆成 N 份 XOR share，原计划的
整数运算改写为分享域构造（拆分/折叠/安全 AND/OR/掩码纹波进位加法器），
全部构造以普通计划步骤（ADD/AND/OR/XOR/SELECT/SHIFT/COPY/ICMP_ULT）
表达——由神经 Controller 在潜空间逐步重放执行，被保护区域内无原生
整数算术参与。这正是「circuit 混淆方法受到 NN 的保护」：share 域运算
本身就是被神经化的动作程序（对比 circuit_v1 原生形态：adapter.py 直接
发射明文 C 代码，share 代数暴露在原生指令层）。

变换契约（与 instrument_ll / profile_gen 的边界协议零扰动）：
  1. 区域数量/顺序/身份不变；每区域 live_in_values / live_out_values 的
     键集合与次序逐项保持（插桩器从 input.ll 独立重导出这些集合）。
  2. live-in/常量在槽位中保持明文（边界 sync/commit 与常量初始化直接
     读写）；拆分(split)步骤在区域内首用处发射，折叠(fold)步骤追加在
     区域末尾写回原键——边界解码读到的仍是明文真值。
  3. share/临时值只在区域内存活（跨区域值经 live-out 折叠 → 原生边界
     → live-in 再拆分，与既有同步语义一致）。
  4. 语义逐位保持：内置差分验证器（interpret_plan）对原计划与变换计划
     在随机输入上逐区域比对全部 live-out 与 STORE 序列。

分享域构造（宽度 w、share 数 N，代数逐条移植自 circuit_v1 adapter.py）：
  - XOR/NOT/SHL/LSHR/SELECT/COPY：GF(2)-线性 → 逐 share 精确（funnel
    移位两分量占位不相交 → OR≡XOR，严格线性）。
  - AND：secure-AND（交叉项 + 刷新掩码）——刷新掩码按构造实例派生
    （改进：circuit_v1 原实现按 share 对静态烘焙，重复使用同一掩码）。
  - OR：xor(xor(a,b), and(a,b))。
  - ADD/SUB（--arith masked）：Kogge-Stone 掩码进位加法器（circuit_v1
    的 _add/_neg/_sub 结构，全 share 域）；--arith fold（默认）：折叠
    输入 → 明文原步骤 → 再拆分（体积/类数预算友好，wbp 规模适用）。
  - 比较折叠：谓词（i1）本属公开量；ICMP_ULT 输入折叠后按原步骤执行。
  - 常量：按 circuit_v1 share_literal 拆成常量 share（c^m, m, ...）。

掩码派生与 circuit_v1 一致：sha256(VERSION \\0 seed \\0 label) 截断取宽。

用法：
    python3 circuit_share.py module_plan.json [-o OUT] [--shares 2|4|8]
        [--seed N] [--arith fold|masked] [--functions f1,f2|@file]
        [--nonce-mask] [--share-encode] [--no-verify] [-v]

protect.py 经 --guards ...xor-mask + --xor-shares N 激活（复用
wbp-anansi-link build_stub.sh 的 --guards 自由文本透传链路）；
--guards ...nonce-mask / ...share-encode 为 antireverse v0.2 新泳道
（consumer_fused_v1 / stateful_v34 方法移植，分别控制掩码的运行期派生与
share 的槽位驻留编码），均自动蕴含 xor-mask。
"""

import argparse
import copy
import hashlib
import json
import random
import sys
from collections import Counter

MASK_VERSION = "circuit-v1-0.5.0-alpha.1+anansi-nn"
PTR_TYPE_IDS = ("ptr", "ptr:as0:64")
SHARE_COUNTS = (2, 4, 8)


class CircuitShareError(RuntimeError):
    """The circuit share transform rejected or failed the plan."""


# ---------------------------------------------------------------------------
# 0. 类型 / 掩码 / 常量键
# ---------------------------------------------------------------------------
def type_info(type_id):
    """i1/i8/i16/i32/i64/ptr → (kind, bit_width)。与 plan_compiler 同构。"""
    if type_id in PTR_TYPE_IDS:
        return "pointer", 64
    if type_id == "i1":
        return "predicate", 1
    if type_id in ("i8", "i16", "i32", "i64"):
        return "integer", int(type_id[1:])
    raise CircuitShareError(f"type {type_id} outside circuit share subset")


def encoded_bytes(width):
    return 1 if width <= 1 else (width + 7) // 8


def mask(seed, label, width):
    """circuit_v1 _Emitter.mask 派生式：sha256(version\\0seed\\0label)。"""
    payload = f"{MASK_VERSION}\0{seed}\0{label}".encode("utf-8")
    value = int.from_bytes(hashlib.sha256(payload).digest()[:8], "big")
    return value & ((1 << width) - 1)


def const_key(width, value):
    return f"const:i{width}:{format(value & ((1 << width) - 1), 'x')}"


# ---------------------------------------------------------------------------
# 1. 计划中间模型
# ---------------------------------------------------------------------------
class _Val:
    __slots__ = ("key", "kind", "type_id", "constant_value",
                 "source_reference", "slot")

    def __init__(self, key, kind, type_id, constant_value=None,
                 source_reference=None):
        self.key = key
        self.kind = kind              # constant / live-in / ssa
        self.type_id = type_id
        self.constant_value = constant_value
        self.source_reference = source_reference
        self.slot = None

    def width(self):
        return type_info(self.type_id)[1]

    def to_json(self):
        kind, w = type_info(self.type_id)
        return {
            "key": self.key, "kind": self.kind,
            "type_kind": "pointer" if kind == "pointer" else "integer",
            "logical_width": w, "encoded_bytes": encoded_bytes(w),
            "type_id": self.type_id, "slot": self.slot,
            "constant_value": self.constant_value,
            "source_reference": self.source_reference, "abi_index": None,
        }


class _Step:
    __slots__ = ("origin_reference", "action_kind", "operation", "inputs",
                 "output", "source_type_id", "value_type_id", "address",
                 "metadata")

    def __init__(self, origin_reference, action_kind, operation, inputs,
                 output, source_type_id, value_type_id, metadata,
                 address=None):
        self.origin_reference = origin_reference
        self.action_kind = action_kind
        self.operation = operation
        self.inputs = list(inputs)
        self.output = output
        self.source_type_id = source_type_id
        self.value_type_id = value_type_id
        self.address = address
        self.metadata = metadata


def _step_from_json(s):
    return _Step(s["origin_reference"], s["action_kind"], s["operation"],
                 s["input_values"], s.get("output_value"),
                 s["source_type_id"], s["value_type_id"],
                 copy.deepcopy(s.get("metadata") or {}),
                 copy.deepcopy(s.get("address")))


def _step_to_json(idx, st, slots):
    src_w = type_info(st.source_type_id)[1]
    val_kind, val_w = type_info(st.value_type_id)
    return {
        "index": idx,
        "origin_reference": st.origin_reference,
        "action_kind": st.action_kind,
        "operation": st.operation,
        "input_values": list(st.inputs),
        "input_slots": [slots[k] for k in st.inputs],
        "output_value": st.output,
        "output_slot": slots[st.output] if st.output else None,
        "source_type_id": st.source_type_id,
        "source_width": src_w,
        "value_type_id": st.value_type_id,
        "type_kind": "pointer" if val_kind == "pointer" else "integer",
        "logical_width": val_w,
        "address": st.address,
        "metadata": st.metadata,
        "next_action": None, "true_action": None, "false_action": None,
        "next_slot_renames": [], "true_slot_renames": [],
        "false_slot_renames": [],
    }


class _RegionState:
    """区域内的表示簿记（share 不跨区域）。

    不变式：键被「明文定义」（原步骤写原键）→ 进 plain、退出 shares；
    被「share 定义」（构造写 share 键）→ 进 shares、退出 plain。多写键
    （微程序原位更新）由此自动获得逐定义失效的语义。
    """
    __slots__ = ("shares", "plain")

    def __init__(self):
        self.shares = {}     # 原键 -> [share 键]
        self.plain = set()   # 原键：本槽位持有明文（live-in/常量/明文定义）


# ---------------------------------------------------------------------------
# 2. 变换器
# ---------------------------------------------------------------------------
class _Transformer:
    def __init__(self, fn, values, orig_steps, regions, shares, seed, arith,
                 always_plain=(), nonce_mask=False, share_encode=False):
        self.fn = fn
        self.values = values            # key -> _Val（含新增）
        self.orig_steps = orig_steps    # [_Step]
        self.regions = regions          # [dict]（保留原字段）
        self.shares = shares
        self.seed = seed
        self.arith = arith
        self.always_plain = set(always_plain)
        self.nonce_mask = nonce_mask
        self.share_encode = share_encode
        self.steps = []                 # 新步骤序列
        self._seq = 0
        self._cshare_cache = {}         # 常量键 -> [share 常量键]
        # nonce-mask（consumer_fused_v1 方法移植）：区域级 nonce/basis 缓存
        # （惰性派生：首个掩码请求时从 integer live-in ∪ 区域 LOAD 输出）
        self._nonce32 = None            # 本区域 nonce 键（None=未派生/回退）
        self._nonce_failed = False      # 已尝试且无源（静态回退）
        self._region_loads = []         # 区域内 integer LOAD 输出（nonce 源）
        self._cur_live_ins = []         # 当前区域 live-in 键
        self._nonce_w_cache = {}        # width -> COPY(nonce→i{w}) 键
        self._basis_cache = {}          # (basis_index, width) -> basis 键
        self.nonce_fallback_regions = 0
        # share-encode（stateful_v34 方法移植）：区域级解码缓存 + 参数缓存
        self._dec_cache = {}            # tuple(share 键) -> [raw share 键]
        self._enc_ridx = 0
        self._enc_param_cache = {}      # (ridx, share_index, width) -> (d, salt, A)
        defs = Counter(s.output for s in orig_steps if s.output)
        self.multi_writer = {k for k, c in defs.items() if c > 1}

    # ---- 基础发射 -------------------------------------------------------
    def _new_key(self, base):
        self._seq += 1
        return f"{base}:cx{self._seq}"

    def _reg(self, key, kind, type_id, constant_value=None,
             source_reference=None):
        if key in self.values:
            return self.values[key]
        v = _Val(key, kind, type_id, constant_value, source_reference)
        self.values[key] = v
        return v

    def _const(self, width, value):
        key = const_key(width, value)
        self._reg(key, "constant", f"i{width}",
                  value & ((1 << width) - 1), key)
        return key

    def _mask_const(self, label, width):
        return self._const(width, mask(self.seed, label, width))

    # ---- nonce-mask：运行期掩码派生（consumer_fusion input-mix 移植） ----
    def _region_begin(self, ridx, r):
        """区域开始：重置区域级缓存（nonce 惰性派生——首个掩码需求时
        才发链，避免无 share 区域的死步骤）。"""
        self._dec_cache = {}
        self._nonce32 = None
        self._nonce_failed = False
        self._region_loads = []
        self._cur_live_ins = list(r["live_in_values"])
        self._nonce_w_cache = {}
        self._basis_cache = {}
        self._enc_ridx = ridx
        self._enc_param_cache = {}

    def _ensure_nonce(self):
        """惰性 nonce 派生：integer live-in（区域入口可用）∪ 区域内已
        定义的 integer LOAD 输出（运行时内存值——金标/wbp 区域常仅有
        指针 live-in，数据经 LOAD 进入，恰为 input-mix 的输入分量）。
        无源 → 标记失败（静态回退，仅对实际请求掩码的区域计数）。"""
        if self._nonce32 is not None or self._nonce_failed:
            return self._nonce32
        if not self.nonce_mask:
            self._nonce_failed = True
            return None
        ints = []
        for k in list(self._cur_live_ins) + list(self._region_loads):
            v = self.values.get(k)
            if v is None:
                continue
            kind, w = type_info(v.type_id)
            if kind == "integer" and w >= 8:
                ints.append(k)
            if len(ints) >= 4:
                break
        if not ints:
            self._nonce_failed = True
            self.nonce_fallback_regions += 1
            return None
        cur = None
        for k in ints:
            tid = self.values[k].type_id
            ck = self._new_key("circuit:nonce")
            self._reg(ck, "ssa", "i32", None, "circuit:nonce")
            self._emit("COPY", [k], ck, tid, "i32",
                       self._md("nonce-in", 32, {"nonce_of": k}),
                       action_kind="layout")
            if cur is None:
                cur = ck
                continue
            nk = self._new_key("circuit:nonce")
            self._reg(nk, "ssa", "i32", None, "circuit:nonce")
            self._emit("XOR", [cur, ck], nk, "i32", "i32",
                       self._md("nonce-mix", 32))
            cur = nk
        self._nonce32 = cur
        return cur

    def _nonce_w(self, width):
        """nonce 的 width 视图：COPY(nonce32→i{w})（区域级缓存）。"""
        if width in self._nonce_w_cache:
            return self._nonce_w_cache[width]
        tid = f"i{width}"
        ck = self._new_key("circuit:nonce")
        self._reg(ck, "ssa", tid, None, "circuit:nonce")
        self._emit("COPY", [self._nonce32], ck, "i32", tid,
                   self._md("nonce-w", width), action_kind="layout")
        self._nonce_w_cache[width] = ck
        return ck

    def _lane_rot(self, key, delta, width, tid):
        """真字节旋转：OR(x, x, lda=delta, ldb=delta-lanes)——两个补零
        移位的并恰为 rotate（route 单用是移位、越界字节丢失，编码不可
        逆的根因）；delta=0 恒等直通。"""
        if delta == 0:
            return key
        lanes = encoded_bytes(width)
        d = delta % lanes
        if d == 0:
            return key
        nk = self._new_key("circuit:rot")
        self._reg(nk, "ssa", tid, None, "circuit:rot")
        self._emit("OR", [key, key], nk, tid, tid,
                   self._md("rot", width,
                            {"input_layout": "binary-lanes",
                             "lane_delta_a": d,
                             "lane_delta_b": d - lanes,
                             "lane_delta_c": 0}))
        return nk

    def _basis(self, basis_index, width):
        """掩码基：XOR(nonce_w, rot(nonce_w, d)) ^ basis_label——w>32 时
        d=lanes//2 把 32 位 nonce 铺到高位字节。区域级缓存。"""
        ck = (basis_index, width)
        if ck in self._basis_cache:
            return self._basis_cache[ck]
        tid = f"i{width}"
        n = self._nonce_w(width)
        lanes = encoded_bytes(width)
        if lanes > 1:
            if width > 32:
                d = lanes // 2
            else:
                d = 1 + (mask(self.seed, f"basis-rot:{basis_index}:{width}", 8)
                         % (lanes - 1))
            r = self._lane_rot(n, d, width, tid)
            x = self._new_key("circuit:basis")
            self._reg(x, "ssa", tid, None, "circuit:basis")
            self._emit("XOR", [n, r], x, tid, tid,
                       self._md("basis-spread", width))
        else:
            x = n
        lab = self._const(width, mask(self.seed,
                                      f"basis:{basis_index}:{width}", width))
        bk = self._new_key("circuit:basis")
        self._reg(bk, "ssa", tid, None, "circuit:basis")
        self._emit("XOR", [x, lab], bk, tid, tid,
                   self._md("basis", width, {"basis_index": basis_index}))
        self._basis_cache[ck] = bk
        return bk

    def _mask_key(self, label, width, basis_index=0):
        """掩码键双路径：nonce 激活（惰性确保）→ 运行期
        XOR(basis, site_const)；否则（含区域回退）→ v0.1 静态常量
        （同 mask(seed,label,w)）。"""
        if self._ensure_nonce() is None:
            return self._mask_const(label, width)
        tid = f"i{width}"
        basis = self._basis(basis_index, width)
        site = mask(self.seed, label, width)
        if site == 0:
            return basis
        site_k = self._const(width, site)
        nk = self._new_key("circuit:nmask")
        self._reg(nk, "ssa", tid, None, f"{label}:circuit:nmask")
        self._emit("XOR", [basis, site_k], nk, tid, tid,
                   self._md("nonce-mask", width, {"label": label}))
        return nk

    # ---- share-encode：槽位驻留编码（stateful_v34 storage-plan 移植） ----
    def _enc_param(self, share_index, width):
        """(d_i, salt_i, A_i) per (区域, share 序号, 宽度)——seed 派生
        （对齐 v34 _storage_plan(seed)：rotate 1..lanes-1、salt 全宽、
        additive |= 1）。"""
        ck = (self._enc_ridx, share_index, width)
        if ck in self._enc_param_cache:
            return self._enc_param_cache[ck]
        lanes = encoded_bytes(width)
        tag = f"{self.fn}:enc:{self._enc_ridx}:{share_index}:{width}"
        d = 1 + (mask(self.seed, f"{tag}:rot", 8)
                 % max(lanes - 1, 1)) if lanes > 1 else 0
        salt = mask(self.seed, f"{tag}:salt", width)
        add = mask(self.seed, f"{tag}:add", width) | 1
        self._enc_param_cache[ck] = (d, salt, add)
        return self._enc_param_cache[ck]

    def _enc_sh(self, raw_shs):
        """编码：enc_i = rot_lanes(sh_i ^ salt_i, d_i) + A_i（3 步/share）。"""
        outs = []
        for i, shk in enumerate(raw_shs):
            v = self.values[shk]
            w = v.width()
            tid = v.type_id
            d, salt, add = self._enc_param(i, w)
            x = self._new_key("circuit:enc")
            self._reg(x, "ssa", tid, None, "circuit:enc")
            self._emit("XOR", [shk, self._const(w, salt)], x, tid, tid,
                       self._md("enc-salt", w, {"enc_share": i}))
            r = self._lane_rot(x, d, w, tid)
            ek = self._new_key("circuit:enc")
            self._reg(ek, "ssa", tid, None, "circuit:enc")
            self._emit("ADD", [r, self._const(w, add)], ek, tid, tid,
                       self._md("enc-add", w, {"enc_share": i}))
            outs.append(ek)
        return outs

    def _dec_sh(self, enc_shs):
        """解码：sh_i = ror_lanes(enc_i - A_i, d_i) ^ salt_i（区域级缓存：
        同一 share 向量只解码一次，多消费者复用 raw 键）。"""
        ck = tuple(enc_shs)
        if ck in self._dec_cache:
            return self._dec_cache[ck]
        outs = []
        for i, ek in enumerate(enc_shs):
            v = self.values[ek]
            w = v.width()
            tid = v.type_id
            d, salt, add = self._enc_param(i, w)
            y = self._new_key("circuit:dec")
            self._reg(y, "ssa", tid, None, "circuit:dec")
            self._emit("SUB", [ek, self._const(w, add)], y, tid, tid,
                       self._md("dec-sub", w, {"enc_share": i}))
            r = self._lane_rot(y, -d, w, tid)
            sk = self._new_key("circuit:dec")
            self._reg(sk, "ssa", tid, None, "circuit:dec")
            self._emit("XOR", [r, self._const(w, salt)], sk, tid, tid,
                       self._md("dec-salt", w, {"enc_share": i}))
            outs.append(sk)
        self._dec_cache[ck] = outs
        return outs

    def _emit(self, operation, inputs, output, src_tid, val_tid, metadata,
              action_kind="tool", origin=None, address=None):
        self._seq += 1
        st = _Step(origin or f"circuit:{self.fn}:cx{self._seq}",
                   action_kind, operation, inputs, output, src_tid, val_tid,
                   metadata, address)
        self.steps.append(st)
        return st

    def _md(self, stage, source_width, extra=None):
        md = {"derived_from": "circuit-v1", "stage": stage,
              "source_width": source_width}
        if extra:
            md.update(extra)
        return md

    def _copy_step(self, s, inputs=None):
        st = _Step(s.origin_reference, s.action_kind, s.operation,
                   list(inputs) if inputs is not None else list(s.inputs),
                   s.output, s.source_type_id, s.value_type_id, s.metadata,
                   s.address)
        self.steps.append(st)
        return st

    # ---- 表示视图 -------------------------------------------------------
    def _is_plain(self, key, st):
        if key in st.plain or key in self.always_plain:
            return True
        return self.values[key].kind == "constant"

    def _shared_view(self, key, st):
        """key 的 share 表示（常量→常量 share；明文→区域拆分）。
        share_encode：st.shares 恒存编码态——取出即解码（raw 供代数）。"""
        if key in st.shares:
            shs = st.shares[key]
            if self.share_encode:
                return self._dec_sh(shs)
            return shs
        v = self.values[key]
        if v.kind == "constant":
            return self._const_shares(key)
        if self._is_plain(key, st):
            return self._split(key, st)
        raise CircuitShareError(
            f"{self.fn}: value {key} has neither shared nor plain form")

    def _plain_view(self, key, st):
        """key 的明文表示（明文→自身；share→折叠临时）。"""
        if self._is_plain(key, st):
            return key
        if key in st.shares:
            shs = st.shares[key]
            if self.share_encode:
                shs = self._dec_sh(shs)
            return self._fold(shs, f"{key}:plain")
        raise CircuitShareError(
            f"{self.fn}: value {key} has neither plain nor shared form")

    def _const_shares(self, ck):
        """常量 share（circuit_v1 share_literal）：{c^m1^.., m1, ..}。"""
        if ck in self._cshare_cache:
            return self._cshare_cache[ck]
        v = self.values[ck]
        w = v.width()
        c = int(v.constant_value)
        mask_keys = [self._mask_const(f"{ck}:share:{i}", w)
                     for i in range(1, self.shares)]
        combined = 0
        for m in mask_keys:
            combined ^= self.values[m].constant_value
        out = [self._const(w, c ^ combined)] + mask_keys
        self._cshare_cache[ck] = out
        return out

    def _split(self, key, st):
        """区域拆分：sh0 = XOR(key, m1^..^m_{N-1})；sh_i = m_i。
        nonce_mask：m_i 为运行期步骤值（basis^site，非计划常量）；
        share_encode：入册为编码态、返回 raw（消费方视图恒 raw——
        与 _shared_view 的 st.shares 解码路径一致）。"""
        v = self.values[key]
        w = v.width()
        if self._ensure_nonce() is not None:
            mask_keys = [self._mask_key(f"{key}:share:{i}", w, i - 1)
                         for i in range(1, self.shares)]
            cur = mask_keys[0]
            for mk in mask_keys[1:]:
                cur = self._emit_xor(cur, mk, f"{key}:xsp", w, v.type_id)
            first = self._new_key(f"{key}:xsp")
            self._reg(first, "ssa", v.type_id, None, f"{key}:circuit:split")
            self._emit("XOR", [key, cur], first, v.type_id, v.type_id,
                       self._md("split", w, {"share_of": key, "nonce": True}))
            out = [first] + mask_keys
        else:
            mask_keys = [self._mask_const(f"{key}:share:{i}", w)
                         for i in range(1, self.shares)]
            combined = 0
            for m in mask_keys:
                combined ^= self.values[m].constant_value
            first = self._new_key(f"{key}:xsp")
            self._reg(first, "ssa", v.type_id, None, f"{key}:circuit:split")
            self._emit("XOR", [key, self._const(w, combined)], first,
                       v.type_id, v.type_id,
                       self._md("split", w, {"share_of": key}))
            out = [first] + mask_keys
        st.shares[key] = self._enc_sh(out) if self.share_encode else out
        return out

    def _fold(self, share_keys, base):
        """折叠：XOR 链 → 明文临时键。"""
        tid = self.values[share_keys[0]].type_id
        w = self.values[share_keys[0]].width()
        cur = share_keys[0]
        for i in range(1, len(share_keys)):
            nxt = self._new_key(f"{base}:xfld")
            self._reg(nxt, "ssa", tid, None, f"{base}:circuit:fold")
            self._emit("XOR", [cur, share_keys[i]], nxt, tid, tid,
                       self._md("fold", w, {"fold_of": base}))
            cur = nxt
        return cur

    def _fold_into(self, key, st):
        """折叠 share → 原键 key（区域 live-out 提交；单一写者）。
        share_encode：入册为编码态，折叠前先解码。"""
        v = self.values[key]
        tid = v.type_id
        w = v.width()
        shs = st.shares[key]
        if self.share_encode:
            shs = self._dec_sh(shs)
        cur = shs[0]
        rest = shs[1:]
        for i, shk in enumerate(rest):
            if i == len(rest) - 1:
                target = key
            else:
                target = self._new_key(f"{key}:xfld")
                self._reg(target, "ssa", tid, None, f"{key}:circuit:fold")
            self._emit("XOR", [cur, shk], target, tid, tid,
                       self._md("fold-out", w, {"fold_of": key}))
            cur = target
        st.shares.pop(key, None)
        st.plain.add(key)

    # ---- 分享域代数 -----------------------------------------------------
    def _xor_sh(self, a_sh, b_sh, out_key, w, tid):
        outs = []
        for i in range(self.shares):
            nk = self._new_key(f"{out_key}:xsh")
            self._reg(nk, "ssa", tid, None, f"{out_key}:circuit:xor")
            self._emit("XOR", [a_sh[i], b_sh[i]], nk, tid, tid,
                       self._md("xor-share", w, {"share_of": out_key}))
            outs.append(nk)
        return outs

    def _secure_and(self, a_sh, b_sh, out_key, w, tid):
        """circuit_v1 _and：逐 share AND + 成对交叉项 + 刷新掩码。

        折叠和 = Σ_{i,j}(a_i&b_j) = a&b（交叉项恰补 i≠j 对）；刷新掩码
        按构造实例派生（改进 circuit_v1 的静态 per-pair 烘焙）。"""
        n = self.shares
        cur = []
        for i in range(n):
            if a_sh[i] == b_sh[i]:
                cur.append(a_sh[i])          # x & x = x（零步）
                continue
            nk = self._new_key(f"{out_key}:and")
            self._reg(nk, "ssa", tid, None, f"{out_key}:circuit:and")
            self._emit("AND", [a_sh[i], b_sh[i]], nk, tid, tid,
                       self._md("and-share", w, {"share_of": out_key}))
            cur.append(nk)
        instance = self._seq
        for left in range(n):
            for right in range(left + 1, n):
                # nonce_mask：刷新掩码同样运行期派生（nonce 链上 site 常量）
                r = self._mask_key(
                    f"{self.fn}:{out_key}:refresh:{instance}:{left}:{right}",
                    w, 0)
                cross = []
                for a_k, b_k in ((a_sh[left], b_sh[right]),
                                 (a_sh[right], b_sh[left])):
                    if a_k == b_k:
                        cross.append(a_k)
                        continue
                    tk = self._new_key(f"{out_key}:and")
                    self._reg(tk, "ssa", tid, None, f"{out_key}:circuit:and")
                    self._emit("AND", [a_k, b_k], tk, tid, tid,
                               self._md("and-cross", w))
                    cross.append(tk)
                u = cross[0]
                for ck in cross[1:]:
                    uk = self._new_key(f"{out_key}:xor")
                    self._reg(uk, "ssa", tid, None, f"{out_key}:circuit:xor")
                    self._emit("XOR", [u, ck], uk, tid, tid,
                               self._md("and-cross-xor", w))
                    u = uk
                r2 = self._new_key(f"{out_key}:xor")
                self._reg(r2, "ssa", tid, None, f"{out_key}:circuit:xor")
                self._emit("XOR", [r, u], r2, tid, tid,
                           self._md("and-refresh", w))
                cur[right] = self._emit_xor(cur[right], r2,
                                            f"{out_key}:and", w, tid)
                cur[left] = self._emit_xor(cur[left], r,
                                           f"{out_key}:and", w, tid)
        return cur

    def _emit_xor(self, x, y, base, w, tid):
        nk = self._new_key(base)
        self._reg(nk, "ssa", tid, None, f"{base}:circuit:xor")
        self._emit("XOR", [x, y], nk, tid, tid, self._md("xor", w))
        return nk

    def _secure_or(self, a_sh, b_sh, out_key, w, tid):
        """or = xor(xor(a,b), and(a,b))（circuit_v1 _or）。"""
        x_sh = self._xor_sh(a_sh, b_sh, f"{out_key}:orx", w, tid)
        g_sh = self._secure_and(a_sh, b_sh, f"{out_key}:org", w, tid)
        return self._xor_sh(x_sh, g_sh, f"{out_key}:oro", w, tid)

    def _not_sh(self, a_sh, w, tid):
        """~(a0^a1^..) = ~a0 ^ a1 ^ ..（仅 share0 取反，1 步）。"""
        full = self._const(w, (1 << w) - 1)
        nk = self._new_key("circuit:not")
        self._reg(nk, "ssa", tid, None, "circuit:not")
        self._emit("XOR", [a_sh[0], full], nk, tid, tid,
                   self._md("not-share", w))
        return [nk] + list(a_sh[1:])

    def _shift_fixed_sh(self, x_sh, amount, direction, w, tid):
        """逐 share 常量移位（复刻 plan_compiler._lower_shift 的 funnel
        形态：r=0 → byte-route OR；r>0 → funnel 链（档 1/2/4，首档吸收
        车道偏移）；尾随 AND 掩码）。

        funnel 语义 per lane：out = (A<<s)|(B>>(8-s))——两分量占位不相交
        → OR≡XOR → 对 XOR 分享严格线性 → 逐 share 精确。"""
        lanes = encoded_bytes(w)
        delta = -1 if direction == "shl" else 1
        operation = "SHIFT_SHL" if direction == "shl" else "SHIFT_LSHR"
        q, r = amount >> 3, amount & 7
        outs = []
        for shk in x_sh:
            cur = shk
            if r == 0:
                zero = self._const(w, 0)
                nk = self._new_key("circuit:shift")
                self._reg(nk, "ssa", tid, None, "circuit:shift")
                self._emit("OR", [cur, zero], nk, tid, tid,
                           self._md("shift-byte-route", w,
                                    {"input_layout": "binary-lanes",
                                     "lane_delta_a": q * delta,
                                     "lane_delta_b": 0, "lane_delta_c": 0}))
                cur = nk
            else:
                first = True
                for s in (1, 2, 4):
                    if not (r & s):
                        continue
                    if first:
                        da, db = q * delta, (q + 1) * delta
                        first = False
                    else:
                        da, db = 0, delta
                    funnel = self._const(w, int("%02x" % s * lanes, 16))
                    nk = self._new_key("circuit:shift")
                    self._reg(nk, "ssa", tid, None, "circuit:shift")
                    self._emit(operation, [cur, cur, funnel], nk, tid, tid,
                               self._md(f"shift-funnel:{s}", w,
                                        {"input_layout": "ternary-lanes",
                                         "lane_delta_a": da,
                                         "lane_delta_b": db,
                                         "lane_delta_c": 0}))
                    cur = nk
            maskc = self._const(w, (1 << w) - 1)
            yk = self._new_key("circuit:shift")
            self._reg(yk, "ssa", tid, None, "circuit:shift")
            self._emit("AND", [cur, maskc], yk, tid, tid,
                       self._md("shift-mask", w))
            outs.append(yk)
        return outs

    def _masked_add(self, a_sh, b_sh, out_key, w, tid):
        """circuit_v1 _add：Kogge-Stone 掩码进位加法器（全 share 域）。

        sum=a^b; gen=a&b; 每 shift 档（1,2,4..<w）：
        bridge=and(prop, shl(gen,k)); gen=or(gen,bridge);
        prop=and(prop, shl(prop,k))；返回 xor(sum, shl(gen,1))。"""
        sum_sh = self._xor_sh(a_sh, b_sh, f"{out_key}:sum", w, tid)
        gen_sh = self._secure_and(a_sh, b_sh, f"{out_key}:gen", w, tid)
        prop_sh = list(sum_sh)
        k = 1
        while k < w:
            sgen = self._shift_fixed_sh(gen_sh, k, "shl", w, tid)
            bridge = self._secure_and(prop_sh, sgen,
                                      f"{out_key}:bridge{k}", w, tid)
            gen_sh = self._secure_or(gen_sh, bridge,
                                     f"{out_key}:gen{k}", w, tid)
            sprop = self._shift_fixed_sh(prop_sh, k, "shl", w, tid)
            prop_sh = self._secure_and(prop_sh, sprop,
                                       f"{out_key}:prop{k}", w, tid)
            k *= 2
        final = self._shift_fixed_sh(gen_sh, 1, "shl", w, tid)
        return self._xor_sh(sum_sh, final, f"{out_key}:res", w, tid)

    def _masked_sub(self, a_sh, b_sh, out_key, w, tid):
        """sub = add(a, neg(b))；neg = add(not(b), 1)（circuit_v1 _neg/_sub）。"""
        not_sh = self._not_sh(b_sh, w, tid)
        one = self._const(w, 1)
        one_sh = self._const_shares(one)
        neg_sh = self._masked_add(not_sh, one_sh, f"{out_key}:neg", w, tid)
        return self._masked_add(a_sh, neg_sh, f"{out_key}:res", w, tid)

    # ---- 步骤分派 -------------------------------------------------------
    def _def_plain(self, out, st):
        """明文定义原键 out：进 plain、退出 shares（多写兼容）。"""
        st.shares.pop(out, None)
        st.plain.add(out)

    def _def_shared(self, out, shares, st):
        """share 定义原键 out（代数输出为 raw）：share_encode 时以
        编码态入册。"""
        st.plain.discard(out)
        if self.share_encode:
            shares = self._enc_sh(shares)
        st.shares[out] = shares

    def _def_shared_enc(self, out, enc_shares, st):
        """编码态 share 直接入册（COPY-share 传播：编码值的 COPY 仍是
        编码值——省去解/再编一对）。"""
        st.plain.discard(out)
        st.shares[out] = enc_shares

    def _shareable(self, s):
        kind, w = type_info(s.source_type_id)
        return kind == "integer" and w >= 8

    def _copy_plain(self, s, st):
        """原步骤保留（输入折叠到明文视图），输出按明文定义。"""
        inputs = [self._plain_view(k, st) for k in s.inputs]
        self._copy_step(s, inputs=inputs)
        if s.output:
            self._def_plain(s.output, st)

    def _transform_step(self, s, st):
        op = s.operation
        out = s.output
        src_w = type_info(s.source_type_id)[1]
        tid = s.source_type_id

        if op == "STORE":
            folded = [self._plain_view(k, st) for k in s.inputs]
            self._copy_step(s, inputs=folded)
            return
        if op == "LOAD":
            self._copy_step(s)
            if out:
                self._def_plain(out, st)
                # nonce 源记账：integer LOAD 输出（运行时内存值——
                # 无 integer live-in 区域的 nonce 输入分量）
                v = self.values.get(out)
                if v is not None:
                    kind, w = type_info(v.type_id)
                    if kind == "integer" and w >= 8:
                        self._region_loads.append(out)
            return
        if op == "COPY":
            src = s.inputs[0]
            if self._shareable(s) and src in st.shares:
                # share_encode：同宽 COPY 传播编码态（编码值 COPY 仍是编码
                # 值，直通入册省一对解/编）；**宽度变化 COPY（trunc/zext）**
                # 必须解码→COPY→按目标宽度重编——XOR 与截断可交换
                # （mask(sh0)^mask(sh1)=mask(sh0^sh1)），代数保持；直接传播
                # 会用源宽参数编码的值被目标宽参数解码（参数错配，wbp
                # compute_env_hash 差分失败根因）
                same_type = s.source_type_id == s.value_type_id
                if self.share_encode and not same_type:
                    raw = self._dec_sh(st.shares[src])
                else:
                    raw = st.shares[src]
                outs = []
                for shk in raw:
                    nk = self._new_key(f"{out}:xcopy")
                    self._reg(nk, "ssa", s.value_type_id, None,
                              f"{out}:circuit:copy")
                    self._emit("COPY", [shk], nk, s.source_type_id,
                               s.value_type_id,
                               self._md("copy-share", src_w,
                                        {"share_of": out}),
                               action_kind="layout")
                    outs.append(nk)
                if self.share_encode and same_type:
                    self._def_shared_enc(out, outs, st)
                else:
                    self._def_shared(out, outs, st)
            else:
                self._copy_plain(s, st)
            return

        if not self._shareable(s):
            # i1 谓词代数 / 指针：原样（谓词本属公开量）
            self._copy_plain(s, st)
            return

        if op == "XOR":
            # XOR 与 lane 路由可交换：逐 share 步骤携带原路由元数据即精确
            # （常量按未路由值取常量 share，由步骤的 ldb 完成路由）。
            a, b = s.inputs
            a_sh = self._shared_view(a, st)
            b_sh = self._shared_view(b, st)
            self._def_shared(
                out, self._per_share_linear("XOR", a_sh, b_sh, out,
                                            src_w, tid, s.metadata), st)
            return

        if op == "AND":
            a, b = s.inputs
            md = s.metadata
            bv = self.values[b]
            av = self.values[a]
            if av.kind == "constant" and int(av.constant_value) == 0 \
                    or bv.kind == "constant" and int(bv.constant_value) == 0:
                # and(x, 0) = 0（路由无关）
                self._def_shared(out, self._const_shares(self._const(
                    src_w, 0)), st)
                return
            if bv.kind == "constant" \
                    and int(bv.constant_value) == (1 << src_w) - 1:
                # 全 1 掩码恒等：R(1s)=1s → 逐 share AND 精确（shift 尾掩码）
                a_sh = self._shared_view(a, st)
                ones = [b] * self.shares
                self._def_shared(
                    out, self._per_share_linear("AND", a_sh, ones, out,
                                                src_w, tid, md), st)
                return
            if av.kind == "constant" \
                    and int(av.constant_value) == (1 << src_w) - 1:
                b_sh = self._shared_view(b, st)
                ones = [a] * self.shares
                self._def_shared(
                    out, self._per_share_linear("AND", ones, b_sh, out,
                                                src_w, tid, md), st)
                return
            a_sh = self._operand_shares(a, md.get("lane_delta_a", 0),
                                        st, src_w, tid)
            b_sh = self._operand_shares(b, md.get("lane_delta_b", 0),
                                        st, src_w, tid)
            self._def_shared(out,
                             self._secure_and(a_sh, b_sh, out, src_w, tid),
                             st)
            return
        if op == "OR":
            a, b = s.inputs
            md = s.metadata
            bv = self.values[b]
            av = self.values[a]
            if bv.kind == "constant" and int(bv.constant_value) == 0:
                # or(x, 0)（byte-route 移位降级形态）：R(0)=0 → 逐 share OR
                # 携带原路由元数据即精确（fold = R_a(x)）
                a_sh = self._shared_view(a, st)
                zeros = [b] * self.shares
                self._def_shared(
                    out, self._per_share_linear("OR", a_sh, zeros, out,
                                                src_w, tid, md), st)
                return
            if av.kind == "constant" and int(av.constant_value) == 0:
                b_sh = self._shared_view(b, st)
                zeros = [a] * self.shares
                self._def_shared(
                    out, self._per_share_linear("OR", zeros, b_sh, out,
                                                src_w, tid, md), st)
                return
            a_sh = self._operand_shares(a, md.get("lane_delta_a", 0),
                                        st, src_w, tid)
            b_sh = self._operand_shares(b, md.get("lane_delta_b", 0),
                                        st, src_w, tid)
            self._def_shared(out,
                             self._secure_or(a_sh, b_sh, out, src_w, tid),
                             st)
            return

        if op in ("ADD", "SUB"):
            if self.arith != "masked" or self._no_share(s):
                self._fold_arith(s, st)
                return
            a, b = s.inputs
            a_sh = self._shared_view(a, st)
            b_sh = self._shared_view(b, st)
            if op == "ADD":
                res = self._masked_add(a_sh, b_sh, out, src_w, tid)
            else:
                res = self._masked_sub(a_sh, b_sh, out, src_w, tid)
            self._def_shared(out, res, st)
            return

        if op == "ICMP_ULT":
            a_p = self._plain_view(s.inputs[0], st)
            b_p = self._plain_view(s.inputs[1], st)
            self._copy_step(s, inputs=[a_p, b_p])
            if out:
                self._def_plain(out, st)
            return

        if op == "SELECT":
            c, t, f = s.inputs
            val_kind, val_w = type_info(s.value_type_id)
            if val_kind == "integer" and val_w >= 8 and not self._no_share(s):
                t_sh = self._shared_view(t, st)
                f_sh = self._shared_view(f, st)
                outs = []
                for i in range(self.shares):
                    nk = self._new_key(f"{out}:xsel")
                    self._reg(nk, "ssa", s.value_type_id, None,
                              f"{out}:circuit:select")
                    self._emit("SELECT", [c, t_sh[i], f_sh[i]], nk,
                               s.value_type_id, s.value_type_id,
                               self._md("select-share", val_w,
                                        {"share_of": out}))
                    outs.append(nk)
                self._def_shared(out, outs, st)
            else:
                self._copy_plain(s, st)
            return

        if op in ("SHIFT_SHL", "SHIFT_LSHR"):
            x = s.inputs[0]
            funnel = s.inputs[2] if len(s.inputs) > 2 else None
            if self._no_share(s):
                self._copy_plain(s, st)
                return
            x_sh = self._shared_view(x, st)
            md = s.metadata
            outs = []
            for shk in x_sh:
                nk = self._new_key(f"{out}:xshf")
                self._reg(nk, "ssa", tid, None, f"{out}:circuit:shift")
                self._emit(op, [shk, shk, funnel], nk, tid, tid,
                           self._md("shift-share", src_w, {
                               "input_layout": md.get("input_layout", ""),
                               "lane_delta_a": md.get("lane_delta_a", 0),
                               "lane_delta_b": md.get("lane_delta_b", 0),
                               "lane_delta_c": md.get("lane_delta_c", 0),
                               "share_of": out}))
                outs.append(nk)
            self._def_shared(out, outs, st)
            return

        # MUL / DIVREM / 其它：fold 策略
        self._fold_arith(s, st)

    def _route_value(self, v, delta, w):
        """编译期常量按 lane 路由（与运行时 route_lanes 同构）。"""
        if delta == 0:
            return v & ((1 << w) - 1)
        lanes = encoded_bytes(w)
        bs = list((v & ((1 << w) - 1)).to_bytes(lanes, "little"))
        out = [bs[d + delta] if 0 <= d + delta < lanes else 0
               for d in range(lanes)]
        return int.from_bytes(bytes(out), "little")

    def _route_md(self, md):
        return {"input_layout": md.get("input_layout", ""),
                "lane_delta_a": md.get("lane_delta_a", 0),
                "lane_delta_b": md.get("lane_delta_b", 0),
                "lane_delta_c": md.get("lane_delta_c", 0)}

    def _has_routing(self, md):
        return (md.get("lane_delta_a", 0) != 0
                or md.get("lane_delta_b", 0) != 0)

    def _route_sh(self, x_sh, delta, w, tid):
        """逐 share 路由：OR(x_i, 0, lane_delta_a=delta)（线性恒等路由步）。"""
        if delta == 0:
            return x_sh
        zero = self._const(w, 0)
        outs = []
        for shk in x_sh:
            nk = self._new_key("circuit:route")
            self._reg(nk, "ssa", tid, None, "circuit:route")
            self._emit("OR", [shk, zero], nk, tid, tid,
                       self._md("route", w,
                                {"input_layout": "binary-lanes",
                                 "lane_delta_a": delta,
                                 "lane_delta_b": 0, "lane_delta_c": 0}))
            outs.append(nk)
        return outs

    def _operand_shares(self, key, delta, st, w, tid):
        """操作数的（可能路由过的）share 视图：常量按路由值取常量 share。"""
        v = self.values[key]
        if v.kind == "constant":
            routed = self._route_value(int(v.constant_value), delta, w)
            return self._const_shares(self._const(w, routed))
        shs = self._shared_view(key, st)
        return self._route_sh(shs, delta, w, tid)

    def _per_share_linear(self, op, x_sh, y_sh, out_key, w, tid, md):
        """逐 share 线性二元op（XOR；或与全 1 掩码 AND / 与 0 的 OR——
        per-share 精确的恒等形式），步骤携带原步骤的 lane 路由元数据：
        线性算子与路由可交换 → fold = F(R_a(x), R_b(y)) 逐位成立。"""
        outs = []
        for i in range(self.shares):
            nk = self._new_key(f"{out_key}:xsh")
            self._reg(nk, "ssa", tid, None, f"{out_key}:circuit:{op.lower()}")
            self._emit(op, [x_sh[i], y_sh[i]], nk, tid, tid,
                       self._md(f"{op.lower()}-share", w,
                                dict(self._route_md(md), share_of=out_key)))
            outs.append(nk)
        return outs

    def _no_share(self, s):
        """多写键参与的步骤不做 share 化（微程序原位更新兼容兜底）。"""
        keys = list(s.inputs) + ([s.output] if s.output else [])
        return any(k in self.multi_writer for k in keys if k in self.values)

    def _fold_arith(self, s, st):
        """折叠输入 → 原步骤（写原键，明文）→ 拆分输出（宽度 ≥8）。"""
        inputs = [self._plain_view(k, st) for k in s.inputs]
        self._copy_step(s, inputs=inputs)
        if s.output:
            self._def_plain(s.output, st)
            v = self.values[s.output]
            kind, w = type_info(v.type_id)
            if kind == "integer" and w >= 8 and s.output not in \
                    self.multi_writer:
                self._split(s.output, st)

    # ---- 区域处理 -------------------------------------------------------
    def _transform_region(self, ridx, r, start, end):
        st = _RegionState()
        st.plain.update(r["live_in_values"])
        # nonce-mask/share-encode 区域初始化（nonce 派生 + 缓存重置）
        self._region_begin(ridx, r)
        for i in range(start, end):
            self._transform_step(self.orig_steps[i], st)
        # live-out 折叠：仅对「share 表示且无明文定义」的原键（折叠写回
        # 原键 = 单一写者；fold-arith 已写原键的跳过，避免双写）
        for k in r["live_out_values"]:
            if k in st.shares and k not in st.plain:
                self._fold_into(k, st)

    def transform(self):
        """整计划变换：区域逐个处理，区域外步骤（哑索引）原样保留。"""
        pos = 0
        region_meta = []
        for ridx, r in enumerate(self.regions):
            start = r["action_start"]
            count = r["action_count"]
            while pos < start:
                self._copy_step(self.orig_steps[pos])
                pos += 1
            new_start = len(self.steps)
            self._transform_region(ridx, r, start, start + count)
            region_meta.append((new_start, len(self.steps) - new_start))
            pos = start + count
        while pos < len(self.orig_steps):
            self._copy_step(self.orig_steps[pos])
            pos += 1
        return region_meta


# ---------------------------------------------------------------------------
# 3. 槽位分配（plan_compiler.assign_slots 移植 + live-out 延寿）
# ---------------------------------------------------------------------------
def assign_slots(values, steps, live_out_keys):
    used = set()
    for s in steps:
        used.update(s.inputs)
        if s.output:
            used.add(s.output)

    # 1) 初始槽：常量 + live-in，按键字典序（"const:" < "function:" →
    #    常量恒连续占据低槽——profile_gen 的常量连续性断言依赖此序）
    initial = sorted(k for k, v in values.items()
                     if v.kind in ("constant", "live-in") and k in used)
    slots = {}
    next_slot = 0
    for k in initial:
        slots[k] = next_slot
        values[k].slot = next_slot
        next_slot += 1

    # 2) last-use（live-out 键延寿至计划尾：槽位在区域解码前不可被复用）
    n_steps = len(steps)
    last_use = {k: -1 for k in values}
    for i, s in enumerate(steps):
        for k in s.inputs:
            last_use[k] = max(last_use[k], i)
        if s.output:
            last_use.setdefault(s.output, -1)
    for k in live_out_keys:
        if k in last_use:
            last_use[k] = n_steps

    # 3) 工作槽线性扫描：输出取最低空闲槽（[def, last_use] 占用；
    #    last_use 步内先读后写 → 该步即可复用）
    slot_free_at = {}
    for i, s in enumerate(steps):
        if not s.output:
            continue
        v = values[s.output]
        if v.kind != "ssa":
            continue
        if v.slot is not None:
            continue                  # 多写单键（保守保留原槽）
        chosen = None
        probe = next_slot
        limit = next_slot + 64 + len(values)
        while probe < limit:
            if slot_free_at.get(probe, 0) <= i:
                chosen = probe
                break
            probe += 1
        if chosen is None:
            raise CircuitShareError("slot allocator exhausted")
        slots[s.output] = chosen
        v.slot = chosen
        slot_free_at[chosen] = last_use[s.output]
    n_slots = (max(slots.values()) + 1) if slots else 0
    return slots, n_slots


# ---------------------------------------------------------------------------
# 4. 计划 JSON 重建
# ---------------------------------------------------------------------------
_TOOL_SIG = {
    "ADD": lambda src: ([src, src, "i1"], [src, "i1"], ["value", "carry"]),
    "SUB": lambda src: ([src, src, "i1"], [src, "i1"], ["value", "carry"]),
    "ICMP_ULT": lambda src: ([src, src], ["i1"], ["predicate"]),
    "SELECT": lambda src: (["i1", src, src], [src], ["value"]),
    "SHIFT_SHL": lambda src: ([src, src, src], [src], ["value"]),
    "SHIFT_LSHR": lambda src: ([src, src, src], [src], ["value"]),
}


def _tool_contracts(steps):
    seen = {}

    def sig(op, src):
        if op in _TOOL_SIG:
            return _TOOL_SIG[op](src)
        return [src, src], [src], ["value"]      # AND/OR/XOR/MUL

    for s in steps:
        if s.operation in ("LOAD", "COPY", "STORE"):
            continue
        src = s.source_type_id
        tid = f"stable:{s.operation.lower()}:{src}->{s.value_type_id}"
        if tid not in seen:
            in_tids, out_tids, roles = sig(s.operation, src)
            seen[tid] = {
                "tool_id": tid,
                "operation": s.operation,
                "input_type_ids": in_tids,
                "output_type_ids": out_tids,
                "output_roles": roles,
                "recursive_safe": True,
                "max_external_refiner_passes": 0,
                "required_precisions": ["fp32", "fp16"],
                "schema": "nnobf-stable-tool-contract-v1",
            }
    return [seen[k] for k in sorted(seen)]


def _rebuild_plan(plan, values, steps, region_meta, n_slots, slots):
    live_out_keys = set()
    for r in plan["regions"]:
        live_out_keys.update(r["live_out_values"])

    regions = []
    for r, (start, count) in zip(plan["regions"], region_meta):
        nr = dict(r)
        nr["action_start"] = start
        nr["action_count"] = count
        regions.append(nr)

    slot_types = {i: set() for i in range(n_slots)}
    for v in values.values():
        if v.slot is not None:
            slot_types[v.slot].add(v.type_id)
    temp_slots = []
    for i in range(n_slots):
        tids = sorted(slot_types[i])
        cap = max(encoded_bytes(type_info(t)[1]) for t in tids) if tids else 1
        temp_slots.append({"slot": i, "capacity_bytes": cap,
                           "allowed_type_ids": tids})
    context = dict(plan["context"])
    context["temp_slot_capacity"] = n_slots
    context["temp_slots"] = temp_slots
    frames = []
    for f in plan["context"]["frames"]:
        nf = dict(f)
        if nf.get("frame_id") == "region":
            nf["temp_slots"] = list(range(n_slots))
        frames.append(nf)
    context["frames"] = frames

    types = []
    for t in sorted({v.type_id for v in values.values()}):
        kind, w = type_info(t)
        types.append({
            "type_id": t,
            "kind": "pointer" if kind == "pointer" else kind,
            "storage_bytes": encoded_bytes(w),
            "alignment": encoded_bytes(w),
            "bit_width": w, "floating_format": None,
            "address_space": 0, "element_type_id": None,
            "element_count": 0, "field_type_ids": [], "field_offsets": [],
            "schema": "nnobf-neural-type-v1",
        })

    controller = dict(plan["controller"])
    controller["max_rollout_steps"] = len(steps)

    inputs = [values[k].to_json() for k in sorted(values)
              if values[k].kind == "live-in"]
    initial = [values[k].to_json() for k in sorted(values)
               if values[k].kind in ("constant", "live-in")
               and values[k].slot is not None]
    all_values = [values[k].to_json() for k in sorted(values)]

    def _keep_keys(field):
        return [v["key"] for v in plan.get(field) or []]

    boundary = [values[k].to_json() for k in _keep_keys("boundary_values")
                if k in values]
    outputs = [values[k].to_json() for k in _keep_keys("outputs")
               if k in values]

    return {
        "schema": plan["schema"],
        "controller_action_schema": plan["controller_action_schema"],
        "function": plan["function"],
        "rewrite_kind": plan["rewrite_kind"],
        "context": context,
        "controller": controller,
        "types": types,
        "tool_contracts": _tool_contracts(steps),
        "abi_parameters": copy.deepcopy(plan.get("abi_parameters") or []),
        "inputs": inputs,
        "initial_values": initial,
        "values": all_values,
        "steps": [_step_to_json(i, s, slots) for i, s in enumerate(steps)],
        "regions": regions,
        "boundary_values": boundary,
        "outputs": outputs,
        "capability_gaps": copy.deepcopy(plan.get("capability_gaps") or []),
        "floating_environment": plan.get("floating_environment"),
        "entry_action": plan.get("entry_action", 0),
        "control_flow_kind": plan.get("control_flow_kind", "linear"),
    }


def transform_plan(plan, shares, seed, arith, nonce_mask=False,
                   share_encode=False):
    """单计划变换：返回 (新计划 dict, 统计)。空区域计划原样返回。"""
    if shares not in SHARE_COUNTS:
        raise CircuitShareError(f"shares must be one of {SHARE_COUNTS}")
    if not plan.get("steps"):
        return copy.deepcopy(plan), {"steps": 0, "new_steps": 0,
                                     "slots": 0, "new_slots": 0,
                                     "values": 0, "new_values": 0}

    values = {}
    for v in plan["values"]:
        values[v["key"]] = _Val(v["key"], v["kind"], v["type_id"],
                                v["constant_value"],
                                v.get("source_reference"))
    orig_steps = [_step_from_json(s) for s in plan["steps"]]
    regions = plan["regions"]

    # encoded-value 参数（call_begin 入槽，全函数可读，非区域 live-in）
    encoded_args = {e["value_key"] for e in plan.get("abi_parameters") or []
                    if e.get("binding_kind") == "encoded-value"
                    and e.get("value_key")}

    t = _Transformer(plan["function"], values, orig_steps, regions,
                     shares, seed, arith, always_plain=encoded_args,
                     nonce_mask=nonce_mask, share_encode=share_encode)
    region_meta = t.transform()

    live_out_keys = set()
    for r in regions:
        live_out_keys.update(r["live_out_values"])
    slots, n_slots = assign_slots(values, t.steps, live_out_keys)

    new_plan = _rebuild_plan(plan, values, t.steps, region_meta, n_slots,
                             slots)

    stats = {
        "steps": len(plan["steps"]),
        "new_steps": len(t.steps),
        "slots": plan["context"]["temp_slot_capacity"],
        "new_slots": n_slots,
        "values": len(plan["values"]),
        "new_values": len(values),
        "shares": shares,
        "arith": arith,
        "nonce_mask": int(nonce_mask),
        "share_encode": int(share_encode),
        "nonce_fallback_regions": t.nonce_fallback_regions,
    }
    return new_plan, stats


# ---------------------------------------------------------------------------
# 5. 计划解释器（差分验证）
# ---------------------------------------------------------------------------
def _interp_rng(tag, master):
    payload = f"{tag}|{master}".encode("utf-8")
    seed = int.from_bytes(hashlib.sha256(payload).digest()[:8], "big")
    return random.Random(seed)


def _maskv(v, w):
    return v & ((1 << max(w, 1)) - 1)


def _route_bytes(v, delta, lanes):
    bs = list(v.to_bytes(lanes, "little"))
    out = []
    for d in range(lanes):
        s = d + delta
        out.append(bs[s] if 0 <= s < lanes else 0)
    return out


def interpret_plan(plan, master_seed=20261101):
    """计划解释器：live-in / LOAD 注入确定性随机值，按运行时语义
    （含 lane 路由 + funnel 移位）逐步执行，返回（区域 live-out 表,
    STORE 序列）。用于变换前后差分验证。"""
    values = {v["key"]: v for v in plan["values"]}
    steps = plan["steps"]
    regions = plan["regions"]
    fn = plan["function"]

    env = {}
    for v in plan["values"]:
        if v["kind"] == "constant":
            cv = 0 if v["constant_value"] is None else int(v["constant_value"])
            env[v["key"]] = _maskv(cv, v["logical_width"])
    # encoded-value 参数（call_begin 入槽；非区域 live-in）：函数级注入
    for e in plan.get("abi_parameters") or []:
        if e.get("binding_kind") == "encoded-value" and e.get("value_key"):
            k = e["value_key"]
            w = max(values[k]["logical_width"], 1)
            rng = _interp_rng(f"{fn}|arg|{k}", master_seed)
            env[k] = _maskv(rng.getrandbits(w), w)

    outs = {}
    stores = []
    starts, ends = {}, {}
    for ridx, r in enumerate(regions):
        if r["action_count"] > 0:
            starts[r["action_start"]] = ridx
            ends[r["action_start"] + r["action_count"] - 1] = ridx
        else:
            outs[ridx] = {}

    for i, s in enumerate(steps):
        if i in starts:
            ridx = starts[i]
            for k in regions[ridx]["live_in_values"]:
                w = max(values[k]["logical_width"], 1)
                rng = _interp_rng(f"{fn}|in|{ridx}|{k}", master_seed)
                env[k] = _maskv(rng.getrandbits(w), w)
        _interp_step(s, env, values, fn, master_seed, stores)
        if i in ends:
            ridx = ends[i]
            outs[ridx] = {k: env.get(k)
                          for k in regions[ridx]["live_out_values"]}
    return outs, stores


def _interp_step(s, env, values, fn, master, stores):
    op = s["operation"]
    keys = s["input_values"]

    def val(k):
        return env[k]

    if op == "STORE":
        v = val(keys[0])
        stores.append((s["address"]["object_id"],
                       s["address"]["constant_offset"],
                       _maskv(v, s["logical_width"])))
        return
    if op == "LOAD":
        w = max(s["logical_width"], 1)
        rng = _interp_rng(f"{fn}|ld|{s['origin_reference']}", master)
        env[s["output_value"]] = _maskv(rng.getrandbits(w), w)
        return
    if op == "COPY":
        src_w = max(s["source_width"], 1)
        out_w = max(s["logical_width"], 1)
        env[s["output_value"]] = _maskv(val(keys[0]), min(src_w, out_w))
        return
    if op == "SELECT":
        c, t, f = (val(keys[0]), val(keys[1]), val(keys[2]))
        env[s["output_value"]] = t if c != 0 else f
        return
    if op == "ICMP_ULT":
        a, b = val(keys[0]), val(keys[1])
        env[s["output_value"]] = 1 if a < b else 0
        return

    md = s.get("metadata") or {}
    lda = md.get("lane_delta_a", 0)
    ldb = md.get("lane_delta_b", 0)
    ldc = md.get("lane_delta_c", 0)
    w = max(s["source_width"], 1)
    lanes = encoded_bytes(w)
    out_w = max(s["logical_width"], 1)

    if op in ("XOR", "AND", "OR", "ADD", "SUB"):
        a = _route_bytes(_maskv(val(keys[0]), w), lda, lanes)
        b = _route_bytes(_maskv(val(keys[1]), w), ldb, lanes)
        av = int.from_bytes(bytes(a), "little")
        bv = int.from_bytes(bytes(b), "little")
        if op == "XOR":
            r = av ^ bv
        elif op == "AND":
            r = av & bv
        elif op == "OR":
            r = av | bv
        elif op == "ADD":
            r = av + bv
        else:
            r = av - bv
        env[s["output_value"]] = _maskv(r, out_w)
        return
    if op in ("SHIFT_SHL", "SHIFT_LSHR"):
        a = _route_bytes(_maskv(val(keys[0]), w), lda, lanes)
        b = _route_bytes(_maskv(val(keys[1]), w), ldb, lanes)
        c = _route_bytes(_maskv(val(keys[2]), w), ldc, lanes)
        outb = []
        for d in range(lanes):
            a_, b_, s_ = a[d], b[d], c[d] & 0xFF
            if op == "SHIFT_SHL":
                outb.append(((a_ << s_) | (b_ >> max(8 - s_, 0))) & 0xFF)
            else:
                outb.append((a_ >> s_)
                            | ((b_ << max(8 - s_, 0)) & 0xFF))
        env[s["output_value"]] = _maskv(
            int.from_bytes(bytes(outb), "little"), out_w)
        return
    raise CircuitShareError(f"interpreter: unsupported op {op}")


def verify_transform(orig_plan, new_plan, trials=3, master=20261101):
    """原/新计划差分：逐区域 live-out + STORE 序列逐项比对。"""
    problems = []
    for t in range(trials):
        seed = master + t
        o_outs, o_stores = interpret_plan(orig_plan, seed)
        n_outs, n_stores = interpret_plan(new_plan, seed)
        if set(o_outs) != set(n_outs):
            problems.append("region set mismatch")
            continue
        for ridx in o_outs:
            for k in o_outs[ridx]:
                ov = o_outs[ridx][k]
                nv = n_outs[ridx].get(k)
                if ov != nv:
                    problems.append(
                        f"trial{t} region{ridx} {k}: {ov} != {nv}")
        if len(o_stores) != len(n_stores):
            problems.append(f"trial{t} store count {len(o_stores)} != "
                            f"{len(n_stores)}")
        else:
            for i, (a, b) in enumerate(zip(o_stores, n_stores)):
                if a != b:
                    problems.append(f"trial{t} store#{i}: {a} != {b}")
    return (not problems), problems


# ---------------------------------------------------------------------------
# 6. 模块变换 + CLI
# ---------------------------------------------------------------------------
def transform_module(module, shares, seed, arith, functions=None,
                     nonce_mask=False, share_encode=False):
    """module_plan（多计划）→ 变换后 module。functions=None → 全部。"""
    want = None
    if functions:
        want = set(functions)
    plans = []
    stats_all = []
    for plan in module["plans"]:
        if want is not None and plan["function"] not in want:
            plans.append(copy.deepcopy(plan))
            continue
        new_plan, stats = transform_plan(plan, shares, seed, arith,
                                         nonce_mask=nonce_mask,
                                         share_encode=share_encode)
        ok, problems = verify_transform(plan, new_plan)
        if not ok:
            raise CircuitShareError(
                f"circuit_share: differential verification FAILED for "
                f"{plan['function']}: {problems[:5]}")
        plans.append(new_plan)
        stats_all.append((plan["function"], stats))
    module = dict(module)
    module["plans"] = plans
    return module, stats_all


def main():
    ap = argparse.ArgumentParser(
        description="circuit-v1 XOR 秘密共享 → 神经动作程序融合器")
    ap.add_argument("plan", help="输入 module_plan.json")
    ap.add_argument("-o", "--output", default=None,
                    help="输出路径（缺省原位覆写）")
    ap.add_argument("--shares", type=int, default=2, choices=SHARE_COUNTS)
    ap.add_argument("--seed", default="0",
                    help="掩码种子（任意字符串/整数；复现用）")
    ap.add_argument("--arith", choices=["fold", "masked"], default="fold",
                    help="ADD/SUB 策略：fold=折叠（默认，预算友好）；"
                         "masked=Kogge-Stone 掩码加法器（全 share 域）")
    ap.add_argument("--nonce-mask", action="store_true",
                    help="nonce-mask 泳道（consumer_fused_v1 运行时 nonce "
                         "派生掩码）：split/刷新掩码改为运行期步骤值"
                         "（nonce=区域 integer live-in 混合），掩码不再是"
                         "计划常量；无 integer live-in 的区域回退静态")
    ap.add_argument("--share-encode", action="store_true",
                    help="share-encode 泳道（stateful_v34 per-share 独立"
                         "编码）：槽位驻留 share 以 rot+salt+additive 编码"
                         "（参数 seed 派生 per 区域/share 序号）；约 +2x "
                         "share 步，masked 档不建议叠加")
    ap.add_argument("--functions", default=None,
                    help="逗号分隔或 @file：仅变换这些函数（缺省全部）")
    ap.add_argument("--no-verify", action="store_true",
                    help="跳过内置差分验证（不建议）")
    ap.add_argument("-v", "--verbose", action="store_true")
    args = ap.parse_args()

    module = json.load(open(args.plan))
    functions = None
    if args.functions:
        spec = args.functions
        if spec.startswith("@"):
            spec = open(spec[1:]).read()
        functions = [x.strip() for x in spec.replace(",", " ").split()
                     if x.strip()]
        known = {p["function"] for p in module["plans"]}
        missing = [f for f in functions if f not in known]
        if missing:
            sys.exit(f"circuit_share: functions not found: {missing}")

    if args.no_verify:
        plans = []
        stats_all = []
        for plan in module["plans"]:
            if functions is not None and plan["function"] not in functions:
                plans.append(copy.deepcopy(plan))
                continue
            new_plan, stats = transform_plan(plan, args.shares, args.seed,
                                             args.arith,
                                             nonce_mask=args.nonce_mask,
                                             share_encode=args.share_encode)
            plans.append(new_plan)
            stats_all.append((plan["function"], stats))
        module = dict(module)
        module["plans"] = plans
    else:
        module, stats_all = transform_module(module, args.shares, args.seed,
                                             args.arith, functions,
                                             nonce_mask=args.nonce_mask,
                                             share_encode=args.share_encode)

    out = args.output or args.plan
    with open(out, "w", encoding="utf-8") as f:
        json.dump(module, f)
        f.write("\n")

    tot_s = sum(s["steps"] for _fn, s in stats_all) or 1
    tot_n = sum(s["new_steps"] for _fn, s in stats_all)
    lanes = []
    if args.nonce_mask:
        lanes.append("nonce-mask")
    if args.share_encode:
        lanes.append("share-encode")
    lanes_txt = (" + " + "+".join(lanes)) if lanes else ""
    print(f"circuit_share: {len(stats_all)} plans transformed "
          f"(shares={args.shares} arith={args.arith} seed={args.seed}"
          f"{lanes_txt})",
          file=sys.stderr)
    print(f"circuit_share: steps {tot_s} -> {tot_n} "
          f"(x{tot_n / tot_s:.1f})", file=sys.stderr)
    if args.nonce_mask:
        fb = sum(s.get("nonce_fallback_regions", 0)
                 for _fn, s in stats_all)
        print(f"circuit_share: nonce-mask fallback regions: {fb} "
              f"(static masks, no integer live-in)", file=sys.stderr)
    if args.verbose:
        for fn, s in stats_all:
            print(f"  {fn}: steps {s['steps']}->{s['new_steps']}, "
                  f"slots {s['slots']}->{s['new_slots']}, "
                  f"values {s['values']}->{s['new_values']}",
                  file=sys.stderr)
    if not args.no_verify:
        print("circuit_share: differential verification PASS "
              f"({len(stats_all)} plans, live-out + store byte-equal)",
              file=sys.stderr)
    print(f"circuit_share: wrote {out}", file=sys.stderr)


if __name__ == "__main__":
    main()
