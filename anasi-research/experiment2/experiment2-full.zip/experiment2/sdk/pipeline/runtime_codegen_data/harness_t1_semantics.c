#include <stdio.h>
#include <stdint.h>
#include <string.h>
void *__nnobf_neural_ir_7da23e53349a43d6_context_create(void);
int __nnobf_neural_ir_7da23e53349a43d6_call_begin(void *);
int __nnobf_neural_ir_7da23e53349a43d6_boundary_run(void *, uint64_t *);
int __nnobf_neural_ir_7da23e53349a43d6_call_finish(void *);
void __nnobf_neural_ir_7da23e53349a43d6_context_destroy(void *);
/* t.c: int x; if (scanf("0",&x)==1) return x*2; return 42;
 * 语义 = (scanf_ret==1) ? x*2 : 42；load x 走镜像 sync_in。 */
static int run(int x, int scanf_ret) {
  void *ctx = __nnobf_neural_ir_7da23e53349a43d6_context_create();
  if (!__nnobf_neural_ir_7da23e53349a43d6_call_begin(ctx)) return -999;
  uint64_t frame[4]; memset(frame,0,sizeof(frame));
  frame[0] = (uint64_t)(uintptr_t)ctx ^ 1360580669965750588ULL;
  frame[1] = (uint64_t)(uintptr_t)&x;
  frame[3] = (uint64_t)scanf_ret;
  int ok = __nnobf_neural_ir_7da23e53349a43d6_boundary_run(ctx, frame);
  __nnobf_neural_ir_7da23e53349a43d6_call_finish(ctx);
  __nnobf_neural_ir_7da23e53349a43d6_context_destroy(ctx);
  return ok ? (int)frame[2] : -998;
}
int main(void) {
  struct { int x, ret, want; } cases[] = {
    {3,0,42},{0,0,42},{1,0,42},          /* scanf("0") 永不成功 → 42（引擎实测） */
    {3,1,6},{1,1,2},{0,1,0},{-5,1,-10},{7,1,14}, /* ret==1 → x*2 */
  };
  int pass=0;
  for (unsigned i=0;i<sizeof(cases)/sizeof(*cases);i++) {
    int got=run(cases[i].x,cases[i].ret);
    int ok = got==cases[i].want;
    printf("x=%3d scanf_ret=%d -> neural=%3d want=%3d %s\n",
           cases[i].x,cases[i].ret,got,cases[i].want, ok?"PASS":"FAIL");
    pass+=ok;
  }
  printf("%d/%d PASS\n",pass,(int)(sizeof(cases)/sizeof(*cases)));
  return pass==(int)(sizeof(cases)/sizeof(*cases))?0:1;
}
