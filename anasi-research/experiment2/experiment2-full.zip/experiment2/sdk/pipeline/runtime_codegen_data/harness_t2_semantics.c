#include <stdio.h>
#include <stdint.h>
#include <string.h>
void *__nnobf_neural_ir_91ab756d3b57d9f3_context_create(void);
int __nnobf_neural_ir_91ab756d3b57d9f3_call_begin(void *);
int __nnobf_neural_ir_91ab756d3b57d9f3_boundary_run(void *, uint64_t *);
int __nnobf_neural_ir_91ab756d3b57d9f3_call_finish(void *);
void __nnobf_neural_ir_91ab756d3b57d9f3_context_destroy(void *);
/* t2.c 参考语义 */
static int ref(unsigned int x) {
  if (1 != 1) return 99;                 /* scanf 成功路径 */
  unsigned int y = x + 0x1234u;
  y = y ^ (x >> 2);
  y = (y << 1) | (y & 1u);
  if (y < 100u) y = y + 7u;
  return (int)(y % 256u);
}
static int neural(unsigned int x, int scanf_ret) {
  void *ctx = __nnobf_neural_ir_91ab756d3b57d9f3_context_create();
  if (!__nnobf_neural_ir_91ab756d3b57d9f3_call_begin(ctx)) return -999;
  /* 帧1: [2]=scanf_ret → region0(4 动作) → [1]=分支条件(i1) */
  uint64_t fA[8]; memset(fA,0,sizeof(fA));
  fA[0] = (uint64_t)(uintptr_t)ctx ^ 2659911325400107137ULL;
  fA[2] = (uint64_t)(unsigned)scanf_ret;
  if (!__nnobf_neural_ir_91ab756d3b57d9f3_boundary_run(ctx, fA)) return -998;
  if (!fA[1]) { __nnobf_neural_ir_91ab756d3b57d9f3_call_finish(ctx);
               __nnobf_neural_ir_91ab756d3b57d9f3_context_destroy(ctx); return 99; }
  /* 帧2: [1]=&x → region1(13 动作) → [2]=返回值 */
  uint64_t fB[8]; memset(fB,0,sizeof(fB));
  fB[0] = (uint64_t)(uintptr_t)ctx ^ 9485348196553556760ULL;
  fB[1] = (uint64_t)(uintptr_t)&x;
  int ok = __nnobf_neural_ir_91ab756d3b57d9f3_boundary_run(ctx, fB);
  int r = ok ? (int)(uint32_t)fB[2] : -997;
  __nnobf_neural_ir_91ab756d3b57d9f3_call_finish(ctx);
  __nnobf_neural_ir_91ab756d3b57d9f3_context_destroy(ctx);
  return r;
}
int main(void) {
  unsigned xs[] = {0,1,2,3,4,7,16,100,255,256,1000,4660,0x1234,0xFFFFFFFFu,0x80000000u,123456789u};
  int pass=0,n=0;
  for (unsigned i=0;i<sizeof(xs)/sizeof(*xs);i++) {
    int want=ref(xs[i]), got=neural(xs[i],1);
    int ok=want==got; pass+=ok; n++;
    printf("x=%-10u ref=%-4d neural=%-4d %s\n",xs[i],want,got,ok?"PASS":"FAIL");
  }
  /* scanf 失败分支 */
  int got=neural(0,0); int ok=(got==99); pass+=ok; n++;
  printf("scanf_fail neural=%d %s\n",got,ok?"PASS":"FAIL");
  printf("%d/%d PASS\n",pass,n);
  return pass==n?0:1;
}
