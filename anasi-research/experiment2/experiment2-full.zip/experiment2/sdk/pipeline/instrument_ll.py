#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ANANSI hybrid-regions 边界插桩器 —— 自研管线 B3 组件（多函数扩展）。

把 plan_compiler 识别出的可神经化计算 region 从 input.ll 中删除，在原位插入
controller 边界调用协议（语义逆向自引擎 0x405820 插桩器，见
decomp/notes-ir-codegen.md §1.2 / notes-normalization-ticket.md §6）：

    %nnobf.boundary.frame = alloca [N x i64], align 8          ; 边界帧
    %nnobf.context  = call ptr  @…_context_create()            ; 序言（函数入口）
    %nnobf.begin.ok = call i32  @…_call_begin(ptr …, <原生参数>)
    call void @…_require_success(i32 …)
    … 原生指令（alloca/call/gep/br/phi/ret）照常 …
    %nnobf.frame.mask.r = ptrtoint ptr %nnobf.context to i64   ; 逐 region：
    %nnobf.frame.code.r = xor i64 %nnobf.frame.mask.r, <ticket>
    store frame[0] = code                                     ; 票号 XOR 绑定
    [同步指针: %nnobf.frame.bits.r.s = ptrtoint … → frame[s]]
    [指针 live-in: %nnobf.livein.ptr.r = ptrtoint … → frame[s]]
    [标量 live-in: %nnobf.livein.r = zext … → frame[s]]
    %nnobf.resume.r.ok = call i32 @…_boundary_run(ptr, ptr)
    call void @…_require_success(…)
    [live-out: %nnobf.liveout.r = trunc i64 (load frame[s]) to <ty>]
    [指针 live-out: %nnobf.liveout.ptr.r = inttoptr i64 … to ptr]
    … 终结符（br/ret 条件/操作数替换为 %nnobf.liveout.r）…
    %nnobf.finish.ok = call i32 @…_call_finish(ptr …)          ; 尾声（ret 前）
    call void @…_require_success(…)
    call void @…_context_destroy(ptr …)

多函数（whibo 引擎真值形态）：
  - 每函数一套 __nnobf_neural_ir_<tag>_* 导出（tag 逐函数独立）
  - call_begin 携带原生参数（指针 passthrough / 整型 encoded-value）
  - 每函数 6 个 declare（call_begin 签名 = 原生参数表）追加到模块尾部
  - 逐函数独立重编号（LLVM 编号本就函数局部）

帧布局：N = 1 + max_region(同步指针 + live-out + 标量 live-in)；每 region 内
[1..]=同步指针 → live-out → 标量。票号以 i64 有符号十进制打印。

用法：
    python3 instrument_ll.py INPUT.ll -o transformed.ll \
        --function main --tag 91ab756d3b57d9f3 --tickets-file t.json
    # 多函数：
    python3 instrument_ll.py INPUT.ll -o transformed.ll --multi mf.json
    #   mf.json = {"functions":[{"function":..,"tag":..,"tickets":{..}},..]}
"""

import argparse
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import plan_compiler as PC  # noqa: E402  复用其解析/区域化（0 差异验收过的实现）

PRED_PAD = 50          # 块标签行 ';' 注释起始列（金标准实测）
TOKEN_RE = re.compile(r"%(\d+|[A-Za-z$._][-A-Za-z$._0-9]*)")
SWITCH_CASE_RE = re.compile(r"^(i\d+)\s+[^,]+,\s*label\s+%[\w.$-]+$")

SIX_DECLARES = [
    "declare ptr {p}context_create()",
    "declare void {p}context_destroy(ptr)",
    "declare i32 {p}call_begin(ptr{extra})",
    "declare i32 {p}boundary_run(ptr, ptr)",
    "declare i32 {p}call_finish(ptr)",
    "declare void {p}require_success(i32)",
]


def fmt_ticket_u64(v):
    """票号按 i64 有符号十进制打印（金标准 .ll 立即数形态）。"""
    v = int(v) & ((1 << 64) - 1)
    return str(v - (1 << 64) if v >= (1 << 63) else v)


# ---------------------------------------------------------------------------
# 1. 带行号的函数体解析（与 plan_compiler.parse_llvm_ir 同一计数语义）
# ---------------------------------------------------------------------------
class Block:
    def __init__(self, label=None):
        self.label = label          # 入口块 None；其余为原标签字符串（如 '4'）
        self.items = []             # [(原始行文本, Inst|None)]（None=透传行）


def parse_define_params(define_line):
    """define 行参数表 → [(type_str, ssa_name, zeroext/signext attr)]。

    括号感知切分（initializes((0, 16)) 内含逗号）。
    """
    pm = re.search(r"\((.*)\)", define_line)
    if not pm:
        return []
    # 深度 0 逗号切分
    parts, depth, cur = [], 0, ""
    for ch in pm.group(1):
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        if ch == "," and depth == 0:
            parts.append(cur)
            cur = ""
        else:
            cur += ch
    if cur.strip():
        parts.append(cur)
    out = []
    for tok in parts:
        tok = tok.strip()
        if not tok:
            continue
        vm = re.search(r"(%[\w.$-]+)$", tok)
        if not vm:
            continue
        body = tok[:vm.start()].strip()
        attr = "zeroext" if "zeroext" in body else (
            "signext" if "signext" in body else "")
        body = re.sub(r"\w+\(\s*\w+\s+\d+\s*,\s*-?\d+\s*\)\)?", " ", body)
        body = re.sub(r"\w+\([^()]*\)", " ", body)
        body = re.sub(r"\(\s*\d+\s*,\s*-?\d+\s*\)", " ", body)
        cands = re.findall(r"\[[^\[\]]*\]|%[\w.$-]+|i\d+|ptr|float|double",
                           body)
        ty = cands[-1] if cands else "i32"
        out.append((ty, vm.group(1), attr))
    return out


def parse_function(text, fn_name=None):
    """返回 (fname, blocks, def_idx, end_idx, lines, define_line)。

    不可解析且非 switch 续行的行按透传保留（Inst=None）；switch 续行
    （'i8 0, label %37' / ']'）不属于指令——跳过（引擎 inst 编号不计）。
    """
    lines = text.split("\n")
    def_idx = None
    for i, l in enumerate(lines):
        m = re.match(r"define\s+.*?@([\w.$-]+)\s*\(", l)
        if m and (fn_name is None or m.group(1) == fn_name):
            def_idx, fname = i, m.group(1)
            break
    if def_idx is None:
        raise SystemExit("instrument_ll: no matching define found")

    blocks = [Block()]
    end_idx = None
    for i in range(def_idx + 1, len(lines)):
        l = lines[i]
        if l.startswith("}"):
            end_idx = i
            break
        stripped = PC._strip_line(l)
        if not stripped:
            continue                       # 块间空行（重建时统一生成）
        m = re.match(r"^([\w.$-]+):\s*$", stripped)
        if m:
            blocks.append(Block(label=m.group(1)))
            continue
        if stripped == "]" or SWITCH_CASE_RE.match(stripped):
            # switch 续行：非独立指令（引擎 inst 编号不计）但必须原样保留
            blocks[-1].items.append((l, None))
            continue
        inst = PC._parse_inst(stripped)
        blocks[-1].items.append((l, inst))
    if end_idx is None:
        raise SystemExit("instrument_ll: function body not closed")
    if blocks[0].label is not None:
        raise SystemExit("instrument_ll: named entry block unsupported")
    return fname, blocks, def_idx, end_idx, lines, lines[def_idx]


# ---------------------------------------------------------------------------
# 2. 区域/边界信息提取（复用 PlanCompiler 的 0 差异实现）
# ---------------------------------------------------------------------------
class RegionSpec:
    def __init__(self, ridx, block_idx, run):
        self.ridx = ridx
        self.block_idx = block_idx
        self.run = run                    # [Inst]
        self.syncs = []                   # [(ssa, slot, obj_id, size, wri)]
        self.ptr_ins = []                 # [(ssa, slot)]（兼容旧接口）
        self.scalar_ins = []              # [(ssa, type_id, slot)]
        self.outs = []                    # [(ssa, type_id, slot)]
        self.ticket = None


def analyze(fname, blocks, region_gaps=False):
    blocks_insts = [[inst for _, inst in b.items if inst is not None]
                    for b in blocks]
    pc = PC.PlanCompiler(fname, blocks_insts, region_gaps=region_gaps)
    pc.lower()
    pc.assign_slots()
    regions_json = pc.build_regions()

    specs = []
    for ridx, (start, count, run) in enumerate(pc.regions):
        sp = RegionSpec(ridx, run[0].block_idx, run)
        # 同步指针：region 内内存步的基指针（首现序；含写标志）
        seen = {}
        for inst in run:
            if inst.opcode not in ("load", "store"):
                continue
            rb = pc._resolve_base(inst)
            if rb is None:
                raise SystemExit(
                    f"instrument_ll: region {ridx} memory base "
                    f"unresolvable ({inst.ptr})")
            ref, obj, offset, sync_ssa = rb
            size = obj["storage_bytes"] if obj["kind"] == "stack" else \
                max(type_size(inst.type), obj["size_bytes"])
            key = sync_ssa
            ent = seen.get(key)
            if ent is None:
                seen[key] = {"ssa": sync_ssa, "obj": obj["object_id"],
                             "size": size, "wri": inst.opcode == "store"}
            else:
                ent["size"] = max(ent["size"], size)
                ent["wri"] = ent["wri"] or inst.opcode == "store"
        for ent in seen.values():
            sp.syncs.append((ent["ssa"], None, ent["obj"], ent["size"],
                             ent["wri"]))
        # 标量 live-in / live-out（plan 的 live_in/out_values，键序）
        # 修正:plan 偶把 alloca 产物(SSA 实际类型 ptr,如 ef_probe_timing
        # 的 sink 变量地址)按元素类型记为 i64 标量,emit 阶段直存指针
        # 会产生 "defined with type 'ptr' but expected 'i64'" 编译错误。
        # 此处把 origin 为 alloca 的 live-in/out 类型改判为 ptr,交给
        # emit 阶段既有的 ptrtoint/inttoptr 分支处理。
        def _eff_type(v):
            if (v.origin_inst is not None
                    and getattr(v.origin_inst, "opcode", None) == "alloca"):
                return "ptr"
            return v.type_id
        for k in regions_json[ridx]["live_in_values"]:
            v = pc.values[k]
            sp.scalar_ins.append((_ll_name_of(pc, fname, v), _eff_type(v)))
        for k in regions_json[ridx]["live_out_values"]:
            v = pc.values[k]
            sp.outs.append((_ll_name_of(pc, fname, v), _eff_type(v)))
        specs.append(sp)

    # 帧 slot 分配：[1..]=同步指针 → live-out → 标量；N = 1 + max 总数
    for sp in specs:
        s = 1
        sp.syncs = [(ssa, s + i, obj, size, wri)
                    for i, (ssa, _, obj, size, wri) in enumerate(sp.syncs)]
        sp.ptr_ins = [(ssa, slot) for ssa, slot, _, _, _ in sp.syncs]
        s += len(sp.syncs)
        sp.outs = [(o, t, s + i) for i, (o, t) in enumerate(sp.outs)]
        s += len(sp.outs)
        sp.scalar_ins = [(v, t, s + i) for i, (v, t) in enumerate(sp.scalar_ins)]
    n_frame = 1 + max((len(sp.syncs) + len(sp.outs) + len(sp.scalar_ins)
                       for sp in specs), default=0)
    return specs, n_frame


def type_size(type_id):
    return PC.type_info(type_id)[2]


def _ll_name_of(pc, fname, value):
    """值键 → .ll 内的 SSA 名（arg live-in 用 FUNC_SIGS 参数名）。"""
    if value.origin_inst is not None:
        return value.origin_inst.ssa
    m = re.search(r":arg:(\d+)$", value.key)
    if m:
        idx = int(m.group(1))
        return PC.FUNC_SIGS[fname][idx][1]
    raise SystemExit(f"instrument_ll: no ll name for value {value.key}")


# ---------------------------------------------------------------------------
# 3. IR 文本发射
# ---------------------------------------------------------------------------
def emit_boundary(sp, n_frame, prefix, liveout_map=None):
    liveout_map = liveout_map or {}
    r = sp.ridx
    L = []
    L.append(f"  %nnobf.frame.mask.{r} = ptrtoint ptr %nnobf.context to i64")
    L.append(f"  %nnobf.frame.code.{r} = xor i64 %nnobf.frame.mask.{r}, "
             f"{fmt_ticket_u64(sp.ticket)}")
    L.append(f"  %nnobf.frame.{r}.0 = getelementptr [{n_frame} x i64], "
             f"ptr %nnobf.boundary.frame, i64 0, i64 0")
    L.append(f"  store i64 %nnobf.frame.code.{r}, ptr %nnobf.frame.{r}.0, "
             f"align 8")
    for ssa, slot, _obj, _size, _wri in sp.syncs:
        # 同步指针可能是先前区域导出名（原生名已被删除）
        src = liveout_map.get(ssa, ssa)
        L.append(f"  %nnobf.frame.bits.{r}.{slot} = ptrtoint ptr {src} "
                 f"to i64")
        L.append(f"  %nnobf.frame.{r}.{slot} = getelementptr "
                 f"[{n_frame} x i64], ptr %nnobf.boundary.frame, "
                 f"i64 0, i64 {slot}")
        L.append(f"  store i64 %nnobf.frame.bits.{r}.{slot}, "
                 f"ptr %nnobf.frame.{r}.{slot}, align 8")
    nptr_in = sum(1 for _ssa, ty, _slot in sp.scalar_ins
                  if ty in ("ptr", PC.PTR_TYPE_ID))
    for i, (ssa, ty, slot) in enumerate(sp.scalar_ins):
        # 跨区域 SSA：live-in 可能是先前区域导出名（原生名已被删除）
        src = liveout_map.get(ssa, ssa)
        if ty in ("ptr", PC.PTR_TYPE_ID):
            nm = f"%nnobf.livein.ptr.{r}" if nptr_in == 1 else \
                 f"%nnobf.livein.ptr.{r}.{i}"
            L.append(f"  {nm} = ptrtoint ptr {src} to i64")
        elif ty == "i64":
            nm = src                     # i64：免转换直存
        else:
            nm = f"%nnobf.livein.{r}" if len(sp.scalar_ins) == 1 else \
                 f"%nnobf.livein.{r}.{i}"
            L.append(f"  {nm} = zext {ty} {src} to i64")
        L.append(f"  %nnobf.frame.{r}.{slot} = getelementptr "
                 f"[{n_frame} x i64], ptr %nnobf.boundary.frame, "
                 f"i64 0, i64 {slot}")
        L.append(f"  store i64 {nm}, ptr %nnobf.frame.{r}.{slot}, align 8")
    L.append(f"  %nnobf.resume.{r}.ok = call i32 {prefix}boundary_run("
             f"ptr %nnobf.context, ptr %nnobf.boundary.frame)")
    L.append(f"  call void {prefix}require_success(i32 %nnobf.resume.{r}.ok)")
    nptr_out = sum(1 for _ssa, ty, _slot in sp.outs
                   if ty in ("ptr", PC.PTR_TYPE_ID))
    for i, (ssa, ty, slot) in enumerate(sp.outs):
        L.append(f"  %nnobf.frame.{r}.{slot} = getelementptr "
                 f"[{n_frame} x i64], ptr %nnobf.boundary.frame, "
                 f"i64 0, i64 {slot}")
        L.append(f"  %nnobf.frame.value.{r}.{slot} = load i64, "
                 f"ptr %nnobf.frame.{r}.{slot}, align 8")
        if ty in ("ptr", PC.PTR_TYPE_ID):
            nm = f"%nnobf.liveout.ptr.{r}" if nptr_out == 1 else \
                 f"%nnobf.liveout.ptr.{r}.{i}"
            L.append(f"  {nm} = inttoptr i64 "
                     f"%nnobf.frame.value.{r}.{slot} to ptr")
        elif ty != "i64":
            nm = f"%nnobf.liveout.{r}" if len(sp.outs) == 1 else \
                 f"%nnobf.liveout.{r}.{i}"
            L.append(f"  {nm} = trunc i64 %nnobf.frame.value.{r}.{slot} "
                     f"to {ty}")
        # i64：帧载入值即结果（无转换）
    return L


def emit_prologue(n_frame, prefix, params):
    args = "".join(f", {ty}{(' ' + attr) if attr else ''} {name}"
                   for ty, name, attr in params)
    return [
        f"  %nnobf.boundary.frame = alloca [{n_frame} x i64], align 8",
        f"  %nnobf.context = call ptr {prefix}context_create()",
        f"  %nnobf.begin.ok = call i32 {prefix}call_begin("
        f"ptr %nnobf.context{args})",
        f"  call void {prefix}require_success(i32 %nnobf.begin.ok)",
    ]


def emit_epilogue(prefix):
    return [
        f"  %nnobf.finish.ok = call i32 {prefix}call_finish("
        f"ptr %nnobf.context)",
        f"  call void {prefix}require_success(i32 %nnobf.finish.ok)",
        f"  call void {prefix}context_destroy(ptr %nnobf.context)",
    ]


# ---------------------------------------------------------------------------
# 4. 单函数变换（返回新函数文本行 + 该函数的 declares）
# ---------------------------------------------------------------------------
def _ensure_module_ctx(text):
    """填充 PC 模块级全局（FUNC_SIGS/STRUCT_TYPES）——签名/结构体尺寸源。"""
    PC.parse_llvm_ir(text)


def instrument_function(text, tag, tickets, fn_name):
    fname, blocks, def_idx, end_idx, lines, define_line = \
        parse_function(text, fn_name)
    _ensure_module_ctx(text)
    prefix = f"@__nnobf_neural_ir_{tag}_"

    specs, n_frame = analyze(fname, blocks)
    for sp in specs:
        key = str(sp.ridx)
        if key not in tickets:
            raise SystemExit(f"instrument_ll: no ticket for region {sp.ridx}")
        sp.ticket = tickets[key]

    # live-out SSA → 导出名（region 产物原生替换；i64 直用帧载入值名）
    liveout_map = {}
    for sp in specs:
        nptr_out = sum(1 for _ssa, ty, _slot in sp.outs
                       if ty in ("ptr", PC.PTR_TYPE_ID))
        for i, (ssa, ty, slot) in enumerate(sp.outs):
            if ty in ("ptr", PC.PTR_TYPE_ID):
                nm = f"%nnobf.liveout.ptr.{sp.ridx}" if nptr_out == 1 else \
                     f"%nnobf.liveout.ptr.{sp.ridx}.{i}"
            elif ty == "i64":
                nm = f"%nnobf.frame.value.{sp.ridx}.{slot}"
            else:
                nm = f"%nnobf.liveout.{sp.ridx}" if len(sp.outs) == 1 else \
                     f"%nnobf.liveout.{sp.ridx}.{i}"
            if ssa in liveout_map:
                raise SystemExit(f"duplicate live-out def {ssa}")
            liveout_map[ssa] = nm

    # 每块的 region 起始（inst 序号 → region）与删除集
    region_start = {}                     # (block_idx, inst_idx) -> ridx
    deleted = set()                       # (block_idx, inst_idx)
    for sp in specs:
        first = sp.run[0]
        region_start[(sp.block_idx, first.inst_idx)] = sp.ridx
        for inst in sp.run:
            deleted.add((sp.block_idx, inst.inst_idx))

    def subst_liveout(line):
        def repl(m):
            name = "%" + m.group(1)
            return liveout_map.get(name, name)
        return TOKEN_RE.sub(repl, line)

    # ---- 逐块发射（此阶段保留原编号；live-out 已替换）----
    params = parse_define_params(define_line)
    final_blocks = []
    for bi, blk in enumerate(blocks):
        out = []
        if bi == 0:
            out.extend(emit_prologue(n_frame, prefix, params))
        pc_idx = -1                     # PC 指令序（透传行不计）
        for raw, inst in blk.items:
            if inst is None:
                out.append(subst_liveout(raw))   # 透传行（switch 续行等）
                continue
            pc_idx += 1
            if (bi, pc_idx) in deleted:
                if (bi, pc_idx) in region_start:
                    out.extend(emit_boundary(
                        specs[region_start[(bi, pc_idx)]], n_frame, prefix,
                        liveout_map))
                continue
            line = subst_liveout(raw)
            if inst.opcode == "ret":
                out.extend(emit_epilogue(prefix))
            out.append(line)
        final_blocks.append(out)

    # ---- 重编号：无名值（指令结果+块标签）单计数器按打印序稠密编号 ----
    # 参数 %0..%N-1 保持；入口块 = %N（无名块也计数——引擎 whibo 实证）
    entry_no = len(params)
    num_map = {i: i for i in range(entry_no)}
    num_map[entry_no] = entry_no          # 入口块（原号恒 = 参数数）
    counter = entry_no
    for bi, blk_lines in enumerate(final_blocks):
        if bi != 0:
            counter += 1
            num_map[int(blocks[bi].label)] = counter
        for ln in blk_lines:
            m = re.match(r"\s*%(?:(\d+)\s*=)", ln)
            if m:
                counter += 1
                num_map[int(m.group(1))] = counter

    def renumber(line):
        def repl(m):
            tok = m.group(1)
            if tok.isdigit():
                n = int(tok)
                if n not in num_map:
                    raise SystemExit(
                        f"instrument_ll: reference to deleted/unknown %{n} "
                        f"survived rewrite: {line!r}")
                return "%%%d" % num_map[n]
            return "%" + tok
        return TOKEN_RE.sub(repl, line)

    final_blocks = [[renumber(l) for l in blk] for blk in final_blocks]

    # ---- preds 注释：逆出现序（opt 打印行为，经金标准往返验证）----
    preds = {num_map[int(b.label)]: [] for b in blocks[1:]}
    for bi, blk_lines in enumerate(final_blocks):
        if bi == 0:
            src = entry_no
        else:
            src = num_map[int(blocks[bi].label)]
        for ln in blk_lines:
            for m in re.finditer(r"label %(\d+)", ln):
                preds[int(m.group(1))].append(src)
    for k in preds:
        preds[k] = ", ".join("%%%d" % p for p in reversed(preds[k]))

    # ---- 组装块文本（带标签行）----
    body_blocks = [final_blocks[0]]
    for bi in range(1, len(final_blocks)):
        label = num_map[int(blocks[bi].label)]
        head = f"{label}:"
        if preds[label]:
            head += " " * (PRED_PAD - len(head)) + f"; preds = {preds[label]}"
        body_blocks.append([head] + final_blocks[bi])
    body = "\n\n".join("\n".join(b) for b in body_blocks)

    # ---- 该函数的 declares（call_begin 签名 = 原生参数表）----
    extra = "".join(f", {ty}{(' ' + attr) if attr else ''}"
                    for ty, _name, attr in params)
    decls = []
    for d in SIX_DECLARES:
        decls.append(d.format(p=prefix, extra=extra))

    return define_line, body, decls


def instrument(text, tag, tickets, module_id, fn_name=None):
    """单函数兼容入口（t2/hashmix 路径不变）。"""
    define_line, body, decls = instrument_function(text, tag, tickets,
                                                   fn_name)
    lines = text.split("\n")
    fname, blocks, def_idx, end_idx, _lines, _dl = \
        parse_function(text, fn_name)
    head = list(lines[:def_idx + 1])
    head[0] = f"; ModuleID = '{module_id}'"
    post = lines[end_idx + 1:]
    decl_idxs = [i for i, l in enumerate(post) if l.startswith("declare ")]
    if decl_idxs:
        j = decl_idxs[-1] + 1
        while j < len(post) and post[j].strip() == "":
            j += 1
    else:
        j = 1 if post and post[0] == "" else 0
    new_decls = []
    for d in decls:
        new_decls += [d, ""]
    post = post[:j] + new_decls + post[j:]
    return "\n".join(head + [body, "}"] + post)


def instrument_module(text, functions, module_id=None):
    """多函数变换：functions = [{function, tag, tickets}, ...]（plan 序）。

    也可传 {"functions": [...]} 包装形态。
    """
    if isinstance(functions, dict):
        functions = functions["functions"]
    lines = text.split("\n")
    # 定位每个函数的 (def_idx, end_idx)
    spans = {}
    cur = None
    for i, l in enumerate(lines):
        m = re.match(r"define\s+.*?@([\w.$-]+)\s*\(", l)
        if m:
            cur = m.group(1)
            spans[cur] = [i, None]
        elif l.startswith("}") and cur is not None:
            spans[cur][1] = i
            cur = None
    missing = [f["function"] for f in functions
               if f["function"] not in spans or spans[f["function"]][1] is None]
    if missing:
        raise SystemExit(f"instrument_ll: functions not found: {missing}")

    out = list(lines)
    all_decls = []
    for spec in functions:
        fn, tag = spec["function"], spec["tag"]
        tickets = {str(k): int(v) for k, v in spec["tickets"].items()}
        define_line, body, decls = instrument_function(
            "\n".join(out), tag, tickets, fn)
        # 在最新文本上重新定位（行号会因前函数替换而漂移）
        fname, blocks, def_idx, end_idx, _ls, _dl = parse_function(
            "\n".join(out), fn)
        out[def_idx] = define_line
        out[def_idx + 1:end_idx] = body.split("\n")
        all_decls.extend(decls)
        print(f"instrument_ll: {fn} tag={tag} regions={len(tickets)}",
              file=sys.stderr)

    # 模块头 ModuleID 替换
    if module_id is not None and out and out[0].startswith("; ModuleID"):
        out[0] = f"; ModuleID = '{module_id}'"

    # declares：追加到最后一个 declare 之后（引擎：33×6 集中追加）
    decl_idxs = [i for i, l in enumerate(out) if l.startswith("declare ")]
    if decl_idxs:
        j = decl_idxs[-1] + 1
        while j < len(out) and out[j].strip() == "":
            j += 1
    else:
        j = len(out)
        while j > 0 and out[j - 1].strip() == "":
            j -= 1
    new_decls = []
    for d in all_decls:
        new_decls += [d, ""]
    out = out[:j] + new_decls + out[j:]
    return "\n".join(out)


# ---------------------------------------------------------------------------
# 5. CLI
# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(
        description="ANANSI hybrid-regions 边界插桩器（B3，多函数）")
    ap.add_argument("input", help="输入 input.ll（规范化文本 IR）")
    ap.add_argument("-o", "--output", required=True,
                    help="输出 transformed.ll")
    ap.add_argument("--tag", default=None,
                    help="单函数模式：ABI 票标签 __nnobf_neural_ir_<tag>")
    ap.add_argument("--tickets", default=None,
                    help="票号表 JSON 内联：{\"0\": u64, ...}（region→ticket）")
    ap.add_argument("--tickets-file", default=None,
                    help="票号表 JSON 文件（与 --tickets 二选一）")
    ap.add_argument("--multi", default=None,
                    help="多函数清单 JSON：[{function,tag,tickets},...]")
    ap.add_argument("--module-id", default=None,
                    help="输出 ModuleID（缺省沿用输入第一行）")
    ap.add_argument("--function", default=None,
                    help="目标函数（缺省第一个 define）")
    args = ap.parse_args()

    text = open(args.input).read()
    module_id = args.module_id
    if module_id is None:
        module_id = re.match(r"; ModuleID = '([^']*)'", text).group(1)

    if args.multi:
        functions = json.load(open(args.multi))
        out = instrument_module(text, functions, module_id=module_id)
        with open(args.output, "w") as f:
            f.write(out)
        print(f"instrument_ll: wrote {args.output} "
              f"({len(functions)} functions)", file=sys.stderr)
        return

    if args.tickets:
        tickets = json.loads(args.tickets)
    elif args.tickets_file:
        tickets = json.load(open(args.tickets_file))
    else:
        raise SystemExit("instrument_ll: --tickets or --tickets-file required")
    tickets = {str(k): int(v) for k, v in tickets.items()}

    out = instrument(text, args.tag, tickets, module_id, args.function)
    with open(args.output, "w") as f:
        f.write(out)
    print(f"instrument_ll: wrote {args.output} "
          f"(tag={args.tag}, regions={len(tickets)})", file=sys.stderr)


if __name__ == "__main__":
    main()
