#include <stdio.h>
int main(void) {
    unsigned int x; int k;
    if (scanf("%u %d", &x, &k) != 2) return 97;
    unsigned int y = x << (k & 31);       /* 变长移位（log-tree 路径） */
    unsigned int z = x >> (k & 31);
    unsigned int w = y ^ z;
    w = w | (x & 0xf0u);
    signed char sc = (signed char)(int)w; /* trunc */
    int ext = (int)sc;                    /* sext */
    unsigned int uext = (unsigned int)(unsigned char)sc; /* trunc+zext */
    printf("%u %u %d %u\n", w, (w << 1) | 1u, ext, uext);
    return (int)((w ^ (unsigned int)ext ^ uext) & 0x7fu);
}
