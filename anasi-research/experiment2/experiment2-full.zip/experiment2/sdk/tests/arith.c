#include <stdio.h>
int main(void) {
    int a, b;
    if (scanf("%d %d", &a, &b) != 2) return 98;
    int s = a + b;            /* ADD */
    int d = a - b;            /* SUB */
    int m = a * b;            /* MUL (未实证) */
    int q = 0, r = 0;
    if (b != 0) { q = a / b; r = a % b; }   /* SDIV/SREM (未实证) */
    printf("%d %d %d %d %d\n", s, d, m, q, r);
    return (s ^ d ^ m ^ q ^ r) & 0x7f;
}
