#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""verify_guards.py — 守卫集成终验（融合版：需在 WSL/Linux 内运行）。

六项验收（全部自动，无需 gdb——用自带 PTRACE_TRACEME 探针模拟调试器）：
  V1 语义保持：guards ON 的保护产物在输入电池上与 native/无守卫版全等
     （忠实环境下 anti-emu delta=0 恒等、integrity 键净零、deny-attach
      未命中不改变行为）
  V2 deny-attach 落地：prctl(DUMPABLE,0) 使同用户 PTRACE_ATTACH 被拒
     （v2 静默腐化语义——构造期命中毒化 churn 诱饵态而非 exit 173，
      173 拒绝码由 V7d 的 --guard-strict 泳道覆盖）；无守卫对照可 attach
  V3 integrity 触发（篡改模拟）：从守卫版构建树删除一个守卫函数的入口
     键 XOR 三行 → 重编译 → token 永不匹配 → checkF 返回拒绝值 0，
     电池结果与正确值分歧
  V4 ai-decoy（v0.1.1-antidebug-bal 移植）：ELF 拖车诱饵可见
     （rustc 洪水=68、金丝雀 ≥2）+ 电池语义不变
  V5 churn：transformed.ll 接线（__sdk_churn_step 调用）+ 机制演示
     （每步 ≥100 个诱饵状态字变化）+ 电池语义不变
  V6 opaque：谓词 -O3 存活（全 .text imul 差分 ≥2——产物 -s strip 无符号
     窗口，改以 opaque 泳道净增寄存器 imul 计数）+ IR 发射（gu.opq 标记）
     + 电池语义不变
  V7 CHAMÆLEON M1-M6 chame 泳道（chame-antidebug v0.2 融合）：
     V7a 全泳道干净差分（E≡0 恒等契约）；V7b M3 textkey 篡改→静默腐化；
     V7c M5 投递分歧（nopass→污染 / pass nostop→恢复）；
     V7d --guard-strict 被 trace → exit 173（D4）

融合版相对 v0.1-antidebug 原版的适配：
  - 本版 protect.py 无 Windows→WSL 桥（沿用基础版 --native 机制）：
    本脚本须在 WSL/Linux 内运行
  - 发行包定位：ANANSI_DIST 环境变量 / ~/anansi / ~/Downloads / SDK
    兄弟目录自动探测（anansi-linux-*-x86_64）
  - deny-attach 在 runtime TU 留有 __sdk_guard_boot 引用
    （_context_create 钩子，NNOBF_GUARD_DENY_ATTACH）：V3 篡改重编译
    的链接行需带上 guard.o
  - V4/V5/V6 自 v0.1.1-antidebug-bal 移植：wsl()/wp()/DIST_WIN →
    sh_bash()/原生路径/DIST（protect.py 加 --native）
  - V9/V10（antireverse v0.2）：nonce-mask（consumer_fused_v1 运行时
    nonce 派生掩码——电池差分 + 掩码数据流达运行时值、纯 xor 对照为
    常量闭包）；share-encode（stateful_v34 per-share 驻留编码——电池
    差分 + enc/dec 步骤在位 + nonce+encode 组合）
"""
import glob
import json
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
PIPE = os.path.join(ROOT, "pipeline")
sys.path.insert(0, PIPE)

RT_FLAGS = "-O3 -march=x86-64 -fno-unroll-loops"


def sh_bash(cmd):
    r = subprocess.run(["bash", "-c", cmd], capture_output=True,
                       text=True, encoding="utf-8", errors="replace")
    return r.returncode, r.stdout.strip()


def detect_dist():
    c = os.environ.get("ANANSI_DIST")
    if c and os.path.isdir(c):
        return c
    home = os.path.expanduser("~")
    for base in (os.path.join(home, "anansi"),
                 os.path.join(home, "Downloads"),
                 os.path.normpath(os.path.join(ROOT, ".."))):
        if os.path.isdir(base):
            gs = sorted(glob.glob(os.path.join(base,
                                               "anansi-linux-*-x86_64")))
            if gs:
                return gs[-1]
    return None


DIST = detect_dist()
VDIR = os.path.join(HERE, "_verify_guards")


def run_case(binary, val):
    rc, out = sh_bash(f"echo {val} | {binary}; echo rc=$?")
    exit_line = [l for l in out.splitlines() if l.startswith("rc=")]
    return int(exit_line[-1][3:]) if exit_line else -1


def expect_native(val):
    x = int(val)
    y = (x + 0x1234) & 0xFFFFFFFF
    y ^= x >> 2
    y = ((y << 1) | (y & 1)) & 0xFFFFFFFF
    y = (y + 7) & 0xFFFFFFFF if y < 100 else y
    return y % 256


def main():
    if os.name != "posix":
        print("本脚本须在 WSL/Linux 内运行（融合版 protect.py 用 --native "
              "宿主 sh），例如：\n  wsl -d Ubuntu -- python3 "
              f"{os.path.join(HERE, 'verify_guards.py')}")
        sys.exit(2)
    if not DIST:
        print("未找到 ANANSI 发行包（设 ANANSI_DIST 环境变量指向 "
              "anansi-linux-*-x86_64）")
        sys.exit(2)
    print(f"dist = {DIST}")
    os.makedirs(VDIR, exist_ok=True)

    print("== 构建：guards OFF（对照）与 guards ON（默认六守卫）==")
    for name in ("my_ng", "my_g"):
        out = os.path.join(VDIR, name)
        if os.path.exists(out):
            print(f"  built {name} (cached)")
            continue
        cmd = [sys.executable, os.path.join(PIPE, "protect.py"),
               "--source", os.path.join(HERE, "t2.c"), "--output", out,
               "--native", "--dist", DIST, "--guard-seed", "20261101"]
        if name == "my_ng":
            cmd += ["--guards", ""]
        r = subprocess.run(cmd, capture_output=True, text=True,
                           encoding="utf-8", errors="replace")
        if r.returncode != 0 or not os.path.exists(out):
            print(f"BUILD {name} FAILED:\n{r.stderr[-800:]}")
            sys.exit(1)
        print(f"  built {name}")

    # native 对照
    rc, _ = sh_bash(f"export LD_LIBRARY_PATH={DIST}/lib:$LD_LIBRARY_PATH && "
                    f"{DIST}/bin/clang {os.path.join(HERE, 't2.c')} "
                    f"-o {VDIR}/native_t2 && echo OK")
    if rc != 0:
        print("native build failed")
        sys.exit(1)

    # ptrace 探针
    probe = os.path.join(VDIR, "tracer_probe.c")
    open(probe, "w").write(r"""
#include <sys/ptrace.h>
#include <unistd.h>
#include <sys/wait.h>
int main(int argc, char **argv) {
    pid_t pid = fork();
    if (pid == 0) {
        ptrace(PTRACE_TRACEME, 0, 0, 0);
        execv(argv[1], argv + 1);
        _exit(127);
    }
    int st = 0;
    waitpid(pid, &st, 0);              /* exec SIGTRAP 停点 */
    ptrace(PTRACE_CONT, pid, 0, 0);    /* 放行到真实退出 */
    waitpid(pid, &st, 0);
    return WIFEXITED(st) ? WEXITSTATUS(st) : -1;
}
""")
    rc, _ = sh_bash(f"export LD_LIBRARY_PATH={DIST}/lib:$LD_LIBRARY_PATH && "
                    f"{DIST}/bin/clang {probe} -o {VDIR}/tracer_probe "
                    f"&& echo OK")
    if rc != 0:
        print("tracer probe build failed")
        sys.exit(1)

    inputs = [l.strip() for l in
              open(os.path.join(HERE, "battery_inputs.txt")) if l.strip()][:20]

    print("\n== V1 语义保持（native vs 无守卫 vs 守卫版）==")
    bad = 0
    for v in inputs:
        a = run_case(f"{VDIR}/native_t2", v)
        b = run_case(f"{VDIR}/my_ng", v)
        c = run_case(f"{VDIR}/my_g", v)
        e = expect_native(v)
        ok = a == b == c == e
        if not ok:
            bad += 1
            print(f"  v={v}: native={a} ng={b} g={c} expect={e} MISMATCH")
    print(f"V1 {'PASS' if bad == 0 else 'FAIL'} "
          f"({len(inputs) - bad}/{len(inputs)})")
    if bad:
        sys.exit(1)

    print("\n== V2 deny-attach 落地（dumpable=0：同用户 attach 被拒；"
          "对照无守卫可 attach）==")
    # v2 静默腐化语义：构造期命中不再 exit 173（毒化 churn 诱饵态）——
    # 可观测面是 prctl(PR_SET_DUMPABLE,0) 的落地：同用户 PTRACE_ATTACH
    # 被拒（EPERM）。173 拒绝码由 V7d 的 --guard-strict 泳道覆盖。
    dump_probe = os.path.join(VDIR, "dump_probe.c")
    open(dump_probe, "w").write(r"""
#include <stdio.h>
#include <unistd.h>
#include <sys/ptrace.h>
#include <sys/wait.h>
int main(int argc, char **argv) {
    int pfd[2];
    if (pipe(pfd) != 0) return 2;
    pid_t pid = fork();
    if (pid == 0) {
        dup2(pfd[0], 0); close(pfd[0]); close(pfd[1]);
        execl(argv[1], argv[1], (char *)0);
        _exit(127);
    }
    close(pfd[0]);
    usleep(300000);                 /* 过构造期（dumpable 已置 0/未置）*/
    long r = ptrace(PTRACE_ATTACH, pid, 0, 0);
    if (r == 0) {                   /* attach 成功 → 对照（dumpable=1）*/
        int st;
        waitpid(pid, &st, 0);
        ptrace(PTRACE_DETACH, pid, 0, 0);
    }
    close(pfd[1]);                  /* 关 stdin → 目标 scanf EOF 退出 */
    int st2 = 0;
    waitpid(pid, &st2, 0);
    printf("attach=%ld\n", r);
    return r == 0 ? 0 : 1;
}
""")
    rc, _ = sh_bash(f"export LD_LIBRARY_PATH={DIST}/lib:$LD_LIBRARY_PATH && "
                    f"{DIST}/bin/clang {dump_probe} -o {VDIR}/dump_probe "
                    f"&& echo OK")
    if rc != 0:
        print("V2 SKIP（dump_probe 编译失败）")
    else:
        rc2, out_g = sh_bash(f"{VDIR}/dump_probe {VDIR}/my_g")
        rc3, out_n = sh_bash(f"{VDIR}/dump_probe {VDIR}/my_ng")
        # 期望：守卫版 attach 被拒（rc=1, attach=-1）；无守卫版 attach 成功（rc=0）
        v2_ok = (rc2 == 1 and "attach=-1" in out_g
                 and rc3 == 0 and "attach=0" in out_n)
        print(f"  guarded: {out_g.strip()}（期望 attach=-1 被拒）")
        print(f"  unguarded: {out_n.strip()}（期望 attach=0 成功）")
        print(f"V2 {'PASS' if v2_ok else 'FAIL'}（dumpable=0 落地）")
        if not v2_ok:
            sys.exit(1)

    print("\n== V3 integrity 篡改触发（删除一个守卫入口键 XOR）==")
    tam_dir = os.path.join(VDIR, "tamper")
    os.makedirs(tam_dir, exist_ok=True)
    src_build = os.path.join(VDIR, "my_g.build")
    # 拷贝插桩+守卫后的 IR，删除 main 入口的 token XOR 三行
    ll = open(os.path.join(src_build, "transformed.ll")).read().split("\n")
    drop = [i for i, l in enumerate(ll)
            if ("%gu.t0 = load i64" in l or "%gu.t1 = xor i64 %gu.t0" in l
                or ("%gu.t1" in l and "store i64 %gu.t1" in l))]
    # 仅删第一个函数（main）的一组（t0/t1/store）
    ll = [l for i, l in enumerate(ll) if i not in set(drop[:3])]
    tam_ll = os.path.join(tam_dir, "transformed.ll")
    open(tam_ll, "w").write("\n".join(ll))
    # 融合版：runtime TU 引用 __sdk_guard_boot（_context_create 钩子），
    # 且 IR 含 churn 调用（__sdk_churn_step）——重链接必须带上全部守卫
    # 对象（guard.o=deny-attach、guard_sc.o=churn，按存在性 glob）
    rc, _ = sh_bash(
        f"export LD_LIBRARY_PATH={DIST}/lib:$LD_LIBRARY_PATH && "
        f"cd {tam_dir} && cp {src_build}/runtime_0.o {src_build}/runtime_1.o "
        f"{src_build}/runtime_2.o . 2>/dev/null; "
        f"cp {src_build}/guard*.o . 2>/dev/null; "
        f"{DIST}/bin/clang {RT_FLAGS} -c -x ir transformed.ll "
        f"-o transformed.o && "
        f"{DIST}/bin/clang transformed.o runtime_0.o runtime_1.o "
        f"runtime_2.o $(ls guard*.o 2>/dev/null) -lm -o tampered "
        f"&& echo OK")
    if rc != 0:
        # 单函数模式可能用 runtime/ 目录形态
        rc, _ = sh_bash(
            f"export LD_LIBRARY_PATH={DIST}/lib:$LD_LIBRARY_PATH && "
            f"cd {tam_dir} && cp -r {src_build}/runtime . && "
            f"cp {src_build}/guard*.o . 2>/dev/null; "
            f"{DIST}/bin/clang {RT_FLAGS} -c -x ir transformed.ll "
            f"-o transformed.o && "
            f"{DIST}/bin/clang transformed.o runtime/*.o "
            f"$(ls guard*.o 2>/dev/null) -lm -o tampered && echo OK")
    if rc != 0:
        print("V3 SKIP（篡改重编译环境异常——非守卫问题）")
    else:
        diffs = 0
        for v in inputs[:10]:
            t = run_case(f"{tam_dir}/tampered", v)
            if t != expect_native(v):
                diffs += 1
        print(f"  tampered 电池分歧 {diffs}/10（期望 ≥1：checkF 拒绝值 0）")
        print(f"V3 {'PASS' if diffs >= 1 else 'FAIL'}")
        if diffs < 1:
            sys.exit(1)

    print("\n== V4 ai-decoy（BLA 拖车植入：运行不受影响 + 诱饵可见）==")
    out_gd = os.path.join(VDIR, "my_gd")
    if not os.path.exists(out_gd):
        cmd = [sys.executable, os.path.join(PIPE, "protect.py"),
               "--source", os.path.join(HERE, "t2.c"), "--output", out_gd,
               "--native", "--dist", DIST, "--guard-seed", "20261102"]
        r = subprocess.run(cmd, capture_output=True, text=True,
                           encoding="utf-8", errors="replace")
        if r.returncode != 0 or not os.path.exists(out_gd):
            print(f"BUILD my_gd FAILED rc={r.returncode}:\n{(r.stderr or '')[-600:]}")
            sys.exit(1)
    rc, out = sh_bash(f"strings -a {out_gd} | grep -c '/rustc/'")
    n_rustc = int(out) if out.isdigit() else -1
    rc, out = sh_bash(f"strings -a {out_gd} "
                      f"| grep -c 'PROTECTED_CANARY_CREDENTIAL'")
    n_canary = int(out) if out.isdigit() else -1
    sz = os.path.getsize(out_gd)
    # 基线取无守卫版（my_ng）：my_g 也是六守卫默认构建（含拖车），
    # 对比它显示不出增量
    base = os.path.getsize(os.path.join(VDIR, "my_ng"))
    bad = 0
    for v in inputs:
        c = run_case(out_gd, v)
        if c != expect_native(v):
            bad += 1
    print(f"  trailer: rustc={n_rustc} canary={n_canary} "
          f"size {base}->{sz} (+{sz - base}B)")
    v4_ok = (n_rustc == 68 and n_canary >= 2 and bad == 0)
    print(f"V4 {'PASS' if v4_ok else 'FAIL'} "
          f"(battery {len(inputs) - bad}/{len(inputs)})")
    if not v4_ok:
        sys.exit(1)

    print("\n== V5 churn（影子堆搅动：机制演示 + 运行不受影响）==")
    out_gc = os.path.join(VDIR, "my_gc")
    if not os.path.exists(out_gc):
        cmd = [sys.executable, os.path.join(PIPE, "protect.py"),
               "--source", os.path.join(HERE, "t2.c"), "--output", out_gc,
               "--native", "--dist", DIST, "--guard-seed", "20261103"]
        r = subprocess.run(cmd, capture_output=True, text=True,
                           encoding="utf-8", errors="replace")
        if r.returncode != 0 or not os.path.exists(out_gc):
            print(f"BUILD my_gc FAILED rc={r.returncode}:\n{(r.stderr or '')[-600:]}")
            sys.exit(1)
    # 机制演示：包含生成的 churn 单元，步进两次统计变化字数
    tll = os.path.join(VDIR, "my_gc.build", "transformed.ll")
    wired = os.path.exists(tll) and "__sdk_churn_step" in open(
        tll, encoding="utf-8").read()
    print(f"  churn IR wiring: "
          f"{'call present in transformed.ll' if wired else 'MISSING'}")
    demo = os.path.join(VDIR, "churn_demo.c")
    open(demo, "w").write(r"""
#include <stdio.h>
#include <string.h>
#include "guard_state_churn.c"
int main(void) {
    unsigned int a[32][4], b[32][4];
    __sdk_churn_step(1);
    memcpy(a, __sdk_churn_state, sizeof(a));
    __sdk_churn_step(2);
    memcpy(b, __sdk_churn_state, sizeof(b));
    int changed = 0;
    for (int i = 0; i < 32; i++)
        for (int j = 0; j < 4; j++)
            if (a[i][j] != b[i][j]) changed++;
    printf("changed_words=%d\n", changed);
    return changed >= 100 ? 0 : 1;   /* >REA 步差上限 20、>观察点 4 */
}
""")
    bd = os.path.join(VDIR, "my_gc.build")
    rc, out = sh_bash(
        f"export LD_LIBRARY_PATH={DIST}/lib:$LD_LIBRARY_PATH && "
        f"{DIST}/bin/clang {demo} -I{bd} -o {VDIR}/churn_demo "
        f"&& {VDIR}/churn_demo")
    churn_ok = rc == 0 and "changed_words=" in out
    n_changed = int(out.split("changed_words=")[-1].split()[0]) \
        if churn_ok else -1
    bad = 0
    for v in inputs:
        c = run_case(out_gc, v)
        if c != expect_native(v):
            bad += 1
    print(f"  churn demo: {n_changed} words changed per step "
          f"(>20 diff limit, >4 watchpoints)")
    v5_ok = churn_ok and n_changed >= 100 and bad == 0 and wired
    print(f"V5 {'PASS' if v5_ok else 'FAIL'} "
          f"(battery {len(inputs) - bad}/{len(inputs)})")
    if not v5_ok:
        sys.exit(1)

    print("\n== V6 opaque（数论不透明谓词：-O3 存活 + 运行不受影响）==")
    out_go = os.path.join(VDIR, "my_go")
    if not os.path.exists(out_go):
        cmd = [sys.executable, os.path.join(PIPE, "protect.py"),
               "--source", os.path.join(HERE, "t2.c"), "--output", out_go,
               "--native", "--dist", DIST, "--guard-seed", "20261104"]
        r = subprocess.run(cmd, capture_output=True, text=True,
                           encoding="utf-8", errors="replace")
        if r.returncode != 0 or not os.path.exists(out_go):
            print(f"BUILD my_go FAILED rc={r.returncode}:\n{(r.stderr or '')[-600:]}")
            sys.exit(1)
    # 谓词存活：产物自 v2-final 起全路径 -s strip（无 <main> 符号窗口），
    # 改用全 .text imul 差分（opaque 泳道净增 谓词平方+decoy 平方 ≥2 个
    # 寄存器 imul——-O3 只强度削减常数乘（lea/shl），寄存器平方必存）
    n_go = sh_bash(f"objdump -d {out_go} --no-show-raw-insn | "
                   f"grep -c imul")
    n_ng = sh_bash(f"objdump -d {os.path.join(VDIR, 'my_ng')} "
                   f"--no-show-raw-insn | grep -c imul")
    n_imul = (int(n_go[1]) if n_go[1].isdigit() else 0) - \
             (int(n_ng[1]) if n_ng[1].isdigit() else 0)
    tll = os.path.join(VDIR, "my_go.build", "transformed.ll")
    ir_ok = os.path.exists(tll) and "gu.opq" in open(
        tll, encoding="utf-8").read()
    bad = 0
    for v in inputs:
        c = run_case(out_go, v)
        if c != expect_native(v):
            bad += 1
    print(f"  predicate survival: imul delta={n_imul}（≥2=谓词+decoy "
          f"平方，strip-safe 全 .text 差分）, "
          f"IR emission={'yes' if ir_ok else 'NO'}")
    v6_ok = n_imul >= 2 and ir_ok and bad == 0
    print(f"V6 {'PASS' if v6_ok else 'FAIL'} "
          f"(battery {len(inputs) - bad}/{len(inputs)})")
    if not v6_ok:
        sys.exit(1)

    # ------------------------------------------------------------
    # V7 CHAMÆLEON M1-M6 chame 泳道（chame-antidebug v0.2 融合验收）
    #   V7a 干净差分：全部 chame 泳道开 → 电池 20/20 与 native 全等
    #        （E≡0 契约：M2 ppid 白名单 / M4 fail-open / M5 投递忠实 /
    #         M6 建期标定 / M3 期望回填，全部干净命中零证据）
    #   V7b M3 textkey 篡改（V10b）：flip .text padding 字节 → 静默腐化
    #        （输出错、不崩溃——fail-closed 折叠语义）
    #   V7c M5 投递分歧（V11b）：tracer 吞 SIGTRAP → 输出污染；
    #        pass SIGTRAP → 恢复（门槛=复现投递而非翻布尔）
    #   V7d strict（D4）：--guard-strict 构建被 trace → exit 173
    # ------------------------------------------------------------
    print("\n== V7 CHAMÆLEON chame lanes（M1-M6：干净差分 + 检测探针）==")
    CHAME_G = ("anti-emu,integrity,deny-attach,churn,opaque,"
               "chame-tracer,chame-textkey,chame-hwbp,chame-trap,"
               "chame-oracle")
    out_ch = os.path.join(VDIR, "my_chame")
    if not os.path.exists(out_ch):
        cmd = [sys.executable, os.path.join(PIPE, "protect.py"),
               "--source", os.path.join(HERE, "t2.c"), "--output", out_ch,
               "--native", "--dist", DIST,
               "--guards", CHAME_G, "--guard-seed", "20261105"]
        r = subprocess.run(cmd, capture_output=True, text=True,
                           encoding="utf-8", errors="replace")
        if r.returncode != 0 or not os.path.exists(out_ch):
            print(f"BUILD my_chame FAILED rc={r.returncode}:\n"
                  f"{(r.stderr or '')[-600:]}")
            sys.exit(1)

    bad = 0
    for v in inputs:
        c = run_case(out_ch, v)
        if c != expect_native(v):
            bad += 1
    print(f"  V7a clean battery {len(inputs) - bad}/{len(inputs)}"
          f"（E=0 恒等契约）")
    if bad:
        sys.exit(1)
    print("V7a PASS")

    # V7b M3 篡改：flip .text 对齐 padding 字节（不执行 → 不崩溃，
    # 哈希变化 → boot 全窗哈希检出 → 静默腐化）
    import struct as _struct
    tdata = bytearray(open(out_ch, "rb").read())
    if tdata[:4] == b"\x7fELF":
        e_shoff = _struct.unpack_from("<Q", tdata, 0x28)[0]
        entsz, nsec, strndx = _struct.unpack_from("<HHH", tdata, 0x3A)
        secs = []
        for i in range(nsec):
            b = e_shoff + i * entsz
            nm, _t = _struct.unpack_from("<II", tdata, b)
            off, size = _struct.unpack_from("<QQ", tdata, b + 24)
            secs.append((nm, off, size))
        so = secs[strndx][1]
        text = next(s for s in secs
                    if tdata[so + s[0]:tdata.index(b"\0", so + s[0])]
                    .decode() == ".text")
        toff, tsize = text[1], text[2]
        run, best = 1, -1
        for i in range(toff + 16, toff + tsize - 16):
            if tdata[i] in (0x90, 0xCC, 0x00) and tdata[i] == tdata[i - 1]:
                run += 1
                if run >= 4:
                    best = i
            else:
                run = 1
        if best > 0:
            orig = tdata[best]
            tdata[best] = 0x90 if orig != 0x90 else 0xCC
            tpath = os.path.join(VDIR, "my_chame_tampered")
            open(tpath, "wb").write(bytes(tdata))
            os.chmod(tpath, 0o755)
            diffs = sum(1 for v in inputs
                        if run_case(tpath, v) != expect_native(v))
            crashed = sum(1 for v in inputs
                          if run_case(tpath, v) in (-1, 139))
            print(f"  V7b textkey tamper: .text+{best - toff} "
                  f"0x{orig:02x}->0x{tdata[best]:02x}, "
                  f"diverged {diffs}/{len(inputs)}, crashed {crashed}")
            v7b_ok = diffs >= 1 and crashed == 0
            print(f"V7b {'PASS' if v7b_ok else 'FAIL'}（静默腐化契约）")
            if not v7b_ok:
                sys.exit(1)
        else:
            print("V7b SKIP（未找到 .text padding run）")

    # V7c M5 投递分歧：nopass 探针（吞 SIGTRAP → handler 缺席 → 污染）；
    # pass 探针（投递信号 → handler 执行 → 恢复）。两探针均循环放行
    # 每个停点（M5 的 K 个 int3 会逐次停）。
    open(os.path.join(VDIR, "tp_nopass.c"), "w").write(r"""
#include <sys/ptrace.h>
#include <unistd.h>
#include <sys/wait.h>
int main(int argc, char **argv) {
    pid_t pid = fork();
    if (pid == 0) {
        ptrace(PTRACE_TRACEME, 0, 0, 0);
        execv(argv[1], argv + 1);
        _exit(127);
    }
    int st = 0;
    waitpid(pid, &st, 0);               /* exec SIGTRAP stop */
    ptrace(PTRACE_CONT, pid, 0, 0);
    while (1) {                          /* 后续停点一律吞信号放行 */
        if (waitpid(pid, &st, 0) < 0) break;
        if (WIFEXITED(st) || WIFSIGNALED(st)) break;
        ptrace(PTRACE_CONT, pid, 0, 0);
    }
    return WIFEXITED(st) ? WEXITSTATUS(st) : -1;
}
""")
    open(os.path.join(VDIR, "tp_pass.c"), "w").write(r"""
#include <sys/ptrace.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>
int main(int argc, char **argv) {
    pid_t pid = fork();
    if (pid == 0) {
        ptrace(PTRACE_TRACEME, 0, 0, 0);
        execv(argv[1], argv + 1);
        _exit(127);
    }
    int st = 0;
    waitpid(pid, &st, 0);
    ptrace(PTRACE_CONT, pid, 0, 0);     /* swallow exec trap only */
    while (1) {                          /* SIGTRAP 投递给被保护程序 */
        if (waitpid(pid, &st, 0) < 0) break;
        if (WIFEXITED(st) || WIFSIGNALED(st)) break;
        int sig = WSTOPSIG(st);
        ptrace(PTRACE_CONT, pid, 0, sig == SIGTRAP ? sig : 0);
    }
    return WIFEXITED(st) ? WEXITSTATUS(st) : -1;
}
""")
    rc, _ = sh_bash(f"export LD_LIBRARY_PATH={DIST}/lib:$LD_LIBRARY_PATH && "
                    f"{DIST}/bin/clang {VDIR}/tp_nopass.c -o {VDIR}/tp_nopass && "
                    f"{DIST}/bin/clang {VDIR}/tp_pass.c -o {VDIR}/tp_pass && "
                    f"echo OK")
    if rc == 0:
        v0 = inputs[0] if inputs else "7"
        clean = run_case(out_ch, v0)
        rc_np, _ = sh_bash(f"echo {v0} | {VDIR}/tp_nopass {out_ch}")
        rc_ps, _ = sh_bash(f"echo {v0} | {VDIR}/tp_pass {out_ch}")
        print(f"  V7c clean={clean} nopass={rc_np} pass={rc_ps}")
        v7c_ok = (clean == expect_native(v0) and rc_np != clean
                  and rc_ps == clean)
        print(f"V7c {'PASS' if v7c_ok else 'FAIL'}"
              f"（投递分歧 oracle：nopass→污染，pass→恢复）")
        if not v7c_ok:
            sys.exit(1)
    else:
        print("V7c SKIP（探针编译失败）")

    # V7d strict：证据命中升级 exit 173（规格 D4）
    out_st = os.path.join(VDIR, "my_chame_strict")
    if not os.path.exists(out_st):
        cmd = [sys.executable, os.path.join(PIPE, "protect.py"),
               "--source", os.path.join(HERE, "t2.c"), "--output", out_st,
               "--native", "--dist", DIST, "--guards", CHAME_G,
               "--guard-strict", "--guard-seed", "20261105"]
        r = subprocess.run(cmd, capture_output=True, text=True,
                           encoding="utf-8", errors="replace")
        if r.returncode != 0 or not os.path.exists(out_st):
            print(f"BUILD my_chame_strict FAILED:\n{(r.stderr or '')[-400:]}")
            sys.exit(1)
    v0 = inputs[0] if inputs else "7"
    rc_s, _ = sh_bash(f"echo {v0} | {VDIR}/tp_nopass {out_st}")
    rc_s_clean = run_case(out_st, v0)
    print(f"  V7d strict: clean={rc_s_clean}, traced={rc_s}（期望 173）")
    v7d_ok = rc_s == 173 and rc_s_clean == expect_native(v0)
    print(f"V7d {'PASS' if v7d_ok else 'FAIL'}（D4 拒绝码升级）")
    if not v7d_ok:
        sys.exit(1)

    # ------------------------------------------------------------
    # V8 anti-reverse-prompt (arp) 泳道（anti-reverse-prompt_v0.0.md §9.2；
    # 声明式守卫，emit 契约：干净零输出、绝不 exit、绝不写 stdout）
    #   V8a 干净差分（三通道：exit/stdout/stderr——stderr 零发射硬断言）
    #   V8b 文件通道（ARPNOTC1 拖车可见 + 拖车篡改 → seal 失配 → poison
    #        → arp 发射链：boot 期 stderr 出声明帧、exit 不变）
    #   V8c 内存通道（exec trap 构造器前缓冲全 0 / 物化后 == CANON，
    #        /proc/pid/mem 由 tracer 父进程扫 rw 段）
    #   V8d 发射通道（PTRACE_TRACEME 探针 → deny-attach 构造期 poison
    #        → arp(103) boot 发射两行声明帧）
    #   V8e 节流/上限（loops.c 循环区域 boundary 长跑：1 ≤ 帧数 ≤ 16）
    #   V8f freestanding（nm 零未定义符号 + -nostdlib -static 冒烟链接
    #        运行出声明——R3 libc-free 编译约束）
    #   V8g 组合（六泳道 + chame + xor-mask + arp 全开干净差分）
    #   V8h 直通降级（hello.c 无可保护区域：拖车 + 原生 memcpy 路径）
    #   V8i NN 在环（owner TU 潜码表 + Python 同构 decode 重放 == canon）
    #   V8perf 性能准入（电池耗时偏差 ≤ 10%）
    # ------------------------------------------------------------
    print("\n== V8 anti-reverse-prompt (arp) 泳道（声明式守卫）==")
    import json as _json
    import time as _time

    def run_case3(binary, val):
        """三通道运行：返回 (exit, stdout, stderr)——arp 验收的差分基元。"""
        r = subprocess.run(["bash", "-c", f"echo {val} | {binary}"],
                           capture_output=True, text=True, timeout=300,
                           encoding="utf-8", errors="replace")
        return r.returncode, r.stdout, r.stderr

    ARP_G = ("anti-emu,integrity,deny-attach,churn,opaque,ai-decoy,"
             "seal,arp")
    ARP_OWNER = "ACME Example Ltd."
    out_arp = os.path.join(VDIR, "my_arp")
    if not os.path.exists(out_arp):
        cmd = [sys.executable, os.path.join(PIPE, "protect.py"),
               "--source", os.path.join(HERE, "t2.c"), "--output", out_arp,
               "--native", "--dist", DIST, "--guards", ARP_G,
               "--guard-seed", "20261101", "--arp-owner", ARP_OWNER]
        r = subprocess.run(cmd, capture_output=True, text=True,
                           encoding="utf-8", errors="replace")
        if r.returncode != 0 or not os.path.exists(out_arp):
            print(f"BUILD my_arp FAILED:\n{(r.stderr or '')[-800:]}")
            sys.exit(1)
        print("  built my_arp")

    arp_meta = {}
    arp_json = os.path.join(VDIR, "my_arp.build", "arp_codes.json")
    if os.path.exists(arp_json):
        arp_meta = _json.load(open(arp_json))

    # V8a 干净差分（stderr 零发射硬断言）
    bad = 0
    for v in inputs:
        rc_a, out_a, err_a = run_case3(out_arp, v)
        rc_n, out_n, err_n = run_case3(f"{VDIR}/native_t2", v)
        if not (rc_a == rc_n == expect_native(v) and out_a == out_n
                and err_a == "" and err_n == ""):
            bad += 1
            print(f"  v={v}: rc={rc_a}/{rc_n} expect={expect_native(v)} "
                  f"out={out_a!r}/{out_n!r} err={err_a[:80]!r} MISMATCH")
    print(f"  V8a clean 3-channel battery {len(inputs) - bad}/{len(inputs)}"
          f"（stderr 零发射）")
    if bad:
        sys.exit(1)
    print("V8a PASS")

    # V8b 文件通道：拖车可见 + 篡改→seal 失配→poison→arp 发射（exit 不变）
    arp_data = open(out_arp, "rb").read()
    mk = arp_data.find(b"ARPNOTC1")
    nid = arp_meta.get("notice_id", "")
    v8b_ok = (mk >= 0 and nid and nid.encode() in arp_data
              and b"TRUSTED_ACCESS_REQUIRED" in arp_data
              and b"ANTI-REVERSE-ENGINEERING NOTICE" in arp_data)
    tam = bytearray(arp_data)
    if mk >= 0:
        tam[mk + 24] ^= 0x5A           # 拖车内翻转 1 字节（seal 哈希覆盖区）
        tpath = os.path.join(VDIR, "my_arp_tampered")
        open(tpath, "wb").write(bytes(tam))
        os.chmod(tpath, 0o755)
        v0 = inputs[0] if inputs else "7"
        rc_t, _o, err_t = run_case3(tpath, v0)
        v8b_ok = (v8b_ok and "TRUSTED_ACCESS_REQUIRED" in err_t
                  and rc_t == expect_native(v0))
        print(f"  V8b trailer @{mk}, tamper->emit={'yes' if 'TRUSTED_ACCESS' in err_t else 'NO'}, "
              f"exit={rc_t} (expect {expect_native(v0)})")
    print(f"V8b {'PASS' if v8b_ok else 'FAIL'}"
          f"（文件通道 + seal→poison→arp 发射链）")
    if not v8b_ok:
        sys.exit(1)

    # V8c 内存通道：/proc/pid/mem 扫描（tracer 父进程；rw 段——.rodata
    # 的 r--p 副本排除）。点1 exec trap（构造器前）应全 0；点2 syscall
    # 停点应含 CANON 前缀（物化后）。
    canon = arp_meta.get("canon") or []
    if canon:
        needle = bytes(canon[:40]).hex()
        inp = os.path.join(VDIR, ".arp_in")
        open(inp, "w").write((inputs[0] if inputs else "7") + "\n")
        mem_probe = os.path.join(VDIR, "arp_mem_probe.c")
        open(mem_probe, "w").write(r"""
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/ptrace.h>
#include <sys/wait.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>

/* dumpable=0（deny-attach 构造器）后非 root 无法再打开 /proc/PID/{maps,
 * mem}——权限在 open 时检查。对策：exec trap（构造器前、dumpable=1）
 * 预解析 rw 段并持有 mem fd，后续扫描以 pread 复用句柄。 */
#define MAXR 64
static unsigned long r_lo[MAXR], r_hi[MAXR];
static int r_n = 0;
static int mem_fd = -1;

static int setup_proc(pid_t pid)
{
    char p[64];
    FILE *f;
    char line[512];
    snprintf(p, sizeof(p), "/proc/%d/maps", pid);
    f = fopen(p, "r");
    if (!f) return -1;
    while (fgets(line, sizeof(line), f)) {
        char *dash = strchr(line, '-');
        if (!dash) continue;
        if (!strstr(line, "rw")) continue;      /* 只扫 rw（跳过 .rodata） */
        unsigned long lo = strtoul(line, NULL, 16);
        unsigned long hi = strtoul(dash + 1, NULL, 16);
        unsigned long sz = hi - lo;
        if (sz == 0 || sz > (64u << 20)) continue;
        if (r_n < MAXR) { r_lo[r_n] = lo; r_hi[r_n] = hi; r_n++; }
    }
    fclose(f);
    snprintf(p, sizeof(p), "/proc/%d/mem", pid);
    mem_fd = open(p, O_RDONLY);
    return (mem_fd >= 0 && r_n > 0) ? 0 : -1;
}

static int scan_rw(const unsigned char *needle, int nlen)
{
    for (int r = 0; r < r_n; r++) {
        unsigned long sz = r_hi[r] - r_lo[r];
        unsigned char *buf = malloc(sz);
        if (!buf) continue;
        ssize_t got = pread(mem_fd, buf, sz, (off_t)r_lo[r]);
        if (got > 0)
            for (ssize_t i = 0; i + nlen <= got; i++)
                if (!memcmp(buf + i, needle, nlen)) { free(buf); return 1; }
        free(buf);
    }
    return 0;
}

int main(int argc, char **argv)
{
    if (argc < 4) { fprintf(stderr, "usage: BIN NEEDLE_HEX INFILE\n"); return 2; }
    int nlen = (int)strlen(argv[2]) / 2;
    unsigned char *needle = malloc(nlen);
    for (int i = 0; i < nlen; i++) {
        unsigned v = 0;
        if (sscanf(argv[2] + 2 * i, "%2x", &v) != 1) return 2;
        needle[i] = (unsigned char)v;
    }
    pid_t pid = fork();
    if (pid == 0) {
        ptrace(PTRACE_TRACEME, 0, 0, 0);
        int in = open(argv[3], O_RDONLY);
        if (in >= 0) { dup2(in, 0); close(in); }
        execv(argv[1], argv + 1);
        _exit(127);
    }
    int st = 0;
    waitpid(pid, &st, 0);                    /* exec SIGTRAP：构造器前 */
    if (setup_proc(pid) != 0) {
        printf("pre=setup_fail post=NA\n");
        ptrace(PTRACE_KILL, pid, 0, 0);
        waitpid(pid, &st, 0);
        return 5;
    }
    int pre = scan_rw(needle, nlen);
    int found = 0;
    ptrace(PTRACE_SYSCALL, pid, 0, 0);
    while (!found) {
        if (waitpid(pid, &st, 0) < 0) break;
        if (WIFEXITED(st) || WIFSIGNALED(st)) break;
        if (WIFSTOPPED(st)) {
            int sig = WSTOPSIG(st);
            if (sig == SIGTRAP) {
                found = scan_rw(needle, nlen);
                ptrace(PTRACE_SYSCALL, pid, 0, 0);
            } else {
                ptrace(PTRACE_SYSCALL, pid, 0, sig);
            }
        }
    }
    printf("pre=%d post=%d\n", pre, found);
    if (found) {
        ptrace(PTRACE_SYSCALL, pid, 0, 0);
        while (1) {
            if (waitpid(pid, &st, 0) < 0) break;
            if (WIFEXITED(st) || WIFSIGNALED(st)) break;
            ptrace(PTRACE_SYSCALL, pid, 0, 0);
        }
    }
    return (pre == 0 && found == 1) ? 0 : 4;
}
""")
        rc, _ = sh_bash(f"export LD_LIBRARY_PATH={DIST}/lib:$LD_LIBRARY_PATH && "
                        f"{DIST}/bin/clang {mem_probe} -o {VDIR}/arp_mem_probe"
                        f" && {VDIR}/arp_mem_probe {out_arp} {needle} {inp}")
        v8c_ok = rc == 0
        print(f"  V8c mem probe rc={rc}（pre=0 全 0 / post=1 物化）")
        print(f"V8c {'PASS' if v8c_ok else 'FAIL'}（内存通道：NN 物化前全 0，"
              f"物化后 == CANON）")
        if not v8c_ok:
            sys.exit(1)
    else:
        print("V8c SKIP（arp_codes.json 缺失）")

    # V8d 发射通道：tracer 探针（TRACEME）→ deny-attach 构造期 poison →
    # arp(103) boot 发射。stderr 经 bash 重定向捕获（子进程继承探针 fd 2）。
    v0 = inputs[0] if inputs else "7"
    errf = os.path.join(VDIR, ".arp_stderr")
    rc_d, _ = sh_bash(f"echo {v0} | {VDIR}/tracer_probe {out_arp} "
                      f"2>{errf}; echo probe_rc=$?")
    err_d = open(errf, encoding="utf-8", errors="replace").read() \
        if os.path.exists(errf) else ""
    v8d_ok = ("TRUSTED_ACCESS_REQUIRED" in err_d
              and '"type":"anti_reverse_notice"' in err_d
              and "notice=" in err_d)
    print(f"  V8d traced run stderr {len(err_d)}B, frames="
          f"{err_d.count('TRUSTED_ACCESS_REQUIRED')}")
    print(f"V8d {'PASS' if v8d_ok else 'FAIL'}（发射通道：人读行 + JSON 行）")
    if not v8d_ok:
        sys.exit(1)

    # V8e 节流/上限：loops.c（循环回边内区域——boundary 长跑）被 trace：
    # 发射帧数 1..16（NNOBF_ARP_EMIT_MAX）
    out_arpl = os.path.join(VDIR, "my_arp_loops")
    if not os.path.exists(out_arpl):
        cmd = [sys.executable, os.path.join(PIPE, "protect.py"),
               "--source", os.path.join(HERE, "loops.c"), "--output",
               out_arpl, "--native", "--dist", DIST, "--guards", ARP_G,
               "--guard-seed", "20261101", "--arp-owner", ARP_OWNER,
               # loops.c 的 4 区域与 t2 金标准 profile 不匹配——走模块管线
               # （--functions main → 现场组装权重/profile）
               "--functions", "main"]
        r = subprocess.run(cmd, capture_output=True, text=True,
                           encoding="utf-8", errors="replace")
        if r.returncode != 0 or not os.path.exists(out_arpl):
            print(f"BUILD my_arp_loops FAILED:\n{(r.stderr or '')[-600:]}")
            sys.exit(1)
    rc_e, _ = sh_bash(f"echo 500 7 | {VDIR}/tracer_probe {out_arpl} "
                      f"2>{errf}")
    err_e = open(errf, encoding="utf-8", errors="replace").read() \
        if os.path.exists(errf) else ""
    frames = err_e.count("[TRUSTED_ACCESS_REQUIRED]")
    v8e_ok = 1 <= frames <= 16
    print(f"  V8e loops(500 iters) traced: frames={frames}（1..16）")
    print(f"V8e {'PASS' if v8e_ok else 'FAIL'}（节流/上限：EMIT_MAX=16）")
    if not v8e_ok:
        sys.exit(1)

    # V8f freestanding（R3）：guard_arp.o 无 libc 未定义符号 +
    # -nostdlib -static 冒烟链接（_start 直接调 boot——TEST_FORCE 强制
    # 证据 + PASSTHROUGH 直通降级，双路径一次覆盖）
    arpf = os.path.join(VDIR, "arpf")
    os.makedirs(arpf, exist_ok=True)
    rc_f, out_f = sh_bash(
        f"{sys.executable} {PIPE}/guard_anti_reverse_prompt.py "
        f"--emit-text {arpf} --seed 20261101 --owner '{ARP_OWNER}' "
        f"&& cp {PIPE}/guard_arp.c {arpf}/ && "
        f"export LD_LIBRARY_PATH={DIST}/lib:$LD_LIBRARY_PATH && "
        f"{DIST}/bin/clang -O3 -march=x86-64 -ffreestanding "
        f"-fno-stack-protector -fvisibility=hidden -DNNOBF_ARP_PASSTHROUGH "
        f"-DNNOBF_ARP_TEST_FORCE -c {arpf}/guard_arp.c "
        f"-o {arpf}/guard_arp.o && "
        f"(command -v llvm-nm >/dev/null 2>&1 && llvm-nm {arpf}/guard_arp.o"
        f" || nm {arpf}/guard_arp.o)")
    undef = [l.split()[-1] for l in (out_f or "").splitlines()
             if l.strip().endswith(" U") or " U " in l]
    smoke = os.path.join(arpf, "arp_smoke.c")
    open(smoke, "w").write(r"""
/* -nostdlib 冒烟入口：内核直接跳转 arp_start 时 rsp≡0 (mod 16)，与 C ABI
 * 函数入口假设（rsp≡8）错位 8 字节 → callee 的 movdqa 等对齐指令 GPF。
 * 对策：入口用纯 asm（标准 freestanding _start 写法）——对齐栈后 call，
 * 被调函数按正常 ABI 进入；退出走 exit_group 裸 syscall。 */
__asm__(
    ".globl arp_start\n"
    "arp_start:\n"
    "   xor %rbp, %rbp\n"
    "   and $-16, %rsp\n"
    "   call __sdk_arp_boot\n"
    "   mov $231, %eax\n"        /* SYS_exit_group */
    "   xor %edi, %edi\n"
    "   syscall\n"
    "   hlt\n"
);
""")
    rc_f2, _ = sh_bash(
        f"export LD_LIBRARY_PATH={DIST}/lib:$LD_LIBRARY_PATH && "
        f"{DIST}/bin/clang -O2 -ffreestanding -c {smoke} "
        f"-o {arpf}/arp_smoke.o && "
        f"{DIST}/bin/clang -nostdlib -static -e arp_start "
        f"{arpf}/arp_smoke.o {arpf}/guard_arp.o -o {arpf}/arp_smoke "
        f"&& {arpf}/arp_smoke 2>{errf}")
    err_f = open(errf, encoding="utf-8", errors="replace").read() \
        if os.path.exists(errf) else ""
    v8f_ok = (rc_f == 0 and not undef and rc_f2 == 0
              and "TRUSTED_ACCESS_REQUIRED" in err_f
              and '"type":"anti_reverse_notice"' in err_f)
    print(f"  V8f nm undefined={undef or 'none'}, -nostdlib smoke "
          f"rc={rc_f2}, emit={'yes' if 'TRUSTED_ACCESS' in err_f else 'NO'}")
    print(f"V8f {'PASS' if v8f_ok else 'FAIL'}（libc-free/-nostdlib 冒烟）")
    if not v8f_ok:
        sys.exit(1)

    # V8g 组合：六泳道 + chame 全开 + xor-mask(2 shares) + arp —— 干净差分
    out_arp_c = os.path.join(VDIR, "my_arp_combo")
    if not os.path.exists(out_arp_c):
        cmd = [sys.executable, os.path.join(PIPE, "protect.py"),
               "--source", os.path.join(HERE, "t2.c"), "--output",
               out_arp_c, "--native", "--dist", DIST,
               "--guards", ARP_G + "," + CHAME_G + ",xor-mask",
               "--xor-shares", "2", "--guard-seed", "20261105",
               "--arp-owner", ARP_OWNER]
        r = subprocess.run(cmd, capture_output=True, text=True,
                           encoding="utf-8", errors="replace")
        if r.returncode != 0 or not os.path.exists(out_arp_c):
            print(f"BUILD my_arp_combo FAILED:\n{(r.stderr or '')[-800:]}")
            sys.exit(1)
    bad = 0
    for v in inputs:
        rc_c, _o_c, err_c = run_case3(out_arp_c, v)
        if rc_c != expect_native(v) or err_c != "":
            bad += 1
    print(f"  V8g combo battery {len(inputs) - bad}/{len(inputs)}"
          f"（全泳道全开，stderr 零发射）")
    if bad:
        sys.exit(1)
    print("V8g PASS")

    # V8h 直通降级：hello.c（无可保护区域）——拖车 + 原生 memcpy 路径 +
    # 行为等价 + tracer 发射（constructor 路径）
    out_arph = os.path.join(VDIR, "my_arp_hello")
    if not os.path.exists(out_arph):
        cmd = [sys.executable, os.path.join(PIPE, "protect.py"),
               "--source", os.path.join(HERE, "hello.c"), "--output",
               out_arph, "--native", "--dist", DIST, "--guards", ARP_G,
               "--guard-seed", "20261101", "--arp-owner", ARP_OWNER]
        r = subprocess.run(cmd, capture_output=True, text=True,
                           encoding="utf-8", errors="replace")
        if r.returncode != 0 or not os.path.exists(out_arph):
            print(f"BUILD my_arp_hello FAILED:\n{(r.stderr or '')[-600:]}")
            sys.exit(1)
    hello_data = open(out_arph, "rb").read()
    rc_h, out_h, err_h = run_case3(out_arph, "0")
    rc_hn, out_hn, _ = run_case3(f"{VDIR}/native_t2", "0")
    # hello 语义：stdout "hello world"，exit 0（与 native_t2 无关——hello
    # 自身基线）；干净运行 stderr 空
    v8h_ok = (b"ARPNOTC1" in hello_data and out_h == "hello world\n"
              and rc_h == 0 and err_h == "")
    # 直通 tracer 发射（constructor(103) + PASSTHROUGH memcpy 降级路径）
    rc_h2, _ = sh_bash(f"echo 0 | {VDIR}/tracer_probe {out_arph} 2>{errf}")
    err_h2 = open(errf, encoding="utf-8", errors="replace").read() \
        if os.path.exists(errf) else ""
    v8h_ok = v8h_ok and "TRUSTED_ACCESS_REQUIRED" in err_h2
    print(f"  V8h passthrough: trailer={'yes' if b'ARPNOTC1' in hello_data else 'NO'}, "
          f"out={out_h!r}, rc={rc_h}, traced_emit="
          f"{'yes' if 'TRUSTED_ACCESS' in err_h2 else 'NO'}")
    print(f"V8h {'PASS' if v8h_ok else 'FAIL'}（直通降级路径）")
    if not v8h_ok:
        sys.exit(1)

    # V8i NN 在环：owner TU 潜码表 + Python 同构 decode 重放 == canon
    rt_main = os.path.join(VDIR, "my_arp.build", "runtime",
                           "runtime_0_main.c")
    v8i_ok = False
    if os.path.exists(rt_main) and arp_meta:
        rt_src = open(rt_main, encoding="utf-8").read()
        has_table = "nnobf_arp_codes[" in rt_src
        has_walk = "void __sdk_arp_materialize(void)" in rt_src
        # Python 同构重放：decode(codes)（与 C decode_byte 同源数学）
        import numpy as _np
        npz = _np.load(os.path.join(ROOT, "weights", "modules",
                                    "module_weights_t2_fp32.npz"))
        w = {k: _np.asarray(npz[k], dtype=_np.float64)
             for k in ("dec_w1", "dec_b1", "dec_w2", "dec_b2",
                       "dec_w3", "dec_b3")}
        codes = _np.asarray(arp_meta["codes"], dtype=_np.float64)
        h1 = _np.maximum(codes @ w["dec_w1"] + w["dec_b1"], 0.0)
        h2 = _np.maximum(h1 @ w["dec_w2"] + w["dec_b2"], 0.0)
        lg = h2 @ w["dec_w3"] + w["dec_b3"]
        replay = ((lg >= 0.0)
                  * (1 << _np.arange(8, dtype=_np.int64))).sum(1)
        canon_arr = _np.asarray(arp_meta["canon"], dtype=_np.int64)
        replay_ok = bool((replay == canon_arr).all())
        v8i_ok = has_table and has_walk and replay_ok
        print(f"  V8i owner TU table={has_table}, walk={has_walk}, "
              f"decode replay {int((replay == canon_arr).sum())}/"
              f"{len(canon_arr)}")
    print(f"V8i {'PASS' if v8i_ok else 'FAIL'}（NN 在环：潜码烤入 + 同构重放）")
    if not v8i_ok:
        sys.exit(1)

    # V8perf 性能准入：arp 增量 ≤ 10%（正确基线 = 同泳道无 arp 的 my_g；
    # 二进制先拷 WSL 本地盘 /tmp——9p 挂载（/mnt/d）的按需分页噪声会
    # 淹没毫秒级物化开销。实测本地盘：物化 ~1ms/次（363×decode walk））
    pdir = "/tmp/arp_perf_bin"
    sh_bash(f"rm -rf {pdir} && mkdir -p {pdir} && "
            f"cp {VDIR}/my_g {VDIR}/my_arp {pdir}/ && "
            f"chmod +x {pdir}/my_g {pdir}/my_arp")
    t0 = _time.time()
    for v in inputs:
        run_case(f"{pdir}/my_g", v)
    t_g = _time.time() - t0
    t0 = _time.time()
    for v in inputs:
        run_case(f"{pdir}/my_arp", v)
    t_arp = _time.time() - t0
    ratio = t_arp / t_g if t_g > 0 else 99.0
    v8p_ok = ratio <= 1.10 or (t_arp - t_g) < 2.0
    print(f"  V8perf battery time (local fs): g={t_g:.1f}s arp={t_arp:.1f}s "
          f"ratio={ratio:.3f}")
    print(f"V8perf {'PASS' if v8p_ok else 'FAIL'}（arp 增量 ≤ +10% 或绝对 <2s）")
    if not v8p_ok:
        sys.exit(1)

    # V9 nonce-mask（antireverse v0.2，consumer_fused_v1 运行时 nonce 派生
    #   掩码——antireverse_v0.2.md §6.2）：
    #   构建差分（电池 20/20）+ 计划级证明：掩码数据流回溯到达运行时值
    #   （live-in / LOAD 输出），而纯 xor-mask 对照的掩码闭包仅常量
    # V10 share-encode（stateful_v34 per-share 槽位驻留编码）：
    #   构建差分 + enc/dec 步骤在位 + 组合（nonce+encode）差分
    print("\n== V9 nonce-mask（consumer_fused_v1 运行时 nonce 掩码）==")
    out_v9 = os.path.join(VDIR, "my_v9")
    if not os.path.exists(out_v9):
        cmd = [sys.executable, os.path.join(PIPE, "protect.py"),
               "--source", os.path.join(HERE, "t2.c"), "--output", out_v9,
               "--native", "--dist", DIST, "--guard-seed", "20261102",
               "--guards", "anti-emu,integrity,deny-attach,churn,opaque,"
                           "ai-decoy,seal,xor-mask,nonce-mask"]
        r = subprocess.run(cmd, capture_output=True, text=True,
                           encoding="utf-8", errors="replace")
        if r.returncode != 0 or not os.path.exists(out_v9):
            print(f"BUILD my_v9 FAILED rc={r.returncode}:\n{(r.stderr or '')[-600:]}")
            sys.exit(1)
    bad = 0
    for v in inputs:
        c = run_case(out_v9, v)
        if c != expect_native(v):
            bad += 1
    print(f"  V9 battery {len(inputs) - bad}/{len(inputs)}")

    def _plan_masks_runtime(build_dir):
        """计划级证明：nonce-mask 步骤的掩码闭包到达运行时值
        （live-in 或 LOAD 产出），返回 (runtime_ok, n_mask_steps)。"""
        ppath = os.path.join(build_dir, "module_plan.json")
        if not os.path.exists(ppath):
            return False, 0
        module = json.load(open(ppath, encoding="utf-8"))
        n_masks = 0
        runtime = 0
        for plan in module["plans"]:
            values = {v["key"]: v for v in plan["values"]}
            producer = {s["output_value"]: s for s in plan["steps"]
                        if s.get("output_value")}
            mask_outs = [s["output_value"] for s in plan["steps"]
                         if (s.get("metadata") or {}).get("stage")
                         == "nonce-mask"]
            n_masks += len(mask_outs)
            seen = set()
            frontier = list(mask_outs)
            while frontier:
                k = frontier.pop()
                if k in seen:
                    continue
                seen.add(k)
                v = values.get(k)
                if v is None or v["kind"] == "constant":
                    continue
                if v["kind"] == "live-in" \
                        or producer.get(k, {}).get("operation") == "LOAD":
                    runtime += 1
                    continue
                ps = producer.get(k)
                if ps:
                    frontier.extend(ps["input_values"])
        return runtime > 0, n_masks

    rt9, nm9 = _plan_masks_runtime(out_v9 + ".build")
    # 对照：纯 xor-mask（无 nonce）构建树的掩码为常量
    out_x = os.path.join(VDIR, "my_x")
    if not os.path.exists(out_x):
        cmd = [sys.executable, os.path.join(PIPE, "protect.py"),
               "--source", os.path.join(HERE, "t2.c"), "--output", out_x,
               "--native", "--dist", DIST, "--guard-seed", "20261102",
               "--guards", "anti-emu,integrity,deny-attach,churn,opaque,"
                           "ai-decoy,seal,xor-mask"]
        r = subprocess.run(cmd, capture_output=True, text=True,
                           encoding="utf-8", errors="replace")
        if r.returncode != 0 or not os.path.exists(out_x):
            print(f"BUILD my_x FAILED rc={r.returncode}:\n{(r.stderr or '')[-600:]}")
            sys.exit(1)
    rt_x, nm_x = _plan_masks_runtime(out_x + ".build")
    v9_ok = bad == 0 and rt9 and nm9 > 0 and nm_x == 0
    print(f"  plan proof: nonce-mask steps={nm9}（runtime closure "
          f"{'yes' if rt9 else 'NO'}）; xor-only control masks={nm_x}")
    print(f"V9 {'PASS' if v9_ok else 'FAIL'}")
    if not v9_ok:
        sys.exit(1)

    print("\n== V10 share-encode（stateful_v34 per-share 驻留编码）==")
    out_v10 = os.path.join(VDIR, "my_v10")
    if not os.path.exists(out_v10):
        cmd = [sys.executable, os.path.join(PIPE, "protect.py"),
               "--source", os.path.join(HERE, "t2.c"), "--output", out_v10,
               "--native", "--dist", DIST, "--guard-seed", "20261103",
               "--guards", "anti-emu,integrity,deny-attach,churn,opaque,"
                           "ai-decoy,seal,xor-mask,share-encode"]
        r = subprocess.run(cmd, capture_output=True, text=True,
                           encoding="utf-8", errors="replace")
        if r.returncode != 0 or not os.path.exists(out_v10):
            print(f"BUILD my_v10 FAILED rc={r.returncode}:\n{(r.stderr or '')[-600:]}")
            sys.exit(1)
    bad = 0
    for v in inputs:
        c = run_case(out_v10, v)
        if c != expect_native(v):
            bad += 1
    ppath = os.path.join(out_v10 + ".build", "module_plan.json")
    stages = set()
    if os.path.exists(ppath):
        for plan in json.load(open(ppath, encoding="utf-8"))["plans"]:
            stages |= {(s.get("metadata") or {}).get("stage")
                       for s in plan["steps"]}
    enc_ok = "enc-salt" in stages and "dec-salt" in stages
    print(f"  V10 battery {len(inputs) - bad}/{len(inputs)}; "
          f"enc/dec steps={'yes' if enc_ok else 'NO'}")
    v10_ok = bad == 0 and enc_ok
    print(f"V10 {'PASS' if v10_ok else 'FAIL'}")
    if not v10_ok:
        sys.exit(1)

    # V10b 组合：nonce-mask + share-encode（防御纵深：编码垫在运行期掩码上）
    out_v10b = os.path.join(VDIR, "my_v10b")
    if not os.path.exists(out_v10b):
        cmd = [sys.executable, os.path.join(PIPE, "protect.py"),
               "--source", os.path.join(HERE, "t2.c"), "--output", out_v10b,
               "--native", "--dist", DIST, "--guard-seed", "20261104",
               "--guards", "anti-emu,integrity,deny-attach,churn,opaque,"
                           "ai-decoy,seal,xor-mask,nonce-mask,share-encode"]
        r = subprocess.run(cmd, capture_output=True, text=True,
                           encoding="utf-8", errors="replace")
        if r.returncode != 0 or not os.path.exists(out_v10b):
            print(f"BUILD my_v10b FAILED rc={r.returncode}:\n{(r.stderr or '')[-600:]}")
            sys.exit(1)
    bad = 0
    for v in inputs:
        c = run_case(out_v10b, v)
        if c != expect_native(v):
            bad += 1
    rt10b, nm10b = _plan_masks_runtime(out_v10b + ".build")
    print(f"  V10b combo battery {len(inputs) - bad}/{len(inputs)}; "
          f"nonce-mask steps={nm10b}, runtime closure "
          f"{'yes' if rt10b else 'NO'}")
    v10b_ok = bad == 0 and rt10b and nm10b > 0
    print(f"V10b {'PASS' if v10b_ok else 'FAIL'}（组合）")
    if not v10b_ok:
        sys.exit(1)

    print("\nverify_guards: ALL PASS")


if __name__ == "__main__":
    main()
