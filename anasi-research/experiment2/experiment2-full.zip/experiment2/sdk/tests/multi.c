#include <stdio.h>

static unsigned int mix(unsigned int v) {
    unsigned int y = v + 0x1234u;
    y ^= v >> 3;
    y = (y << 2) | (y & 3u);
    if (y < 50u) y = y + 11u;
    return y & 0xffu;
}

int main(void) {
    unsigned int a, b;
    if (scanf("%u %u", &a, &b) != 2) return 95;
    unsigned int r1 = mix(a);        /* 函数 1：含区域 */
    unsigned int r2 = mix(b + r1);   /* 第二次调用（不同常量传播形态） */
    unsigned int r3 = (a ^ b) + (r1 | r2);  /* main 内区域 */
    printf("%u %u %u\n", r1, r2, r3);
    return (int)((r1 + r2 + r3) & 0x7fu);
}
