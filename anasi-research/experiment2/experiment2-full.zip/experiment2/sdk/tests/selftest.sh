#!/bin/bash
# anansi-neural-sdk 自检（无需 Docker；--docker 附加端到端测试）
# T1: plan_compiler 对金标准 module_plan 回归（0 字段差异为通过）
# T2: runtime_codegen 用附带权重生成 3 个运行时 TU（非空+可 diff 结构为通过）
# T3 (--docker): protect.py 端到端 + 51 输入差分电池（需 docker 镜像）
set -u
cd "$(dirname "$0")/.."
PY=python3
fail=0

echo "== T1: plan_compiler 金标准回归 =="
$PY pipeline/plan_compiler.py tests/golden/input_t2.ll \
    --module-identifier "/tmp/nnobf-ir-compat-1242640673/input.ll" \
    -o /tmp/sdk_plan.json || fail=1
$PY - <<'PYEOF'
import json
mine = json.load(open('/tmp/sdk_plan.json'))
gold = json.load(open('tests/golden/module_plan_t2.json'))
gm, gg = mine['plans'][0], gold['plans'][0]
def core(s): return (s['operation'], tuple(s['input_slots']), s['output_slot'])
mc, gc = [core(s) for s in gm['steps']], [core(s) for s in gg['steps']]
n = sum(a == b for a, b in zip(mc, gc))
fd = sum(1 for a, b in zip(gm['steps'], gg['steps']) for k in set(a)|set(b) if a.get(k) != b.get(k))
print(f"T1 core-seq {n}/{len(gc)}, field diffs {fd}")
assert n == len(gc) and len(mc) == len(gc) and fd == 0, "T1 FAIL"
print("T1 PASS")
PYEOF
[ $? -ne 0 ] && fail=1

echo "== T2: runtime_codegen 运行时生成 =="
rm -rf /tmp/sdk_rt && mkdir -p /tmp/sdk_rt
$PY pipeline/runtime_codegen.py \
    --weights weights/modules/module_weights_t2_fp32.npz \
    --profile pipeline/runtime_codegen_data/profile_fp32_t2.json \
    --out /tmp/sdk_rt || fail=1
for f in runtime_0_main.c runtime_weights.c runtime_module_state.c; do
  if [ -s "/tmp/sdk_rt/$f" ]; then echo "  $f: $(wc -l < /tmp/sdk_rt/$f) lines OK"; else echo "  $f: MISSING"; fail=1; fi
done
grep -q "nnobf_controller_step" /tmp/sdk_rt/runtime_0_main.c && echo "T2 PASS" || { echo "T2 FAIL"; fail=1; }

echo "== T3: weight_composer 任意计划权重组装（零训练，包内权重库）=="
$PY pipeline/weight_composer.py --plan tests/golden/module_plan_t2.json \
    --storage fp32 --out /tmp/sdk_composed.npz 2>&1 | grep -E "ok|FAIL" | tail -5
$PY -c "
import numpy as np
w = np.load('/tmp/sdk_composed.npz')
assert 'alu_region' in w.files and len(w.files) > 20, 'composer output invalid'
print('T3 PASS (%d tensors)' % len(w.files))" || fail=1

if [ "${1:-}" = "--docker" ]; then
  echo "== T3: 端到端 + 差分电池（需 Docker）=="
  $PY pipeline/protect.py --source tests/t2.c --output /tmp/sdk_myprot \
      --weight-npz weights/modules/module_weights_t2_fp32.npz || fail=1
  for v in $(head -5 tests/battery_inputs.txt); do
    echo "$v" | /tmp/sdk_myprot >/dev/null 2>&1; m=$?
    n=$($PY -c "
x=$v; y=(x+0x1234)&0xffffffff; y^=x>>2; y=((y<<1)|(y&1))&0xffffffff
y=(y+7)&0xffffffff if y<100 else y; print(y%256)")
    [ "$m" = "$n" ] && echo "  v=$v ok ($m)" || { echo "  v=$v MISMATCH mine=$m native=$n"; fail=1; }
  done
fi

echo
[ $fail -eq 0 ] && echo "SELFTEST ALL PASS" || echo "SELFTEST FAILED"
exit $fail
