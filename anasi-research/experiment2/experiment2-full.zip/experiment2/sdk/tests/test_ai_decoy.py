#!/usr/bin/env python3
"""test_ai_decoy.py — Lane 4 ai-decoy 单元测试（纯 Python，无需编译环境）。

覆盖：
  T1 载荷生成：确定性（同 seed 同字节）/ 数量（rustc 洪水 68>64）/ 形状
  T2 ELF 拖车：追加后原字节不动、marker 可解析、可剥离还原
  T3 非 ELF 拒绝 + 截断 ELF 拒绝
"""
import os
import struct
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "pipeline"))
import guard_ai_decoy as D  # noqa: E402

FAILURES = []


def check(name, cond, detail=""):
    print(f"[{'PASS' if cond else 'FAIL'}] {name}"
          + (f"  {detail}" if detail and not cond else ""))
    if not cond:
        FAILURES.append(name)


# ---- T1 载荷 ----
b1, d1 = D.build_payload(12345)
b2, d2 = D.build_payload(12345)
b3, _ = D.build_payload(999)
check("T1 同 seed 逐字节一致", b1 == b2)
check("T1 异 seed 不同", b1 != b3)
check("T1 rustc 洪水 68 条（>REA 上限 64）",
      b1.count(b"/rustc/") == 68, f"got {b1.count(b'/rustc/')}")
check("T1 金丝雀令牌存在且明示 canary/EXAMPLE",
      b"PROTECTED_CANARY_CREDENTIAL=" in b1
      and (b"EXAMPLE" in b1 or b"canary" in b1))
check("T1 歧义凭据 URL（单斜杠方案）",
      b"TRANSPORT_ENDPOINT=https:/canary:" in b1)
check("T1 诊断兔子洞", b"Remediation:" in b1 and b"attest" in b1)
check("T1 架构/证据幻象", b"EVIDENCE_CONTRACT_SUMMARY" in b1
      and b"TEE Enclave" in b1)
check("T1 不含伪造合规声明（伦理边界）",
      b"COPPA" not in b1 and b"IEC_62304" not in b1
      and b"minor" not in b1.lower())
check("T1 全部 NUL 结尾（strings 可见）",
      b1.endswith(b"\x00") and b1.count(b"\x00") == d1["payloads"])

# ---- T2 ELF 拖车 ----
# 合成最小 ELF64（头 64B + 假 section 表）
ehdr = bytearray(64)
ehdr[0:4] = b"\x7fELF"
ehdr[4] = 2                      # ELF64
ehdr[5] = 1                      # LE
struct.pack_into("<H", ehdr, 58, 64)      # shentsize
struct.pack_into("<H", ehdr, 60, 1)       # shnum
struct.pack_into("<H", ehdr, 62, 0)       # shstrndx
fake = bytes(ehdr) + b"\x00" * 64         # 1 个空 section 头
p = os.path.join(HERE, "_decoy_test.elf")
open(p, "wb").write(fake)
desc = D.apply_ai_decoy(p, 777)
data = open(p, "rb").read()
check("T2 原字节前缀不动", data[:len(fake)] == fake)
check("T2 marker 存在且长度字段正确",
      data[len(fake):len(fake) + 9] == b"BLADECOY1"
      and struct.unpack_from("<I", data, len(fake) + 9)[0]
      == desc["trailer_bytes"] - 13)
# 剥离还原
blk_len = struct.unpack_from("<I", data, len(fake) + 9)[0]
stripped = data[:len(fake)]
check("T2 剥离后 == 原文件",
      data[:len(fake)] == stripped
      and len(data) == len(fake) + 13 + blk_len)
check("T2 拖车含 rustc 洪水", data.count(b"/rustc/") == 68)

# ---- T3 拒绝非 ELF ----
p2 = os.path.join(HERE, "_decoy_notelf.bin")
open(p2, "wb").write(b"MZ\x90\x00" + b"\x00" * 100)
try:
    D.apply_ai_decoy(p2, 1)
    check("T3 非 ELF 拒绝", False)
except SystemExit:
    check("T3 非 ELF 拒绝", True)
p3 = os.path.join(HERE, "_decoy_trunc.elf")
open(p3, "wb").write(b"\x7fELF\x02\x01" + b"\x00" * 10)   # <64B
try:
    D.apply_ai_decoy(p3, 1)
    check("T3 截断 ELF 拒绝", False)
except SystemExit:
    check("T3 截断 ELF 拒绝", True)

for f in [p, p2, p3]:
    os.remove(f)

print()
if FAILURES:
    print(f"FAILED: {FAILURES}")
    sys.exit(1)
print("ai_decoy: ALL TESTS PASS")
