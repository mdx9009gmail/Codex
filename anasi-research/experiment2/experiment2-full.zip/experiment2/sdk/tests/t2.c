#include <stdio.h>
int main(void) {
    unsigned int x;
    if (scanf("%u", &x) != 1) return 99;
    unsigned int y = x + 0x1234u;        /* ADD */
    y = y ^ (x >> 2);                    /* XOR, LSHR */
    y = (y << 1) | (y & 1u);             /* SHL, OR, AND */
    if (y < 100u) y = y + 7u;            /* ICMP_ULT, ADD, SELECT */
    return (int)(y % 256u);
}
