#include <stdio.h>
int main(void) {
    unsigned int n; unsigned int seed;
    if (scanf("%u %u", &n, &seed) != 2) return 96;
    unsigned int acc = seed;
    unsigned int i = 0;
    while (i < n) {                 /* 循环 N 次由输入决定 */
        acc = acc * 3u + 0x9eu;     /* 区域在循环体内：MUL+ADD 累积 */
        acc ^= acc >> 4;            /* 常量移位 LSHR + XOR */
        i = i + 1u;
    }
    printf("%u\n", acc);
    return (int)(acc & 0x7fu);
}
