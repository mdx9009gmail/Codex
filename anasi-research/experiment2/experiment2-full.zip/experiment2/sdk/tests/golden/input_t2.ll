; ModuleID = '/out/t2.c'
source_filename = "/out/t2.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-conda-linux-gnu"

@.str = private unnamed_addr constant [3 x i8] c"%u\00", align 1

; Function Attrs: nofree nounwind uwtable
define dso_local range(i32 0, 256) i32 @main() local_unnamed_addr #0 {
  %1 = alloca i32, align 4
  %2 = call i32 (ptr, ...) @__isoc99_scanf(ptr noundef nonnull @.str, ptr noundef nonnull %1)
  %3 = icmp eq i32 %2, 1
  br i1 %3, label %4, label %16

4:                                                ; preds = %0
  %5 = load i32, ptr %1, align 4, !tbaa !5
  %6 = add i32 %5, 4660
  %7 = lshr i32 %5, 2
  %8 = xor i32 %6, %7
  %9 = shl i32 %8, 1
  %10 = and i32 %8, 1
  %11 = or disjoint i32 %9, %10
  %12 = icmp ult i32 %9, 100
  %13 = add nuw nsw i32 %11, 7
  %14 = select i1 %12, i32 %13, i32 %11
  %15 = and i32 %14, 255
  br label %16

16:                                               ; preds = %0, %4
  %17 = phi i32 [ %15, %4 ], [ 99, %0 ]
  ret i32 %17
}

; Function Attrs: nofree nounwind
declare noundef i32 @__isoc99_scanf(ptr noundef readonly captures(none), ...) local_unnamed_addr #1

attributes #0 = { nofree nounwind uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}
!llvm.errno.tbaa = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{!"clang version 22.1.8 (https://github.com/conda-forge/clangdev-feedstock fb53dd81989499cc67dae1f1f8965d8e5db7af47)"}
!5 = !{!6, !6, i64 0}
!6 = !{!"int", !7, i64 0}
!7 = !{!"omnipotent char", !8, i64 0}
!8 = !{!"Simple C/C++ TBAA"}
