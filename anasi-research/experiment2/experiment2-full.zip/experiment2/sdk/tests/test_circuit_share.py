#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""circuit_share（circuit-under-NN）单元测试。

覆盖：
  - 金标准 t2 计划（fold/masked 两档 × share 2/4/8）差分
  - 分享域代数（secure-AND/OR、掩码 Kogge-Stone 加/减法器）对随机向量
  - lane 路由保持（byte-route OR、funnel 移位）
  - 区域边界（live-in 拆分 / live-out 折叠 / 跨区域值）
  - STORE 折叠、函数过滤、确定性、验证器自检（注入腐化必须被抓）
"""

import copy
import json
import os
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
PIPE = os.path.normpath(os.path.join(HERE, "..", "pipeline"))
sys.path.insert(0, PIPE)

import circuit_share as CS  # noqa: E402

GOLDEN = os.path.join(HERE, "golden", "module_plan_t2.json")


# ---------------------------------------------------------------------------
# 合成计划构造器（最小合法计划 JSON）
# ---------------------------------------------------------------------------
def _vj(key, kind, tid, const=None):
    kind_t, w = CS.type_info(tid)
    return {
        "key": key, "kind": kind,
        "type_kind": "pointer" if kind_t == "pointer" else "integer",
        "logical_width": w, "encoded_bytes": CS.encoded_bytes(w),
        "type_id": tid, "slot": None, "constant_value": const,
        "source_reference": key, "abi_index": None,
    }


def build_plan(fn, steps, regions, values=None):
    """steps: [(op, inputs, output, src_tid, val_tid, md, kind)]；
    regions: [(live_in_keys, live_out_keys)]（区域按步序切分）。
    values 额外补注（live-in/常量）。"""
    vlist = []
    seen = set()

    def add(v):
        if v["key"] not in seen:
            seen.add(v["key"])
            vlist.append(v)

    for v in values or []:
        add(v)
    step_json = []
    for i, (op, inputs, output, src_tid, val_tid, md, kind) in enumerate(
            steps):
        for k in inputs:
            add(_vj(k, "live-in", src_tid if not k.startswith("const:")
                    else k.split(":")[1]))
        if output:
            add(_vj(output, "ssa", val_tid))
        step_json.append({
            "index": i, "origin_reference": f"synthetic:{fn}:{i}",
            "action_kind": kind, "operation": op,
            "input_values": list(inputs), "input_slots": [],
            "output_value": output, "output_slot": None,
            "source_type_id": src_tid, "source_width":
                CS.type_info(src_tid)[1],
            "value_type_id": val_tid, "type_kind": "integer",
            "logical_width": CS.type_info(val_tid)[1],
            "address": None, "metadata": md,
            "next_action": None, "true_action": None, "false_action": None,
            "next_slot_renames": [], "true_slot_renames": [],
            "false_slot_renames": [],
        })
    region_json = []
    pos = 0
    for ridx, (live_in, live_out) in enumerate(regions):
        count = len(steps) // len(regions)
        start = ridx * count
        region_json.append({
            "index": ridx, "region_id": f"{fn}:region:{ridx}",
            "action_start": start, "action_count": count,
            "instruction_references": [],
            "live_in_values": list(live_in),
            "live_out_values": list(live_out),
            "entry_block": None, "exit_block": None, "region_blocks": [],
            "entry_slot_bindings": [], "resident_in_values": [],
            "resident_out_values": [], "resident_phi_edges": [],
        })
        pos = start + count
    n = len(steps)
    return {
        "schema": "nnobf-neural-ir-v8",
        "controller_action_schema": "nnobf-controller-action-v7",
        "function": fn, "rewrite_kind": "hybrid-regions",
        "context": {
            "schema": "nnobf-neural-context-v2",
            "temp_slot_capacity": 8, "temp_slot_width_bytes": 4,
            "temp_slots": [], "persistent_objects": [],
            "controller_kind": "static-mlp", "control_stack_capacity": 0,
            "thread_local": True,
            "frames": [
                {"frame_id": "module", "layer": "module", "temp_slots": [],
                 "object_ids": [], "control_stack_capacity": 0,
                 "reentrant": True},
                {"frame_id": "region", "layer": "region",
                 "temp_slots": list(range(8)), "object_ids": [],
                 "control_stack_capacity": 0, "reentrant": True},
            ],
        },
        "controller": {
            "cell_id": f"static-mlp:{fn}", "kind": "static-mlp",
            "action_schema": "nnobf-controller-action-v7", "state_width": 64,
            "condition_type_id": "i1", "event_kinds": [], "schema":
                "nnobf-controller-cell-v1",
            "context_summary_fields": [], "action_mask_required": False,
            "max_rollout_steps": n,
        },
        "types": [], "tool_contracts": [], "abi_parameters": [],
        "inputs": [], "initial_values": [], "values": vlist,
        "steps": step_json, "regions": region_json,
        "boundary_values": [], "outputs": [], "capability_gaps": [],
        "floating_environment": None, "entry_action": 0,
        "control_flow_kind": "linear",
    }


def T(op, a, b, out, tid="i32", md=None, kind="tool"):
    return (op, [a, b], out, tid, tid, md or {"source_width":
            CS.type_info(tid)[1]}, kind)


def C(src, out, from_tid, to_tid):
    return ("COPY", [src], out, from_tid, to_tid,
            {"source_width": CS.type_info(from_tid)[1]}, "layout")


# ---------------------------------------------------------------------------
# 金标准差分
# ---------------------------------------------------------------------------
class TestGolden(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.module = json.load(open(GOLDEN))

    def check(self, arith, shares):
        plan = copy.deepcopy(self.module["plans"][0])
        new, stats = CS.transform_plan(plan, shares, "unit-golden", arith)
        ok, problems = CS.verify_transform(plan, new)
        self.assertTrue(ok, problems[:5])
        self.assertGreater(stats["new_steps"], stats["steps"])
        return stats

    def test_fold_2(self):
        self.check("fold", 2)

    def test_masked_2(self):
        s = self.check("masked", 2)
        # masked 档对加法的爆炸性展开（t2 含 4 个 ADD/SUB）
        self.assertGreater(s["new_steps"], 200)

    def test_shares_4_8(self):
        for n in (4, 8):
            plan = copy.deepcopy(self.module["plans"][0])
            new, _ = CS.transform_plan(plan, n, "unit-golden", "fold")
            ok, problems = CS.verify_transform(plan, new)
            self.assertTrue(ok, problems[:5])

    def test_region_contract_preserved(self):
        plan = copy.deepcopy(self.module["plans"][0])
        new, _ = CS.transform_plan(copy.deepcopy(plan), 2, "unit-golden",
                                   "fold")
        self.assertEqual(len(new["regions"]), len(plan["regions"]))
        for a, b in zip(plan["regions"], new["regions"]):
            self.assertEqual(a["live_in_values"], b["live_in_values"])
            self.assertEqual(a["live_out_values"], b["live_out_values"])
        # 变换后区域步覆盖须与步骤总数一致（执行范围合法）
        covered = sum(r["action_count"] for r in new["regions"])
        self.assertLessEqual(covered, len(new["steps"]))

    def test_deterministic(self):
        plan = copy.deepcopy(self.module["plans"][0])
        a, _ = CS.transform_plan(copy.deepcopy(plan), 2, "det", "fold")
        b, _ = CS.transform_plan(copy.deepcopy(plan), 2, "det", "fold")
        self.assertEqual(json.dumps(a, sort_keys=True),
                         json.dumps(b, sort_keys=True))

    def test_verifier_catches_corruption(self):
        plan = copy.deepcopy(self.module["plans"][0])
        new, _ = CS.transform_plan(copy.deepcopy(plan), 2, "corrupt", "fold")
        # 注入腐化：翻转一个实际被步骤引用的常量 share 掩码位
        used = {k for s in new["steps"] for k in s["input_values"]}
        target = None
        for v in new["values"]:
            if v["kind"] == "constant" and v["constant_value"] is not None \
                    and v["key"] in used:
                target = v
                break
        self.assertIsNotNone(target, "no referenced constant found")
        target["constant_value"] = int(target["constant_value"]) ^ 1
        ok, problems = CS.verify_transform(plan, new)
        self.assertFalse(ok)


# ---------------------------------------------------------------------------
# 分享域代数（合成计划）
# ---------------------------------------------------------------------------
class TestAlgebra(unittest.TestCase):
    def run_plan(self, fn, steps, regions, values, arith="fold", shares=2):
        plan = build_plan(fn, steps, regions, values)
        new, _ = CS.transform_plan(copy.deepcopy(plan), shares, "alg", arith)
        ok, problems = CS.verify_transform(plan, new)
        self.assertTrue(ok, problems[:5])
        return plan, new

    def test_secure_and_or(self):
        steps = [T("AND", "a", "b", "o1"), T("OR", "a", "b", "o2"),
                 T("XOR", "a", "b", "o3")]
        vals = [_vj("a", "live-in", "i32"), _vj("b", "live-in", "i32")]
        self.run_plan("alg_bool", steps, [(["a", "b"],
                                           ["o1", "o2", "o3"])], vals)

    def test_secure_and_or_shares8(self):
        steps = [T("AND", "a", "b", "o1"), T("OR", "b", "a", "o2")]
        vals = [_vj("a", "live-in", "i64"), _vj("b", "live-in", "i64")]
        plan = build_plan("alg8", steps, [(["a", "b"], ["o1", "o2"])], vals)
        new, _ = CS.transform_plan(copy.deepcopy(plan), 8, "alg", "fold")
        ok, problems = CS.verify_transform(plan, new)
        self.assertTrue(ok, problems[:5])

    def test_masked_adder_sub_i32_i64(self):
        for tid in ("i32", "i64"):
            steps = [T("ADD", "a", "b", "s", tid),
                     T("SUB", "a", "b", "d", tid)]
            vals = [_vj("a", "live-in", tid), _vj("b", "live-in", tid)]
            self.run_plan(f"arith_{tid}", steps,
                          [(["a", "b"], ["s", "d"])], vals, arith="masked")

    def test_masked_adder_widths_8_16(self):
        for tid in ("i8", "i16"):
            steps = [T("ADD", "a", "b", "s", tid)]
            vals = [_vj("a", "live-in", tid), _vj("b", "live-in", tid)]
            self.run_plan(f"arith_{tid}", steps, [(["a", "b"], ["s"])],
                          vals, arith="masked")

    def test_masked_adder_random_reference(self):
        """掩码加法器 vs Python 参考加法（随机 200 向量，直读解释器 env）。"""
        import random as _r
        plan = build_plan(
            "madd", [T("ADD", "a", "b", "s", "i32")],
            [(["a", "b"], ["s"])],
            [_vj("a", "live-in", "i32"), _vj("b", "live-in", "i32")])
        new, _ = CS.transform_plan(copy.deepcopy(plan), 2, "madd",
                                   "masked")
        consts = {v["key"]: CS._maskv(0 if v["constant_value"] is None
                                      else int(v["constant_value"]),
                                      v["logical_width"])
                  for v in new["values"] if v["kind"] == "constant"}
        values = {v["key"]: v for v in new["values"]}
        for t in range(200):
            rng = _r.Random(9000 + t)
            av, bv = rng.getrandbits(32), rng.getrandbits(32)
            env = dict(consts)
            env["a"], env["b"] = av, bv
            stores = []
            for s in new["steps"]:
                CS._interp_step(s, env, values, "madd", 0, stores)
            self.assertEqual(env["s"], (av + bv) & 0xFFFFFFFF)

    def test_byte_route_or(self):
        """移位降级 byte-route（OR+const0+lane 路由）必须保留路由。"""
        md = {"derived_from": "shift-funnel-core-v1",
              "stage": "shift:fixed:byte-route",
              "input_layout": "binary-lanes",
              "lane_delta_a": 3, "lane_delta_b": 0, "lane_delta_c": 0}
        steps = [T("OR", "x", "const:i32:0", "o", "i32", md)]
        vals = [_vj("x", "live-in", "i32"),
                _vj("const:i32:0", "constant", "i32", 0)]
        plan, new = self.run_plan("route", steps, [(["x"], ["o"])], vals)
        # 步骤必须携带原 lane 路由
        routed = [s for s in new["steps"]
                  if s["operation"] == "OR"
                  and (s.get("metadata") or {}).get("lane_delta_a") == 3]
        self.assertEqual(len(routed), 2)   # 每 share 一个

    def test_funnel_shift(self):
        md = {"derived_from": "shift-funnel-core-v1",
              "stage": "shift:fixed:funnel:2",
              "input_layout": "ternary-lanes",
              "lane_delta_a": 0, "lane_delta_b": -1, "lane_delta_c": 0}
        steps = [("SHIFT_SHL", ["x", "x", "const:i64:202020202020202"],
                  "o", "i64", "i64", md, "tool")]
        vals = [_vj("x", "live-in", "i64"),
                _vj("const:i64:202020202020202", "constant", "i64",
                    0x0202020202020202)]
        self.run_plan("fshift", steps, [(["x"], ["o"])], vals)

    def test_select_and_predicates(self):
        # ICMP 先定义谓词 p，SELECT 以 p 为条件（数据流顺序）
        steps = [("ICMP_ULT", ["a", "b"], "p", "i32", "i1",
                  {"predicate": "ult", "source_width": 32}, "tool"),
                 ("SELECT", ["p", "a", "b"], "o", "i32", "i32",
                  {"source_width": 32}, "tool")]
        vals = [_vj("a", "live-in", "i32"), _vj("b", "live-in", "i32")]
        self.run_plan("sel", steps, [(["a", "b"], ["o", "p"])], vals)

    def test_i8_trunc_copy_and_store(self):
        steps = [T("AND", "a", "b", "m"),
                 C("m", "t", "i32", "i8"),
                 ("STORE", ["t"], None, "i8", "i8",
                  {"alignment": 1}, "memory")]
        # STORE 需要 address 字段 → 手工补
        addr = {"pointer_reference": "obj", "object_id": "obj",
                "constant_offset": 0, "dynamic_terms": [],
                "source_type": "stack", "address_space": 0,
                "guaranteed_alignment": 1, "provenance": "obj",
                "lifetime": "internal", "router_id": None,
                "router_stride": 0, "router_slots": 0, "router_kind":
                    "dense", "router_radix": 0, "router_index_bias": 0,
                "schema": "nnobf-address-expression-v1"}
        steps[2] = ("STORE", ["t"], None, "i8", "i8",
                    {"alignment": 1}, "memory")
        vals = [_vj("a", "live-in", "i32"), _vj("b", "live-in", "i32")]
        plan = build_plan("i8s", steps, [(["a", "b"], ["t"])], vals)
        for s in plan["steps"]:
            if s["operation"] == "STORE":
                s["address"] = copy.deepcopy(addr)
        new, _ = CS.transform_plan(copy.deepcopy(plan), 2, "i8s", "fold")
        for s in new["steps"]:
            if s["operation"] == "STORE":
                s["address"] = copy.deepcopy(addr)
                s["input_slots"] = [0] * len(s["input_values"])
        ok, problems = CS.verify_transform(plan, new)
        self.assertTrue(ok, problems[:5])


# ---------------------------------------------------------------------------
# 区域边界 / 模块级
# ---------------------------------------------------------------------------
class TestRegions(unittest.TestCase):
    def test_cross_region_value(self):
        # region0: v = a^b（live-out）；region1: w = v&a（live-in 复用）
        steps = [T("XOR", "a", "b", "v"),
                 T("AND", "v", "a", "w"),
                 T("OR", "v", "b", "u")]
        vals = [_vj("a", "live-in", "i32"), _vj("b", "live-in", "i32")]
        plan = build_plan("cross", steps,
                          [(["a", "b"], ["v"]), (["v", "a", "b"],
                                                 ["w", "u"])], vals)
        new, _ = CS.transform_plan(copy.deepcopy(plan), 2, "cross", "fold")
        ok, problems = CS.verify_transform(plan, new)
        self.assertTrue(ok, problems[:5])
        # 区域边界键集合不变
        self.assertEqual(new["regions"][0]["live_out_values"], ["v"])
        self.assertEqual(new["regions"][1]["live_in_values"],
                         ["v", "a", "b"])

    def test_module_function_filter(self):
        m1 = build_plan("f1", [T("XOR", "a", "b", "o")],
                        [(["a", "b"], ["o"])],
                        [_vj("a", "live-in", "i32"), _vj("b", "live-in",
                                                         "i32")])
        m2 = build_plan("f2", [T("AND", "a", "b", "o")],
                        [(["a", "b"], ["o"])],
                        [_vj("a", "live-in", "i32"), _vj("b", "live-in",
                                                         "i32")])
        module = {"schema": "nnobf-neural-ir-module-v2",
                  "module_identifier": "t", "functions": ["f1", "f2"],
                  "plans": [m1, m2], "module_objects": [], "sync_specs": [],
                  "capability_gaps": []}
        new, stats = CS.transform_module(copy.deepcopy(module), 2, "mod",
                                         "fold", functions=["f1"])
        self.assertEqual(len(stats), 1)
        self.assertEqual(new["plans"][1]["steps"], m2["steps"])  # 未动
        self.assertGreater(len(new["plans"][0]["steps"]), 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
