#!/usr/bin/env python3
"""test_guards.py — guards_ir 单元测试（纯 Python，无需编译环境）。

覆盖：
  T1 金标 IR（input_t2.ll, crown=main）：全局/token/键/折叠/门控结构
  T2 token 数学自检：C == XOR(祖先键)（合成双守卫模块，checkF 走全链）
  T3 确定性：同 seed 输出逐字节一致；异 seed 键不同
  T4 语义恒等结构：忠实环境下 delta 折叠 = XOR 0（asm 双读 + xor 链存在）
"""
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "pipeline"))
import guards_ir as G  # noqa: E402

FAILURES = []


def check(name, cond, detail=""):
    tag = "PASS" if cond else "FAIL"
    print(f"[{tag}] {name}{('  ' + detail) if detail and not cond else ''}")
    if not cond:
        FAILURES.append(name)


def run_cli(args):
    return subprocess.run([sys.executable,
                           os.path.join(ROOT, "pipeline", "guards_ir.py")]
                          + args, capture_output=True, text=True)


# ---------------------------------------------------------------- T1 金标 IR
src = os.path.join(HERE, "golden", "input_t2.ll")
out1 = os.path.join(HERE, "_guard_t1.ll")
r = run_cli([src, "-o", out1, "--crown", "main", "--seed", "12345"])
check("T1 CLI rc=0", r.returncode == 0, r.stderr[-300:])
text1 = open(out1, encoding="utf-8").read()

check("T1 全局 token/fail 已插入",
      "@__sdk_ig_tok = internal global i64 0" in text1
      and "@__sdk_ig_fail = internal global i8 0" in text1)
asm_calls = len(re.findall(r'call i32 asm sideeffect "mov \$\$0', text1))
check("T1 传感器双读 ≥2 信号×2 次", asm_calls >= 4, f"asm_calls={asm_calls}")
check("T1 xor-双读差值链存在",
      re.search(r"%gu\.sd\d = xor i32 %gu\.sa\d, %gu\.sb\d", text1)
      and re.search(r"zext i32 %gu\.sd\d to i64", text1))
check("T1 返回折叠（XOR delta）存在",
      re.search(r"%gu\.rv\d = xor i\d+ %[\w.$-]+, %gu\.(tr|dz|\w+)", text1)
      or re.search(r"%gu\.rv\d = xor i\d+ .+, %gu\.sz\d", text1))
check("T1 非局部门控序列存在",
      re.search(r"%gu\.ok\d = icmp eq i64 %gu\.tk\d, -?\d+", text1)
      and re.search(r"%gu\.sel\d = select i1 %gu\.ok\d", text1)
      and "store i8 %gu.f1" in text1 and "ret" in text1)
check("T1 拒绝值为 0（显式拒绝）", re.search(r"select i1 %gu\.ok\d, i\d+ .+, i\d+ 0", text1))
check("T1 入口 XOR 键 + 返回还原", text1.count("ptr @__sdk_ig_tok") >= 3)
check("T1 define 数量不变（无函数损坏）",
      len(re.findall(r"^define ", text1, re.M))
      == len(re.findall(r"^define ", open(src, encoding="utf-8").read(), re.M)))

# ---------------------------------------------------------------- T2 token 数学
mod = """define i32 @f1(i32 %a) {
entry:
  %v = add i32 %a, 1
  ret i32 %v
}

define i32 @main() {
entry:
  %r = call i32 @f1(i32 41)
  ret i32 %r
}
"""
p2 = os.path.join(HERE, "_guard_t2_in.ll")
p2o = os.path.join(HERE, "_guard_t2.ll")
open(p2, "w").write(mod)
r = run_cli([p2, "-o", p2o, "--crown", "f1", "main", "--seed", "77"])
t2 = open(p2o, encoding="utf-8").read()
check("T2 CLI rc=0", r.returncode == 0, r.stderr[-300:])

desc = r.stdout and __import__("json").loads(r.stdout)
if desc:
    check("T2 checkIn=f1（有 main 祖先的整数返回 crown）",
          desc.get("integrity", {}).get("check_in") == "f1", str(desc))

# 从生成的 IR 反解键：entry XOR 常量（%gu.t1 = xor i64 %gu.t0, K）
keys = [int(m) for m in re.findall(r"%gu\.t1 = xor i64 %gu\.t0, (-?\d+)", t2)]
check("T2 恒等式：checkF 的 C == XOR(祖先键)",
      len(keys) >= 2 and "icmp eq i64 %gu.tk" in t2)
if len(keys) >= 2 and desc:
    C = int(desc["integrity"]["expected_token"], 16) & ((1 << 64) - 1)
    got = 0
    for k in keys:
        got ^= k & ((1 << 64) - 1)
    check("T2 C 数学一致", C == got, f"C={C:#x} got={got:#x}")
check("T2 main 非检查宿主 → 只还原不门控",
      "select i1 %gu.ok" not in "".join(
          re.findall(r"define i32 @main.*?\n\}", t2, re.S)))

# ---------------------------------------------------------------- T3 确定性
out3a = os.path.join(HERE, "_guard_t3a.ll")
out3b = os.path.join(HERE, "_guard_t3b.ll")
run_cli([src, "-o", out3a, "--crown", "main", "--seed", "12345"])
run_cli([src, "-o", out3b, "--crown", "main", "--seed", "12345"])
a, b = open(out3a, encoding="utf-8").read(), open(out3b, encoding="utf-8").read()
check("T3 同 seed 逐字节一致", a == b)
ka = re.findall(r"%gu\.t1 = xor i64 %gu\.t0, (-?\d+)", a)
run_cli([src, "-o", out3b, "--crown", "main", "--seed", "999"])
kb = re.findall(r"%gu\.t1 = xor i64 %gu\.t0, (-?\d+)", open(out3b, encoding="utf-8").read())
check("T3 异 seed 键不同", ka and kb and ka != kb)

# ---------------------------------------------------------------- T4 恒等语义
check("T4 asm sideeffect 标记（防 CSE 合并双读）",
      "asm sideeffect" in text1)
check("T4 永不分支（无 if/br 引入）——门控仅 select",
      len(re.findall(r"br i1 %gu\.", text1)) == 0)
check("T4 store 折叠站点命名唯一（SSA）",
      len(re.findall(r"%gu\.sv(\d+)", text1))
      == len(set(re.findall(r"%gu\.sv(\d+)", text1))))

# ---------------------------------------------------------------- T5 churn 泳道
out5 = os.path.join(HERE, "_guard_t5.ll")
r = run_cli([src, "-o", out5, "--crown", "main", "--seed", "42",
             "--guards", "churn"])
t5 = open(out5, encoding="utf-8").read()
check("T5 CLI rc=0", r.returncode == 0, r.stderr[-200:])
check("T5 declare 存在", "declare void @__sdk_churn_step(i64)" in t5)
import zlib as _z
fd = _z.crc32(b"main") & 0x7FFFFFFF
check("T5 crown 入口调用（v2：tracer_check XOR crc32 delta 进 churn）",
      "%gu.tracer = call i32 @__sdk_tracer_check()" in t5
      and f"%gu.churn_in = xor i32 %gu.tracer, {fd}" in t5
      and "call void @__sdk_churn_step(i64 %gu.churn_z)" in t5)
run_cli([src, "-o", out5, "--crown", "main", "--seed", "42",
         "--guards", "churn"])
t5b = open(out5, encoding="utf-8").read()
check("T5 同 seed 同输出", t5 == t5b)
os.remove(out5)

# ------------------------------------------------- T7 M1 cpuid 信号 3→7
# chame-antidebug v0.2 §4.1：SIGNALS 扩为 7（leaf-0 ebx/ecx/edx/eax +
# leaf-1 eax/ecx/edx），与 CHAMÆLEON targets/x86_64/target_x86_64.cpp
# signals() 逐条一致；leaf-1 EBX 排除（per-core APIC ID 假阳性）。
names = [n for n, _ in G.SIGNALS]
check("T7 信号数 = 7（3→7 扩展）", len(names) == 7, f"got {len(names)}")
check("T7 leaf-0 四寄存器齐全",
      all(f"cpuid.0:{r}" in names for r in ("eax", "ebx", "ecx", "edx")))
check("T7 leaf-1 三寄存器齐全（eax/ecx/edx）",
      all(f"cpuid.1:{r}" in names for r in ("eax", "ecx", "edx")))
check("T7 leaf-1 EBX 排除（APIC ID 假阳性）", "cpuid.1:ebx" not in names)
# asm 形态与信号名自洽（leaf 号 + 输出寄存器路由；$$ 为 LLVM asm 转义）
check("T7 asm 形态自洽（leaf 号 + 寄存器路由）",
      all((f"mov $${leaf}, %eax" in asm)
          and (f"mov %{reg}, $0" in asm)
          for nm, asm in G.SIGNALS
          for leaf, reg in [nm.replace("cpuid.", "").split(":")]))
# 金标 IR：被选中的信号一律双读（每信号恰好 2 次出现；66% 抽样非全量）
_counts = {nm: text1.count(asm) for nm, asm in G.SIGNALS}
_sel = {k: v for k, v in _counts.items() if v > 0}
check("T7 金标 IR 选中信号一律双读（每信号恰 2 次）",
      len(_sel) >= 2 and all(v == 2 for v in _sel.values()), str(_sel))

for f in [out1, p2, p2o, out3a, out3b]:
    try:
        os.remove(f)
    except OSError:
        pass

print()
if FAILURES:
    print(f"FAILED: {FAILURES}")
    sys.exit(1)
print("guards_ir: ALL TESTS PASS")
