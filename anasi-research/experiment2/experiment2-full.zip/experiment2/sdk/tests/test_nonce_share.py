#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""test_nonce_share.py — antireverse v0.2 双泳道单元测试。

  nonce-mask（consumer_fused_v1 运行时 nonce 派生掩码）
  share-encode（stateful_v34 per-share 独立槽位驻留编码）

覆盖（对应 antireverse_v0.2.md §6.1）：
  N1 金标 t2 计划：nonce-mask / share-encode / 组合 × fold/masked ×
     share 2/4 差分（内置验证器 + verify_transform 显式复核）
  N2 运行期性证明：split/nonce-mask 掩码的数据流回溯到达 live-in
     （静态模式仅终止于常量）
  N3 输入多样性：同计划两个 master 的解释执行——掩码值不同而
     live-out 不变（掩码 = f(输入)）
  N4 确定性：同 seed 逐字节一致；异 seed 计划不同
  N5 share-encode 结构：enc/dec 步骤成对存在；per-share 参数互异
  N6 编码语义：OR 双 delta 字节旋转在解释器语义下可逆（编码往返
     的核心 idiom）
  N7 组合统计：stats 上报泳道标记与 fallback 计数
  N8 回退路径：无 integer live-in 区域 → 静态回退 + 计数
  N9 CLI 端到端：--nonce-mask/--share-encode 作用于金标 module 计划
"""

import copy
import json
import os
import subprocess
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
PIPE = os.path.normpath(os.path.join(HERE, "..", "pipeline"))
sys.path.insert(0, PIPE)

import circuit_share as CS  # noqa: E402

GOLDEN = os.path.join(HERE, "golden", "module_plan_t2.json")


def golden_plan():
    return copy.deepcopy(json.load(open(GOLDEN))["plans"][0])


def golden_module():
    return copy.deepcopy(json.load(open(GOLDEN)))


# ---------------------------------------------------------------------------
# 解释器 env 捕获（N3）：复刻 interpret_plan 主循环，额外记录掩码值
# ---------------------------------------------------------------------------
def run_capture_masks(plan, master):
    values = {v["key"]: v for v in plan["values"]}
    steps = plan["steps"]
    regions = plan["regions"]
    fn = plan["function"]
    env = {}
    for v in plan["values"]:
        if v["kind"] == "constant":
            cv = 0 if v["constant_value"] is None else int(v["constant_value"])
            env[v["key"]] = CS._maskv(cv, v["logical_width"])
    mask_keys = set()
    outs = {}
    starts, ends = {}, {}
    for ridx, r in enumerate(regions):
        if r["action_count"] > 0:
            starts[r["action_start"]] = ridx
            ends[r["action_start"] + r["action_count"] - 1] = ridx
        else:
            outs[ridx] = {}
    for i, s in enumerate(steps):
        if i in starts:
            ridx = starts[i]
            for k in regions[ridx]["live_in_values"]:
                w = max(values[k]["logical_width"], 1)
                rng = CS._interp_rng(f"{fn}|in|{ridx}|{k}", master)
                env[k] = CS._maskv(rng.getrandbits(w), w)
        CS._interp_step(s, env, values, fn, master, [])
        md = s.get("metadata") or {}
        if md.get("stage") == "nonce-mask":
            mask_keys.add(s["output_value"])
        if i in ends:
            ridx = ends[i]
            outs[ridx] = {k: env.get(k)
                          for k in regions[ridx]["live_out_values"]}
    return outs, {k: env.get(k) for k in mask_keys}


# ---------------------------------------------------------------------------
# 数据流回溯（N2）：key → 生产步骤 → 输入闭包
# ---------------------------------------------------------------------------
def closure_keys(plan, seed_keys):
    """seed 键的完整后向闭包（键集合；常量终止展开）。"""
    values = {v["key"]: v for v in plan["values"]}
    producer = {}
    for s in plan["steps"]:
        if s.get("output_value"):
            producer[s["output_value"]] = s
    seen = set()
    frontier = list(seed_keys)
    while frontier:
        k = frontier.pop()
        if k in seen:
            continue
        seen.add(k)
        v = values.get(k)
        if v is None or v["kind"] == "constant":
            continue
        ps = producer.get(k)
        if ps:
            frontier.extend(ps["input_values"])
    return seen


def backward_kinds(plan, seed_keys):
    values = {v["key"]: v for v in plan["values"]}
    return {values.get(k, {}).get("kind")
            for k in closure_keys(plan, seed_keys) if values.get(k)}


def new_vals(plan):
    return {v["key"]: v for v in plan["values"]}


class TestNonceMask(unittest.TestCase):

    def test_n1_golden_differential(self):
        for shares in (2, 4):
            for arith in ("fold", "masked"):
                if arith == "masked" and shares == 4:
                    continue  # 体积/时延（~x100+）：fold 已覆盖 4 份
                orig = golden_plan()
                new, stats = CS.transform_plan(orig, shares, "77", arith,
                                               nonce_mask=True)
                ok, problems = CS.verify_transform(orig, new)
                self.assertTrue(ok, problems[:3])
                self.assertGreater(stats["new_steps"], stats["steps"])

    def test_n2_masks_reach_live_in(self):
        orig = golden_plan()
        new, _ = CS.transform_plan(orig, 2, "77", "fold", nonce_mask=True)
        # 掩码步骤（stage=nonce-mask）回溯到达运行时数据
        # （live-in 或 LOAD 输出——金标区域 1 数据经 LOAD 进入）
        mask_outs = [s["output_value"] for s in new["steps"]
                     if (s.get("metadata") or {}).get("stage") == "nonce-mask"]
        self.assertTrue(mask_outs, "no nonce-mask steps emitted")
        kinds = backward_kinds(new, mask_outs)
        self.assertTrue(kinds & {"live-in", "ssa"},
                        f"mask closure kinds={kinds}（应含运行时值）")
        # 进一步：闭包内至少一个 ssa 的生产步骤是 LOAD（运行时内存值）
        # 或值为 live-in
        producer = {s["output_value"]: s for s in new["steps"]
                    if s.get("output_value")}
        reached = closure_keys(new, mask_outs)
        runtime = [k for k in reached
                   if new_vals(new).get(k, {}).get("kind") == "live-in"
                   or (producer.get(k, {}).get("operation") == "LOAD")]
        self.assertTrue(runtime, "mask closure has no live-in/LOAD source")
        # 对照：静态模式 split 掩码闭包仅 constant（掩码=计划常量）
        static, _ = CS.transform_plan(golden_plan(), 2, "77", "fold")
        split_masks = []
        for s in static["steps"]:
            md = s.get("metadata") or {}
            if md.get("stage") == "split":
                # 输入中除被拆值外的常量即静态掩码
                for k in s["input_values"][1:]:
                    split_masks.append(k)
        self.assertTrue(split_masks)
        skinds = backward_kinds(static, split_masks)
        self.assertNotIn("live-in", skinds)
        self.assertNotIn("ssa", skinds)

    def test_n3_masks_vary_with_inputs(self):
        new, _ = CS.transform_plan(golden_plan(), 2, "77", "fold",
                                   nonce_mask=True)
        o_a, _ = CS.interpret_plan(golden_plan(), 20261101)
        o_b, _ = CS.interpret_plan(golden_plan(), 20261234)
        outs_a, masks_a = run_capture_masks(new, 20261101)
        outs_b, masks_b = run_capture_masks(new, 20261234)
        # 逐 master 差分：orig@M == new@M（掩码派生不改语义）
        for tag, o_outs, n_outs in (("A", o_a, outs_a), ("B", o_b, outs_b)):
            for ridx in o_outs:
                for k in o_outs[ridx]:
                    self.assertEqual(o_outs[ridx][k], n_outs[ridx][k],
                                     f"trial {tag} region{ridx} {k}")
        # 掩码值随输入改变（掩码 = f(输入)）
        self.assertTrue(masks_a and masks_b)
        diff = [k for k in masks_a
                if masks_a[k] is not None and masks_b[k] is not None
                and masks_a[k] != masks_b[k]]
        self.assertGreater(len(diff), 0, "masks identical across inputs")

    def test_n4_determinism(self):
        a, _ = CS.transform_plan(golden_plan(), 2, "77", "fold",
                                 nonce_mask=True, share_encode=True)
        b, _ = CS.transform_plan(golden_plan(), 2, "77", "fold",
                                 nonce_mask=True, share_encode=True)
        self.assertEqual(json.dumps(a, sort_keys=True),
                         json.dumps(b, sort_keys=True))
        c, _ = CS.transform_plan(golden_plan(), 2, "78", "fold",
                                 nonce_mask=True, share_encode=True)
        self.assertNotEqual(json.dumps(a, sort_keys=True),
                            json.dumps(c, sort_keys=True))

    def test_n7_stats_lanes(self):
        new, stats = CS.transform_plan(golden_plan(), 2, "77", "fold",
                                       nonce_mask=True, share_encode=True)
        self.assertEqual(stats["nonce_mask"], 1)
        self.assertEqual(stats["share_encode"], 1)
        self.assertGreaterEqual(stats["nonce_fallback_regions"], 0)
        plain, pstats = CS.transform_plan(golden_plan(), 2, "77", "fold")
        self.assertEqual(pstats["nonce_mask"], 0)
        self.assertEqual(pstats["share_encode"], 0)

    def test_n8_fallback_region(self):
        # 其一：纯常量区域（无 integer live-in、无 LOAD）→ 静态回退
        def V(k, kind, tid, cv=None, slot=None):
            w = int(tid[1:])
            return {"key": k, "kind": kind, "type_id": tid,
                    "constant_value": cv, "source_reference": k,
                    "slot": slot, "type_kind": "integer",
                    "logical_width": w,
                    "encoded_bytes": (w + 7) // 8, "abi_index": None}

        def S(i, op, ins, out, tid):
            w = int(tid[1:])
            return {"index": i, "origin_reference": f"inst:{i}",
                    "action_kind": "tool", "operation": op,
                    "input_values": ins, "input_slots": [0] * len(ins),
                    "output_value": out, "output_slot": 3,
                    "source_type_id": tid, "source_width": w,
                    "value_type_id": tid, "type_kind": "integer",
                    "logical_width": w, "address": None, "metadata": {},
                    "next_action": None, "true_action": None,
                    "false_action": None, "next_slot_renames": [],
                    "true_slot_renames": [], "false_slot_renames": []}

        plan = {
            "schema": "nnobf-neural-plan-v1",
            "controller_action_schema": "v1", "function": "g",
            "rewrite_kind": "region",
            "context": {"temp_slot_capacity": 6,
                        "frames": [{"frame_id": "region",
                                    "temp_slots": list(range(6))}]},
            "controller": {"max_rollout_steps": 16},
            "types": [], "tool_contracts": [], "abi_parameters": [],
            "inputs": [], "initial_values": [],
            "values": [V("const:i32:5", "constant", "i32", 5),
                       V("const:i32:7", "constant", "i32", 7),
                       V("out", "ssa", "i32", slot=3)],
            "steps": [S(0, "ADD", ["const:i32:5", "const:i32:7"],
                        "out", "i32")],
            "regions": [{"action_start": 0, "action_count": 1,
                         "live_in_values": [],
                         "live_out_values": ["out"]}],
            "boundary_values": [], "outputs": [], "capability_gaps": [],
            "floating_environment": None, "entry_action": 0,
            "control_flow_kind": "linear",
        }
        new, stats = CS.transform_plan(plan, 2, "77", "fold",
                                       nonce_mask=True)
        self.assertEqual(stats["nonce_fallback_regions"], 1)
        # 回退区域：split 掩码为常量（无 nonce-mask 步骤）
        stages = {(s.get("metadata") or {}).get("stage")
                  for s in new["steps"]}
        self.assertNotIn("nonce-mask", stages)
        # 无掩码请求的区域不计 fallback（区域无 split → 0）
        plan2 = copy.deepcopy(plan)
        plan2["steps"] = [dict(plan["steps"][0],
                               operation="SELECT",
                               input_values=["const:i32:5", "const:i32:7",
                                             "const:i32:7"])]
        _, stats2 = CS.transform_plan(plan2, 2, "77", "fold",
                                      nonce_mask=True)
        self.assertEqual(stats2["nonce_fallback_regions"], 0)


class TestShareEncode(unittest.TestCase):

    def test_n11_width_changing_copy(self):
        """回归（wbp compute_env_hash 差分失败根因）：宽度变化 COPY（trunc
        i32→i8）传播编码态时源/目标参数错配——须解码→COPY→按目标宽重编。"""
        def V(k, kind, tid, cv=None, slot=None):
            w = int(tid[1:])
            return {"key": k, "kind": kind, "type_id": tid,
                    "constant_value": cv, "source_reference": k,
                    "slot": slot, "type_kind": "integer",
                    "logical_width": w,
                    "encoded_bytes": (w + 7) // 8, "abi_index": None}

        def S(i, op, ins, out, src_tid, val_tid):
            sw = int(src_tid[1:])
            vw = int(val_tid[1:])
            return {"index": i, "origin_reference": f"inst:{i}",
                    "action_kind": "tool", "operation": op,
                    "input_values": ins, "input_slots": [0] * len(ins),
                    "output_value": out, "output_slot": 3,
                    "source_type_id": src_tid, "source_width": sw,
                    "value_type_id": val_tid, "type_kind": "integer",
                    "logical_width": vw, "address": None, "metadata": {},
                    "next_action": None, "true_action": None,
                    "false_action": None, "next_slot_renames": [],
                    "true_slot_renames": [], "false_slot_renames": []}

        a = "function:f:block:unnamed_block_0:a"
        b = "function:f:block:unnamed_block_0:b"
        x = "function:f:block:unnamed_block_1:x"      # i32 共享值
        t = "function:f:block:unnamed_block_1:t"      # i8 截断结果
        y = "function:f:block:unnamed_block_1:y"      # live-out
        plan = {
            "schema": "nnobf-neural-plan-v1",
            "controller_action_schema": "v1", "function": "f",
            "rewrite_kind": "region",
            "context": {"temp_slot_capacity": 8,
                        "frames": [{"frame_id": "region",
                                    "temp_slots": list(range(8))}]},
            "controller": {"max_rollout_steps": 64},
            "types": [], "tool_contracts": [], "abi_parameters": [],
            "inputs": [], "initial_values": [],
            "values": [V(a, "live-in", "i32"), V(b, "live-in", "i32"),
                       V(x, "ssa", "i32"), V(t, "ssa", "i8"),
                       V(y, "ssa", "i8")],
            "steps": [
                S(0, "XOR", [a, b], x, "i32", "i32"),
                S(1, "COPY", [x], t, "i32", "i8"),      # trunc
                S(2, "XOR", [t, "const:i8:5a"], y, "i8", "i8"),
            ],
            "regions": [{"action_start": 0, "action_count": 3,
                         "live_in_values": [a, b],
                         "live_out_values": [y]}],
            "boundary_values": [], "outputs": [], "capability_gaps": [],
            "floating_environment": None, "entry_action": 0,
            "control_flow_kind": "linear",
        }
        # 常量
        plan["values"].append(V("const:i8:5a", "constant", "i8", 0x5a))
        new, stats = CS.transform_plan(plan, 2, "9", "fold",
                                       share_encode=True)
        ok, problems = CS.verify_transform(plan, new)
        self.assertTrue(ok, problems[:3])
        # 结构：宽度变化 COPY 的 share 路径应出现解/编对（dec 在 COPY 前）
        stages = [(s.get("metadata") or {}).get("stage") for s in new["steps"]]
        self.assertIn("dec-salt", stages)
        self.assertIn("enc-salt", stages)


    def test_n1_golden_differential(self):
        orig = golden_plan()
        new, stats = CS.transform_plan(orig, 2, "77", "fold",
                                       share_encode=True)
        ok, problems = CS.verify_transform(orig, new)
        self.assertTrue(ok, problems[:3])
        self.assertGreater(stats["new_steps"], stats["steps"])

    def test_n5_structure_and_params(self):
        new, _ = CS.transform_plan(golden_plan(), 2, "77", "fold",
                                   share_encode=True)
        stages = [(s.get("metadata") or {}).get("stage")
                  for s in new["steps"]]
        n_enc = sum(1 for x in stages if x and x.startswith("enc-"))
        n_dec = sum(1 for x in stages if x and x.startswith("dec-"))
        self.assertGreater(n_enc, 0)
        self.assertGreater(n_dec, 0)
        # per-share 参数互异：share0/share1 的 enc-salt 步骤 salt 常量不同
        values = {v["key"]: v for v in new["values"]}
        salts = {}
        for s in new["steps"]:
            md = s.get("metadata") or {}
            if md.get("stage") == "enc-salt":
                idx = md.get("enc_share")
                salts.setdefault(idx, set()).update(
                    values[k]["constant_value"]
                    for k in s["input_values"] if k.startswith("const:"))
        self.assertTrue(salts)
        s0 = salts.get(0, set())
        s1 = salts.get(1, set())
        self.assertFalse(s0 & s1, "per-share salt 应互异")

    def test_n6_rotation_idiom_reversible(self):
        # 解释器语义下的字节旋转可逆性（编码往返核心 idiom）
        for lanes_w in (16, 32, 64):
            w = lanes_w
            lanes = CS.encoded_bytes(w)
            for d in range(1, lanes):
                x = 0x0123456789ABCDEF & ((1 << w) - 1)
                s1 = {"operation": "OR",
                      "input_values": ["x", "x"], "output_value": "r",
                      "source_width": w, "logical_width": w,
                      "metadata": {"input_layout": "binary-lanes",
                                   "lane_delta_a": d,
                                   "lane_delta_b": d - lanes,
                                   "lane_delta_c": 0}}
                s2 = {"operation": "OR",
                      "input_values": ["r", "r"], "output_value": "y",
                      "source_width": w, "logical_width": w,
                      "metadata": {"input_layout": "binary-lanes",
                                   "lane_delta_a": -d,
                                   "lane_delta_b": lanes - d,
                                   "lane_delta_c": 0}}
                env = {"x": x}
                CS._interp_step(s1, env, {}, "f", 1, [])
                CS._interp_step(s2, env, {}, "f", 1, [])
                self.assertEqual(env["y"], x,
                                 f"w={w} d={d}: rot not invertible")

    def test_n7_combo(self):
        orig = golden_plan()
        new, stats = CS.transform_plan(orig, 2, "77", "fold",
                                       nonce_mask=True, share_encode=True)
        ok, problems = CS.verify_transform(orig, new)
        self.assertTrue(ok, problems[:3])
        self.assertEqual(stats["nonce_mask"], 1)
        self.assertEqual(stats["share_encode"], 1)
        # 组合代价实测上报（体积/步数比值 > 单泳道）
        single, s1 = CS.transform_plan(golden_plan(), 2, "77", "fold",
                                       share_encode=True)
        self.assertGreaterEqual(stats["new_steps"],
                                s1["new_steps"])


class TestCLI(unittest.TestCase):

    def test_n9_cli_end_to_end(self):
        import tempfile
        tmp = tempfile.mkdtemp(prefix="nonce_t9_")
        out = os.path.join(tmp, "plan_out.json")
        module = golden_module()
        src = os.path.join(tmp, "plan_in.json")
        with open(src, "w", encoding="utf-8") as f:
            json.dump(module, f)
        r = subprocess.run(
            [sys.executable, os.path.join(PIPE, "circuit_share.py"), src,
             "-o", out, "--shares", "2", "--seed", "20261102",
             "--arith", "fold", "--nonce-mask", "--share-encode"],
            capture_output=True, text=True)
        self.assertEqual(r.returncode, 0, r.stderr[-400:])
        mod = json.load(open(out, encoding="utf-8"))
        self.assertIn("plans", mod)
        self.assertTrue(mod["plans"])
        stages = {(s.get("metadata") or {}).get("stage")
                  for s in mod["plans"][0]["steps"]}
        self.assertIn("nonce-mask", stages)
        self.assertIn("enc-salt", stages)
        self.assertIn("dec-salt", stages)
        self.assertIn("differential verification PASS", r.stderr)
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    unittest.main(verbosity=1)
