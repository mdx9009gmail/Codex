# anansi-neural-sdk

神经代码保护算法的**可读、可编译、可运行**参考实现——把 C 源文件中选定的整数计算区域
改写为由神经网络在潜空间逐步重放执行，产出行为完全一致的"被保护"可执行文件。

## 目录结构

```
anansi-neural-sdk/
├── README.md               本文件
├── docs/
│   ├── CAPABILITIES.md     当前能力：输入/处理/输出/已验证范围/边界
│   └── EXTENDING.md        扩展接口：LLVM Pass 移植/新增算子/守卫/票号/权重档位
├── pipeline/               保护管线（Python，组件可独立使用）
│   ├── protect.py          一条命令端到端驱动
│   ├── normalize_ll.py     IR 归一化
│   ├── plan_compiler.py    IR → 神经动作程序（module_plan）
│   ├── instrument_ll.py    IR 边界插桩
│   ├── runtime_codegen.py  权重 → 运行时 C 三 TU（fp16/fp32）
│   ├── weight_composer.py  任意计划 → 模块权重（零训练组装，含内置验证）
│   ├── validate_b.py / verify_battery.py   差分验证器
│   └── runtime_codegen_data/  C 模板 + 轮次 profile（fp16/fp32）
├── neural/
│   ├── neural_core.py      神经核心可读参考（Controller/codec/ALU + 动作解释器）
│   └── verify_t2.py        神经核心功能验证（穷举/性质/差分）
├── weights/
│   ├── production/         生产权重库（per-op stable_*.npz，composer 的原料）
│   ├── codec/              codec 权重
│   └── （neural/weights/   两份现成模块权重包，t1 fp16 / t2 fp32）
└── tests/
    ├── t2.c                参考样例（8 类整数运算）
    ├── golden/              金标准（参考 IR + 参考动作程序，回归测试用）
    └── selftest.sh         自检（见下）
```

## 环境要求

- Python 3 + numpy（运行管线与神经参考）
- **编译工具链（自持，无需任何外部发行包）**：Linux x86-64 + clang/LLVM 22.x
  （运行时含 `_Float16`，clang 22 / gcc 13+ 均可编译）。两种用法：
  - Docker：`docker build -t sdk-build - <<'EOF'
    FROM ubuntu:24.04
    RUN apt-get update && apt-get install -y --no-install-recommends g++ zlib1g-dev bsdutils
    EOF`
    然后 `protect.py --image sdk-build --dist <你的LLVM/bin目录>`
  - 原生 Linux：`--dist` 指向你的 clang/bin，去掉 docker 步骤（改 protect.py 中
    run_docker 为直接 subprocess 即可，约 10 行）
- 神经权重：随包提供（`neural/weights/`），无需训练；**覆盖面 = CAPABILITIES.md
  实证算子集**，超出该集需要权重库或训练（见 EXTENDING.md §6）

## 快速开始

```bash
# 1) 自检（无 Docker 也可跑：金标准回归 + 运行时生成）
bash tests/selftest.sh

# 2) 端到端：保护一个 C 文件（需 Docker 镜像做编译链接）
python3 pipeline/protect.py --source tests/t2.c --output my_prot \
    --weight-npz neural/weights/module_weights_t2_fp32.npz

# 3) 验证：被保护程序与原生程序在输入电池上行为一致
python3 pipeline/verify_battery.py --mine my_prot

# 4) 多函数保护（带编译依赖透传）
python3 pipeline/protect.py --source app.c --output my_prot \
    --functions func_a func_b func_c \
    --include /path/inc1 --include /path/inc2 --define _GNU_SOURCE \
    --weight-npz neural/weights/modules/module_weights_t2_fp32.npz
# 通用三方差分器（任意样例+输入文件+三通道）
python3 pipeline/diff3.py --native native_bin --orig ref_prot --mine my_prot --inputs inputs.txt
```

## 当前能力状态（v3 基础上融合 v0.1-antidebug + v0.1.1-antidebug-bal 守卫层，全量回归通过）

- **单函数 & 多函数**（`--functions f1 f2 ...` 或 `--functions @funcs.txt`）均支持
- 已验证：8 个历史样例从零重保护、230/230 输入行为差分零失败
  （t2/arith/shifts/loops/multi/hello/hashmix/33 函数真实 harness，见 FULL_REGRESSION.md 摘要）
- 权重组装容量无上限（构造性拟合，任意步数计划）
- **内建守护（CHAMELEON + BLA 六泳道，默认全开）**：anti-emu（cpuid 双读 XOR
  折叠）/ integrity（分布式互证守卫）/ deny-attach（TracerPid 反调试，命中
  exit 173）/ churn（影子堆搅动，防内存差分）/ opaque（数论不透明谓词）/
  ai-decoy（ELF 拖车诱饵，仅 ELF 产物）；`--guards ""` 关闭；
  `--stub-tu --link-mode objects` 平铺 stub 形态下经 `_context_create` 钩子
  生效（guard.o/guard_sc.o 随 .o 产出，供 wbp `ld -T stub.lds` 接管；
  ai-decoy 对平铺 stub 不适用，自动跳过）。细节见 docs/CAPABILITIES.md §7
- **arp 泳道（anti-reverse-prompt v0.1，opt-in）**：声明式守卫（emit 契约）
  ——`--guards ...,arp` 在文件（ARPNOTC1 拖车 + .rodata 双语声明）/内存
  （CANON 潜码表烤入 owner TU → NN decode walk 物化 __sdk_arp_buf——guard
  受 NN 保护）/stderr（证据命中发射 TRUSTED_ACCESS_REQUIRED 帧）三通道植入
  拒绝逆向声明；干净运行零输出、绝不 exit/写 stdout；libc-free（-nostdlib
  兼容）；配 `--arp-owner <真实权利人>`/`--arp-notice <自定义文本>`。
  设计/验收：anti-reverse-prompt_v0.0.md + CAPABILITIES §7c
  （tests/test_arp.py 47 项 + verify_guards.py V8a-V8perf）
- 环境要求：Python3+numpy；编译需 Linux x86-64 + clang/LLVM 22.x（Docker 用法见下）
- **xor-mask 泳道（circuit-under-NN，默认关）**：AntiReverse circuit_v1 的 XOR
  秘密共享混淆方法移植到**计划层**——`--guards ...xor-mask`（配 `--xor-shares
  2|4|8` / `--xor-arith fold|masked` / `--xor-functions`）在 plan_compiler 之后
  把 module_plan 的数据值拆成 N 份 XOR share，整数运算改写为分享域构造
  （区域首拆分/末折叠、secure-AND（逐实例刷新掩码，改进 circuit_v1 的静态
  烘焙）/secure-OR/掩码 Kogge-Stone 加法器），**全部构造以普通计划步骤表达、
  由神经核心在潜空间执行**——circuit 混淆方法本身受到 NN 保护（对比 circuit_v1
  原生形态：share 代数以明文 C 代码发射）。fold 档（默认）对 ADD/SUB/比较折叠
  输入再拆分（wbp 27 函数实测 ×1.64 步数、35.3MB stub、e2e 输出逐字节一致）；
  masked 档为全 share 域掩码加法器（步数 ~×26，适合小样例：t2 实测 51/51 差分
  通过）。变换器内置差分验证器（随机输入逐区域比对 live-out + STORE，失败即
  中止构建）。掩码派生与 circuit_v1 一致（sha256(version\0seed\0label)），
  --guard-seed 复现。验证：`tests/test_circuit_share.py` 17/17；wbp-anansi-link
  `--guards ...xor-mask --xor-shares 2` 零改动接入（`--guards` 自由文本透传）
- **antireverse v0.2 双泳道（默认关，均蕴含 xor-mask）**：consumer_fused_v1 /
  stateful_v34 方法级融合（设计/验收 `antireverse_v0.2.md`）——
  `nonce-mask`：split/刷新掩码从构建期常量改为**运行期步骤值**（nonce =
  区域 integer live-in ∪ LOAD 输出惰性混合；掩码不再静态可提取，换输入→
  全新 share 形态；t2 实测 ×3.8 步，**wbp 21 函数实测 e2e 逐字节一致**）；
  `share-encode`：槽位驻留 share 以 per-share rot+salt+additive 独立编码
  （参数 seed 派生，对齐 v34 storage-plan；防御纵深，t2 实测 ×11.3 步，
  **wbp fast-list 实测 e2e 逐字节一致**，全档慎用）。单测
  `tests/test_nonce_share.py` 12/12；终验 verify_guards V9/V10/V10b

## 一分钟理解

被保护程序的控制流仍是原生代码；被选中区域的**整数计算**被移出 CPU，翻译成
"动作程序"（每步一个原子数据搬运/ALU 动作），由内嵌的神经 Controller
（q[64]+condition[32] → 189/204 头 → argmax）在 32 维 float 潜空间中用 17 种
宏基底（纹波进位加法/位运算/选择等）逐步重放。数值经神经 codec（字节↔32 维
潜码）进出边界。全程 fp16/fp32 浮点矩阵乘，无原生整数算术指令参与被保护区域。
